#ifndef INC_BOOTLOADER_H_
#define INC_BOOTLOADER_H_

/* These are just the externally visible items for the bootloader.  For       */
/* #defines, etc, that are common between Bootloader.c and Bootloader2.c, see */
/* BootloaderCom.h.                                                           */

/* This is the magic number that will activate a software update by the       */
/* bootloader on reboot.                                                      */
#define BOOTLOADER_MAGICNUM 0x4d62a3b9

extern void Bootloader(void) ;

/* The pre-HAL QSPI Setup code uses some calls from the bootloader code.      */
extern void ConfigGpio(void) ;
extern void ConfigQspi(void) ;
extern void ReConfigQspi(void) ;
extern void BL_QSPINOR_Init(int) ;
extern void BL_QSPINOR_Cmd(uint8_t,uint32_t,uint32_t) ;
extern void BL_QSPINOR_WrDat (uint8_t,int,uint8_t*) ;
extern void SW_msDelay(int) ;
extern void BL_QSPINOR_SetupXIP(void) ;

#endif /* INC_BOOTLOADER_H_ */
