#ifndef INC_ITCMSETUP_H_
#define INC_ITCMSETUP_H_

void ITCM_Setup(void) ;
void ITCM_Verify(void) ;

#endif /* INC_ITCMSETUP_H_ */
