#ifndef INC_TTONE_H_
#define INC_TTONE_H_

extern char* cmd_ttone_cmd ;
extern char* cmd_ttone_help ;

extern int  Cmd_ttone(int, char**) ;

#endif /* INC_TTONE_H_ */
