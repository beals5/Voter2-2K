/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Rx_DSP file.  It is in charge of all the Receive DSP functions.*/
/* These routines get passed a packets worth of raw audio samples from the    */
/* ADC routines and create the "cooked" packets of samples for the DIALTask   */
/* to compress and send over Ethernet.                                        */
/* With Voter support the audio packet size must be 160 samples, if Voting is */
/* disabled, it can be variable.                                              */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Rx_FilterInit - Initialize Rx DSP filters                               */
/*  - Rx_EnqPacket - Processed and enqueues a packet of audio samples.        */
/*                                                                            */
/******************************************************************************/
// TO DO:
//  - DeEmphasis and the voice filter attenuate a lot!
//  - Optimize RSSI RMS math once it is verified functional (sqrt and uint64_t)
//  - Need to reset filter (line 166) when changing between local and dial modes

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h> /* for memcpy */

#include "Options.h"
#include "main.h"
#include "Utils.h"
#include "Settings.h"
#include "SetShow.h"
#include "Gpio.h"
#include "AnalogIO.h"
#include "Rx_DSP.h"
#include "Tx_DSP.h"
#include "Gps.h"
#include "LocalMode.h"
#include "DialTask.h"
#include "VoiceFilter.h"
#include "RSSIFilter.h"
#include "Codecs.h"

#ifdef USE_CMSIS_DSP
#ifndef ARM_MATH_CM7
#define ARM_MATH_CM7
#endif
#ifndef _ARM_MATH_H
#include "arm_math.h"
#endif
#endif

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
/* Audio peak-peak levels for determining Rx LED color                        */
#define VINPP_MIN  1024 /* 1/4 scale is min (yellow-green transition)         */
#define VINPP_MAX  3840 /* 7/8 scale as overdrive (yellow-red transition)     */

/* RX LED state */
//#define RXLED_ON  true
//#define RXLED_OFF false

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/* For offline De-emphasis.  The default is off unless a local mode overrides */
/* it.  Note that each local mode has its own settings structure, so for code */
/* independence, this is the common setting each local mode must set.         */
int LocalDeemph = false ;

int16_t  Rx_ppbuf1[APKT_SAMPLES] IN_DTCM = {0} ; /* Rx Pingpong buffer 1      */
int16_t  Rx_ppbuf2[APKT_SAMPLES] IN_DTCM = {0} ; /* Rx Pingpong buffer 2      */
uint8_t  Hpf_RSSI                        =  0  ; /* High-pass filt RSSI value */
uint32_t Gui_hpf_RSSI                    =  0  ; /* HPF RSSI value for the GUI*/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
uint16_t VinPP = 0 ;
uint16_t VinPP_Max = 0 ;

#ifndef USE_CMSIS_DSP
static VoiceFilter vf = {0} ;
static RSSIFilter  rf = {0} ;
#else
static arm_fir_instance_q15 Voice_Instance                 = {0} ;
static q15_t Voice_Coefs[VOICEFILTER_TAP_NUM]              = {0} ;
static q15_t Voice_State[VOICEFILTER_TAP_NUM+APKT_SAMPLES] = {0} ;

/* Note that for the CMSIS DSP routines, there must be an even number of      */
/* Coefficients.  Since this filter has 23, I need an extra coefficient of 0  */
/* added to the end.                                                          */
static arm_fir_instance_q15 RSSI_Instance                  = {0} ;
static q15_t RSSI_Coefs[RSSIFILTER_TAP_NUM+1]              = {0} ;
static q15_t RSSI_State[RSSIFILTER_TAP_NUM+APKT_SAMPLES+1] = {0} ;

#endif

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void MakeSigned(uint16_t*,int16_t*) ;
static void DeEmphasis(int16_t*, int16_t*) ;
static void Voice_Filter(int16_t*,int16_t*) ;
static int  RSSI_Filter(int16_t*,int16_t*) ;
static int  Figger_RxActive(void) ;
static void Set_Rx_LED(int) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : Rx_FilterInit
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : Filter tables
*
* This routine initializes all the filters used on the receive path.  They get
* initialized on power-up and if we get a new flag byte from the DIAL server.
*******************************************************************************/
void Rx_FilterInit(void)
{
#ifndef USE_CMSIS_DSP
   VoiceFilter_init(&vf) ;
   RSSIFilter_init(&rf) ;
#else
   int i = 0 ;

   /* Examples say I need to reverse the filter taps - but aren't the         */
   /* coefs symmetric?                                                        */

   /* Pick the right voice filter depending on the DIAL Flag byte bit.        */
   /* Note that for the CMSIS DSP routines the choice of filter coefficients  */
   /* is made at initialization (here) versus for the T-Filter C routines the */
   /* choice of filter is made during data IO (in Voice_Filter()).            */
   if (DIAL_AUTHORIZED && DIAL_FLATAUDIO)
   {
      for (i=0;i<VOICEFILTER_TAP_NUM;i++) Voice_Coefs[i]=voice_filter_taps2[VOICEFILTER_TAP_NUM-i-1] ;
      arm_fir_init_q15(&Voice_Instance,VOICEFILTER_TAP_NUM,Voice_Coefs,Voice_State,APKT_SAMPLES) ;
   }
   else
   {
      for (i=0;i<VOICEFILTER_TAP_NUM;i++) Voice_Coefs[i]=voice_filter_taps1[VOICEFILTER_TAP_NUM-i-1] ;
      arm_fir_init_q15(&Voice_Instance,VOICEFILTER_TAP_NUM,Voice_Coefs,Voice_State,APKT_SAMPLES) ;
   }

   /* This filter has 23 real coefficients, but the CMSIS routines must have  */
   /* even number of coefficients.  Interestingly, you can't have a high pass */
   /* filter with an even number of coefficients--I tried.  Instead the CMSIS */
   /* suggestion is to simply add an extra 0 coefficient at the end, so adding*/
   /* 1 to the CMSIS tap array size and setting the last entry to 0.          */
   for (i=0;i<RSSIFILTER_TAP_NUM;i++) RSSI_Coefs[i]=rssi_filter_taps[RSSIFILTER_TAP_NUM-i-1] ;
   RSSI_Coefs[RSSIFILTER_TAP_NUM] = 0 ;
   arm_fir_init_q15(&RSSI_Instance,RSSIFILTER_TAP_NUM+1,RSSI_Coefs,RSSI_State,APKT_SAMPLES) ;
#endif
}

/*******************************************************************************
* Routine  : Rx_EnqPacket
* Gazintas : Rawdata - pointer to 16-bit audio samples (12 bits used)
*            Normally 160 samples)
* IOs      : None.
* Returns  : Nothing
* Globals  : Rx_Compressed - to AudioTask
*
* This routine is the common handler for a ping or pong buffers of a packets
* worth of audio samples.
* This is the supervisory routine to do all the work to filter, convert, and
* create a packet of data to be sent out.
*
* OPEN ISSUE: Data coming in is 12-bit unsigned audio samples (DAC values).
* The compression algos assume 16-bit signed samples.  Should I do all the DSP
* on 12-bit data then convert to 16-bit just for compression or do all the DSP
* on 16-bit data? I like less chance of overflows but might have better DSPing
* with more bits.  Going to go 16-bit for now.
*
* Execution time with C code: 224us max. (1.1% CPU load)
* Execution time with CMSIS:  138us max. (0.7% CPU load)
*   - It gets a bit complicated in local mode where some Tx code runs under the
*      Rx ISR.
*******************************************************************************/
void Rx_EnqPacket(uint16_t* RawData)
{
   /* As soon as possible after the interrupt as practical, get the timestamp.*/
   /* This will get used by the DIAL code later.                              */
   Get_GPSTime(&NewPktSecs,&NewPktNs) ;

   /* Find out if we're getting valid Rx audio (it's complicated) */
   Rx_Active = Figger_RxActive() ;

   /* *********************************************************************** */
   /* THIS IS THE MAIN RECEIVE DSP COMPUTATIONAL SEQUENCE!!  Here is where we */
   /* convert ADC samples into packets ready to be sent to the DIAL server    */
   /* and/or Local State Machine!                                             */
   /* *********************************************************************** */
   /* Inside each step I have ProbeCheck().  This allows the user to "probe"  */
   /* the audio signal after each step in the chain and see the results on    */
   /* DAC2.  What to probe is a CLI command.                                  */
   /* *********************************************************************** */

   MakeSigned  (RawData  ,Rx_ppbuf1) ; /* A2D format to DSP format            */
   RSSI_Filter (Rx_ppbuf1,Rx_ppbuf2) ; /* Above band (2400-4000Hz) frequencies*/
   DeEmphasis  (Rx_ppbuf1,Rx_ppbuf2) ; /* De-emphasis (optional)              */
   Voice_Filter(Rx_ppbuf2,Rx_ppbuf1) ; /* Only voice (300-2400Hz) frequencies */
   /* Coming Maybe?: CTCSS detector                                           */

   /* Update the Rx LED */
   Set_Rx_LED(Rx_Active) ;

   /* OK, all done DSPing, the data is ready to send to the DIAL server and   */
   /* local state machine.  Both state machines need to be called every       */
   /* packet regardless of if there is Rx Active or if we are in local or     */
   /* DIAL mode so they can maintain proper state values.  They use RX_Active */
   /* and DIAL_State to know what to do.                                      */
   /* Last pingpong buffer is Rx_ppbuf1, so tell Dialtask to use it.          */
#ifndef NODIALTASK
   /* Only enqueue data to the DIAL task if it is enabled.  If compiled for a */
   /* local mode only setup, then DIAL support won't exist.                   */
   Dial_Enqueue(DIALTASK_STREAMID_RXAUDIO,DIALTASK_BUFID_ADC1,APKT_SAMPLES) ;
#endif
   LocalModeSM(Rx_ppbuf1,DIAL_State,Rx_Active) ;

}

/*******************************************************************************
* Routine  : MakeSigned
* Gazintas : RawData - Audio samples in unsigned 12-bit offset format
* IOs      : SignedData - Audio samples in 16-bit signed format
* Returns  : Nothing
* Globals  : None
*
* This routine converts the raw A2D data which is 12-bit samples with "0V" at
* the middle of the A2D range into samples for the DSP routines which assume
* 16-bit signed data with 0V at 0.
* While here, I also determine the min and max values of the raw data coming
* in for the packet so we can report incoming signal volume.
*
* Execution time with C code: 10.4us.
* Execution time with CMSIS:     N/A
*******************************************************************************/
static void MakeSigned(uint16_t* RawData, int16_t* SignedData)
{
   int      i   =    0 ;
   uint16_t min = 2048 ;
   uint16_t max = 2048 ;

   for (i=0;i<APKT_SAMPLES;i++)
   {
      SignedData[i] = (int16_t)(((int32_t)(RawData[i])-2048)<<4) ;
      if (RawData[i] < min) min = RawData[i] ;
      if (RawData[i] > max) max = RawData[i] ;
   }

   /* Remember the Vin peak-peak voltage for Rx level calibration */
   VinPP = max - min ;

   /* This is for the levels status command.  It resets VinPP_Max each        */
   /* display cycle, then this below gets the max value until reset again.    */
   if (VinPP>VinPP_Max) VinPP_Max = VinPP ;

   /* Check for probing this output */
   ProbeCheck(SignedData,PROBE_RXIN,PROBE_AUDIO) ;
}

/*******************************************************************************
* Routine  : DeEmphasis
* Gazintas : in - Audio samples (Emphasized)
* IOs      : out - Audio samples (De-Emphasized)
* Returns  : Nothing
* Globals  : None
*
* This routine implements a 75us (2.1KHz cutoff frequency) De-emphasis filter.
* Pretty sure this is just implemented as a single order low pass filter.  I'm
* using the Z transform to calculate the coefficients.  This is the standard C
* implementation.  Given its simplicity, I'm not sure it is a good candidate
* for the CMSIS DSP libraries.  It's certainly lower priority.
* 
* Vout[n]=(a/1+a)*Vin[n] + (1/1+a)*Vout[n-1] where a = 2*pi*(fc/fs)
*
* fc = cutoff frequency = 2.1KHz
* fs = sample frequency = 8.0KHz
* a  = 1.649336115
* a/(1+a) = 0.622546953 or 0x4FAF in Q15 format
* 1/(1+a) = 0.377453047 or 0x3050 in Q15 format
*
* LOTS OF ASSUMPTIONS INTO THIS CODE!!!  It works observationally, but
* definitely needs quantitative verification!!!
* At a minimum, the baseline code severely attenuaed even the passband, so I've
* added a 2.5x "amplifier".
*
* De-Emphasis is normally on except if disabled by the DIAL server when
* authenticated or overridden in local mode.
*
* Execution time with C code:  5.00us.
* Execution time with CMSIS:      N/A.
*******************************************************************************/
static void DeEmphasis(int16_t* in, int16_t* out)
{
#define DE_EMPH_COEF_N   0x4faf
#define DE_EMPH_COEF_NM1 0x3050

   static int16_t last = 0x8000 ; /* Last sample from previous packet */
   int i = 0 ;

   if ((DIAL_NOTAUTHORIZED && LocalDeemph) || (DIAL_AUTHORIZED && (!DIAL_FLATAUDIO)))
   {
      /* First output sample uses last sample from previous frame */
      out[0] = (int16_t)((((int32_t)in[0]*DE_EMPH_COEF_N + (int32_t)last*DE_EMPH_COEF_NM1)>>16)) ;

      /* Rest of the samples in a loop */
      for (i=1;i<APKT_SAMPLES;i++)
      {
         out[i] = (int16_t)((((int32_t)in[i]*DE_EMPH_COEF_N + (int32_t)out[i-1]*DE_EMPH_COEF_NM1)>>16)) ;

         /* Now for the post-processing gain , currently 2.5 */
         out[i-1] = ((int32_t)out[i-1]*5)/2 ;
      }

      /* Finally save the last output coefficient for the next call */
      last = out[APKT_SAMPLES-1] ;

      /* ...and gain for the last sample */
      out[APKT_SAMPLES-1] = ((int32_t)out[APKT_SAMPLES-1]*5)/2 ;

   }
   else /* DeEmphasis not requested */
   {
	   memcpy(out,in,APKT_SAMPLES*2) ;
   }
   
   /* Check for probing */
   ProbeCheck(out,PROBE_RXDEM,PROBE_AUDIO) ;
}

/*******************************************************************************
* Routine  : Voice_Filter
* Gazintas : in - Audio samples (full spectrum)
* IOs      : out - Audio samples (voice frequencies only--maybe)
* Returns  : Nothing
* Globals  : None
*
* This routine implements either a 300Hz - 2400Hz bandpass filter or a 0-2400Hz
* bandpass filter depending on the "Do not filter sub-audible tones" bit in the
* DIAL Flags byte sent during authorization.  If we are in local mode, it is
* always 300-2400Hz.  The coefficients come from TFilter
* http://t-filter.engineerjs.com/
* VoiceFilter.c has their standard C implementation.  If using the CMSIS DSP
* library, all I use is the coefficients, not the code.
*
* This routine attenuates even in the passband too.  It needs an extra 1.5x
* "amplifier" afterwards.
*
* Execution time with C code: 125.0us.
* Execution time with CMSIS:   54.4us.
*******************************************************************************/
static void Voice_Filter(int16_t* in, int16_t* out)
{
#ifndef USE_CMSIS_DSP
   int i = 0 ;
   
   /* Pick the right voice filter depending on the DIAL Flag byte bit.        */
   /* Note that for the CMSIS DSP routines the choice of filter coefficients  */
   /* is made a initialization (above) versus for the T-Filter C routines the */
   /* choice of filter is made during data IO (just below)                    */

   /* The T-filter code uses put/get routines to add and pull samples from    */
   /* filter.  Do that for all samples in the packet.  That code keeps its    */
   /* state in static variables.                                              */
   for (i=0;i<APKT_SAMPLES;i++)
   {
      VoiceFilter_put(&vf,in[i]) ;
      if (DIAL_AUTHORIZED) && DIAL_FLATAUDIO)
      {
         out[i] = ((int32_t)VoiceFilter_get2(&vf)*3)/2 ;
      }
      else
      {
         out[i] = ((int32_t)VoiceFilter_get1(&vf)*3)/2 ;
      }
   }
#else
   arm_fir_q15(&Voice_Instance,in,out,APKT_SAMPLES) ;
#endif

   /* Check for probing */
   ProbeCheck(out,PROBE_RXVOICE,PROBE_AUDIO) ;
}

/*******************************************************************************
* Routine  : RSSI_Filter
* Gazintas : in - Audio samples (full spectrum)
* IOs      : out - identical RSSI values (for analog out monitoring)
* Returns  : RSSI value (0-255) (same as out samples above)
* Globals  : TBD
*
* This routine implements a 2400Hz - 4000Hz high pass filter, then does an
* energy measurement to get an RSSI value from 0-255.  The only reason for
* noise above 2400Hz is if the incoming signal is weak, so the higher the
* noise the lower the RSSI.
*
* Execution time with C code: 53.2us.
* Execution time with CMSIS:  27.4us.
*******************************************************************************/
static int RSSI_Filter(int16_t* in, int16_t* out)
{
   uint64_t rms_accum = 0 ; /* Accumulator for RMS value */
   int32_t cooked_rssi = 0 ;
   int i = 0 ;

#ifndef USE_CMSIS_DSP

   /* The T-filter code uses put/get routines to add and pull samples from    */
   /* filter.  Do that for all samples in the packet.  That code keeps its    */
   /* state in static variables.                                              */
   for (i=0;i<APKT_SAMPLES;i++)
   {
      RSSIFilter_put(&rf,in[i]) ;
      out[i] = RSSIFilter_get(&rf) ;
      rms_accum += out[i]*out[i] ;
   }
#else
   arm_fir_q15(&RSSI_Instance,in,out,APKT_SAMPLES) ;
   for (i=0;i<APKT_SAMPLES;i++) rms_accum += out[i]*out[i] ;
#endif

   /* This is just for bring-up */
   /* NOTE: not sure sqrt() is a good idea, it's floating point! check time!! */
   rms_accum = sqrt(rms_accum/APKT_SAMPLES) ;
   cooked_rssi = 255 - (rms_accum/13) ; /* derived entirely empirically! */

   /* Bounds check this as it's noisy and save the result as the official RSSI*/
   if (cooked_rssi <  0) cooked_rssi = 0 ;
   if (cooked_rssi >255) cooked_rssi = 255 ;
   Hpf_RSSI = cooked_rssi ;

   /* This is for the mainapp logging display, show the highest signal        */
   /* strength noted for the 1-second period.  mainapp resets it.             */
   if (Gui_hpf_RSSI<rms_accum) Gui_hpf_RSSI = rms_accum ;

   /* Check for probing of the RSSI signal */
   ProbeCheck(out,PROBE_RSSSIG,PROBE_AUDIO) ;

   /* If we're probing the RSSI level instead of the raw signal, copy the     */
   /* RSSI value into the entire packet for the DAC. This way the debug DAC   */
   /* output will show the RSSI level for the given audio packet.             */
   /* The RSSI value is multipled by 16 go get a 0-4096 range for the DAC.    */
   if (PROBE_RSSLVL==AnalogProbe)
   {
      for (i=0;i<APKT_SAMPLES;i++) out[i] =  cooked_rssi*16 ;
      ProbeCheck(out,PROBE_RSSLVL,PROBE_RAW) ;

   }
   /* Debugging, just ignore all of above and return a fixed value! :) */
   return (128) ;
}

/*******************************************************************************
* Routine  : Figger_RxActive
* Gazintas : None (GPIO's sampled)
* IOs      : None
* Returns  : true if RX is active
* Globals  : Settings
*
* This routine looks at the COR (valid carrier) and RDSTAT (valid CTCSS) GPIO
* inputs and based on the RxMode setting, determines if Rx is active.
* This may get more complicated with RSSI processing as well at some point.
*******************************************************************************/
static int  Figger_RxActive(void)
{
   int retval = false ;

   switch (Settings.RxMode)
   {
      case RXMODE_OFF  : retval = false                        ; break ;
      case RXMODE_COR  : retval = COR_State()                  ; break ;
      case RXMODE_CTCSS: retval = RDSTAT_State()               ; break ;
      case RXMODE_BOTH : retval = COR_State() & RDSTAT_State() ; break ;
      case RXMODE_ON   : retval = true                         ; break ;
      default          : retval = false                        ; break ;
   }

   return(retval) ;
}

/*******************************************************************************
* Routine  : Set_Rx_LED
* Gazintas : Cor - Carrier Operated Relay (Got a carrier (and CTCSS tone?))
* IOs      : None
* Returns  : Nothing
* Globals  : VinPP - DAC input Peak-Peak voltage (0-4096 scale)
*
* This routine sets the Rx LED according to the following logic:
*  - COR false                               : LED off    (no valid carrier)
*  - COR true, Vpp < VINPP_MIN               : LED Yellow (carrier, low audio)
*  - COR true, VINPP_MIN < VinPP < VINPP_MAX : LED Green  (carrier, good audio)
*  - COR true, Vpp > VINPP_MAX               : LED Red    (carrier, overdriving audio)
*******************************************************************************/
static void Set_Rx_LED(int RxActive)
{
   int color          = RSSI_NOSIG ; /* Default   */
   static int LastCol = RSSI_NOSIG ; /* Save last */

        if (RxActive && (VinPP < VINPP_MIN)) color = RSSI_LOW ;
   else if (RxActive && (VinPP > VINPP_MAX)) color = RSSI_HIGH ;
   else if (RxActive) color = RSSI_GOOD ;

   /* Only write a new color if it is different from the previous colors.     */
   /* Just save lots of IO writes and probably noise.  This also allows the   */
   /* startup blinky light sequence to work.                                  */
   if (LastCol!=color) Show_State(RSSI_STATE,color) ;
   LastCol = color ;
}

