/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/* ************************************************************************** */
/* This is the UartIO file.  It is in charge of the UART "FinishInit"         */
/* routines and the shared ISR callbacks for the UARTs.  For the callbacks,   */
/* we just take the common interrupt that is for any UART and based on the    */
/* UART handle, vector to that code in that source file for actual handling.  */
/* The following UARTS are defined:                                           */
/*  - USART1 - Debug interface                                                */
/*  - USART3 - GPS Comms                                                      */
/*  - UART4  - "Spare" for Dave M (just test code for now)                    */
/*  - UART7  - Repeater Command/Control                                       */
/*  - UART8  - Console (via FTDi230)                                          */
/*                                                                            */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - UART1s FinishInit is part of the Logger2r source                        */
/*  - My_UART3_FinishInit - GPS UART                                          */
/*  - My_UART7_FinishInit - Repeater UART                                     */
/*  - My_UART8_FinishInit - Console UART                                      */
/* Public-ish routines are: (__weak overrides)                                */
/*  - HAL_UART_TxCpltCallback - Callback for UART Tx                          */
/*  - HAL_UART_RxCpltCallback - Callback for UART Rx                          */
/*                                                                            */
/******************************************************************************/
// TO DO:
// Check for extraneous interrupts!

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "Options.h"
#include "main.h"
#include "Settings.h"
#include "logger2rt.h"
#include "ConsoleTask.h"
#include "Ser2NetTask.h"
#include "GPS.h"
#include "xuart.h"

/* Not sure why these are not in something like main.h, but ST-generated code */
/* does it this way.  Copying their format without understanding why.         */
extern UART_HandleTypeDef huart1 ;
extern UART_HandleTypeDef huart3 ;
extern UART_HandleTypeDef huart4 ;
extern UART_HandleTypeDef huart7 ;
extern UART_HandleTypeDef huart8 ;

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : My_UART3_FinishInit
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : huart3
*
* This initializes the UART hardware for the GPS interface.  All GPS traffic is
* handled by interrupts, so this is the only call by mainline code.

*******************************************************************************/
void My_UART3_FinishInit(void)
{
   uint32_t RegVal = 0 ; /* Temporary register value for read/mod/write */

   /* The CubeMX-generated code in main.c has been disabled as I need to      */
   /* initialize the UART differently depending on the board rev and GPS      */
   /* module. Below is mods as needed to the CubeMX-generated code.           */

   /* Regression issue, a 0 value causes a driver run-time exception.         */
   /* If there is a 0 value for some reason, override it.                     */
   if (0==Settings.GPS_Baud) Settings.GPS_Baud=4800 ;

   huart3.Instance = USART3;
   huart3.Init.BaudRate = Settings.GPS_Baud;
   huart3.Init.WordLength = UART_WORDLENGTH_8B;
   huart3.Init.StopBits = UART_STOPBITS_1;
   huart3.Init.Parity = UART_PARITY_NONE;
   huart3.Init.Mode = UART_MODE_TX_RX;
   huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
   huart3.Init.OverSampling = UART_OVERSAMPLING_16;
   huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
   huart3.Init.ClockPrescaler = UART_PRESCALER_DIV1;
#if PCBREV == V2_2K_100
   /* The Rev 1.00 board had Rx and Tx swapped */
   huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_SWAP_INIT;
   huart3.AdvancedInit.Swap = UART_ADVFEATURE_SWAP_ENABLE;
#endif
   if (HAL_UART_Init(&huart3) != HAL_OK)
   {
     Error_Handler();
   }
   if (HAL_UARTEx_SetTxFifoThreshold(&huart3, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
   {
     Error_Handler();
   }
   if (HAL_UARTEx_SetRxFifoThreshold(&huart3, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
   {
     Error_Handler();
   }
   if (HAL_UARTEx_DisableFifoMode(&huart3) != HAL_OK)
   {
     Error_Handler();
   }

   /* The GPS was probably sending data even before the UART was enabled, so  */
   /* we have a bit of a mess that needs cleaning up.                         */
   /* Start by disabling the UART, clear any/all flags, set up the            */
   /* interrupts and DMA, then finally re-enable the UART.                    */
   __HAL_UART_DISABLE(&huart3) ;

   /* I can't find any HAL routines to set up what the register manual calls  */
   /* Modbus/ASCII mode which is basically to enable an interrupt on a        */
   /* specific character.  So, just doing it manually.                        */
   /* The character is an LF of the CR/LF at the end of an NMEA sentence.     */
   RegVal = huart3.Instance->CR2 ; /* Current CR2 value    */
   RegVal = RegVal & 0x00ffffff  ; /* Mask off ADD bits    */
   RegVal = RegVal | (0x0a<<24)  ; /* Put LF into ADD bits */
   huart3.Instance->CR2 = RegVal ; /* Modified value back  */

   /* Clear out any error flags or character match from before       */
   __HAL_UART_CLEAR_IT(&huart3,UART_CLEAR_PEF)  ; /* Parity Error    */
   __HAL_UART_CLEAR_IT(&huart3,UART_CLEAR_FEF)  ; /* Framing error   */
   __HAL_UART_CLEAR_IT(&huart3,UART_CLEAR_NEF)  ; /* Noise error     */
   __HAL_UART_CLEAR_IT(&huart3,UART_CLEAR_OREF) ; /* Overrun Error   */
   __HAL_UART_CLEAR_IT(&huart3,UART_CLEAR_CMF)  ; /* Character match */
   __HAL_UART_CLEAR_IT(&huart3,0x00001000)      ; /* EndofBuffer Error (no #define for this???) */

   /* Enable the interrupts we want, character match and any comms errors */
   __HAL_UART_ENABLE_IT(&huart3,UART_IT_CM) ;
   __HAL_UART_ENABLE_IT(&huart3,UART_IT_PE) ;
   __HAL_UART_ENABLE_IT(&huart3,UART_IT_ERR) ;

   /* Enable DMA for USART3 Rx! */
   HAL_UART_Receive_DMA (&huart3,GPSRx_buf,GPS_RX_BUFSIZE) ;

   /* OK, should be set.  With the GPS likely still sending data the odds    */
   /* are good we'll still get some initial startup errors.  We'll just toss */
   /* any invalid data until we get good NMEA sentences.                     */
   __HAL_UART_ENABLE(&huart3) ;
}

/*******************************************************************************
* Routine  : My_UART7_FinishInit
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : huart7, RPTR_UART_RxChar
*
* This initializes the UART for the Repeaters Ser2Net interface.  IO is a
* Circular DMA buffer for Rx, "regular" DMA for Tx.
*******************************************************************************/
void My_UART7_FinishInit(void)
{
   /* Enable Circular DMA for USART7 Rx! */
   HAL_UART_Receive_DMA (&huart7,S2NRx_buf,S2N_RX_BUFSIZE) ;

   /* Nothing needed to "FinishInit" for the Tx DMA */
}


/*******************************************************************************
* Routine  : My_UART8_FinishInit
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : huart8, RxChar
*
* This initializes the UART for the Console interface.  IO is character-by
* character interrupt for Rx, line DMA for Tx.
* This initializes the UART for the Console interface.  IO is character-by-
* character interrupt for Rx, DMA for Tx.
* The HAL routines for interrupt IO are awful heavy, supporting arbitrary sized
* buffer filling using interrupts. This is way overkill for me, just needing a
* simple per-character interrupt for me to process that character.
* If UART8_HALIRQ_BYPASS is defined, I still use the HAL to set up interrupt-
* based Rx, but in the IRQ routine just handle that interrupt myself directly
* rather than letting the HAL deal with it, "stealing" the interrupt.
*******************************************************************************/
void My_UART8_FinishInit(void)
{
   /* Set up the interrupt to get a character.  It will be plunked in         */
   /* UART_RxChar.  Note that this call terminates after the single byte,     */
   /* since I want to process each byte, I need to re-call this HAL routine   */
   /* again after each byte.                                                  */
   HAL_UART_Receive_IT(&huart8,&UART_RxChar,1) ;

   /* Nothing needed to "FinishInit" for the Tx DMA */
}

/*******************************************************************************
* Routine  : HAL_UART_TxCpltCallback
* Gazintas : huart - structure pointer
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This is the general routine for UART Tx complete callback.
* Determine which UART and go to that routines UART Complete handler.
*  - For UART1 (Debug) this is at the end of a DMA for an entire message.
*  - For UART3 (GPS) Tx is not currently used.
*  - For UART4 (xuart) this is at the end of a DMA for an entire message.
*  - For UART7 (Repeater) this is at the end of a DMA for an entire message.
*  - For UART8 (Console) this is at the end of a DMA for an entire message.
*******************************************************************************/
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
   if (&huart1 == huart) Logger2TxComplete() ;
   if (&huart4 == huart) XUARTTxComplete() ;
   if (&huart7 == huart) S2NUARTTxComplete() ;
   if (&huart8 == huart) ConUARTTxComplete() ;
}

/*******************************************************************************
* Routine  : HAL_UART_RxCpltCallback
* Gazintas : huart - structure pointer
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This is the general routine for UART Rx complete callback.
* Determine which UART and go to that routines UART Complete handler.
*  - For UART1 (Debug) Rx is not used
*  - For UART3 (GPS) Rx data is just DMAd to a circular buffer, so no action
*    here
*  - For UART4 (xuart) this is at the end of a DMA for an entire message.
*  - For UART7 (Repeater) Rx data is just DMAd to a circular buffer, so no
*    action here
*  - For UART8 (Console) character-by-character interrupt
*******************************************************************************/
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
   if (&huart4 == huart) XUARTRxComplete() ;
   if (&huart8 == huart) ConUARTRxComplete() ;
}
