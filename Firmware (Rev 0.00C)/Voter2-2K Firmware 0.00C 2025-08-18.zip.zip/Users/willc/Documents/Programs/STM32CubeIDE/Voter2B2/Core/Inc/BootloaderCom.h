#ifndef INC_BOOTLOADERCOM_H_
#define INC_BOOTLOADERCOM_H_

extern void I_Bootloader2(void) ;

/* These are the common definitions and such for the two Bootloader source    */
/* files.  They are in a separate header file as I want them only included    */
/* in the Bootloader source files and not in other files.                     */

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
#define VERIFY_ERASE_PROG /* Enable verification of erase and programming */

#define CS_INACTIVE 0
#define CS_ACTIVE 1

#define QSPI_FSIZE  21 /* Flash address size -1, so 22 bits for 4MBit */
#define ITCMSIZE 0x10000 /* ITCM size in bytes */

#define QPSIS_SPISTART 0x00000000 /* SPI  starting addr for QPSI flash */
#define QSPIS_SIZE     0x001e0000 /* QSPI buffer size                  */
#define QPSIS_DSTSTART 0x00000000 /* QSPI Starting addr for QPSI flash */

#define STMS_SPISTART  0x001e0000 /* SPI   starting addr for STM flash */
#define STMS_SPIEND    0x001fffff /* SPI   ending   addr for STM flash */
#define STMS_DSTSTART  0x08000000 /* flash starting addr for STM flash */
#define STMS_DSTEND    0x0801ffff /* flash ending   addr for STM flash */
#define STMS_SIZE      0x001fffff /* STM flash size                    */

#define FLASH_WORDLENW  8 /* STM32 Flash programming block size (in words) */
#define FLASH_WORDLENB 32 /* STM32 Flash programming block size (in bytes) */
#define QSPI_BLKLENB  256 /* QSPI  Flash programming block size (in bytes) */

typedef enum
{
   SPINOR_UNKNOWN = 0,
   SPINOR_MX25L3233,
   SPINOR_MX25L25645
} SPINOR_TYPES ;

/* The bit definitions in stm32h750xx.h are a bit lacking for fields that are */
/* multiple bits, just defining the individual bits--ick. The #include for    */
/* HAL routines are more useful, but alas not including any HAL includes, so  */
/* doing this manually here.                                                  */

#define QSPI_IMODE_1BIT  (QUADSPI_CCR_IMODE_0) /* 0x0100 */

#define QSPI_FCR_ALLBITS 0x001b /* Clear all status bits */

#define QSPI_ADDRSIZE_8  (0x0000                                     ) /* 0x0000 */
#define QSPI_ADDRSIZE_16 (                       QUADSPI_CCR_ADSIZE_0) /* 0x1000 */
#define QSPI_ADDRSIZE_24 (QUADSPI_CCR_ADSIZE_1                       ) /* 0x2000 */
#define QSPI_ADDRSIZE_32 (QUADSPI_CCR_ADSIZE_1 | QUADSPI_CCR_ADSIZE_0) /* 0x3000 */

#define QSPI_FMODE_WRITE (0x00000000                               ) /* 0x00000000 */
#define QSPI_FMODE_READ  (                      QUADSPI_CCR_FMODE_0) /* 0x04000000 */
#define QSPI_FMODE_POLL  (QUADSPI_CCR_FMODE_1                      ) /* 0x08000000 */
#define QSPI_FMODE_MMAP  (QUADSPI_CCR_FMODE_1 | QUADSPI_CCR_FMODE_0) /* 0x0c000000 */

#define QSPI_DMODE_NONE (0x00000000                               ) /* 0x00000000 */
#define QSPI_DMODE_1BIT (                      QUADSPI_CCR_DMODE_0) /* 0x01000000 */
#define QSPI_DMODE_2BIT (QUADSPI_CCR_DMODE_1                      ) /* 0x02000000 */
#define QSPI_DMODE_4BIT (QUADSPI_CCR_DMODE_1 | QUADSPI_CCR_DMODE_0) /* 0x03000000 */

#define QSPI_ADMODE_NONE (0x00000000                                 ) /* 0x00000000 */
#define QSPI_ADMODE_1BIT (                       QUADSPI_CCR_ADMODE_0) /* 0x00000400 */
#define QSPI_ADMODE_2BIT (QUADSPI_CCR_ADMODE_1                       ) /* 0x00000800 */
#define QSPI_ADMODE_4BIT (QUADSPI_CCR_ADMODE_1 | QUADSPI_CCR_ADMODE_0) /* 0x00000c00 */

#define FLASH_KEY1 0x45670123
#define FLASH_KEY2 0xcdef89ab

#endif /* INC_BOOTLOADERCOM_H_ */
