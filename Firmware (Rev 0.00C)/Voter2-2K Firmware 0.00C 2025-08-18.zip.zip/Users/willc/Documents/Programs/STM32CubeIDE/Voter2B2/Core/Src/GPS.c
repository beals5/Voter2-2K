/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the GPS file.  It is in charge of accepting the NMEA sentences and */
/* 1PPS signal from the GPS receiver, then processing them as needed.  This   */
/* code does not call any other code!  Rather it stores the last NMEA time    */
/* and TIM2 count value of the active 1PPS signal.  Code in DialTask calls    */
/* Get_GPSTime() that reads the last GPS time and the current TIM2 count      */
/* value to determine the packets timestamp.  Incoming info comes from:       */
/*  - NMEA sentences come in on USART3.                                       */
/*  - 1PPS comes in on TIM2.                                                  */
/* HOW IT WORKS:                                                              */
/*  - 1PPS, is fed to a capture register on TIM2 (the 32-bit timer) counting  */
/* at 40MHz (overkill!) to get the timestamp of the 1PPS.  That edge also     */
/* generates an interrupt so the timestamp can be processed.                  */
/* - NMEA sentences come in USART3 and are fed to circular DMA buffer.  The   */
/* UART generates an interrupt on reception of an LF so I get just one        */
/* interrupt at the end of each NMEA sentence to parse it.                    */
/******************************************************************************/
/* Public routines are:                                                       */
/*  - MY_TIM2_Svc - Timer2 ISR                                                */
/*  - MY_UART3_Svc - LF interrupt from UART3                                  */
/*  - Get_GPSTime - Get timestamp (super-accurate version)                    */
/******************************************************************************/
/* Details about each GPS module I've look at so far:                         */
/* MODULE        BAUD RATE 1PPS ACTIVE EDGE DATA-EDGE                         */
/* ============= ========= ================ =============================     */
/* uBlox MN8         9,600 RISING           Data is for previous edge         */
/* ST Teso LIV4F   115,200 RISING           Data is for previous edge         */
/*                                                                            */
/******************************************************************************/
// To Do:
//  - The UART startup is messy, is there something cleaner?

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>
#include <ctype.h>
#include <time.h>

#include "cmsis_os.h"

#include "main.h"
#include "Options.h"
#include "Settings.h"
#include "logger2rt.h"
#include "GPS.h"
#include "Timers.h"
#include "Utils.h"

/******************************************************************************/
/* Local defines (using enums)                                                */
/******************************************************************************/

#define CHECKSUM_OK 0
#define CHECKSUM_BAD 1

#define PARAMSTRLEN 32 /* GPS parameter text (long, lat mostly) */

/* GPS Sentences I care about (rest are ignored) */
#define GPS_GNRMC_SENTENCE 1
#define GPS_GNGGA_SENTENCE 2
#define GPS_GPGSV_SENTENCE 3

/* Timer 2 important constants: for counting at 40MHz (sysclk/6). */
/* Sysclk/6 was picked as it is the smallest divider that yields  */
/* an integer number of ns/tick (25).                             */
#define TIM2_TICKS_PER_SEC 40000000
#define TIM2_NS_PER_TICK 25

/******************************************************************************/
/*  typedefs                                                                  */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
GPS_STRUCT GPSData     = {0}   ; /* The necessary stuff      */
SAT_STATUS SatStatus   = {0}   ; /* The informational stuff  */
uint32_t   GPS_TimeSec =  0    ; /* Last GPS time (Unix fmt) */
uint32_t   GPS_TimeCap =  0    ; /* TIM2 1PPS Capture value  */

/* The DMAd circular buffer) */
uint8_t GPSRx_buf[GPS_RX_BUFSIZE] IN_DMADD2 ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TOKENLIST GPS_Sentences[] =
{
   {"$GNRMC" ,GPS_GNRMC_SENTENCE},
   {"$GNGGA" ,GPS_GNGGA_SENTENCE},
   {"$GPGSV" ,GPS_GPGSV_SENTENCE},
   {NULL     ,0                 }
} ;

static uint32_t GPS_QdTimeSec = 0 ; /* Last GPS time (Unix fmt) before 1 PPS */

/* Statistics on GPS sentence types parsed */
static int tstat[5] = {0} ;

/******************************************************************************/
/* External globals. How CubeMX does things instead of in an include file,    */
/* weird.                                                                     */
/******************************************************************************/
extern TIM_HandleTypeDef htim2 ;
extern UART_HandleTypeDef huart3 ;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static int  ParseGPSSentence(char*) ;
static void Parse_GNRMC(char*,int*) ;
static void Parse_GNGGA(char*,int*) ;
static void Parse_GPGSV(char*,int*) ;
static void Parse_GPS_Num(char*,int*,int*,int*,int*) ;
static void Parse_GPS_Text(char*,int*,char*,int,int*,int*) ;
static int  Check_GPSChecksum(char*) ;

/******************************************************************************/
/* Local routines (finally!)                                                  */
/******************************************************************************/

/*******************************************************************************
* Routine  : GPS_1PPS_Handler
* Gazintas : Count - TIM2 counter value on active edge of GPS's 1PPS
*          : Delta - Delta in ticks from last GPS 1PPS.
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* The active edge of the GPS's 1PPS signal is *the* time as send out by all
* the GPS sentences via the UART. Report it if is weird, it should be 40
* million plus or minus a little and then save the counter value.  That way
* any other code can determine the exact time by looking at how many TIM2 ticks
* there have been since the GPS 1PPS edge.
*
* I need to do some error checking on the NMEA sentences coming from the GPS,
* comms can get messed up on startup.  That checking is done here.
*******************************************************************************/
void GPS_1PPS_Handler(uint32_t Count, int32_t Delta)
{
   uint32_t        IsrReg    = 0 ; /* Interrupt status register     */

   /* For accurate packet timing, make time in Unix format we got via the  */
   /* UART I/F now "Live" and save the TIM2 capture value at the active    */
   /* edge of the 1PPS signal.  That way "real time" is the live Unix time */
   /* value plus whatever time has elapsed between the 1PPS edge time and  */
   /* "now".                                                               */
   GPS_TimeSec = GPS_QdTimeSec ;
   GPS_TimeCap = Count ;

   /* Lots of debug messaging here if requested */
   if ((Delta<(TIM2_FREQ-TIM2_ERRB))||(Delta>(TIM2_FREQ+TIM2_ERRB)))
   {
      Logger2_IRQMsg(Logger.GPS,LOG_MAJOR,LOG_TIME,0x01000000,"GPS Delta OOB! %d\r\n",Delta) ;
   }
   Logger2_IRQMsg(Logger.GPS,LOG_REGIO,LOG_TIME,0x01000000,"GPS Tim2 IRQ : CC1 = %u delta %d\r\n",Count,Delta) ;
   Logger2_IRQMsg(Logger.GPS,LOG_REGIO,LOG_TIME,0x01000000,"GPS Data: %2.2d/%2.2d/%2.2d %2.2d:%2.2d:%2.2d.%3.3d UT: %u\r\n",
         GPSData.UTC_Year,GPSData.UTC_Month,GPSData.UTC_Day,
         GPSData.UTC_Hour,GPSData.UTC_Min,GPSData.UTC_Sec,GPSData.UTC_mSec,GPS_TimeSec) ;
   Logger2_IRQMsg(Logger.GPS,LOG_REGIO,LOG_TIME,0x01000000,"GPS Data: %s%c %s%c Alt:%d St:%c\r\n",
       GPSData.Longitude,GPSData.LongDir,GPSData.Latitude,GPSData.LatDir,GPSData.Altitude,GPSData.Status) ;

   Logger2_IRQMsg(Logger.GPS,LOG_SUPPORT,LOG_TIME,0x01000000,"GPS Data: OK %2d BS %2d BC %2d I %2d\r\n",
      tstat[0],tstat[1],tstat[2],tstat[3]) ;
   tstat[0] = tstat[1] = tstat[2] = tstat[3] = 0 ;


   /* Sometimes on startup there is UART Rx error which hangs up the DMA.  */
   /* If that happens, the UART RX Overflow flag gets set.  If we see that,*/
   /* re-start the DMA and clear flags.  This should only happen once on   */
   /* initial boot-up, but this is a convenient place to check and correct.*/
   IsrReg = huart3.Instance->ISR ;
   Logger2_IRQMsg(Logger.GPS,LOG_REGIO,LOG_TIME,0x01000000,"GPS ISR1 %8.8x\r\n",IsrReg) ;
   if (IsrReg&0x20)
   {
      Logger2_IRQMsg(Logger.GPS,LOG_SUPPORT,LOG_TIME,0x01000001,"GPS DMA restart\r\n") ;
      HAL_UART_Receive_DMA (&huart3,GPSRx_buf,GPS_RX_BUFSIZE) ;
      __HAL_UART_CLEAR_FLAG(&huart3,UART_CLEAR_PEF) ;
      __HAL_UART_CLEAR_FLAG(&huart3,UART_CLEAR_FEF) ;
      __HAL_UART_CLEAR_FLAG(&huart3,UART_CLEAR_NEF) ;
      __HAL_UART_CLEAR_FLAG(&huart3,UART_CLEAR_OREF) ;
   }
}

/*******************************************************************************
* Routine  : MY_UART3_Svc
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This handles the UART3 interrupt. Besides the CMIE (Character match interrupt
* enable) interrupt, I also enable error interrupts and just clear them out and
* go on.  If there is an error in the sentence it will be detected with the
* checksum.
*
* This code does assume the CPU responds to the interrupt before the next
* character arrives (I don't do any checking that the index no longer points
* to the LF that generated the interrupt). I have circular buffers, so if this
* is an issue, I can address it. At any baud rate I'm pretty sure I'm fine.
*******************************************************************************/
void MY_UART3_Svc(void)
{
   static int LastIndex = 0 ; /* End of last message     */
   int        ThisIndex = 0 ; /* End of current message  */
   int        CopyIndex = 0 ; /* Copying index           */
   int        Len       = 0 ; /* NMEA Sentence length    */
   int        i         = 0 ; /* General purpose counter */
   char       Sentence[MAX_SENTENCE_LEN] = {0} ; /* The NMEA Sentence */

   /* First clear the interrupt we hope we got */
   __HAL_UART_CLEAR_FLAG(&huart3,UART_CLEAR_CMF) ;

   /* Just pro-actively clear out any error interrupts if they happened */
   __HAL_UART_CLEAR_FLAG(&huart3,UART_CLEAR_PEF) ;
   __HAL_UART_CLEAR_FLAG(&huart3,UART_CLEAR_FEF) ;
   __HAL_UART_CLEAR_FLAG(&huart3,UART_CLEAR_NEF) ;
   __HAL_UART_CLEAR_FLAG(&huart3,UART_CLEAR_OREF) ;

   /* Data is being DMAd into a circular buffer. We have the end of the last  */
   /* message, get the end of the current message.                            */
   /* The DMA counter is bytes DMAd, so index is size-count.                  */
   ThisIndex = GPS_RX_BUFSIZE - __HAL_DMA_GET_COUNTER(huart3.hdmarx) ;
   /* The index actually points to the byte after the linefeed, so go back 1  */
   /* Fancy math to gracefully handle wraps.                                  */
   ThisIndex = (ThisIndex+GPS_RX_BUFSIZE-1)%GPS_RX_BUFSIZE ;
   /* Get the message length, with same fancy wraparound math.                */
   Len = (ThisIndex+GPS_RX_BUFSIZE-LastIndex)%GPS_RX_BUFSIZE ;

 //Logger2_IRQMsg(Logger.GPS,LOGGER2_GPSCODE,LOG_TIME,0x01000002,"GPS UART IDX %3d %3d %2.2x %2.2x %2.2x - ",
 //        ThisIndex,Len,GPSRx_buf[LastIndex-1],GPSRx_buf[LastIndex],GPSRx_buf[LastIndex+1]) ;
 //Logger2_IRQMsg(Logger.GPS,LOGGER2_GPSCODE,LOG_NOTIME,0x01000002,"%3d %3d %2.2x %2.2x %2.2x\r\n",
 //        ThisIndex,Len,GPSRx_buf[ThisIndex-1],GPSRx_buf[ThisIndex],GPSRx_buf[ThisIndex+1]) ;

   /* Ignore any too-short messages or something crazy-long.  If either       */
   /* extreme, then it was a comm  error of some kind.                        */
   if ((Len>7) && (Len<MAX_SENTENCE_LEN))
   {
      Len = Len - 2 ; /* Omit the trailing CR/LF */

      /* LastIndex was the LF of the last sentence, so +1 for first byte of   */
      /* the current sentence.                                                */
      /* Make a non-circularized copy of the sentence.                        */
      CopyIndex = (LastIndex+1)%GPS_RX_BUFSIZE ;
      for (i=0;i<Len;i++)
      {
         Sentence[i] = GPSRx_buf[CopyIndex] ;
         CopyIndex = (CopyIndex+1)%GPS_RX_BUFSIZE ;
      }

      Logger2_IRQMsg(Logger.GPS,LOG_REGIO,LOG_TIME,0x01000003,"GPS UART IRQ %3d-%3d (%3d) \"%s\"\r\n",LastIndex,ThisIndex,Len,Sentence) ; /* was %.6s */
      i = ParseGPSSentence(Sentence) ;

      /* Some temporary debugging info */
      if (GPS_SENT_OK     ==i) tstat[0]++ ;
      if (GPS_SENT_BADSTR ==i) tstat[1]++ ;
      if (GPS_SENT_BADSTR ==i) tstat[2]++ ;
      if (GPS_SENT_IGNORED==i) tstat[3]++ ;
   }

   /* All done, save the current EOS to be the index for the next message */
   LastIndex = ThisIndex ;
}

/*******************************************************************************
* Routine  : ParseGPSSentence
* Gazintas : line - GPS sentence
* IOs      : None
* Returns  : Nuthin
* Globals  : GPSData and SatStatus (indirectly)
*
* This is the top level routine to parse a GPS sentence and fill the GPSData
* and SatStatus structures with the parsed information.  This routine can get
* junk, so error checking is needed.  It currently recognizes these sentences:
*  - GNRMC - For Lat/Long, Date, and Time (needed). For Speed (informational).
*  - GNGGA - For Altitude (needed) and # of Sats and HDOP (informational)
*  - GPGSV - For Satellite specific data
* These three provide all the info I need and are supported by the Ublox and
* ST Teso GPS receivers.  I'll add other sentences if necessary when I look at
* other GPS receivers.  All other sentences can be safely ignored.
*******************************************************************************/
int ParseGPSSentence(char* line)
{
   int rval        = GPS_SENT_OK ; /* Return value    */
   int len         = 0           ; /* sentence length */
   int success     = true        ; /* Success flag    */
   int sentence    = 0           ; /* Sentence ID     */

   /* Check we have at least something to work with. */
   if (NULL==line) rval = GPS_SENT_BADSTR ;

   /* Get the length and it has to be at least long enough for the ID. */
   if (GPS_SENT_OK==rval)
   {
      len = strlen(line) ;
      if (len<7) rval = GPS_SENT_BADSTR ;
   }

   /* So far, so good, look for a checksum */
   /* For now, I'm assuming a checksum is mandatory.  The NMEA spec implies   */
   /* it is optional.                                                         */
   if (GPS_SENT_OK==rval)
   {
      if (Check_GPSChecksum(line)!=CHECKSUM_OK) rval = GPS_SENT_BADCHECK ;
   }

   /* With a valid checksum, we're good to parse! */
   /* A good checksum is pretty solid, so minimal checking after here */
   /* Look at the sentence ID.  Isolate it for parsing, then lookup   */
   if (GPS_SENT_OK==rval)
   {
      line[6] = 0 ; /* just the sentence ID */
      sentence = parse_token(GPS_Sentences,line,&success) ;

      /* Fire off the specific parser, if not a supported sentence, no big deal, */
      /* OK to ignore them. Note it is ignored though for logging.               */
      switch (sentence)
      {
         case GPS_GNRMC_SENTENCE: Parse_GNRMC(line+7,&success)    ; break ;
         case GPS_GNGGA_SENTENCE: Parse_GNGGA(line+7,&success)    ; break ;
         case GPS_GPGSV_SENTENCE: Parse_GPGSV(line+7,&success)    ; break ;
         default                : rval = GPS_SENT_IGNORED         ; break ;
      } ;
   }

   return(rval) ;
}

/*******************************************************************************
* Routine  : Check_GPSChecksum
* Gazintas : line - GPS sentence
* IOs      : None
* Returns  : Result code (pass or fail)
* Globals  : None
*
* This checks the integrity of a GPS NMEA sentence. It makes sure it starts
* with a $ character and computes the checksum up to the * character and
* verifies the checksum is good.  If anything is amiss it returns a failure.
* Previous checks already ensure this line is at least 7 chars long.
* **NOTE** Technically the checksum is optional, but it seems always there in
* in the GPS receivers I'm playing with, so no checksum will result in a fail.
*******************************************************************************/
static int Check_GPSChecksum(char* line)
{
   uint8_t MyChecksum  = 0    ; /* My computed checksum     */
   uint8_t GPSChecksum = 0    ; /* Checksum in GPS sentence */
   int     len         = 0    ; /* line length              */
   int     i           = 1    ; /* Character counter        */
   int     success     = true ; /* Success flag             */

   /* First check is the line must start wtih a $ */
   if (line[0]!='$') return (CHECKSUM_BAD) ;

   /* Now do the checksum up to the * character */
   len = strlen(line) ;
   while ((i<len) && (line[i]!='*')) MyChecksum ^= line[i++] ;

   /* If we didn't get a * before the end of the line, oops!                  */
   /* Also better have at least 2 chars after * for the checksum (CR/LF       */
   /* optional).                                                              */
   if (i>len-2) return (CHECKSUM_BAD) ;

   /* Get the checksum... */
   GPSChecksum = ReadHex(line+i+1,2,SOLOPARAM,&success) ;

   /* if a bad or inequal checksum, OOPS! */
   if((!success) || (MyChecksum != GPSChecksum)) return (CHECKSUM_BAD) ;

   /* If we failed to fail, then that must mean we succeeded! :) */
   return (CHECKSUM_OK) ;
}

/*******************************************************************************
* Routine  : Parse_GNRMC
* Gazintas : line - GPS sentence (after the sentence ID and comma)
* IOs      : success - Success flag
* Returns  : Nothing
* Globals  : GPSData - GPS data structure
*            SatStatus - Satellite status info (informational)
*
* This parses the NMEA GNRMC sentence.  Of the default sentences from the Ublox
* MN8, this sentence has everything except altitude to meet the minimum required
* data for the Voter2.  I parse and save all but the ground heading and magnetic
* declination information.
*******************************************************************************/
static void Parse_GNRMC(char* line,int* success)
{
   int index    = 0    ; /* line parsing index      */
   int intpart  = 0    ; /* parameter integer part  */
   int decpart  = 0    ; /* parameter decimal part  */
   int len      = 0    ; /* Text parameter length   */
   int lsuccess = true ; /* local success flag      */
   char str[PARAMSTRLEN] = {0}  ; /* parameter text */
   struct tm GPStime = {0} ;

   /* Just plunk through the parameters and save them away! */
   /* The getter routines update the index as we go along.  */

   /* UTC Time is in the format hhmmss.sss, so just pull them apart */
   Parse_GPS_Num(line,&index,&intpart,&decpart,&lsuccess) ;
   GPSData.UTC_Hour = (intpart/10000)     ;
   GPSData.UTC_Min  = (intpart/100  )%100 ;
   GPSData.UTC_Sec  = (intpart      )%100 ;
   GPSData.UTC_mSec = decpart             ;

   /* Status flag, a single character */
   Parse_GPS_Text(line,&index,str,PARAMSTRLEN,&len,&lsuccess) ;
   if (lsuccess && (1==len)) GPSData.Status = str[0] ; else *success = false ;

   /* next is the Latitude.  For Voter2, just keep it a string, don't need it */
   /* in a computable (numeric) format.                                       */
   Parse_GPS_Text(line,&index,GPSData.Latitude,COORDSTRLEN,&len,&lsuccess) ;
   Parse_GPS_Text(line,&index,str,PARAMSTRLEN,&len,&lsuccess) ;
   if (lsuccess && (1==len)) GPSData.LatDir = str[0] ; else *success = false ;

   /* next is the Longitude... */
   Parse_GPS_Text(line,&index,GPSData.Longitude,COORDSTRLEN,&len,&lsuccess) ;
   Parse_GPS_Text(line,&index,str,PARAMSTRLEN,&len,&lsuccess) ;
   if (lsuccess && (1==len)) GPSData.LongDir = str[0] ; else *success = false ;

   /* Next is ground speed.  I think default is knots and its decimal, so it */
   /* will be knots x10 for an integer value.  This isn't important data.    */
   /* Mainly saving in case anything much above 0 likely means bad GPS data. */
   Parse_GPS_Num(line,&index,&intpart,&decpart,&lsuccess) ;
   SatStatus.Speed = (intpart*10)+(decpart/10000) ;

   /* Skip the ground heading */
   Parse_GPS_Text(line,&index,str,PARAMSTRLEN,&len,&lsuccess) ;

   /* Last parameter I care about is UTC date.  It is in the format ddmmyy. */
   Parse_GPS_Num(line,&index,&intpart,&decpart,&lsuccess) ;
   GPSData.UTC_Day  = (intpart/10000)     ;
   GPSData.UTC_Month = (intpart/100  )%100 ;
   GPSData.UTC_Year  = (intpart      )%100 ;

   /* Don't care about the last two params, magnetic declination. */

   /* With all the data in UTC format, get it in Unix time.     */
   GPStime.tm_year  = GPSData.UTC_Year+100 ; /* 1900-based year */
   GPStime.tm_mon   = GPSData.UTC_Month-1  ; /* 0-based month   */
   GPStime.tm_mday  = GPSData.UTC_Day      ; /* 1-based day     */
   GPStime.tm_hour  = GPSData.UTC_Hour     ; /* "Normal"        */
   GPStime.tm_min   = GPSData.UTC_Min      ; /* "Normal"        */
   GPStime.tm_sec   = GPSData.UTC_Sec      ; /* "Normal"        */
   GPStime.tm_isdst = -1                   ; /* UTC, so no      */
   /* Rest of the items in the struct are not inputs (I hope)   */

   /* This is the "queued up" time.  It will become the actual time on the    */
   /* active edge of the next 1PPS signal.                                    */
   GPS_QdTimeSec = mktime(&GPStime) ;
}

/*******************************************************************************
* Routine  : Parse_GNGGA
* Gazintas : line - GPS sentence (after the sentence ID and comma)
* IOs      : success - Success flag
* Returns  : Nothing
* Globals  : GPSData - GPS data structure
*            SatStatus - Satellite status info (informational)
*
* This parses the NMEA GNGGA sentence.  This gets the missing (required)
* Altitude data plus the informational satellite count and HDOP.  It has
* lots of other fields I've already gotten from the $GNRMC sentence, so
* ignoring those here.
* **Note**.  For a GPS other than the Ublox or ST Teso, I may need to parse
* ore of the parameters in this block.
*******************************************************************************/
static void Parse_GNGGA(char* line,int* success)
{
   int i        = 0    ; /* General counter         */
   int index    = 0    ; /* line parsing index      */
   int intpart  = 0    ; /* parameter integer part  */
   int decpart  = 0    ; /* parameter decimal part  */
   int len      = 0    ; /* Text parameter length   */
   int lsuccess = true ; /* local success flag      */
   char str[PARAMSTRLEN] = {0}  ; /* parameter text */

   /* Skip the first 6 parameters (time, lat (2x) Long (2x) and Status. */
   for (i=0;i<6;i++) Parse_GPS_Text(line,&index,str,PARAMSTRLEN,&len,&lsuccess) ;

   /* Next is the number of satellites */
   Parse_GPS_Num(line,&index,&intpart,&decpart,&lsuccess) ;
   SatStatus.nSats = intpart ;

   /* Next is HDOP (Horizontal Dilution of Precision).  It is in meters and   */
   /* decimal so it will be meters x100 for an integer value.                 */
   Parse_GPS_Num(line,&index,&intpart,&decpart,&lsuccess) ;
   SatStatus.hdop = (intpart*100)+(decpart/1000) ;

   /* and the last value of interest is Altitude, just going to do integer    */
   /* meters, ignoring the decimal part since precision here isn't important. */
   Parse_GPS_Num(line,&index,&intpart,&decpart,&lsuccess) ;
   GPSData.Altitude = intpart ;
}

/*******************************************************************************
* Routine  : Parse_GPGSV
* Gazintas : line - GPS sentence (after the sentence ID and comma)
* IOs      : success - Success flag
* Returns  : Nothing
* Globals  : SatStatus - Satellite status info (informational)
*
* This parses the NMEA GPGSV sentence.  This gets the satellite status info,
* so is purely informational.  For each channel I save the satellite number and
* SNR, I don't bother saving As/El info.  I save up to MAXSATS channels, if
* there are more than that, I ignore them.
* This sentence is a bit tricky as each sentence only supports data for up to
* four satellites so there are multiple sentences with indexing in them.
*******************************************************************************/
static void Parse_GPGSV(char* line,int* success)
{
   int index    = 0    ; /* line parsing index      */
   int intpart  = 0    ; /* parameter integer part  */
   int decpart  = 0    ; /* parameter decimal part  */
   int lsuccess = true ; /* local success flag      */

   int nmsgs    = 0    ; /* numer of GSV messages  */
   int msgnum   = 0    ; /* GSV message number     */
   int nsats    = 0    ; /* Number of satellites   */
   int satidx   = 0    ; /* Satellite array index  */

   /* Get the Number of messages, current message numbers, and satellite count */
   Parse_GPS_Num(line,&index,&nmsgs ,&decpart,&lsuccess) ; /* Number of messages  */
   Parse_GPS_Num(line,&index,&msgnum,&decpart,&lsuccess) ; /* message number      */
   Parse_GPS_Num(line,&index,&nsats ,&decpart,&lsuccess) ; /* Number of satellies */
   SatStatus.nSats = nsats ; /* remember this parameter */

   /* Up to four sets of satellite data per message */
   for(satidx=(msgnum-1)*4;satidx<msgnum*4;satidx++)
   {
      if ((satidx<nsats) && (satidx<MAXSATS)) /* setting boundaries! :) */
      {
         Parse_GPS_Num(line,&index,&intpart,&decpart,&lsuccess) ; SatStatus.SatDat[satidx].SatNum = intpart ;
         Parse_GPS_Num(line,&index,&intpart,&decpart,&lsuccess) ; /* Toss elevation */
         Parse_GPS_Num(line,&index,&intpart,&decpart,&lsuccess) ; /* Toss azimuth   */
         Parse_GPS_Num(line,&index,&intpart,&decpart,&lsuccess) ; SatStatus.SatDat[satidx].SatSNR = intpart ;
      }
   }
}

/*******************************************************************************
* Routine  : Parse_GPS_Num
* Gazintas : line - GPS sentence (after the sentence ID and comma)
* IOs      : index - where in the line to start parsing
*          : intpart - integer part of the number parsed (before decimal point)
*          : decpart - decimal part of the number parsed (after decimal point)
*          : success - Success flag
* Returns  : Nothing
* Globals  : GPSData - None
*
* This parses a numeric parameter in an NMEA sentence. The number may have a
* decimal point, and if so, it goes into decpart as an integer.  I'm avoiding
* floating point for now.  The parsing goes up to the comma/asterisk separator.
* If the field is empty, 0.0 is returned.  If there is no decimal, decpart will
* be 0.  Decpart is parsed up to 5 digits and will be in 100,000ths for
* consistency.  If anything other than digits or a decimal show up, that's an
* error.
* This will break if there are more than 5 digits after the deciamal.
*******************************************************************************/
static void Parse_GPS_Num(char* line,int* index,int* intpart,int* decpart,int* success)
{
   int accumulator = 0 ; /* general accumulator           */
   int chr         = 0 ; /* current char being parsed     */
   int decfactor   = 0 ; /* Way to handle decimal parsing */

   /* instead of using line[*index] a lot, I just get it once and use it.     */
   /* Admittedly, the optimizer may do this even if I didn't.                 */
   chr = line[*index] ;
   while ((chr!=',') && (chr!='*'))
   {
      /* for digits, just accumulate them.  If in the decimal part, divide    */
      /* the multiplier by 10 for each digit parsed.                          */
      if (isdigit(chr))
      {
         accumulator = (accumulator*10) + chr-'0' ;
         decfactor   = decfactor/10 ;
      }
      /* If there is a decimal, save the integer part, reset the accumulator, */
      /* and prime the decimal multiplier to get divided by 10 for each digit */
      /* parsed.                                                              */
      else if ('.'==chr)
      {
         *intpart    = accumulator ;
         accumulator = 0           ;
         decfactor   = 100000      ;
      }
      else /* oops! */
      {
         *success = false ;
      }

      /* update the index and get the next character to be parsed.            */
      (*index)++ ;
      chr = line[*index] ;
   }

   /* OK, unless an error, we got to the end of the parameter                 */
   if (0==decfactor)
   {
      /* no decimal, so accumulator has the integer value and decpart stays 0 */
     *intpart = accumulator ;
   }
   else
   {
      /* The integer part is fine, fix the decimal part                       */
      *decpart = accumulator * decfactor ;
   } ;

   /* and finally increment the index once more to pass the separator        */
   (*index)++ ;
}

/*******************************************************************************
* Routine  : Parse_GPS_Text
* Gazintas : line - GPS sentence (after the sentence ID and comma)
*          : maxlen - max string length to copy
* IOs      : index - where in the line to start parsing
*          : str - string to copy to
*          : len - number of characters copied
*          : success - Success flag
* Returns  : Nothing
* Globals  : None
*
* This parses a string parameter in an NMEA sentence.  Pretty simple, it just
* copies characters to the destination string until a comma or asterisk
*******************************************************************************/
static void Parse_GPS_Text(char* line,int* index,char* string,int maxlen,int* len,int* success)
{
   int chr    = 0 ; /* current char being parsed */
   int chrcnt = 0 ; /* character counter         */
   int llen   = 0 ; /* chars copied */

   chr = line[*index] ;
   while ((chr!=',') && (chr!='*'))
   {
      if (chrcnt<maxlen)
      {
         string[chrcnt] = chr ;
         chrcnt++ ;
         llen++ ;
      }
      else
      {
         *success = false ;
      }

      /* update the index and get the next character to be parsed.            */
      (*index)++ ;
      chr = line[*index] ;
   }

   /* and finally increment the index once more to pass the ,                 */
   (*index)++ ;
   *len = llen ;
}

/*******************************************************************************
* Routine  : Get_GPSTime
* Gazintas : None
* IOs      : Secs - Unix time (seconds)
*          : nSecs - Unix time (nanoseconds)
* Returns  : Nothing
* Globals  : GPS_TimeSec,GPS_TimeCap
*
* This returns the GPS-based time *right now*. As part of the TIM2 ISR (above),
* we know what time it was at the active edge of the last 1PPS signal and the
* TIM2 counter capture value at that edge.  So, for the current time, we look
* at the current value of the TIM2 counter and add that to the time captured
* at the 1PPS edge and that is the current time.
* NOTE: The +1 for GPSTime to returned time is *I think* because the time in
* the GPS messages is for the 1PPS tick before, not the 1PPS after.
*******************************************************************************/
void Get_GPSTime(uint32_t* Secs,uint32_t* nSecs)
{
   uint32_t TSecs  = 0 ; /* Working Seconds value */
   uint32_t TnSecs = 0 ; /* Working nSecs value   */
   uint32_t tmp1   = 0 ; /* For counter math      */
   uint32_t tmp2   = 0 ; /* For counter math      */

   TSecs  = GPS_TimeSec+1       ; /* The last sync'd time +1 */
   tmp1   = htim2.Instance->CNT ; /* TIM2 Count *right now*  */
   tmp2   = tmp1-GPS_TimeCap    ; /* Delta since 1PPS edge   */ /* Don't care about overflow! */

   /* TIM2 is programmed to count at 40MHz or 25ns/clock.  Way overkill for   */
   /* what we need, but comes out nicely to 25ns per tick or 40 million ticks */
   /* per second.  Take care of any overflow below next.                      */
   if (tmp2>TIM2_TICKS_PER_SEC)
   {
      TSecs++ ;
      tmp2 -= TIM2_TICKS_PER_SEC ;
   }

   /* Convert Timer ticks to ns */
   TnSecs = tmp2*TIM2_NS_PER_TICK ;

   /* Move working values to results */
   *Secs  = TSecs ;
   *nSecs = TnSecs ;
}
