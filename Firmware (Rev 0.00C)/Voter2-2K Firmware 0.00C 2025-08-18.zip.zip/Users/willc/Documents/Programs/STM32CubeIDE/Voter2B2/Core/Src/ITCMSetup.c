/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the ITCM_Setup file.  It is in charge of setting up and verifying  */
/* the ITCM. There isn't much to setting up the ITCM itself, the main chore   */
/* is to copy the code intended for the ITCM from external flash (SPINOR in   */
/* my case) into ITCM.  Code intended for ITCM should use the IN_ITCM macro   */
/* to have it end up in ITCM.                                                 */
/* The test routine confirms code gets copied OK and can run.                 */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - ITCM_Setup - Sets up the ITCM and copy code to it.                      */
/*  - ITCM_Verify - A routine in ITCM to make sure it works.                  */
/*                                                                            */
/******************************************************************************/
// TO DO:
//  Any way to suppress the "copy to null" warning?

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>

#include "Options.h"
#include "main.h"
#include "Settings.h"
#include "logger2rt.h"

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
#define ITCM_START    (void*)0x00000000
#define SPINOR_SOURCE (void*)0x90000000
#define ITCM_SIZE     (65536)

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/

/******************************************************************************/
/* External globals. How CubeMX does things instead of in an include file,    */
/* weird.                                                                     */
/******************************************************************************/

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
void ITCM_Setup2(void*) ;

/******************************************************************************/
/* Routines                                                                   */
/******************************************************************************/

/*******************************************************************************
* Routine  : ITCM_Setup
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : ITCM code in SPINOR?
*
* This routine gets called after the SpiNor_Setup() routine that sets up the
* QSPI interface and NOR flash so it is directly accessible and ready to have
* the reserved buffer for ITCM code copied to ITCM.
*
* NOTE: Since this is copying code from SPINOR to ITCM, it clearly needs to be
* called *after* SPINOR is set up, but before any code in ITCM needs to
* execute.  This might be tricky!
*******************************************************************************/
void ITCM_Setup(void)
{

   /* ITCM itself doesn't need any setup, just copy data from the first 64K   */
   /* SPINOR to ITCM.  For now I'm going to copy all 64K, this can be smarter */
   /* with some linker magic.  It looks like the CPU can write to ITCM as if  */
   /* it were data ram, so seems pretty easy. No MDMA needed.                 */
   /* WARNING: GCC initially got understandably grumpy!!! ITCM starts at      */
   /* address 0, so GCC suggested using memcpy to copy data to "NULL" was     */
   /* probably a bad thing!!! :)  It was just a warning, but still...         */
   /* -Wnonnull would ignore the warning, but would also disable that warning */
   /* everywhere and I want it for all the rest of my code.  Plan B is to     */
   /* just pass NULL as a parameter to another routine that actually does the */
   /* memcopy (ITCM_Setup2 below).  That avoids the warning.  Cheesy, but it  */
   /* works.                                                                  */
	ITCM_Setup2(ITCM_START) ;
}

void ITCM_Setup2(void* dest)
{
   memcpy(dest,SPINOR_SOURCE,ITCM_SIZE) ;
}

/*******************************************************************************
* Routine  : ITCM_Verify
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : huart1
*
* This is just a routine forced to be in ITCM that says "hi".  That is, if
* it passes.  if it fails, things just crash.  This could be better (later).
* It requires checking the linker map output file to know this code is in
* SPI NOR.
*******************************************************************************/
void IN_ITCM ITCM_Verify(void)
{
   Logger2_Msg(Logger.Boot,LOG_SUPPORT,LOG_TIME,"Greetings from  ITCM  space! 0x%8.8x\n",(uint32_t)ITCM_Verify) ;
}
