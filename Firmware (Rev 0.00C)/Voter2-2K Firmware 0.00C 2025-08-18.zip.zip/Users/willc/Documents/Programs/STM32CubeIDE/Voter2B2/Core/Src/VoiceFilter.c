#include "Options.h"

#include "VoiceFilter.h"

int16_t voice_filter_taps1[VOICEFILTER_TAP_NUM] = {
  1237,
  507,
  -869,
  -1251,
  -343,
  -105,
  -614,
  -236,
  316,
  -110,
  -67,
  683,
  407,
  57,
  866,
  823,
  -13,
  629,
  945,
  -391,
  -211,
  656,
  -1010,
  -1656,
  31,
  -1524,
  -3612,
  -674,
  -1033,
  -6749,
  -1137,
  14332,
  14332,
  -1137,
  -6749,
  -1033,
  -674,
  -3612,
  -1524,
  31,
  -1656,
  -1010,
  656,
  -211,
  -391,
  945,
  629,
  -13,
  823,
  866,
  57,
  407,
  683,
  -67,
  -110,
  316,
  -236,
  -614,
  -105,
  -343,
  -1251,
  -869,
  507,
  1237
};

int16_t voice_filter_taps2[VOICEFILTER_TAP_NUM] = {
  -52,
  433,
  394,
  -129,
  -90,
  224,
  -99,
  -174,
  260,
  -10,
  -298,
  256,
  145,
  -422,
  170,
  364,
  -500,
  -28,
  626,
  -481,
  -369,
  903,
  -294,
  -902,
  1157,
  202,
  -1792,
  1351,
  1552,
  -4090,
  1456,
  17283,
  17283,
  1456,
  -4090,
  1552,
  1351,
  -1792,
  202,
  1157,
  -902,
  -294,
  903,
  -369,
  -481,
  626,
  -28,
  -500,
  364,
  170,
  -422,
  145,
  256,
  -298,
  -10,
  260,
  -174,
  -99,
  224,
  -90,
  -129,
  394,
  433,
  -52
};

/******************************************************************************/
/* If using the CMSIS DSP library, we don't need any of the structures and    */
/* routines below, just the coefficient table.                                */
/******************************************************************************/
#ifndef USE_CMSIS_DSP

void VoiceFilter_init(VoiceFilter* f) {
  int i;
  for(i = 0; i < VOICEFILTER_TAP_NUM; ++i)
    f->history[i] = 0;
  f->last_index = 0;
}

void VoiceFilter_put(VoiceFilter* f, int16_t input) {
  f->history[(f->last_index++) & 63] = input;
}

int16_t VoiceFilter_get1(VoiceFilter* f) {
  int32_t acc = 0;
  int index = f->last_index, i;
  for(i = 0; i < VOICEFILTER_TAP_NUM; ++i) {
    acc += (int32_t)f->history[(index--) & 63] * voice_filter_taps1[i];
  };
  return acc >> 16;
}

int16_t VoiceFilter_get2(VoiceFilter* f) {
  int32_t acc = 0;
  int index = f->last_index, i;
  for(i = 0; i < VOICEFILTER_TAP_NUM; ++i) {
    acc += (int32_t)f->history[(index--) & 63] * voice_filter_taps2[i];
  };
  return acc >> 16;
}

#endif
