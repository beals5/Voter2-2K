/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the QSPINORSetup file.  It is in charge of setting up the the      */
/* external SPI NOR to support memory mapped XIP mode starting at address     */
/* 0x9000_0000.                                                               */
/* Rev B of this code needs to work without any HAL calls as I want to be     */
/* be able to move all HAL routines to external flash.  Of Note:              */
/*  - The target device is a Macronix MX25L3233 (4MBytes)                     */
/*  - The first 64K of memory space is reserved for copying to ITCM.  That    */
/*    doesn't impact any code here, but keep this in mind.                    */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - QSPINOR_NOHAL_Setup - Sets up the QSPI NOR XIP mode without HAL drivers.*/
/*  - QSPINOR_HAL_Setup - Sets up the QSPI NOR XIP mode using HAL drivers.    */
/*  - QSPINOR_Verify - A routine in QSPI NOR to make sure it works.           */
/*                                                                            */
/******************************************************************************/
// TO DO:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "Options.h"
#include "main.h"
#include "Settings.h"
#include "logger2rt.h"
#include "gpio.h"
#include "MX25Lxx.h"
#include "Bootloader.h"

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
#define MEMORY_OK          ((uint32_t)0x00)
#define MEMORY_ERROR       ((uint32_t)0x01)

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static QSPI_CommandTypeDef sCommand ;
static QSPI_AutoPollingTypeDef sConfig  ; /* Shared polling config            */

/******************************************************************************/
/* External globals. How CubeMX does things instead of in an include file,    */
/* weird.                                                                     */
/******************************************************************************/
extern QSPI_HandleTypeDef hqspi;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static int  ResetSPINOR(void) ;
static void QUADSPI_MemoryMappedMode(void) ;
static int  QSPI_WriteEnable(void) ;
static int  WriteQSPIReg(int,int,uint8_t*) ;
static void sCommandDefaults(uint32_t) ;

/******************************************************************************/
/* Routines                                                                   */
/******************************************************************************/

/*******************************************************************************
* Routine  : QSPINOR_NOHAL_Setup1
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine gets called right after the bootloader (so before any HW setup
* at all) to enabled the QSPIs XIP mode.  Like the bootloader, this code to
* initialize the QSPI interface cannot use any HAL routines as this is pre-HAL.
* Reason is I want most HAL code to be in the QSPI flash, so I need QSPI
* working before any HAL calls.  The bootloader has the same issue, so I do
* borrow some routines from it.
*
* This gets the QSPI memory mapped mode functional, but not optimized yet.  At
* this early stage the system clocks are not yet set up, so we're limping along
* off the HSI clock.  After this call all the "regular" HAL code gets executed
* that sets up the faster system clocks and then QSPINOR_NOHAL_Setup2()
* optimizes the QSPI interface based on the faster system clocks.
*
* IMPORTANT: Once this code is good and stable the QSPINOR_HAL_Setup() routine
* is no longer needed.
*******************************************************************************/
void QSPINOR_NOHAL_Setup1(void)
{
   uint8_t Cmd = 0x40 ; /* Status register Enable 4READ bit */

   /* First the two Bootloader routines to set up QSPI interface and flash.   */
   ConfigGpio()           ; /* Need GPIO clocks running for QSPI to work.     */
   ConfigQspi()           ; /* Configure QSPI peripheral and IO pins          */
   BL_QSPINOR_Init(false) ; /* Initialize the QSPI flash                      */

   /* I'm going to be using 4READ commands for memory mapped mode, it is      */
   /* disabled by default on the MX25L3233, so I need to enable that mode.    */
   /* But to even to do that, I have to enable writes to the status register! */
   BL_QSPINOR_Cmd(WRITE_ENABLE_CMD,0,0) ;
   BL_QSPINOR_WrDat(WRITE_STATUS_REG_CMD,1,&Cmd) ;
   SW_msDelay(50) ; /* Spec says 40ms max */

   /* Finally, set up the QSPI's memory mapped or XIP mode.                   */
   BL_QSPINOR_SetupXIP() ;
}

/*******************************************************************************
* Routine  : QSPINOR_NOHAL_Setup2
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This is part 2 of setting up the QSPI interface.  See comments for
* QSPINOR_NOHAL_Setup1() for what part 1 does.
*
* For part 2 we now have a fast system clock running and need to set up the
* QSPI peripheral to use it for best performance.  To change the settings I have
* to disable it first!  The HAL is now running--and running from QSPI!
* To do this I temporarily disable all interrupts (this code is in STM flash),
* reset the QSPI peripheral, then re-enable interrupts.
*******************************************************************************/
void QSPINOR_NOHAL_Setup2(void)
{
   __disable_irq() ; /* Disable interrupts to stop any HAL QSPI accesses      */
   ReConfigQspi()  ; /* Reconfigure the QSPI for speed.                       */
   BL_QSPINOR_SetupXIP() ; /* Re-enable memory mapped or XIP mode             */
   __enable_irq()  ; /* Re-enable interrupts now that it is safe again        */
}

/*******************************************************************************
* Routine  : QSPINOR_HAL_Setup
* Gazintas : QSPIHandle - What is says! :)
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine gets called after the MX_QUADSPI_Init() routine that sets up the
* QSPI interface  This resets SPI NOR chip (there is no hardware reset line)
* and enables direct (XIP) access mode.
*
* IMPORTANT: Once QSPINOR_NOHAL_Setup works, this routine is no longer needed.
*******************************************************************************/
void QSPINOR_HAL_Setup(QSPI_HandleTypeDef* QSPIHandle)
{
   ResetSPINOR() ;
   QUADSPI_MemoryMappedMode() ;
}

/*******************************************************************************
* Routine  : ResetMemory
* Gazintas : None
* IOs      : None
* Returns  : 0 for success, 2 for failure
* Globals  : QSPIHandle
*
* This resets the SPI NOR device.  It sends the RESET enable followed by the
* Reset command, then waits a bit for reset to finish.
* I think this uses direct register read/writes instead of HAL commands is they
* want it to work before the HAL is initialized.  Alas I use the HAL later to
* set up memory mapped mode, so need the HAL anyway.
*******************************************************************************/
static int ResetSPINOR(void)
{
   int timeout = 0 ; /* timeout counter */

   /* Reset memory config, Cmd in 1 line */
   /* Send RESET ENABLE command (0x66) to be able to reset the memory registers */
   while(hqspi.Instance->SR & QSPI_FLAG_BUSY)  /* Wait for busy flag to be cleared */
   {
      HAL_Delay(1) ;
      timeout++ ;
      if (timeout>100) /* 10ms */
      {
         return(2) ;
      }
   }
   hqspi.Instance->CCR = 0x2166;
   hqspi.Instance->AR = 0;
   hqspi.Instance->ABR = 0;
   hqspi.Instance->DLR = 0;
   __DSB();

   /* Send RESET command (0x99) to reset the memory registers */
   while(hqspi.Instance->SR & QSPI_FLAG_BUSY)  /* Wait for busy flag to be cleared */
   {
      HAL_Delay(1) ;
      timeout++ ;
      if (timeout>100) /* 10ms */
      {
         return(2) ;
      }
   }
   hqspi.Instance->CCR = 0x2199;
   hqspi.Instance->AR = 0;
   hqspi.Instance->ABR = 0;
   hqspi.Instance->DLR = 0;
   __DSB();

   /* Spec says 30us after reset command before operations resume.            */
   /* Adding a bit...                                                         */
   HAL_Delay(1) ;
   return(0) ;
}

/*******************************************************************************
* Routine  : QUADSPI_MemoryMappedMode
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : sCommand, QSPIHandle
*
* This sets up memory mapped mode for the QUADSPI SPI NOR device.
*******************************************************************************/
static void QUADSPI_MemoryMappedMode(void)
{
   QSPI_MemoryMappedTypeDef sMemMappedCfg = {0} ;
   uint8_t Cmds[2] = {0x40,0x00} ;

   /* I'm going to be using 4READ commands for memory mapped mode, it is   */
   /* disabled by default on the MX25L3233, so I first need to enable that */
   /* mode.  But to even to do that, I have to enable writes to the status */
   /* register! :)                                                         */
   QSPI_WriteEnable() ;  /* Enable writes to the status register  */
   WriteQSPIReg(WRITE_STATUS_REG_CMD,1,Cmds) ; /* Enable 4READs   */
   HAL_Delay(100) ; /* Wait a bit for write to complete           */

   /* OK, on to the command to turn on memory mapped mode! */
   sCommand.Instruction        = READ4_INOUT_FAST_READ_CMD;
   sCommand.InstructionMode    = QSPI_INSTRUCTION_1_LINE;

   sCommand.AddressSize        = QSPI_ADDRESS_24_BITS;
   sCommand.AddressMode        = QSPI_ADDRESS_4_LINES;
   sCommand.Address            = 0; /* handled by MMIO hardware */

   sCommand.AlternateByteMode  = QSPI_ALTERNATE_BYTES_NONE ;
   sCommand.AlternateBytesSize = QSPI_ALTERNATE_BYTES_8_BITS;
   sCommand.AlternateBytes     = 0xffffffff ;

   sCommand.DummyCycles        = READ4_NUMDUMMYCYCLES;

   sCommand.DataMode           = QSPI_DATA_4_LINES;
   sCommand.NbData             = 0;  /* handled by MMIO hardware */
   sCommand.DdrMode            = QSPI_DDR_MODE_DISABLE;
   sCommand.DdrHoldHalfCycle   = QSPI_DDR_HHC_ANALOG_DELAY;
   sCommand.SIOOMode           = QSPI_SIOO_INST_EVERY_CMD;

   sMemMappedCfg.TimeOutActivation = QSPI_TIMEOUT_COUNTER_DISABLE;
   sMemMappedCfg.TimeOutPeriod     = 0 ;

   HAL_QSPI_MemoryMapped(&hqspi, &sCommand, &sMemMappedCfg) ;
}

/*******************************************************************************
* Routine  : QSPI_WriteEnable
* Gazintas : None
* IOs      : None
* Returns  : 0 for error, 1 for good.
* Globals  : hqspi, sCommand, sConfig
*
* This sends the write enable command and waits for it to be complete.  Writes
* to the status register can take up to 15ms.
*******************************************************************************/
static int QSPI_WriteEnable(void)
{
   /* Enable writes */
   sCommandDefaults(WRITE_ENABLE_CMD) ; /* Defaults all good! */

   if (HAL_QSPI_Command(&hqspi, &sCommand, HAL_QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)
   {
      return 0;
   }

   /* Configure automatic polling mode to wait for write enabling ---- */
   sConfig.Match           = 0x02;
   sConfig.Mask            = 0x02;
   sConfig.MatchMode       = QSPI_MATCH_MODE_AND;
   sConfig.StatusBytesSize = 1;
   sConfig.Interval        = 0x10;
   sConfig.AutomaticStop   = QSPI_AUTOMATIC_STOP_ENABLE;

   sCommand.Instruction    = READ_STATUS_REG_CMD;
   sCommand.DataMode       = QSPI_DATA_1_LINE  ;

   if (HAL_QSPI_AutoPolling(&hqspi, &sCommand, &sConfig, HAL_QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)
   {
      return 0;
   }

   return 1;
}

/*******************************************************************************
* Routine  : WriteQSPIReg
* Gazintas : RegID - Register address to write
*          : nbytes - number of bytes to write
* IOs      : RegData - Data to write
* Returns  : Error code.  0 = success, 1 = write error
* Globals  : sCommand
*
* This writes a command (and possible data) to the QSPINOR.
*******************************************************************************/
static int WriteQSPIReg(int RegID,int nbytes, uint8_t* RegData)
{
   sCommandDefaults(RegID) ; /* Initial Defaults... */

   /* If any data, set that up */
   if (nbytes>0)
   {
      sCommand.DataMode    = QSPI_DATA_1_LINE;
      sCommand.NbData      = nbytes;
   }

   if (HAL_QSPI_Command(&hqspi, &sCommand, HAL_QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)
   {
      return 0;
   }

   if (nbytes>0)
   {
      if (HAL_QSPI_Transmit(&hqspi,RegData, HAL_QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)
      {
         return 0;
      }
   }

   return (1) ;
}

/*******************************************************************************
* Routine  : sCommandDefaults
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : sCommand
*
* This is just a quick routine to set up defaults for the sCommand structure.
* Primarily it is to ensure that the entire structure is filled out with
* defaults, then to have specific parameters overridden afterwards. Defaults
* are for a single byte command with no address or data.
*******************************************************************************/
static void sCommandDefaults(uint32_t inst)
{
   sCommand.InstructionMode    = QSPI_INSTRUCTION_1_LINE;
   sCommand.Instruction        = inst ;

   sCommand.AddressMode        = QSPI_ADDRESS_NONE;
   sCommand.Address            = 0 ;
   sCommand.AddressSize        = QSPI_ADDRESS_24_BITS;

   sCommand.AlternateByteMode  = QSPI_ALTERNATE_BYTES_NONE;
   sCommand.AlternateBytesSize = QSPI_ALTERNATE_BYTES_32_BITS;
   sCommand.AlternateBytes     = 0 ;
   sCommand.DummyCycles        = 0 ;

   sCommand.DataMode           = QSPI_DATA_NONE;
   sCommand.NbData             = 0 ;

   sCommand.DdrMode            = QSPI_DDR_MODE_DISABLE;
   sCommand.DdrHoldHalfCycle   = QSPI_DDR_HHC_ANALOG_DELAY;
   sCommand.SIOOMode           = QSPI_SIOO_INST_EVERY_CMD;
}

/*******************************************************************************
* Routine  : QSPINOR_Verify
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : huart2
*
* This is just a routine forced to be in SPI NOR that says "hi".  That is, if
* it passes.  if it fails, things just crash.  This could be better (later).
* It requires checking the linker map output file to know this code is in
* SPI NOR.
*******************************************************************************/
void IN_QSPINOR QSPINOR_Verify(void)
{
   Logger2_Msg(Logger.Boot,LOG_SUPPORT,LOG_TIME,"Greetings from SPINOR space! 0x%8.8x\n",(uint32_t)QSPINOR_Verify) ;
}
