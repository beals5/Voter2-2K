/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Timers file.  It is in charge of low lever timer stuff.        */
/* Timers used in this project are:                                           */
/*  - SysTick - used by FreeRTOS, no code for it here.                        */
/*  - TIM2  - Creates A2D and DAC sample clocks either phase locked to the    */
/*            GPS 1PPS or free running if GPS 1PPS is missing or not wanted.  */
/*  - TIM7  - HAL Sequencer.  For lower level stuff "below" the RTOS/         */
/*            It is actually set up in stm32h7xx_hal_timebase_tim.c.          */
/*  - TIM15 - Creates 250Hz ADC sample clock for RSSI data                    */
/******************************************************************************/
/* The source of the ADC and DAC sampling clock will be either the output of  */
/* TIM6 if being sourced locally or TIM2-CC2 if being derived from the GPS    */
/* 1PPS.  The logic to determine the source is as follows:                    */
/*                        DIAL                                                */
/*              Connected Timing  GPS     || Voter   Clock                    */
/*  NODIALTASK  to DIAL   Mode    Active  || Active? Source Note              */
/*  =========== ========= ======= ========   ======= ====== ================= */
/*  #defined    N/A       N/A     N/A     || Yes     Local  Local only device */
/*  not defined No        N/A     N/A     || Yes     Local  Local Mode        */
/*  not defined Yes       General N/A     || Yes     Local  DIAL general timing*/
/*  not defined Yes       GPS     No      || Yes     Local  Local mode (**)   */
/*  not defined Yes       GPS     Yes     || Yes     GPS    DIAL GPS timing   */
/*                                                                            */
/*  (**) RTCM goes offline in this state, so different from RTCM.             */
/*                                                                            */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - MY_TIM2_FinishInit - Finish TIM2 initialization                         */
/*  - MY_TIM2_Svc - GPS 1PPS (and derived clocks) handler                     */
/*  - MY_TIM7_Svc - HAL system timer sequencer                                */
/*  - MY_TIM15_FinishInit - Finish TIM15 initialization                       */
/*  - WWDG_HariKiri - Stop petting the watchdog to generate a reset           */
/*  - MainTaskWatchdogPet - MainTasks's part of the watchdog petting.         */
/******************************************************************************/
// TO DO:
// - Figger out what is *really* going on with the TIM2 HAL DMA call.
// - Redo TIM code using LL routines or direct register access

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "Options.h"
#include "main.h"
#include "AnalogIO.h"
#include "Timers.h"
#include "GPS.h"
#include "Settings.h"
#include "Utils.h"
#include "SetShow.h"
#include "Logger2rt.h"
#include "Gpio.h"
#include "MtrSpi.h"
#include "DialSettings.h"
#include "DialTask.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/
extern TIM_HandleTypeDef htim2 ;
extern TIM_HandleTypeDef htim15 ;
extern WWDG_HandleTypeDef hwwdg1;
extern DMA_HandleTypeDef hdma_tim2_ch2;

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
#define MAINTASKWDG_LIMIT  100 /* 20ms ticks (2 secs) for Maintask watchdog    */
#define GPS2PACKET_MULT     (APKT_SAMPLERATE/SAMPLESIZE) /* PLL multiplier for packet PLL -50 packets/sec*/
#define GPS2ANALOG_MULT  (APKT_SAMPLERATE*2) /* PLL multiplier for A2D/DAC - 8000 samples/sec*/ /* x2 cus I need to define both edges of the clock--ick!! */
#define DEADMAN_DELTA (TIM2_FREQ/2) /* Extra time for GPS 1PPS before error   */

/* The four different TIM2 capture/compare event flags */
#define GPS1PPS_IRQ   1 /* CC1 (irq)                   */
#define A2DDACPLL_IRQ 2 /* CC2 (event only, no IRQ)    */
#define PACKETPLL_IRQ 3 /* CC3 (irq)                   */
#define DEADMAN_IRQ   4 /* CC4 (irq)                   */

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
uint32_t RunTime   = 0     ; /* FreeRTOS Counter for runtime monitoring       */
int      GPSLocked = false ; /* GPS 1PPS Locked and stable flag               */
int      GPSUsed   = false ; /* GPS Used flag (sample clock PLLd to GPS)      */

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
/* The DMA buffer for timer compare values to generate A2D/DAC ticks */
#ifndef DUMBTIMERMODE
static uint32_t A2ddac_Ticks[SAMPLESIZE*2] IN_DMADD2 = {0} ;
static uint32_t LastGPSCount     = 0     ; /* Last GPS count                  */
#endif

static int      MainTaskWatchdog = 0     ; /* Watchdog counter for MainTask   */
static int      HariKiri         = false ; /* Disable watchdog to force a rst */

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
#ifndef DUMBTIMERMODE
static void TIM2_DeadmanTrig(uint32_t) ;
static void TIM2_GpsTrig(uint32_t) ;
static void Packet_PLL(int,uint32_t,uint32_t) ;
static void A2ddac_PLL(int,uint32_t,uint32_t) ;
#endif
static void PetWatchdog(void) ;
static void ReportFlag(void) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : MY_TIMx_FinishInit
* Gazintas : Nothing
* IOs      : None.
* Returns  : Nothing
* Globals  : htim6
*
* This routine wraps up any final initialization of TIM6 after the MX_INIT
* routines.  Basically, the timer is set up, it just needs to be told to start!
* Code put here to lessen the likelihood of losing it.
*
* TIM2 The main counter free-runs at 40MHz, 25ns/tick.
*      CC1 is set to capture mode to get the 1PPS signal from the GPS.
*      CC2 is compare mode to generate the A2D/DAC sample clock
*      CC3 is compare mode to generate a "packet" clock (see header)
*      CC4 is compare mode to take over if GPS clock fails or not wanted.
* TIM7 just generates an interrupt every 1ms for HAL sequencing.
* TIM15 sets the sample clock for ADC2 to get RSSI information. I have a PWM
*       output set for it too to verify it is working OK.
*
* If in local-only mode where nothing needs to be GPS-timed, this whole
* complicated PLL thing isn't needed for audio clocks and TIM2 can devolve to
* just a simple clock divider.  This is DUMBTIMERMODE.  The reason to not use
* DUMBTIMERMODE even for local-only mode is if you still want stupid-accurate
* GPS-based timestamps for something else than audio clocks.
*******************************************************************************/
void MY_TIM2_FinishInit(void)
{
#ifdef DUMBTIMERMODE
   /* In this mode, TIM2 reverts to just a simple clock divider!              */
   /* Override all the settings in main.c and set up TIM2 to be an 8KHz PWM   */
   /* output with a 50% duty cycle coming out the trigger output.             */

   TIM_OC_InitTypeDef sConfigOC = {0};

   htim2.Instance = TIM2;
   htim2.Init.Prescaler = 599;
   htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
   htim2.Init.Period = 49;
   htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
   htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
   HAL_TIM_Base_Init(&htim2) ;
   HAL_TIM_PWM_Init(&htim2) ;

   sConfigOC.OCMode = TIM_OCMODE_PWM1;
   sConfigOC.Pulse = 24;
   sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
   sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
   HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) ;
   __HAL_TIM_DISABLE_OCxPRELOAD(&htim2, TIM_CHANNEL_2);

   HAL_TIM_PWM_Start (&htim2,TIM_CHANNEL_2 ) ;
#else
   TIM_IC_InitTypeDef sConfigIC = {0};

   /* TIM2 is mostly set up by MX_TIM2_Init() in main.c, but not actually     */
   /* started yet.  In CubeMX I set it to rising edge, but this is a user     */
   /* option, so program the user option before firing up the timer.          */
   sConfigIC.ICPolarity = (GPS_1PPS_RISING==Settings.GPS_PPSEdge)?TIM_INPUTCHANNELPOLARITY_RISING:TIM_INPUTCHANNELPOLARITY_FALLING;
   sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
   sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
   sConfigIC.ICFilter = 0;
   if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
   {
     Error_Handler();
   }

   /* Time to fire up the timer and all of its capture/compare registers!     */
   HAL_TIM_IC_Start_IT (&htim2,TIM_CHANNEL_1 ) ;

   __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_3,(htim2.Instance->CNT)+TIM2_FREQ) ;
   HAL_TIM_OC_Start_IT (&htim2,TIM_CHANNEL_3 ) ;

   /* CC4 is our GPS 1PPS deadman switch, so set up the output compare to     */
   /* 1 second from now then enable interrupts.  As the GPS isn't locked      */
   /* right after boot, we'll be in that mode anyway.                         */
   __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_4,(htim2.Instance->CNT)+TIM2_FREQ+DEADMAN_DELTA) ;
   HAL_TIM_OC_Start_IT (&htim2,TIM_CHANNEL_4 ) ;

   /* IMPORTANT NOTE!  While I use HAL routines to set up this timer, I do    */
   /* NOT use the HAL code for IRQ handling.  I disable the HAL call in       */
   /* st32h7xx_it.c and call MY_TIM2_Svc() below directly and take care of    */
   /* the IRQ registers.  I do this for speed and efficiency.                 */
#endif
}

void MY_TIM15_FinishInit(void)
{
   /* Timer15 all configured, just need to start it! */
	HAL_TIM_PWM_Start(&htim15,TIM_CHANNEL_2) ;
}

#ifndef DUMBTIMERMODE
/*******************************************************************************
* Routine  : MY_TIM2_Svc
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This handles the TIM2 interrupts for the four capture/compare channels.
*  - CC1 is a capture interrupt for the GPS 1PPS signal. It is the edge that is
*    *the* time we get from the GPS so the TIM2 count can be used with a bit of
*    math to get the GPS time to ns-level accuracy at any time by reading the
*    TIM2 count value and last GPS sentence.
*  - CC2 is used for the A2D/DAC sample clock which is 160 samples/packet. Code
*    in the CC3 ISR sets up a DMA for the TIM2 counter values for the 160 sample
*    clocks for the A2D and DAC.  No IRQ is generated for CC2.
*  - CC3 is used for an internally generated interrupt to set up a DMA for the
*    CC2 counter values to generate the A2D/DAC sample clock.  It does NOT
*    actually fire off packet creation, see the important note in the header
*    for this routine.
*  - CC4 is a "dead man" timer set to a bit more than 1 second from the last
*    GPS 1PPS if running GPS timing.  At every 1PPS it gets reset to a bit
*    more than another second.  As long as 1PPS is healthy, this interrupt will
*    never fire.  If 1PPS goes away it will fire and then this interrupt will
*    then fire off every second based on the local crystal to keep the A2D and
*    DAC running in local mode.  Once 1PPS comes back (and assuming you are in
*    DIAL GPS-timed mode), this timer goes back to its deadman switch mode.
*
* TIM2 is counting at 40MHz.  I somewhat arbitrarily chose this as it was the
* fastest division of 240Mz (the incoming clock) yielding an integer number of
* ns per tick (25ns) which is handy for creating timestamps and some debugging
* messages, nothing else.  If faster is better, no big deal.  Slower isn't
* better as precision matters for the GPS Stabilized Oscillator.  If you change
* it, go fix Get_GPSTime() in Gps.c.  If it isn't a nice integer number of ns
* per tick the math will get a bit more involved.
*
* IMPORTANT! First try to fully understand this Timer2 code as it relates to
* being effectively a PLL that phase locks to the GPS 1PPS.  Then, just realize
* that in non-GPS mode I just force a fake 1PPS event based on a 40,000,000
* ticks of TIM2.  If you were to try and understand local mode first this code
* would look insanely complicated.  Local clock mode is still the full PLL
* implementation, just with a locally generated 1PPS.
*
* IMPORTANT! Due to critical timing needs generating the DMA buffer for audio
* samples, this code must run "below" the RTOS, that is its interrupt level is
* below the LIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY level so even the RTOS can't
* disable it during its critical code.  As such, no RTOS calls are allowed for
* this TIM2 code.  For any kind of reporting, use the Flags[] array that can
* then be reported by RTOS-friendly code.
*******************************************************************************/
void MY_TIM2_Svc(void)
{
   uint32_t Count = 0 ; /* Event count value */

   /* Even though I only enabled CC1 and CC3 interrupts, I still get a call   */
   /* for CC2 interrupts into this routine!  After a bit of sleuthing, it     */
   /* it seems when I enable the DMA for CC2, the HAL code still calls the    */
   /* TIM2 CC2 IRQ handler at the end of the DMA.  No idea why.  As it isn't  */
   /* a *real* interrupt that needs to hardware-cleared, it is OK to ignore.  */

   /* If a CC3 interrupt, that is one of the "packet" interrupts.  Clear the  */
   /* interrupt flag and go set up the next packet interrupt along with the   */
   /* next 160 A2D and DAC sample triggers.                                   */
   if (__HAL_TIM_GET_FLAG(&htim2,TIM_FLAG_CC3))
   {
      __HAL_TIM_CLEAR_FLAG(&htim2,TIM_FLAG_CC3) ;
      Packet_PLL(PACKETPLL_IRQ,0,0) ; /* Go compute Packet clock PLL  */
      A2ddac_PLL(PACKETPLL_IRQ,0,0) ; /* Go compute A2D/DAC clock PLL */
   }

   /* CC4 is our "deadman switch" that fires if we don't have a GPS lock and  */
   /* then fires every second based on the local clock until the GPS 1PPS     */
   /* comes back.                                                             */
   /* For Voters modes that force local mode, the GPS 1PPS is ignored and     */
   /* this is the timer that always runs all the packet and sample clocks.    */
   if (__HAL_TIM_GET_FLAG(&htim2,TIM_FLAG_CC4))
   {
      __HAL_TIM_CLEAR_FLAG(&htim2,TIM_FLAG_CC4) ;
      Count = htim2.Instance->CCR4 ; /* Count that triggered this IRQ */
      TIM2_DeadmanTrig(Count) ;
   }

   /* It is important to handle the CC1 interrupt last! Particularly for the  */
   /* Adddac PLL DMA values, I want to get them all calculated and DMA set up */
   /* before the next audio sample clock.  The GPS_1PPS_Handler() code could  */
   /* take some time, so want to all the a2ddac stuff finished first.         */

   /* CC1 is our GPS 1PPS capture trigger. If in a GPS-timed mode this        */
   /* generates the sample and packet clocks synchronized with GPS 1PPS.      */
   if (__HAL_TIM_GET_FLAG(&htim2,TIM_FLAG_CC1))
   {
      __HAL_TIM_CLEAR_FLAG(&htim2,TIM_FLAG_CC1) ;
      Count = htim2.Instance->CCR1 ; /* Count that triggered this IRQ */
      TIM2_GpsTrig(Count) ;
   }
}

/*******************************************************************************
* Routine  : TIM2_DeadmanTrig
* Gazintas : Count: TIM2 counter value that triggered the interrupt
* IOs      : None
* Returns  : Nothing
* Globals  : GPSLocked, GPSUsed
*
* The CC4 interrupt is our GPS "dead man switch".  During normal GPS-timed
* operations the CC4 trigger is set to after the next GPS 1PPS is expected
* to arrive.  As long as the GPS 1PPSes happen, the trigger keeps getting
* set to later than the next GPS 1PPS, so CC4 never fires.  If the GPS 1PPS
* stops for some reason though, CC4 will fire and this routine takes over
* generating the sample and packet clocks.  As soon as the GPS 1PPS is back
* and confirmed stable, it takes over again and CC4 goes back to "dead man
* switch" mode.
*******************************************************************************/
static void TIM2_DeadmanTrig(uint32_t Count)
{
   /* If we're here due to being in local mode we still want to be monitoring */
   /* the GPS status.  This gets called every second in local mode.  If the   */
   /* last GPS event was more than 1.5 seconds ago, GPS lock was lost.  Note  */
   /* this even though it's not being used.                                   */
   if (GPSLocked && (Count-LastGPSCount > TIM2_FREQ+DEADMAN_DELTA))
   {
      GPSLocked = false ;
      GPSUsed   = false ;
      Flags[0] = 1 ; /* Note this so it can be reported */
   }

   /* Whether the first time or continuing in local mode, fire off the        */
   /* Packet and A2ddac PLLs based on local timing.                           */
   /* For local timing, the delta is *by definition* 40,000,000 ticks         */
   Packet_PLL(DEADMAN_IRQ,Count,TIM2_FREQ) ; /* Process the packet IRQs       */
   A2ddac_PLL(DEADMAN_IRQ,Count,TIM2_FREQ) ; /* Compute A2D/DAC clocks        */

   /* Finally, set up the next "dead man" timer tick to be 1 second based     */
   /* on the crystal instead of the GPS.  This gets us back to regular        */
   /* packet processing timing while in local mode.                           */
   __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_4,Count+TIM2_FREQ) ;
}

/*******************************************************************************
* Routine  : TIM2_GpsTrig
* Gazintas : Count: TIM2 counter value that triggered the interrupt
* IOs      : None
* Returns  : Nothing
* Globals  : GPSLocked,GPSUsed
*
* The CC1 interrupt is our GPS 1PPS interrupt.  The count value is the number of
* TIM2 ticks since the last 1PPS edge.  That value is used by the PLLs to keep
* the A2D and DAC sample clocks phase locked to GPS 1PPS.  If that value is out
* of bounds we declare GPS unlocked and wait for 5 in-bounds 1PPSes to declare
* GPS lock restored.  We also set the CC4 "deadman" trigger here after every
* good GPS 1PPS.
*
* Finally, here is also where we decide if we want to use the GPS 1PPS or not.
* Even if active and good, we only use it if we are in DIAL GPS-timed mode.  If
* not, we stay in local mode regardless of the quality of the GPS timing.
*******************************************************************************/
static void TIM2_GpsTrig(uint32_t Count)
{
   static uint32_t Good_1PPSes = 0 ; /* Good GPS 1PPS counter         */
   static uint32_t LastCount   = 0 ; /* Last GPS 1PPS count value     */
   int32_t         Delta       = 0 ; /* Delta from last 1PPS          */

   /* For debugging, emulate 1PPS going away if Flags[3]!=0.                  */
   /* This is disabled now, but leaving it for later if needed.               */
   if (true) //(0==Flags[3])
   {
      Delta        = Count - LastCount ; /* Get the delta from last capture   */
      LastCount    = Count             ; /* Save for next capture             */
      LastGPSCount = Count             ; /* Save for GPS 1PPS watchdog        */

      /* External events can force GPSLocked to false.  If that happens, also */
      /* reset the Good_1PPSes count to 0.  The setting to 0 later below is   */
      /* only if the 1PPS itself is out of tolerance.                         */
      if (!GPSLocked && (6==Good_1PPSes)) Good_1PPSes = 0 ;

      /* To trust the GPS 1PPS ticks we need five in a row that are within    */
      /* tolerance.                                                           */
      if ((Delta<(TIM2_FREQ-TIM2_ERRB))||(Delta>(TIM2_FREQ+TIM2_ERRB)))
      {
         /* Log that we got an out of tolerance 1PPS pulse */
         IncErrLog(TIM2GPSTRIG_TOLERANCE,ERRLOG_NOSHOW) ;

         /* If this is a transition to GPS unlocked, report it */
         if (GPSLocked) Flags[0]=1 ;

         /* reset the count whenever out of tolerance */
         Good_1PPSes = 0 ;
         GPSLocked = false ;
         GPSUsed   = false ;
      }
      else
      {
         /* Fancy logic to only set GPSLocked at a count of five, but let the */
         /* counter go to six and hold so it doesn't wrap over every 2^32     */
         /* seconds.                                                          */
         if (Good_1PPSes<6) Good_1PPSes++ ;
         if (5==Good_1PPSes)
         {
            GPSLocked = true ;
            Flags[0] = 2 ; /* Note GPS restored so it can be reported */

            /* OK, GPS is good again, but only actually use it if we are in   */
            /* even have DIAL support and are in Voter GPS-timed mode,        */
            /* otherwise keep using the local clock even if the the GPS is    */
            /* good.                                                          */
#ifndef NODIALTASK
            if (PKTTIM_GPS==DIALSettings.PacketTiming)
            {
               GPSUsed = true ;
            }
#endif
         }
      }

      /* If using the GPS go run the PLL code using the GPS 1PPS timing info. */
      /* If not using the GPS, just skip this and the "deadman" code will     */
      /* continue running the sample clock based on the local crystal.        */
      if (GPSUsed)
      {
        /* Set the deadman switch trigger to 1.5 seconds from now */
         __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_4,Count+TIM2_FREQ+DEADMAN_DELTA) ;

         /* Go set up the PLLs and process the GPS data */
         Packet_PLL(GPS1PPS_IRQ,Count,Delta) ; /* Process the packet interrupt*/
         A2ddac_PLL(GPS1PPS_IRQ,Count,Delta) ; /* Compute A2D/DAC clock ticks */
      }

      /* Even if the GPS isn't being used, if it is locked, go ahead and      */
      /* process the timing info so accurate timestamps are available for     */
      /* other purposes.                                                      */
      if (GPSLocked)
      {
         GPS_1PPS_Handler(Count,Delta) ; /* Process the GPS 1PPS data         */
      }
   } /* if Flags[0]==0 */
}
/*******************************************************************************
* Routine  : Packet_PLL
* Gazintas : CcType - Interrupt type
*          : count - TIM2 count that caused the interrupt (GPS or internal)
*          : PPSDelta - Delta since last edge
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine implements a sorta GPS stabilized Oscillator!  Well a software
* one anyway.  We get 1PPS interrupts from the GPS, but I want a 50Hz clock
* (the packet clock) that is phase locked to the GPS 1PPS.  This does that.
* When called by the GPS 1PPS (CC1), this routine gets the timer count of that
* edge as well as the delta (in ticks) from the last edge.  It then sets up
* 49 subsequent internal interrupts using CC3 that are spaced 1/50th of the
* count since the last 1PPS.  When a CC3 interrupt happens, this same routine
* gets called so the state variables can track.
* NOTE: The cool part about this code is that it gracefully handles any
* difference in frequency between the local clock and GPS 1PPs by using
* whatever the local count is for the delta between GPS 1PPSes.  The packet
* clock will stay phase locked to the GPS 1PPS not matter how far or in which
* direction the local clock drifts.
* NOTE: My comments are all for 50x, but for code it is the GPS2PACKET_MULT
* #define.
*
* All the comments are centered around assuming the the event is CC1 from the
* GPS 1PPS.  If the GPS 1PPS is unavailable or not needed, this routine still
* gets called by CC4 (the deadman switch code) and calls it with a count and
* delta that are exactly 40,000,000 ticks apart emulating GPS 1PPS as close as
* the local crystal can.  It will be off, but good enough for local modes.
*
* IMPORTANT!!!! While this PLL generates an interrupt every 160 samples, it
* (currently) does NOT fire off the generation of a packet!  The interrupt that
* does this is the DMA.  While the DMA interrupt and this PLL interrupt both
* occur every 160 samples, there is no synchronization between the two and
* they are likely out of phase.  The only output of the timer is the sample
* clock.  I may change this as I get into the details of implementing simulcast
* mode.
*******************************************************************************/
static void Packet_PLL(int CcType,uint32_t count,uint32_t PPSDelta)
{
   static   uint32_t MyOscDelta = 0 ; /* Integer delta for interim interrupts */
   static   uint32_t DeltaRem   = 0 ; /* Remainder after the integer delta    */
   static   uint32_t DeltaAccum = 0 ; /* Accumulator for the remainders       */
   static   uint32_t NextIRQ    = 0 ; /* Count value for the next interrupt   */
   static   int      IRQCount   = 0 ; /* Internal interrupt counter           */

   /* If a CC1 or CC4 interrupt (actual 1PPS or synthesized one), use the     */
   /* timer count of the 1PPS edge and delta since the last edge to calculate */
   /* the timer count value for the next 49 CC3 interrupts.                   */
   /* Just dividing the delta by GPS_MULT is a bit too coarse.  I note the    */
   /* remainder after the division so we can smooth things out a bit          */
   /* (see CC3 comment below)                                                 */
   if ((GPS1PPS_IRQ==CcType) || (DEADMAN_IRQ==CcType))
   {
      MyOscDelta = PPSDelta/GPS2PACKET_MULT ; /* Delta to next IRQ (integer)  */
      DeltaRem   = PPSDelta%GPS2PACKET_MULT ; /* Remainder afterwards         */
      NextIRQ    = count + MyOscDelta       ; /* Next interrupt timer value   */
      IRQCount   = 0                        ; /* Reset the IRQ counter        */
      DeltaAccum = 0                        ; /* Reset remainder accumulator  */
      /* Load the timer count value into the timer compare register    */
      __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_3,NextIRQ) ;
   }

   /* If a CC3 interrupt (a locally generated one), then we are in the middle */
   /* of our internally generated interrupts so just keep on using the delta  */
   /* calculated before for the next 49 clocks.  The 50th clock will be the   */
   /* next 1PPS.                                                              */
   /* For the delta I add the integer difference, but then separately         */
   /* accumulate the remainder each call.  If/when that accumulator exceeds   */
   /* the integer we "round up" the actual timer compare value by 1 and then  */
   /* reset the accumulator.  A nice way to compensate for the integer        */
   /* division error introduction.                                            */
   if ((PACKETPLL_IRQ==CcType) && (IRQCount<GPS2PACKET_MULT-2))
   {
      NextIRQ    += MyOscDelta ; /* Next interrupt timer value */
      DeltaAccum += DeltaRem   ; /* Add up remainders */
      if (DeltaAccum>=GPS2PACKET_MULT)
      {
         NextIRQ++ ;
         DeltaAccum -= GPS2PACKET_MULT ;
      }

      IRQCount++ ; /* Count local interrupts */

      /* Load the timer count value into the timer compare register   */
      __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_3,NextIRQ) ;
   }
}

/*******************************************************************************
* Routine  : A2ddac_PLL
* Gazintas : CcType - Interrupt type
*          : count - TIM2 count that caused the interrupt (GPS or internal)
*          : PPSDelta - Delta since last edge
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine is algorithmically the same as Packet_PLL(), but instead of the
* 50Hz packet clock, it generates the 8KHz sample clock for the A2D and DAC.
* (see all the comments for Packet_PLL() for how it works).
* This routine also gets called every packet clock but instead of just
* computing the timer count for the next packet clock, it computes the timer
* values for the next 160 sample clocks and sets them up to be DMAd into TIM2s
* compare register.  That way the CPU still only gets interrupted only every
* packet, not every sample.
*******************************************************************************/
static void A2ddac_PLL(int CcType,uint32_t count,uint32_t PPSDelta)
{
   static   uint32_t MyOscDelta = 0 ; /* Integer delta for interim interrupts */
   static   uint32_t DeltaRem   = 0 ; /* Remainder after the integer delta    */
   static   uint32_t DeltaAccum = 0 ; /* Accumulator for the remainders       */
   int               i          = 0 ; /* General counter                      */
   uint32_t          Tim2_Ccmr1 = 0 ; /* Temp register value                  */


   /* If a CC1/CC4 interrupt (actual 1PPS or synthesized one), use the timer  */
   /* count of the 1PPS edge and delta since the last edge to calculate the   */
   /* timer count value for the next 8000 CC2 sample clocks.  Note that the   */
   /* TIM2 compare output can only toggle an output, so I need to generate    */
   /* 16,000 edges for 8,000 clocks.  Ick.                                    */
   /* Just dividing by GPS2ANALOG_MULT is a bit too coarse.  I note the       */
   /* remainder after the division so we can smooth things out a bit.         */
   if ((GPS1PPS_IRQ==CcType) || (DEADMAN_IRQ==CcType))
   {
      MyOscDelta = PPSDelta/GPS2ANALOG_MULT ; /* Delta to next tick (integer) */
      DeltaRem   = PPSDelta%GPS2ANALOG_MULT ; /* Remainder afterwards         */
      DeltaAccum = 0                        ; /* Reset remainder accumulator  */
      /* For the next sample tick I offset by a quarter clock just to avoid   */
      /* any potential race conditions.                                       */
      A2ddac_Ticks[0] = count + MyOscDelta/2  ;
   }
   else /* if not CC1/CC4, it was CC3 */
   {
      /* For the packets between GPS 1PPS ticks, just use the last counter    */
      /* value of the last DMA as the reference to add to.  The remainder     */
      /* tracker just keeps on plugging along, no change to it.               */
      A2ddac_Ticks[0] = A2ddac_Ticks[SAMPLESIZE*2-1] + MyOscDelta ;
   }

   /* With the first of the 160 samples figured out depending on if it is a   */
   /* GPS/fake 1PPS interrupt or just a subsequent packet interrupt, computing*/
   /* the remaining 159 sample ticks for DMAing is the same.                  */
   for (i=1;i<SAMPLESIZE*2;i++)
   {
      A2ddac_Ticks[i] = A2ddac_Ticks[i-1]+ MyOscDelta ;
      DeltaAccum += DeltaRem   ;
      if (DeltaAccum>=GPS2ANALOG_MULT)
      {
         (A2ddac_Ticks[i])++ ;
         DeltaAccum -= GPS2ANALOG_MULT ;
      }
   }

   /* Firing up the DMA is a bit tricky.  Timer DMA requests only happen as a */
   /* result of compare, so the first compare can't be from DMA'd data        */
   /* because the DMA hasn't started yet!  Catch-22.  The solution is to      */
   /* manually (well, in software) program up the first compare value.  When  */
   /* that first value triggers, then the DMA kicks in after that for the     */
   /* remaining trigger values.                                               */

   /* Very weirdly, this first manual trigger doesn't trigger the channel     */
   /* output!  So temporarily setting an earlier trigger that doesn't         */
   /* generate any output but does queue up the DMA request.                  */
   /* I have a feeling this is because the HAL driver "shuts down" the        */
   /* channel after the DMA ends so the manual trigger below doesn't affect   */
   /* the output, but with the call to HAL_TIM_OC_Start_DMA() next that       */
   /* re-enables everything.                                                  */
   /* That means I need to really dig into this as I suspect the HAL code is  */
   /* having unintended consequences like unwanted interrupts.                */

   /* DMA'd CC2 triggers can only toggle the output, so at the start of every */
   /* 160-sample packet force the CC2 output low so that clock behavior is    */
   /* consistent.  Only do this if it is a *real* GPS 1PPS interrupt!         */
   /* Code below writes the "force 0" mode into the CC control register, then */
   /* writes it back to toggle mode right afterwards.  I'm doing this at the  */
   /* register level for speed.                                               */
   if (GPS1PPS_IRQ==CcType)
   {
      Tim2_Ccmr1 = htim2.Instance->CCMR1 ;
      htim2.Instance->CCMR1 = (Tim2_Ccmr1&0xffef8fff)|0x00004000 ;
      htim2.Instance->CCMR1 = Tim2_Ccmr1 ;
   }

   /* OK, we have the times for the ticks, queue up the DMA to start ticking */
   HAL_TIM_OC_Start_DMA(&htim2,TIM_CHANNEL_2,A2ddac_Ticks,SAMPLESIZE*2) ;
   /* Send a dummy compare to trigger the DMA to start */
   __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_2,A2ddac_Ticks[0]-20) ;
}
#endif /* ifndef DUMBTIMERMODE */

/*******************************************************************************
* Routine  : MY_TIM7_Svc
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : None.
*
* This is called by the TIM7 handler every 1ms.  It is the main EMBEDDED state
* timing sequencer, operating "below" the RTOS doing any other hard realtime
* stuff. This is normally called by SysTick, but it is being used byFreeRTOS
* instead.
*
* This routine usually does a lot more, but with an RTOS, it is pretty under
* utilized!
*
*******************************************************************************/
void MY_TIM7_Svc(void)
{
   static int seq  = 0 ; /* Sequence counter */

   /* 1MHz counter value FreeRTOS can use for process monitoring. */
   RunTime++ ;

   /* I need a clean timer-based wiggling of the OPT_IRQ signal. This         */
   /* sequencer in MtrSpi.c does that.                                        */
   OPTIRQ_Wiggler() ;

   /* This is the sequencer, it counts 0-49 to partition out timer tasks over */
   /* time. This allows interrupt-based tasks to be spread out over time.     */
   /* Each task gets called once every 50ms.                                  */
   seq++ ;
   if (seq>=50) seq = 0 ;

   switch (seq)
   {
      case  1 : PetWatchdog() ; break ; /* Pet the watchdog             */
      case  2 : ReportFlag()  ; break ; /* Report a non-zero flag value */
      default :                 break ; /* Nothing for other states     */
   }
}

/*******************************************************************************
* Routine  : WWDG_HariKiri
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : HariKiri
*
* Call this to proactively reboot the Voter2.  It sets the HariKiri global to
* true which tells PetWatchdog to stop petting which forces a reboot.
* Of course, only if the WWDG is enabled.  I disable it during development.
*
*******************************************************************************/
void WWDG_HariKiri(void)
{
   HariKiri = true ;
}

/*******************************************************************************
* Routine  : MainTaskWatchdogPet
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : MainTaskWatchdog
*
* MainTask should call this every second (it's loop time).  PetWatchdog()
* increments this counter every 20ms, and this resets that count.  If MainTask
* hangs for some reason, then we'll generate a watchdog.
*******************************************************************************/
void MainTaskWatchdogPet(void)
{
   MainTaskWatchdog = 0 ;
}

/*******************************************************************************
* Routine  : PetWatchdog
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : HariKiri
*
* This gets called every 20ms to pet the watchdog.  The WWDG is set to about
* 40ms, so if it misses, we'll get a reset.  To further keep a watch on the
* RTOS, MainTask has a 1-second loop and calls MainTaskWatchdogPet() above.
* If the RTOS hangs,then MainTaskWatchdog will increment enough to also force
* a reboot.  Finally, a call to WWDG_HariKiri() also stops petting which
* forces a reboot as well.
*******************************************************************************/
static void PetWatchdog(void)
{
#ifdef WWDG_ENABLED
   MainTaskWatchdog++ ;
   if (MainTaskWatchdog>MAINTASKWDG_LIMIT) HariKiri = true ;

   if (!HariKiri) HAL_WWDG_Refresh(&hwwdg1) ;
#endif
}

/*******************************************************************************
* Routine  : RebootNow
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine reboots the Voter2 right away.  I used to use the watchdog, but
* the NVIC is simpler and more direct, so this routing got pretty trivial.
* The call to NVIC_SystemReset() does not return.
*******************************************************************************/
void RebootNow(void)
{
   NVIC_SystemReset();
}

/*******************************************************************************
* Routine  : ReportFlag
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This is a debugging routine called by my low level sequencer.  This is very
* transient code depending on what I'm debugging at this moment.
*
* This is clearly code for targeted debugging, not general purpose.
*******************************************************************************/
static void ReportFlag(void)
{
   static uint8_t LastFlag3 = 0 ;

   /* This ought to become a general purpose function, not a debugging flag */
   if (0!=Flags[0])
   {
      if (1==Flags[0]) Logger2_Msg(Logger.MainApp,LOG_MAJOR,LOG_TIME,"Flag 0 = 1: GPS lost\r\n") ;
      if (2==Flags[0]) Logger2_Msg(Logger.MainApp,LOG_MAJOR,LOG_TIME,"Flag 0 = 2: GPS restored\r\n") ;
      Flags[0] = 0 ;
   }

   if (0!=Flags[1])
   {
      Logger2_Msg(Logger.Console,LOG_MAJOR,LOG_TIME,"Flag 1 = %d\r\n",Flags[1]) ;
      Flags[1] = 0 ;
   }

   if (0!=Flags[2])
   {
      Logger2_Msg(Logger.MainApp,LOG_SUPPORT,LOG_TIME,"Timer : 1PPS: %d\r\n",HAL_GPIO_ReadPin(GPS_1PPS_GPIO_Port,GPS_1PPS_Pin)) ;
   }

   if (LastFlag3!=Flags[3])
   {
      Logger2_Msg(Logger.Console,LOG_MAJOR,LOG_TIME,"Flag 3 = %d\r\n",Flags[3]) ;
      LastFlag3 = Flags[3] ;
   }

}
