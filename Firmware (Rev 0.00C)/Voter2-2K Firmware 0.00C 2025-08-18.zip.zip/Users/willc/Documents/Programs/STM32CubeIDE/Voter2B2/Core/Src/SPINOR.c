/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the SPINOR file.  It is in charge of the offline SPI NOR device.   */
/* That is, the secondary NOR flash that isn't memory mapped.  It currently   */
/* has three functions:                                                       */
/*  - Storing/checking firmware updates locally before programming the main   */
/*    XIP flash.                                                              */
/*  - Storing OTP information like serial number and MAC address.             */
/*  - Dave's 7330 audio data for his functions.                               */
/* For the first two functions, the smaller MX25L3233E (4MByte) is fine.      */
/* For the 7330 audio, the larger MX25L25645G (32MByte) is needed.            */
/* This code will support both devices and determines the device on the fly.  */
/*                                                                            */
/* The reason for using a separate flash for storing code updates is that it  */
/* is very hard to program a flash that you are also executing code from, and */
/* we are executing code directly from the main flash.  It can be done, but   */
/* is very messy, error prone, etc., so not worth it.                         */
/*                                                                            */
/* Note that the 4MByte part uses 24-bit addressing while the 32MByte part    */
/* uses 32-bit addressing, so there is some extra decision making in the      */
/* lowest level drivers.                                                      */
/*                                                                            */
/* Also note that SPINOR reads and writes use DMA, so buffers passed to those */
/* routines must be in DMA-able space.                                        */
/*                                                                            */
/* Finally, the read code needs rewriting to be HAL-less as I need to be able */
/* to do a software update of both the XIP flash and internal flash meaning   */
/* code in there will be unexecutable.                                        */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - SPINOR_Init  - Identify and set up the SPI NOR for IO.                  */
/*  - SPINOR_read  - Read a range of memory.                                  */
/*  - SPINOR_erase - Erase a sector or whole device.                          */
/*  - SPINOR_write - Write a sector                                           */
/*  * SPINOR_ReadOTP  - Read OTP data                                         */
/*  * SPINOR_WriteOTP - Write OTP data                                        */
/*  * SPINOR_LockOTP  - Lock OTP                                              */
/*                                                                            */
/*   (*) Not written yet!                                                     */
/*                                                                            */
/******************************************************************************/
// TO DO:
// - Is PIO mode OK for commands under RTOS.  Data isn't.
// - Erase sizes other than 4K sectors?

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "cmsis_os.h"

#include "Options.h"
#include "main.h"
#include "Settings.h"
#include "logger2rt.h"
#include "gpio.h"
#include "SPINOR.h"
#include "MX25Lxx.h"

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
#define CS_INACTIVE 0
#define CS_ACTIVE 1

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
int SPINOR_Type = SPINOR_NONE ; /* Gets filled in by SPINOR_Init */

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/

/******************************************************************************/
/* External globals. How CubeMX does things instead of in an include file,    */
/* weird.                                                                     */
/******************************************************************************/
extern SPI_HandleTypeDef hspi3;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void SpiNor_cmd_PIO (uint8_t* cmd, int len,int cs_end) ;
static void SpiNor_Read_PIO(uint8_t* buf,int len,int cs_end) ;
static void SPI_WritePage(uint32_t,uint32_t,uint8_t*);
static void Poll_WIP(void) ;

/******************************************************************************/
/* Routines                                                                   */
/******************************************************************************/

/*******************************************************************************
* Routine  : SPINOR_Init
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine gets called after the MX_SPI3_Init() routine that sets up the
* SPI interface.  This resets SPI NOR chip (there is no hardware reset line)
* and reads the Chip ID so we know what size device we are working with.
* NOTE: This is called before the RTOS, so no RTOS APIs (eg. delays)
*******************************************************************************/
void SPINOR_Init(void)
{
   uint8_t cmd[4]    = {0} ; /* Command buffer     */
   uint8_t ChipID[2] = {0} ; /* ID read from flash */

   /* First, send the reset command--well really reset enable, then the reset */
   /* command!                                                                */
   cmd[0]= RESET_ENABLE_CMD ;
   SpiNor_cmd_PIO(cmd,1,CS_INACTIVE) ;
   cmd[0]= RESET_MEMORY_CMD ;
   SpiNor_cmd_PIO(cmd,1,CS_INACTIVE) ;
   HAL_Delay(1) ; /* Reset takes 20-ish us, need a delay, 1ms is overkill     */

   /* Now that we have the NOR's attention (parent joke), read the Chip ID.   */
   cmd[0]= READ_IDS_CMD ; /* 2nd-4th bytes already 0 */
   SpiNor_cmd_PIO (cmd,4,CS_ACTIVE) ;
   SpiNor_Read_PIO(ChipID,2,CS_INACTIVE) ;

   /* Log the chip ID data if in Regio mode */
   Logger2_Msg(Logger.SpiNor,LOG_REGIO,LOG_TIME,"SPINOR REMS Info: 0x%2.2x, 0x%2.2x\n",ChipID[0],ChipID[1]) ;

   /* Note the device type in global SPINOR_Type for other code to know.      */
   /* Also log the part numbers in support mode, or as major event if no match*/
   if ((MACRONIX_MFR_ID==ChipID[0])&&(MX25L3233_DEVICE_ID==ChipID[1]))
   {
      Logger2_Msg(Logger.SpiNor,LOG_SUPPORT,LOG_TIME,"SPINOR Device: MX25L3233\n") ;
      SPINOR_Type = SPINOR_MX25L3233 ;
   }
   else if ((MACRONIX_MFR_ID==ChipID[0])&&(MX25L25645_DEVICE_ID==ChipID[1]))
   {
      Logger2_Msg(Logger.SpiNor,LOG_SUPPORT,LOG_TIME,"SPINOR Device: MX25L25645\n") ;
      SPINOR_Type = SPINOR_MX25L25645 ;
   }
   else
   {
      Logger2_Msg(Logger.SpiNor,LOG_MAJOR,LOG_TIME,"SPINOR Device Missing/unrecognized!\n") ;
   }
}

/*******************************************************************************
* Routine  : SpiNor_cmd_PIO
* Gazintas : cmd - Command to send
*          : len - length of command
*          : cs_end - CS state after command sent
* IOs      : None
* Returns  : Nothing, can't fail!
* Globals  : None
*
* This routine sends a command to the SPI flash.  It assume CS was de-asserted,
* asserts it, sends the command if if cs_end is set to CS_INACTIVE,de-asserts
* CS afterwards. This uses PIO mode, but should be OK for both pre-RTOS and
* RTOS.
*******************************************************************************/
static void SpiNor_cmd_PIO(uint8_t* cmd, int len,int cs_end)
{
   SPIFLASH_CS_ASSERT ;                            /* assert CS               */
   HAL_SPI_Transmit(&hspi3,cmd,len,10) ;           /* send command byte(s)    */
   if (CS_INACTIVE==cs_end) SPIFLASH_CS_DEASSERT ; /* optionally de-assert CS */
}

/*******************************************************************************
* Routine  : SpiNor_Read_PIO
* Gazintas : buf - Pointer for received data
*          : len - length of data to read
*          : cs_end - CS state after read complete
* IOs      : None
* Returns  : Nothing, can't fail!
* Globals  : None
*
* This routine reads data back from the SPI flash.  It assumes the command for
* what to read has already been sent and this now reads in the data.
* This uses PIO mode and should be used for pre-RTOS only.  For bigger reads
* RTOS rescheduling messes things up.
*******************************************************************************/
static void SpiNor_Read_PIO(uint8_t* buf,int len,int cs_end)
{
   HAL_SPI_Receive(&hspi3,buf,len,10) ;
   if (CS_INACTIVE==cs_end) SPIFLASH_CS_DEASSERT ; /* optionally de-assert CS */
}

/*******************************************************************************
* Routine  : SpiNor_erase
* Gazintas : size - size flag, ERASE_SECTOR or ERASE_ALL
*          : addr - address in the 4K sector to be erased (ignored for erase all)
* IOs      : None
* Returns  : Nothing, can't fail!
* Globals  : None
*
* This routine erases a 4K sector or the whole device.  It sends the write
* enable command, then the erase command and waits for it to finish before
* returning.
* NOTE: With logging on, I also note when done so you can see erase times.
* NOTE: I only support sector erase and device erase.  Looking at the datasheet,
*       the time savings for 32K, 64K and whole-chip are only slightly faster
*       all-in, so this is more for convenience over speed.
*******************************************************************************/
void SpiNor_erase(int size,uint32_t addr)
{
   uint8_t cmd[5] = {0} ; /* Buffer for the whole flash command */

   Logger2_Msg(Logger.SpiNor,LOG_REGIO,LOG_TIME,"SPINOR Erase: 0x%8.8x\n",addr) ;

   /* Send the write enable command first */
   cmd[0] = WRITE_ENABLE_CMD ;
   SpiNor_cmd_PIO(cmd,1,CS_INACTIVE) ;

   if (ERASE_SECTOR==size)
   {
      if (SPINOR_MX25L3233==SPINOR_Type) /* 3-byte addressing */
      {
         /* The sector erase command with the target address */
         cmd[0] = SECTOR_ERASE_4KB_CMD ;
         cmd[1] = (addr>>16)&0xff ;
         cmd[2] = (addr>> 8)&0xff ;
         cmd[3] = (addr    )&0xff ;

         /* Send the command! */
         SpiNor_cmd_PIO (cmd,4,CS_INACTIVE) ;
      }
      else /* MX25L25645 with 4-byte addressing */
      {
         /* The sector erase command with the target address */
         cmd[0] = SECTOR_ERASE4B_4KB_CMD   ;
         cmd[1] = (addr>>23)&0xff ;
         cmd[2] = (addr>>16)&0xff ;
         cmd[3] = (addr>> 8)&0xff ;
         cmd[4] = (addr    )&0xff ;

         /* Send the command! */
         SpiNor_cmd_PIO (cmd,5,CS_INACTIVE) ;
      }
   }
   else if (ERASE_ALL==size)
   {
      /* For chip erase it is the same command for either chip type */
      cmd[0] = CHIP_ERASE_CMD ;

      /* Send the command! */
      SpiNor_cmd_PIO (cmd,1,CS_INACTIVE) ;
   }

   /* Wait for the erase to complete and note the time if in regio mode. */
   Poll_WIP() ;
   Logger2_Msg(Logger.SpiNor,LOG_REGIO,LOG_TIME,"SPINOR Erase: Done\n") ;
}

/*******************************************************************************
* Routine  : SpiNor_read
* Gazintas : buf - pointer to buffer to be filled with the read
*          :       NOTE!!  This must be in DMA-able space!!
*          : addr - flash address to start reading from
*          : len - number of bytes to read
* IOs      : None
* Returns  : Nothing, can't fail!
* Globals  : None
*
* This routine reads up to 64Kbytes of data from flash starting at any arbitrary
* address, the flash handles arbitrary addressing nicely.  The reason for a 64K
* limit is the STM32 DMA, not the flash.
*******************************************************************************/
void SpiNor_read(uint8_t* buf,uint32_t addr, uint32_t len)
{
   uint8_t cmd[5] = {0} ; /* Buffer for the whole read command */

   Logger2_Msg(Logger.SpiNor,LOG_REGIO,LOG_TIME,"SPINOR  Read: 0x%8.8x len %d\n",addr,len) ;

   /* if a bad size, hang! (for catching during debug) */
   if (len>0xffff) while (1) ;

   if (SPINOR_MX25L3233==SPINOR_Type) /* 3-byte addressing */
   {
      /* The read command with the target address */
      cmd[0] = READ_DATA_CMD   ;
      cmd[1] = (addr>>16)&0xff ;
      cmd[2] = (addr>> 8)&0xff ;
      cmd[3] = (addr    )&0xff ;

      /* Send the command (PIO mode here) */
      SpiNor_cmd_PIO (cmd,4,CS_ACTIVE) ;
   }
   else /* MX25L25645 with 4-byte addressing */
   {
      /* The read command with the target address */
      cmd[0] = READ4B_DATA_CMD ;
      cmd[1] = (addr>>24)&0xff ;
      cmd[2] = (addr>>16)&0xff ;
      cmd[3] = (addr>> 8)&0xff ;
      cmd[4] = (addr    )&0xff ;

      /* Send the command (PIO mode here) */
      SpiNor_cmd_PIO (cmd,5,CS_ACTIVE) ;
   }

   /* Read the data using DMA */
   HAL_SPI_Receive_DMA(&hspi3,buf,len) ;

   /* I may do call-backs later, but for now just poll for done */
   while (HAL_SPI_GetState(&hspi3)!=HAL_SPI_STATE_READY ) ;

   /* All done, de-assert CS */
   SPIFLASH_CS_DEASSERT ;
}

/*******************************************************************************
* Routine  : SpiNor_write
* Gazintas : buffer - pointer to buffer to be written to flash
*          :       NOTE!!  This must be in DMA-able space!!
*          : Address - flash address to start writing to
*          : Size - number of bytes to write
* IOs      : None
* Returns  : Nothing, can't fail!
* Globals  : None
*
* This routine writes an arbitrary number of bytes to an arbitrary address in
* flash.  It does assume the target memory had been fully erased before hand.
* Flash writes are limited to 256-byte pages, so this routine breaks the write
* into pages, also handling possible short pages as well.
* NOTE: Since writes are broken into pages, no 64K DMA limit like reads.
* NOTE: With logging on, I also note when done so you can see flash write times.
*******************************************************************************/
void SpiNor_write(uint8_t* buffer,uint32_t Address, uint32_t Size)
{
   uint32_t PageStartAddr =  0   ; /* Starting address of the page to write */
   uint32_t PgmStartAddr  =  0   ; /* Starting address to write (may be after page start) */
   uint32_t PageEndAddr   =  0   ; /* Address at the end of the page */
   uint32_t BytesWritten  =  0   ; /* Bytes written so far */
   uint32_t BytesToWrite  =  0   ; /* Bytes to write in the page */
   uint8_t* BuffToWrite   = NULL ; /* part of the buffer to write */

   Logger2_Msg(Logger.SpiNor,LOG_REGIO,LOG_TIME,"SPINOR Write: 0x%8.8x len %d\n",Address,Size) ;

   PgmStartAddr = Address ; /* the place to start! */
   BuffToWrite  = buffer ;


   /* The code blow is super-dense (and took MANY iterations), but in one     */
   /* piece of loop code handles short pages at both the start and end of a   */
   /* range and even a few bytes in the middle of a page!  It even handles    */
   /* the boundary case of 0 size. Proud of it!                               */
   while (BytesWritten<Size)
   {
      PageStartAddr = PgmStartAddr - PgmStartAddr%QSPI_PAGE_SIZE   ;
      PageEndAddr   = PageStartAddr + QSPI_PAGE_SIZE -1 ;
      BytesToWrite  = PageEndAddr - PgmStartAddr + 1 ;
      if (BytesToWrite>(Size-BytesWritten)) BytesToWrite = Size-BytesWritten ;

      SPI_WritePage(PgmStartAddr, BytesToWrite,BuffToWrite);

      PgmStartAddr += BytesToWrite ;
      BytesWritten += BytesToWrite ;
      BuffToWrite  += BytesToWrite ;
   }

   /* All done, not ending time if in regio mode. */
   Logger2_Msg(Logger.SpiNor,LOG_REGIO,LOG_TIME,"SPINOR Write: Done\n") ;
}

/*******************************************************************************
* Routine  : SPI_WritePage
* Gazintas : addr - flash address to start writing to
*          : len - number of bytes to write
*          : buf - pointer to buffer to be written to flash
* IOs      : None
* Returns  : Nothing, can't fail!
* Globals  : None
*
* SpiNor_write breaks a big write into pages, this routine writes the actual
* page to the flash.  It can be any starting address and length as long as it
* is fully contained within one 256-byte page.  SpiNor_write does all that,
* this just does the programming.
*******************************************************************************/
static void SPI_WritePage(uint32_t addr,uint32_t len,uint8_t* buf)
{
   uint8_t cmd[5] = {0} ; /* Buffer for the whole write command */

   /* Send the write enable command first */
   cmd[0] = WRITE_ENABLE_CMD ;
   SpiNor_cmd_PIO(cmd,1,CS_INACTIVE) ;

   if (SPINOR_MX25L3233==SPINOR_Type) /* 3-byte addressing */
   {
      /* Now send the data write command followed by the data */
      cmd[0] = PAGE_PROG_CMD   ;
      cmd[1] = (addr>>16)&0xff ;
      cmd[2] = (addr>> 8)&0xff ;
      cmd[3] = (addr    )&0xff ;
      SpiNor_cmd_PIO(cmd,4,CS_ACTIVE) ;
   }
   else /* MX25L25645 with 4-byte addressing */
   {
      /* Now send the data write command followed by the data */
      cmd[0] = PAGE_PROG4B_CMD ;
      cmd[1] = (addr>>24)&0xff ;
      cmd[2] = (addr>>16)&0xff ;
      cmd[3] = (addr>> 8)&0xff ;
      cmd[4] = (addr    )&0xff ;
      SpiNor_cmd_PIO(cmd,5,CS_ACTIVE) ;
   }

   /* Send the data using DMA */
   HAL_SPI_Transmit_DMA(&hspi3,buf,len) ;

   /* I may do call-backs later, for now just poll for done */
   while (HAL_SPI_GetState(&hspi3)!=HAL_SPI_STATE_READY ) ;

   /* De-assert CS and poll for writing to be complete. */
   SPIFLASH_CS_DEASSERT ;
   Poll_WIP() ;
}

/*******************************************************************************
* Routine  : Poll_WIP
* Gazintas : None
* IOs      : None
* Returns  : Nothing, can't fail!
* Globals  : None
*
* This routine polls the flash status register waiting for the WIP (Write In
* Progress) bit to clear, indicating a write or erase has completed.
* The chip supports continuous reads (not re-sending the read command) so it
* could be improved a little.
*
* For polling an erase cycle, this can take upwards of a few minutes!  By
* design the maintask that pets the watchdog is the lowest priority task, so
* if this runs without a break maintask will get starved and cause a watchdog
* reset.  If the polling takes more than 250ms, I introduce a delay so maintask
* (and any other tasks) can get attention.
*******************************************************************************/
static void Poll_WIP(void)
{
   uint8_t cmd[4] = {0} ; /* Buffer for the whole command */
   uint8_t result =  0  ; /* Polling result               */
   uint32_t alarm =  0  ; /* Timer alarm                  */

   /* Set an alarm for 250ms from now */
   alarm = HAL_GetTick()+250 ;

   do
   {
      if (HAL_GetTick()>alarm)
      {
         osDelay(5) ;
         alarm +=250 ;
      }

      /* Read Status register */
      cmd[0]=READ_SR_CMD ;
      SpiNor_cmd_PIO (cmd,1,CS_ACTIVE) ;
      SpiNor_Read_PIO(&result,1,CS_INACTIVE) ;
   }
   while (result&0x01) ;
}

/*******************************************************************************
* Routine  : SpiNor_readOTP
* Gazintas : buffer - pointer to buffer to be filled with the read
*          :       NOTE!!  This must be in DMA-able space!!
*          : addr - OTP address to start reading from
*          : len - number of bytes to read
* IOs      : None
* Returns  : Nothing, can't fail!
* Globals  : None
*
* This routine reads from the OTP space of the SPINOR flash.  This is 4Kbits or
* 512 bytes.  Reading OTP involves doing a "context swap" to OTP space, then a
* regular read (which now reads from OTP space), then a context swap back to
* regular memory space.
*******************************************************************************/
void SpiNor_readOTP(uint8_t* buffer,uint32_t addr, uint32_t len)
{
   uint8_t cmd[4] = {0} ; /* Command Buffer */

   Logger2_Msg(Logger.SpiNor,LOG_REGIO,LOG_TIME,"SPINOR  ReadOTP: 0x%8.8x len %d\n",addr,len) ;

   /* Enter OTP mode first */
   cmd[0]= ENTER_OTP_MODE_CMD ;
   SpiNor_cmd_PIO(cmd,1,CS_INACTIVE) ;

   /* Do the regular read (but now its OTP space) */
   SpiNor_read(buffer,addr,len) ;

   /* Then exit OTP mode */
   cmd[0]= EXIT_OTP_MODE_CMD ;
   SpiNor_cmd_PIO(cmd,1,CS_INACTIVE) ;
}

/*******************************************************************************
* Routine  : SpiNor_writeOTP
* Gazintas : buffer - pointer to buffer to be written to flash
*          :       NOTE!!  This must be in DMA-able space!!
*          : Address - OTP address to start writing to
*          : Size - number of bytes to write
* IOs      : None
* Returns  : Nothing, can't fail!
* Globals  : None
*
* This routine writes to the OTP space of the SPINOR flash.  This is 4Kbits or
* 512 bytes.  Writing OTP involves doing a "context swap" to OTP space, then a
* regular write (which now writes to OTP space), then a context swap back to
* regular memory space.
*******************************************************************************/
void SpiNor_writeOTP(uint8_t* buffer,uint32_t Address, uint32_t Size)
{
   uint8_t cmd[4] = {0} ; /* Command Buffer */

   /* Enter OTP mode first */
   cmd[0]= ENTER_OTP_MODE_CMD ;
   SpiNor_cmd_PIO(cmd,1,CS_INACTIVE) ;

   /* Do the regular write (but now its OTP space) */
   SpiNor_write(buffer,Address,Size) ;

   /* Then exit OTP mode */
   cmd[0]= EXIT_OTP_MODE_CMD ;
   SpiNor_cmd_PIO(cmd,1,CS_INACTIVE) ;
}

/*******************************************************************************
* Routine  : SpiNor_lockOTP
* Gazintas : None
* IOs      : None
* Returns  : Nothing, can't fail!
* Globals  : None
*
* This routine sends the command sequence to lock OTP space.
* Not doing it yet.
*******************************************************************************/
void SpiNor_lockOTP(void)
{
   uint8_t cmd    = 0 ; /* Command Buffer */
   uint8_t result = 0 ; /* Read buffer    */

   Logger2_Msg(Logger.SpiNor,LOG_REGIO,LOG_TIME,"SPINOR Locking OTP...\n") ;

   /* Read Security register back to confirm */
   cmd = READ_SECURITY_REG_CMD ;
   SpiNor_cmd_PIO (&cmd,1,CS_ACTIVE) ;
   SpiNor_Read_PIO(&result,1,CS_INACTIVE) ;

   Logger2_Msg(Logger.SpiNor,LOG_REGIO,LOG_TIME,"SPINOR Security Reg before 0x%2.2x\n",result) ;

   /* Send the write enable command first */
   cmd = WRITE_ENABLE_CMD ;
   SpiNor_cmd_PIO(&cmd,1,CS_INACTIVE) ;

   /* Write the security register (no data!) */
   /* This locks OTP.                        */
   cmd = WRITE_SECURITY_REG_CMD ;
   SpiNor_cmd_PIO(&cmd,1,CS_INACTIVE) ;

   /* The write security register execution time is 1ms, so wait a bit before */
   /* checking to see if it got written.                                      */
   osDelay(5) ;

   /* Read Security register back to confirm */
   cmd = READ_SECURITY_REG_CMD ;
   SpiNor_cmd_PIO (&cmd,1,CS_ACTIVE) ;
   SpiNor_Read_PIO(&result,1,CS_INACTIVE) ;

   Logger2_Msg(Logger.SpiNor,LOG_REGIO,LOG_TIME,"SPINOR Security Reg after 0x%2.2x\n",result) ;

   if (result&0x02)
   {
      Logger2_Msg(Logger.SpiNor,LOG_REGIO,LOG_TIME,"SPINOR OTP Locked\n") ;
   }
   else
   {
      Logger2_Msg(Logger.SpiNor,LOG_REGIO,LOG_TIME,"SPINOR OTP didn't lock!\n") ;
   }
}
