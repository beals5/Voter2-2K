#ifndef RSSIFILTER_H_
#define RSSIFILTER_H_

/* For filter Try # */
#define RSSIFILTER1
//#define RSSIFILTER2
//#define RSSIFILTER3

/* RSSIFILTER1: A simple 0-gain to 2400Hz, then 1-gain at 2800+Hz.  After     */
/*              the others, this seems the best after all.  It's system gain  */
/*              rolls off in the passband due to the rolloff of the Nyquist   */
/*              filter, which is why I was trying out the two next filters.   */
/* RSSIFILTER2: 0-gain to 2400Hz, 1-gain at 2900Hz, 5-gain at 2900Hz.         */
/*              This was the first attempt to add some slope to the passband  */
/*              in order to compensate for the attenuation of the Nyquist     */
/*              filter.  The theory was good, but in practice the filter      */
/*              produced huge fluctuations, almost like it was unstable.  It  */
/*              isn't, so thinking maybe adding gain at the top of the Nyquist*/
/*              frequency when the analog filter is still allowing frequencies*/
/*              above the sample frequency may be doing weird things.  It     */
/*              didn't work, so sticking with RSSFILTER1.                     */
/* RSSIFILTER3: 0-gain to 2400Hz, 1-gain at 2900Hz, 9-gain at 2900Hz.         */
/*              More gain at higher frequencies while I was experimenting     */
/*              before realizing added gain here was hurting instead of       */
/*              helping.                                                      */

#ifdef RSSIFILTER1

/*

FIR filter designed with
http://t-filter.engineerjs.com/

sampling frequency: 8000 Hz

fixed point precision: 16 bits

* 0 Hz - 2400 Hz
  gain = 0
  desired attenuation = -40 dB
  actual attenuation = n/a

* 2800 Hz - 4000 Hz
  gain = 1
  desired ripple = 5 dB
  actual ripple = n/a

*/

#define RSSIFILTER_TAP_NUM 23

/******************************************************************************/
/* If using the CMSIS DSP library, we don't need any of the structures and    */
/* routines below, just the coefficient table.                                */
/******************************************************************************/

extern int16_t rssi_filter_taps[] ;

#ifndef USE_CMSIS_DSP

typedef struct {
  int16_t history[RSSIFILTER_TAP_NUM];
  unsigned int last_index;
} RSSIFilter;

void RSSIFilter_init(RSSIFilter* f);
void RSSIFilter_put(RSSIFilter* f, int16_t input);
int16_t RSSIFilter_get(RSSIFilter* f);

#endif
#endif

#ifdef RSSIFILTER2

/*

FIR filter designed with
http://t-filter.engineerjs.com/

sampling frequency: 8000 Hz

fixed point precision: 16 bits

* 0 Hz - 2400 Hz
  gain = 0
  desired attenuation = -40 dB
  actual attenuation = n/a

* 2800 Hz - 3000 Hz
  gain = 1
  desired ripple = 5 dB
  actual ripple = n/a

* 3500 Hz - 4000 Hz
  gain = 5
  desired ripple = 5 dB
  actual ripple = n/a

*/

#define RSSIFILTER_TAP_NUM 25

typedef struct {
  int32_t history[RSSIFILTER_TAP_NUM];
  unsigned int last_index;
} RSSIFilter;

void RSSIFilter_init(RSSIFilter* f);
void RSSIFilter_put(RSSIFilter* f, int32_t input);
int32_t RSSIFilter_get(RSSIFilter* f);

#endif

#ifdef RSSIFILTER3

/*

FIR filter designed with
http://t-filter.engineerjs.com/

sampling frequency: 8000 Hz

fixed point precision: 16 bits

* 0 Hz - 2400 Hz
  gain = 0
  desired attenuation = -40 dB
  actual attenuation = n/a

* 2800 Hz - 3000 Hz
  gain = 1
  desired ripple = 5 dB
  actual ripple = n/a

* 3500 Hz - 4000 Hz
  gain = 8
  desired ripple = 5 dB
  actual ripple = n/a

*/

#define RSSIFILTER_TAP_NUM 27

typedef struct {
  int16_t history[RSSIFILTER_TAP_NUM];
  unsigned int last_index;
} RSSIFilter;

void RSSIFilter_init(RSSIFilter* f);
void RSSIFilter_put(RSSIFilter* f, int16_t input);
int16_t RSSIFilter_get(RSSIFilter* f);

#endif

#endif

