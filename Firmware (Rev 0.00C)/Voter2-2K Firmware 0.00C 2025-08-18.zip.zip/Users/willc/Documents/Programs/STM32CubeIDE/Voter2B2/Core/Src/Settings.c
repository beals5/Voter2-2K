/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Settings file.  It manages all the settings for the Voter2.    */
/* This includes reading them from NVM and writing them to NVM.               */
/* Note that we need to read NVM before the RTOS starts as there are some     */
/* parameters that need to be there as part of the RTOS startup.  Hence the   */
/* NVM read function supports both pre-RTOS and in-RTOS modes.                */
/* As the temperature sensor shares the I2C bus with NVM, support for it is   */
/* here too.  This code mostly runs as a client of the ConsoleTask.           */
/******************************************************************************/
/* Data is stored in NVM using a TLV (Tag, Length, Value) structure to more   */
/* gracefully handle new variables getting added or removed.  Additionally,   */
/* the first four bytes have a magic number to identify both a virgin NVM as  */
/* well as an interrupted write.  That is, the magic number is "broken"       */
/* before an NVM update starts, then is fixed after the update is complete.   */
/* A third Magic Number indicates factory reset, if that number is present on */
/* boot-up, the NVM is restored to factory defaults.                          */
/* The Tag of the TLV is now two fields.  The first byte is a group ID to     */
/* segregate by groups that may or may not be present.  Then, for each group  */
/* the tag is the ID for that setting within the group.  The groups are:      */
/*  - Group 0 - TGRP_COMMON: Common settings for any Voter2 flavor.           */
/*  - Group 1 - TGRP_LOCAL: Default local mode settings (others possible)     */
/*  - Group 2 - TGRP_ASTERISK: Asterisk (DIAL) server settings (optional)     */
/*  - Group 3 - TGRP_7330: For Dave's repeater controller mode (future)       */
/*  - Groups 4-255 - Future expansion.                                        */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Settings_init - (pre-RTOS) Read settings from NVM                       */
/*  - Cmd_settings - (RTOS) CLI routine for settings.                         */
/*  - Settings_clear - Corrupts NVM for a factory reset                       */
/*  - Waiton_I2C_DMA - wait on DMA (Shared with temperature sensing)          */
/*  - write_tlv_str - Write TLV to NVM for a string.                          */
/*  - write_tlv_i4 - Write TLV to NVM for a 32-bit integer                    */
/*  - write_tlv_i2 - Write TLV to NVM for a 16-bit integer                    */
/*  - write_tlv_i1 - Write TLV to NVM for an 8-bit integer                    */
/*                                                                            */
/******************************************************************************/
// TO DO:
//  - Don't need NULL at the end of the parameter table.

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <stdbool.h>
#include <string.h>

#include "cmsis_os.h"

#include "main.h"
#include "Options.h"
#include "Settings.h"
#include "logger2rt.h"
#include "ConsoleTask.h"
#include "DialTask.h"
#include "EthernetTask.h"
#include "Gpio.h"
#include "Settings.h"
#include "AnalogIO.h"
#include "Rx_DSP.h"
#include "Utils.h"
#include "SPINOR.h"

#ifdef LOCALVOTER
#include "LocalVoter/LocalSettings.h"
#endif

#ifndef NODIALTASK
#include "DialSettings.h"
#endif

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/

/* Basics on the NVM */
#define EEPROM_ADDRESS 0xa0 /* Shifted Address                        */
#define EEPROM_SIZE    8192 /* in bytes! Part number is usually bits  */
#define I2C_PAGESIZE     32 /* I2C chip page size                     */
#define MEMADDR_SIZE I2C_MEMADD_SIZE_16BIT /* 8 or 16-bit sub-address */

#define I2C_MAXPARAM (SETTINGS_FQDN_LEN+3) /* Biggest parameter to read/write (plus header) */
#define MAGICNUM_GOOD 0xbaadbeef /* NVM state - Contents Good */
#define MAGICNUM_PGM  0xabadcafe /* NVM state - program OTP   */
#define MAGICNUM_BAD  0xffffffff /* NVM state - Contents bad  */

/* For letting Settings_Reload know which mode we're in */
#define INRTOS true
#define PRERTOS false

/******************************************************************************/
/*  typedefs and enums                                                        */
/******************************************************************************/
enum
{
   CMD_OOPS = 0,
   CMD_SAVE,
   CMD_RELOAD,
   CMD_DUMP
} SETTING_ENUMS ;

/* WARNING!  When making changes below, don't change existing sequence        */
/* numbers!!  That will mess up T's in the TLV tables!                        */
enum
{
   TLVT_MYSTATICIP = 1,
   TLVT_MYSTATICSUBNET = 2,
   TLVT_MYSTATICGATEWAY = 3,
   TLVT_MYSTATICDNS = 4,
   TLVT_MYMACADDR = 5,
   TLVT_MYIPMODE = 6,
   TLVT_GUESTPASSWORD = 7,
   TLVT_ROOTPASSWORD = 8,

   TLVT_GPSBAUD = 9,
   TLVT_GPSEDGE = 10,

   TLVT_S2NPORT = 11,
   TLVT_S2NPTIME = 12,
   TLVT_TTONELVL = 13,
   TLVT_TTONEFREQ = 14,
   TLVT_RXMODE = 15,
   TLVT_RSSIMODE = 16,
   TLVT_MYNAME = 17,
   TLVT_TFTPADDR = 18,

   TLVT_MYSERIALNUM = 19,
   TLVT_MYHWREV = 20,

   /* no-more-tags tag */
   TLVT_ENDOFLINE = 0xff,
} SETTING_VALUE_TYPES ;

typedef struct
{
   uint8_t group ; /* Setting Group      */
   uint8_t type  ; /* Setting Type       */
   uint8_t len   ; /* Setting length     */
} SETTINGS_TLV ;

/******************************************************************************/
/* External globals. CubeMX has you define them as externs in each file       */
/* instead of an include file, weird.                                         */
/******************************************************************************/
extern I2C_HandleTypeDef hi2c1;
extern osThreadId ConsoleTaskIDHandle;

/******************************************************************************/
/* The Settings Structure, 0-initialized at boot.                             */
/* Setting "initialized" gets set to true once all params are loaded from NVM */
/* so other routines know when it is OK to use the settings structure.        */
/* Logger settings aren't saved, so just get reloaded on each boot.           */
/******************************************************************************/
SETTINGS        Settings = {0} ;
LOGGER_SETTINGS Logger   = {0} ;
uint8_t Flags[NFLAGS]    = {0} ;

char* cmd_settings_cmd  = "settings" ;
char* cmd_settings_help = "settings - save|reload|dump\n"
                          "  save   - saves current settings to NVM\n"
                          "  reload - discards current settings and reloads from NVM\n"
                          "  dump [start end] - dumps NVM. If no start/end, default is 0-255.\n"
                          "See Users Guide to reset to factory defaults.\n" ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static int          Glob_inRTOS  = false ;
static volatile int I2C_DMA_Busy = false ;

static TOKENLIST SettingCmds[] =
{
   {"save"  ,CMD_SAVE  },
   {"reload",CMD_RELOAD},
   {"dump"  ,CMD_DUMP  },
   {NULL    ,0         }
} ;

/* Shared buffer for data to be DMA'd over I2C */
static uint8_t i2c_dmabuf[I2C_PAGESIZE] IN_DMADD2 = {0} ;
static uint8_t OTPdata[16] IN_DMADD2 = {0} ;  /* The data to program in OTP */

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/
static int  Settings_save  (void) ;
static int  Settings_reload(int) ;
static int  Settings_dump  (int,char**) ;
static void write_magic    (uint32_t*,int) ;
static void write_i2cpaged (uint32_t ,uint8_t*,int) ;
static void get_i2cmem     (uint32_t*,int,uint8_t*,int) ;
static void get_tlv        (uint32_t*,uint8_t*,uint8_t*,uint8_t*,int) ;

/*******************************************************************************
* Routine  : Settings_init
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : All settings structures.
*
* This routine initializes the Settings structure, ideally from NVM.  If NVM is
* corrupt or un-initialized, then factory defaults are set instead.
*
* Settings themselves are in globally accessible structures.  Settings are
* stored in the NVM using a TLV structure.
*
* NOTE: Settings_init gets called pre-RTOS!
*******************************************************************************/
void Settings_init(void)
{
   int i = 0 ; /* Wiggle counter */

   /* Try loading from NVM first, use the pre-RTOS mode.  If the result is 0  */
   /* bytes read, that means NVM isn't initialized or corrupt, so set factory */
   /* defaults.                                                               */
   if (0==Settings_reload(PRERTOS))
   {
      Settings.My_StaticIP       = (192<<24) + (168<<16) + (  2<<8) + 226 ;
      Settings.My_StaticSubnet   = (255<<24) + (255<<16) + (255<<8) +   0 ;
      Settings.My_StaticGateway  = (192<<24) + (168<<16) + (  2<<8) +   1 ;
      Settings.My_StaticDNS      = (192<<24) + (168<<16) + (  2<<8) +   1 ;
      Settings.TFTP_Addr         = (192<<24) + (168<<16) + (221<<8) + 200 ;

      Settings.Initialized     = false ; /* gets changed below */
      Settings.My_IPMode       = MYIPMODE_DHCP ;
      Settings.Dirty           = true ;
      Settings.GPS_Baud        = 115200 ;
      Settings.GPS_PPSEdge     = GPS_1PPS_RISING ;
      Settings.S2N_Port        = 2000 ;
      Settings.S2N_PollTime    = 100 ;
      Settings.TTone_lvl       = TTONE_NONE ;
      Settings.TTone_freq      = 1000 ;
      Settings.RxMode          = RXMODE_COR ;
      Settings.RssiMode        = RSSI_ANALOG ;

      strcpy(Settings.Guest_Password, "password") ;
      strcpy(Settings.Root_Password,  "guru") ;
      memset(Settings.Voter_Name,0,SETTINGS_NAME_LEN) ;

      /* Now for the optional settings blocks */
#ifdef LOCALVOTER
      LocalSettingsInit() ;
#endif
#ifndef NODIALTASK
      DIALSettingsInit() ;
#endif

      /* All set, set this last to tell others finally ready */
      Settings.Initialized = true ;

      /* Rapid flash the heartbeat LED to show we loaded factory defaults */
      /* End at 10 so we exit with the LED off.                           */
     for (i=0;i<11;i++)
      {
         Show_State(HB_STATE,i&1) ;
         HAL_Delay(100) ;
      }
   }

   /* For Logger settings, just load the defaults on each boot. */
   Logger.Boot    = LOGINIT_BOOT      ; /* Logging trigger level             */
   Logger.MainApp = LOGINIT_MAINAPP   ; /* Logging mode for MainTask         */
   Logger.EthApp  = LOGINIT_ETHAPP    ; /* Logging mode for Ethernet app     */
   Logger.EthLWIP = LOGINIT_ETHLL_IO  ; /* Logging mode for Ethernet LWIP    */
   Logger.KSZ8081 = LOGINIT_KSZ8081   ; /* Logging mode for Ethernet PHY     */
   Logger.Console = LOGINIT_CONSOLE   ; /* Logging mode for ConsoleTask      */
   Logger.i2c     = LOGINIT_I2C       ; /* Logging mode for I2C drivers      */
   Logger.Dial    = LOGINIT_DIALTASK  ; /* Logging mode for DialTask         */
   Logger.GPS     = LOGINIT_GPSCODE   ; /* Logging mode for GPS drivers      */
   Logger.LogTel  = LOGINIT_LOGTELNET ; /* Logging mode for Logger Telnet    */
   Logger.Local   = LOGINIT_LOCAL     ; /* Logging mode for Local mode       */
   Logger.Ser2Net = LOGINIT_SER2NET   ; /* Logging mode for Ser2Net task     */
   Logger.SpiNor  = LOGINIT_SPINOR    ; /* Logging mode for SPI NOR drivers  */
   Logger.SpiMtr  = LOGINIT_SPIMTR    ; /* Logging mode for SPI Mtr interface*/
   Logger.Tftp    = LOGINIT_TFTP      ; /* Logging mode for TFTP interface   */

} ;

/*******************************************************************************
* Routine  : Settings_clear
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine effectively corrupts NVM by erasing the magic number.  On a
* reboot, Settings_init() will restore factory defaults.
*******************************************************************************/
void Settings_clear(void)
{
   uint32_t memaddr = 0 ; /* Incrementing I2C memory address */

   Glob_inRTOS = true    ; /* Set this for IRQs           */
   osSignalWait (0x01,0) ; /* clear out any older signals */

   write_magic (&memaddr,MAGIC_BAD) ; /* Tag NVM as invalid */
}

/*******************************************************************************
* Routine  : Cmd_settings
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command saves or reloads all the settings with NVM.  Note that settings
* are initially loaded before the RTOS starts.
*******************************************************************************/
int Cmd_settings(int argc, char* argv[])
{
   int error = false ; /* Parsing error flag */
   int Token = 0     ; /* Command token      */
   int bytes = 0     ; /* Bytes read/written */

   /* See which settings command */
   Token = parse_token(SettingCmds,argv[1],&error) ;

   if (error)
   {
      Console_printf("First parameter must be save, reload, or dump.\n") ;
   }
   else
   {
      switch(Token)
      {
         case CMD_SAVE  : bytes=Settings_save()          ; break ;
         case CMD_RELOAD: bytes=Settings_reload(INRTOS)  ; break ;
         case CMD_DUMP  : bytes=Settings_dump(argc,argv) ; break ;
         default        : /* Shouldn't happen */           break ;
      }
      Console_printf("Done. %d bytes read/written.\n",bytes) ;
   }

   return (0) ;
}

/*******************************************************************************
* Routine  : Settings_save
* Gazintas : None
* IOs      : None
* Returns  : Bytes written to NVM.
* Globals  : Settings - the settings structure. (plus other optional settings)
*
* This routine saves the Settings structures to NVM.  Before starting, delete
* the magic number to say contents are untrustable, then after writes are
* complete, put the magic number back to say they're valid.
*******************************************************************************/
static int Settings_save(void)
{
   uint32_t memaddr  = 0             ; /* Incrementing I2C memory address */
   uint32_t fixaddr  = 0             ; /* Just for the magic number fix   */
   uint32_t MagicNum = MAGICNUM_GOOD ; /* Just a magic number             */
 
   /* Saving settings is for root only, not guest */
   if (!RootMode)
   {
      Console_printf("Sorry, this command isn't available in guest mode.\n") ;
   }
   else
   {
      Glob_inRTOS = true    ; /* Set this for IRQs           */
      osSignalWait (0x01,0) ; /* clear out any older signals */
 
      write_magic  (&memaddr,MAGIC_BAD)                                                   ; /* Tag NVM as invalid first */
      write_tlv_i4 (&memaddr,TGRP_COMMON,TLVT_MYSTATICIP     ,&Settings.My_StaticIP     ) ;
      write_tlv_i4 (&memaddr,TGRP_COMMON,TLVT_MYSTATICSUBNET ,&Settings.My_StaticSubnet ) ;
      write_tlv_i4 (&memaddr,TGRP_COMMON,TLVT_MYSTATICGATEWAY,&Settings.My_StaticGateway) ;
      write_tlv_i4 (&memaddr,TGRP_COMMON,TLVT_MYSTATICDNS    ,&Settings.My_StaticDNS    ) ;
      write_tlv_i4 (&memaddr,TGRP_COMMON,TLVT_TFTPADDR       ,&Settings.TFTP_Addr       ) ;
      write_tlv_i4 (&memaddr,TGRP_COMMON,TLVT_GPSBAUD        ,&Settings.GPS_Baud        ) ;

    //write_tlv_str(&memaddr,TGRP_COMMON,TLVT_MYMACADDR      ,&Settings.MyMACAddr,6     ) ;
      write_tlv_i1 (&memaddr,TGRP_COMMON,TLVT_MYIPMODE       ,&Settings.My_IPMode       ) ;
      write_tlv_i1 (&memaddr,TGRP_COMMON,TLVT_GPSEDGE        ,&Settings.GPS_PPSEdge     ) ;
      write_tlv_i2 (&memaddr,TGRP_COMMON,TLVT_S2NPORT        ,&Settings.S2N_Port        ) ;
      write_tlv_i2 (&memaddr,TGRP_COMMON,TLVT_S2NPTIME       ,&Settings.S2N_PollTime    ) ;

      write_tlv_str(&memaddr,TGRP_COMMON,TLVT_GUESTPASSWORD  ,&Settings.Guest_Password ,SETTINGS_PASSWORD_LEN ) ;
      write_tlv_str(&memaddr,TGRP_COMMON,TLVT_ROOTPASSWORD   ,&Settings.Root_Password  ,SETTINGS_PASSWORD_LEN ) ;
      write_tlv_str(&memaddr,TGRP_COMMON,TLVT_MYNAME         ,&Settings.Voter_Name     ,SETTINGS_NAME_LEN     ) ;

      write_tlv_i2 (&memaddr,TGRP_COMMON,TLVT_TTONELVL       ,&Settings.TTone_lvl        ) ;
      write_tlv_i2 (&memaddr,TGRP_COMMON,TLVT_TTONEFREQ      ,&Settings.TTone_freq       ) ;
      write_tlv_i1 (&memaddr,TGRP_COMMON,TLVT_RXMODE         ,&Settings.RxMode           ) ;
      write_tlv_i1 (&memaddr,TGRP_COMMON,TLVT_RSSIMODE       ,&Settings.RssiMode         ) ;

      /* Now for the optional settings groups */
#ifdef LOCALVOTER
      LocalSettingsWrite(&memaddr) ;
#endif
#ifndef NODIALTASK
      DIALSettingsWrite(&memaddr) ;
#endif

      write_tlv_i4 (&memaddr,TGRP_COMMON,TLVT_ENDOFLINE,&MagicNum) ; /* Last one! */

      /* Writes complete, now go flag NVM contents as valid and clear the dirty flag */
      write_magic (&fixaddr,MAGIC_GOOD) ;
      Settings.Dirty = false ;
   }
   return (memaddr) ;
}

/*******************************************************************************
* Routine  : Settings_reload
* Gazintas : inRTOS - flag we're running under an RTOS
* IOs      : None
* Returns  : Bytes read from NVM. 0 means NVM corrupted.
* Globals  : Settings - the settings structure.
*
* This routine reloads the settings from NVM and OTP.
*******************************************************************************/
static int Settings_reload(int inRTOS)
{
   uint32_t memaddr           =  0  ; /* Incrementing I2C memory address */
   uint8_t  group             =  0  ; /* Group of the TLV                */
   uint8_t  tag               =  0  ; /* Tag of the TLV                  */
   uint8_t  buf[I2C_MAXPARAM] = {0} ; /* Value of the TLV                */

   Glob_inRTOS = inRTOS ;              /* Set this for IRQs           */
   if (inRTOS) osSignalWait (0x01,0) ; /* clear out any older signals */

   /* Go (hopefully) get the magic number first to know we have good data */
   get_i2cmem(&memaddr,4,buf,inRTOS) ;
   if (MAGICNUM_GOOD != ((buf[3]<<24) | (buf[2]<<16) | (buf[1]<<8) | (buf[0])))
   {
      /* For console only.  If pre-RTOS, settings_init() blinks LEDS. */
      memaddr = 0 ; /* flag nothing read on return */
      if (inRTOS) Console_printf("NVM corrupt! Aborted.\n") ;
   }
   else
   {
      do
      {
         /* Get a TLV entry and then copy it to the target setting */
         get_tlv(&memaddr,&group,&tag,buf,inRTOS) ;

         /* Handle the common settings right here */
         if (TGRP_COMMON==group) switch (tag)
         {
            case TLVT_MYSTATICIP     : memcpy(&Settings.My_StaticIP     ,buf,4) ; break ;
            case TLVT_MYSTATICSUBNET : memcpy(&Settings.My_StaticSubnet ,buf,4) ; break ;
            case TLVT_MYSTATICGATEWAY: memcpy(&Settings.My_StaticGateway,buf,4) ; break ;
            case TLVT_MYSTATICDNS    : memcpy(&Settings.My_StaticDNS    ,buf,4) ; break ;
            case TLVT_TFTPADDR       : memcpy(&Settings.TFTP_Addr       ,buf,4) ; break ;
            case TLVT_GPSBAUD        : memcpy(&Settings.GPS_Baud        ,buf,4) ; break ;

          //case TLVT_MYMACADDR      : memcpy(&Settings.MyMACAddr       ,buf,6) ; break ;
            case TLVT_MYIPMODE       : memcpy(&Settings.My_IPMode       ,buf,1) ; break ;
            case TLVT_GPSEDGE        : memcpy(&Settings.GPS_PPSEdge     ,buf,1) ; break ;
            case TLVT_S2NPORT        : memcpy(&Settings.S2N_Port        ,buf,2) ; break ;
            case TLVT_S2NPTIME       : memcpy(&Settings.S2N_PollTime    ,buf,2) ; break ;

            case TLVT_GUESTPASSWORD  : memcpy(&Settings.Guest_Password  ,buf,SETTINGS_PASSWORD_LEN)  ; break ;
            case TLVT_ROOTPASSWORD   : memcpy(&Settings.Root_Password   ,buf,SETTINGS_PASSWORD_LEN)  ; break ;
            case TLVT_MYNAME         : memcpy(&Settings.Voter_Name      ,buf,SETTINGS_NAME_LEN    )  ; break ;

            case TLVT_TTONELVL       : memcpy(&Settings.TTone_lvl       ,buf,2) ; break ;
            case TLVT_TTONEFREQ      : memcpy(&Settings.TTone_freq      ,buf,2) ; break ;
            case TLVT_RXMODE         : memcpy(&Settings.RxMode          ,buf,1) ; break ;
            case TLVT_RSSIMODE       : memcpy(&Settings.RssiMode        ,buf,1) ; break ;

            default                  : /* ignore unknown tags */                  break ;
         }

      /* Now for the optional settings groups */
#ifdef LOCALVOTER
         if (TGRP_LOCAL==group) LocalSettingsRead(tag,buf) ;
#endif
#ifndef NODIALTASK
         if (TGRP_ASTERISK==group) DIALSettingsRead(tag,buf) ;
#endif

      } while (tag != TLVT_ENDOFLINE) ;
   }

   /* Test tone mode always comes up disabled. */
   Settings.TTone_lvl       = TTONE_NONE ;
   Settings.TTone_freq      = 1000 ;

   /* Finished reading from NVM (if it was valid), now read from OTP */
   SpiNor_readOTP(OTPdata,0,12) ;
   memcpy(&Settings.MyMACAddr  ,OTPdata+ 4,6) ;
   Settings.MySerialNum = (OTPdata[ 0]<<24)+(OTPdata[1]<<16)+(OTPdata[2]<<8)+OTPdata[3] ;
   Settings.MyHwRev     = (OTPdata[10]<< 8)+ OTPdata[11] ;

   /* Clear dirty flag and return! */
   Settings.Dirty = false ;
   return (memaddr) ;
}

/*******************************************************************************
* Routine  : Settings_dump
* Gazintas : argc, argv
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This reads raw data from NVM and prints to the screen for debugging.
*******************************************************************************/
static int Settings_dump (int argc, char* argv[])
{
   uint8_t  data[16] = {0}   ; /* Data buffer                */
   char     str[40]  = {0}   ; /* String buffer (Hex dump)   */
   char     str2[10] = {0}   ; /* String buffer (ASCII dump) */
   uint32_t start    =  0    ; /* Default starting address   */
   uint32_t end      = 255   ; /* Default ending address     */
   uint32_t addr     =  0    ; /* Incrementing address       */
   int      error    = false ; /* Parsing error flag         */
   int      result   =  0    ; /* I2C read result code       */
   int      count    =  0    ; /* Bytes read                 */
   int      i        =  0    ; /* General counter            */

   /* Only allow this command in Root mode as it can show    */
   /* all the passwords!                                     */
   if (!RootMode)
   {
      Console_printf("Command only available in root mode.\n") ;
      error = true ;
   }
   else if (4==argc) /* Starting and ending addresses specified */
   {
      start = parse_num(argv[2],0    ,EEPROM_SIZE,&error) ;
      end   = parse_num(argv[3],start,EEPROM_SIZE,&error) ;
      if (error) Console_printf("Bad start/end addresses\n") ;
   }
   else if (2!=argc) /* if no start/end address, better be nothing! */
   {
      Console_printf("Invalid params for dump command.\n") ;
      error = true ;
   }

   /* If we passed the parsing gauntlet, dump data! */
   if (!error)
   {
      Glob_inRTOS = true    ; /* Set this for IRQs           */
      osSignalWait (0x01,0) ; /* clear out any older signals */

      for (addr=start;addr<=end;)
      {
         get_i2cmem(&addr,8,data,true) ;
         Console_printf("I2CDump: %d,0x%3.3x ",result,addr-8) ;
         Logger2_DispBytes(str,data,8,8) ;
         for (i=0;i<8;i++) str2[i] = ((data[i]>=' ')&&(data[i]<='~'))?data[i]:'.' ;
         Console_printf("%s : >%s<\n",str,str2) ;
         osDelay(50) ; /* so we don't overflow the UART buffers */
      }
      count = end-start+1 ;
   }
   return (count) ;
}

/*******************************************************************************
* Routine  : write_magic, write_tlv_str, write_tlv_i4,write_tlv_i2, write_tlv_i1
* Gazintas : group - Settings group ID
*          : type - Parameter type or Tag value
*          : val - The setting to write (cast to void to just write bytes)
*          : len - length for a string (length known for parameter types)
* IOs      : memaddr - I2C device memory address (gets incremented)
* Returns  : Nothing (maybe error code later)
* Globals  : None
*
* These routines write parameter values to NVM. memaddr gets incremented as
* data is written to allow sequential calls.  Routines only needed locally are
* static, but if not static, then they are used by the routines for the other
* settings structures.
*******************************************************************************/
static void write_magic (uint32_t* memaddr,int magic)
{
   uint8_t  buf[I2C_MAXPARAM] = {0} ; /* Buffer to queue up to write */
   uint32_t MagicNum          =  0  ; /* Place for the magic number  */

   /* Pick the magic number or not, then copy to the byte buffer */
   switch (magic)
   {
      case MAGIC_GOOD : MagicNum = MAGICNUM_GOOD ; break ;
      case MAGIC_PGM  : MagicNum = MAGICNUM_PGM  ; break ;
      default         : MagicNum = MAGICNUM_BAD  ; break ;
   }
   memcpy(buf,(void*)&MagicNum,4) ;

   /* I2C memory pages are messy, needs special handling */
   write_i2cpaged(*memaddr,buf,4) ;

   /* increment the memory address for the next write. */
   *memaddr = *memaddr + 4 ;
}

void write_tlv_str(uint32_t* memaddr,uint8_t group,uint8_t type,void* val,int len)
{
   uint8_t buf[I2C_MAXPARAM] = {0} ; /* Buffer to queue up to write */

   buf[0] = group        ; /* Byte 0 is the Group  */
   buf[1] = type         ; /* Byte 0 is the Tag    */
   buf[2] = len          ; /* Byte 1 is the length */
   memcpy(buf+3,val,len) ; /* Rest is the value    */

   /* I2C memory pages are messy, needs special handling */
   write_i2cpaged(*memaddr,buf,len+3) ;

   /* increment the memory address for the next write. */
   *memaddr = *memaddr + len+3 ;
}

void write_tlv_i4 (uint32_t* memaddr,uint8_t group,uint8_t type,void* val)
{
   uint8_t buf[I2C_MAXPARAM] = {0} ; /* Buffer to queue up to write */

   buf[0] = group        ; /* Byte 0 is the Group  */
   buf[1] = type       ; /* Byte 0 is the Tag    */
   buf[2] = 4          ; /* Byte 1 is the length */
   memcpy(buf+3,val,4) ; /* 4-byte/32bit value   */

   /* I2C memory pages are messy, needs special handling */
   write_i2cpaged(*memaddr,buf,7) ;

   /* increment the memory address for the next write. */
   *memaddr = *memaddr + 7 ;
}

void write_tlv_i2 (uint32_t* memaddr,uint8_t group,uint8_t type,void* val)
{
   uint8_t buf[I2C_MAXPARAM] = {0} ; /* Buffer to queue up to write */

   buf[0] = group        ; /* Byte 0 is the Group  */
   buf[1] = type       ; /* Byte 0 is the Tag    */
   buf[2] = 2          ; /* Byte 1 is the length */
   memcpy(buf+3,val,2) ; /* 2-byte/16bit value   */

   /* I2C memory pages are messy, needs special handling */
   write_i2cpaged(*memaddr,buf,5) ;

   /* increment the memory address for the next write. */
   *memaddr = *memaddr + 5 ;
}

void write_tlv_i1 (uint32_t* memaddr,uint8_t group,uint8_t type,void* val)
{
   uint8_t buf[I2C_MAXPARAM] = {0} ; /* Buffer to queue up to write */

   buf[0] = group        ; /* Byte 0 is the Group  */
   buf[1] = type       ; /* Byte 0 is the Tag    */
   buf[2] = 1          ; /* Byte 1 is the length */
   memcpy(buf+3,val,1) ; /* 1-byte/8bit value   */

   /* I2C memory pages are messy, needs special handling */
   write_i2cpaged(*memaddr,buf,4) ;

   /* increment the memory address for the next write. */
   *memaddr = *memaddr + 4 ;
}

/*******************************************************************************
* Routine  : write_i2cpaged
* Gazintas : memaddr - I2C memory address to write to (first byte)
*          : data - data to write
*          : len - number of bytes to write
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This writes an array of bytes to NVM.  For speed you want to do block writes,
* but for the NVM a block write can't cross a page (8/16-byte) boundary, so you
* have to break up the write into chunks that don't cross that boundary.
* ITS MESSY!  There may be a smarter way, but this is what I came up with.
* I'm using the DMA routines, so buffers need to be in uncached space.
*******************************************************************************/
static void write_i2cpaged(uint32_t memaddr,uint8_t* data,int len)
{
   uint32_t caddr   = 0    ; /* Current write starting address */
   uint32_t pagelen = 0    ; /* Current block write length     */
   uint8_t* wrptr   = NULL ; /* Source data pointer            */
   char    str[6+3*I2C_MAXPARAM] = {0}  ; /* For debugging messages         */

   wrptr = data    ; /* Starting point */
   caddr = memaddr ; /* Starting point */

   do
   {
      /* The bytes to write to the page must end at the page boundary, so first  */
      /* figure out the max writable, then if the number to actually write is    */
      /* less, truncate it.                                                      */
      pagelen = I2C_PAGESIZE-(caddr%I2C_PAGESIZE) ;
      if (len<pagelen) pagelen=len ;

      /* Copy the data to write to the non-cached buffer for DMAing */
      memcpy(i2c_dmabuf,wrptr,pagelen) ;

      Logger2_Msg(Logger.i2c,LOG_REGIO,LOG_TIME,"I2CPWr: 0x%2.2x,%d ",caddr,pagelen) ;
      Logger2_DispBytes(str,i2c_dmabuf,pagelen,8) ;
      Logger2_Msg(Logger.i2c,LOG_REGIO,LOG_NOTIME,"%s\r\n",str) ;

      HAL_I2C_Mem_Write_DMA(&hi2c1,EEPROM_ADDRESS,caddr,MEMADDR_SIZE,i2c_dmabuf,pagelen) ;
      osSignalWait (0x01,osWaitForever); /* Wait for the DMA to complete. */
      osDelay(10) ; /* hack to see if this solves a lockup--it does! */

      /* update our pointers and byte counts */
      wrptr = wrptr + pagelen ;
      caddr = caddr + pagelen ;
      len   = len   - pagelen ;
   } while(len>0) ; /* do this until all data written! */
}

/*******************************************************************************
* Routine  : get_i2cmem
* Gazintas : len - bytes to read
*          : inRTOS - Running under RTOS flag
* IOs      : memaddr - I2C device memory address (gets incremented)
*          : buf - where data will be stored
* Returns  : Nothing
* Globals  : None
*
* This reads memory from NVM starting at the supplied address.  That address
* gets incremented so the routine can be called sequentially. The max length
* of memory to get is I2CMAXPARAM.
*******************************************************************************/
static void get_i2cmem (uint32_t* memaddr,int len,uint8_t* buf,int inRTOS)
{
   char str[6+3*I2C_MAXPARAM] = {0} ; /* For debugging purposes.              */

   /* Limits check */
   if (len>I2C_MAXPARAM)
   {
      len = I2C_MAXPARAM ;
      if (inRTOS) Logger2_Msg(Logger.i2c,LOG_REGIO,LOG_TIME,"I2CRdm: Read length capped!\n") ;
   }

   HAL_I2C_Mem_Read_DMA(&hi2c1,EEPROM_ADDRESS,*memaddr,MEMADDR_SIZE,i2c_dmabuf,len) ;
   Waiton_I2C_DMA(inRTOS) ;

   if (inRTOS)
   {
      Logger2_Msg(Logger.i2c,LOG_REGIO,LOG_TIME,"I2CRdm: 0x%2.2x,%d ",*memaddr,len) ;
      Logger2_DispBytes(str,i2c_dmabuf,len,I2C_MAXPARAM) ;
      Logger2_Msg(Logger.i2c,LOG_REGIO,LOG_NOTIME,"%s\r\n",str) ;
   }

   memcpy(buf,i2c_dmabuf,len) ;
   *memaddr = *memaddr + len    ; /* Increment I2C memory address */
}

/*******************************************************************************
* Routine  : get_tlv
* Gazintas : inRTOS - Running under RTOS flag
* IOs      : memaddr - I2C device memory address (gets incremented)
*          : group - TLV group ID
*          : type - The type or Tag of the TLV
*          : buf - where TLV data is stored
* Returns  : Nothing
* Globals  : None
*
* This reads a TLV from NVM starting at the supplied address.  That address
* gets incremented so the routine can be called sequentially.  For valid tags,
* only the tag and value are returned as length is implied from the Tag. If an
* unknown tag, then the length let you safely ignore the tag and go on to the
* next.
*******************************************************************************/
static void get_tlv (uint32_t* memaddr,uint8_t* group,uint8_t* type,uint8_t* buf,int inRTOS)
{
   int  lenleft =  0  ; /* Remaining bytes to read from NVM after first read */
   char str[56] = {0} ; /* For debugging purposes.                           */

   /* Read the Group, Tag, Length, and the first byte of data.  There must be */
   /* at least one byte of data, so get it now to potentially save a second   */
   /* read if the parameter happens to be 1 byte.                             */
   HAL_I2C_Mem_Read_DMA(&hi2c1,EEPROM_ADDRESS,*memaddr,MEMADDR_SIZE,i2c_dmabuf,4) ;
   Waiton_I2C_DMA(inRTOS) ;

   if (inRTOS)
   {
      Logger2_Msg(Logger.i2c,LOG_REGIO,LOG_TIME,"I2CRd1: 0x%2.2x,%d ",*memaddr,4) ;
      Logger2_DispBytes(str,i2c_dmabuf,4,4) ;
      Logger2_Msg(Logger.i2c,LOG_REGIO,LOG_NOTIME,"%s\r\n",str) ;
   }

   *group   = i2c_dmabuf[0]   ; /* Save the TLV Group           */
   *type    = i2c_dmabuf[1]   ; /* Save the TLV Tag             */
   lenleft  = i2c_dmabuf[2]-1 ; /* Remaining bytes to get       */
   buf[0]   = i2c_dmabuf[3]   ; /* Save the first byte of data  */
   *memaddr = *memaddr + 4    ; /* Increment I2C memory address */

   /* If there is more data to get (but not too much!!) get it. */
   if ((lenleft>=1) && (lenleft<I2C_MAXPARAM-1))/* If more data left--but not too much, get it */
   {
      HAL_I2C_Mem_Read_DMA(&hi2c1,EEPROM_ADDRESS,*memaddr,MEMADDR_SIZE,i2c_dmabuf,lenleft) ;
      Waiton_I2C_DMA(inRTOS) ;

      if (inRTOS)
      {
         Logger2_Msg(Logger.i2c,LOG_REGIO,LOG_TIME,"I2CRd2: 0x%2.2x,%d,%d ",*memaddr,*type,lenleft) ;
         Logger2_DispBytes(str,i2c_dmabuf,lenleft,15) ;
         Logger2_Msg(Logger.i2c,LOG_REGIO,LOG_NOTIME,"%s\r\n",str) ;
      }

      memcpy(buf+1,i2c_dmabuf,lenleft) ;
      *memaddr = *memaddr + lenleft ;
   }
   /* if anything else but 1 total (0 lenleft), then an invalid length */
   else if (0!=lenleft)
   {
      /* An invalid TLV length means memory is corrupted, stop. */
      *type = TLVT_ENDOFLINE ;
   }
}

/*******************************************************************************
* Routine  : Waiton_I2C_DMA
* Gazintas : inRTOS - flag we're running in the RTOS
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This waits for the I2C DMA to finish.  If in RTOS mode we wait on a signal,
* if in bare metal mode we wait on the semaphore.
*******************************************************************************/
void Waiton_I2C_DMA(int inRTOS)
{
   I2C_DMA_Busy = true   ; /* busy now (assumes DMA started before this call) */
   Glob_inRTOS  = inRTOS ; /* Tell call-back how to signal things             */

   if (inRTOS)
   {
      osSignalWait (0x01,osWaitForever) ;
   }
   else
   {
	   while (I2C_DMA_Busy) ;
   }
}

/*******************************************************************************
* Routine  : HAL_I2C_MemTxCpltCallback, HAL_I2C_MemRxCpltCallback
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* Callbacks for I2C DMA Tx and Rx functions.  Let the caller know they are
* done!  Set the semaphore always (it just gets ignored in RTOS mdoe), but
* only call the signal if in RTOS mode.
*******************************************************************************/
void HAL_I2C_MemTxCpltCallback(I2C_HandleTypeDef *hi2c)
{
   I2C_DMA_Busy = false ;
   if (Glob_inRTOS) osSignalSet (ConsoleTaskIDHandle,0x01);
}

void HAL_I2C_MemRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
   I2C_DMA_Busy = false ;
   if (Glob_inRTOS) osSignalSet (ConsoleTaskIDHandle,0x01);
}
