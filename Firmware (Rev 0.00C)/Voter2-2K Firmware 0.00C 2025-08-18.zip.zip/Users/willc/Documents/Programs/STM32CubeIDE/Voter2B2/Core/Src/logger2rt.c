/* ************************************************************************** */
/* This is the logger2r file.  It manages debug message logging to a UART     */
/* interface.  While no code was copied, the inspiration for these routines   */
/* came from something similar included with the ST NFC demo code that is     */
/* part of the Z-NUCLEO-NFC03A1 package.                                      */
/*                                                                            */
/* Logger2rt is the RTOS-flavored version of Logger2 that also supports       */
/* Telnet.  Also, the message routines gracefully handle a call to the        */
/* message routines before the RTOS starts for any initial messages.  If that */
/* early, the message routines use blocking program IO instead.               */
/* *** NOTE: See main.c for a summary of task stack size needs.               */
/*                                                                            */
/* To minimize timing perturbations, UART messages are sent using DMA to      */
/* avoid blocking IO or by-character interrupts.  The only interrupts are at  */
/* the end of a DMA--typically an entire debug message.  Messages get queued  */
/* up by Logger2_Msg then sent by the task Logger2Task process.  Text to send */
/* is managed through a circular buffer.                                      */
/*                                                                            */
/* In theory, if you set the #define LOGGER2_LEVEL to 0, all this code gets   */
/* ifdef'd out, so easy to remove the code when not needed.                   */
/******************************************************************************/
/* Public routines are:                                                       */
/*  - Logger2_SetUart - Selects which UART for logger output.                 */
/*  - Logger2_Msg - Send logger message (maybe)                               */
/*  - Logger2_LWIP - LWIP-compatible version of Logger2_Msg                   */
/*  - Logger2_IRQMsg - IRQ-friendly version of Logger2_Msg                    */
/*  - Logger2_DispBytes - Convert byte array to string                        */
/*  - Logger2Task - The RTOS task that sends the message.                     */
/*  - Logger2TxComplete - end of UART DMA interrupt callback.                 */
/*  - vApplicationStackOverflowHook - For FreeRTOS stack checking.            */
/*  - LoggerEthRxTask() - Telnet management/Rx task.                          */
/*                                                                            */
/* *** NOTE: Logger2Task should only need a 50-word stack but it is set to    */
/*     512 words right now.  This needs investigating.                        */
/******************************************************************************/
/* INTEGRATION DETAILS: (things to do besides including this file)            */
/*  - In CubeMX enable UART and UART global interrupt.                        */
/*    - Also enable UART Tx & Rx DMAs and DMA interrupts. (Yes, Rx not used). */
/*  - In stm32xxx_it.c no need for any changes.                               */
/*  - Need to have HAL_UART_TxCpltCallback() call Logger2TxComplete()         */
/*    - I have this in UartIO.c.  Note, this currently hard coded to USART1!  */
/*  - In main.c (before kernel start) call Logger2_SetUart()                  */
/******************************************************************************/
// TO DO:
//  Mutex on pointers in task code?
//  I'm calling from ISRs and using mutexes, a no-no

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#include "cmsis_os.h"
#include "lwip.h"
#include "lwip/opt.h"
#include "lwip/sys.h"
#include "lwip/api.h"

#include "Options.h"
#include "main.h"
#include "Settings.h"
#include "Utils.h"
#include "SetShow.h"
#include "logger2rt.h"
#include "UartIO.h"
#include "gpio.h"
#include "EthernetTask.h"

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
#define LOGBUFSIZE 1024 /* Circular Log buffer size (4K max!!!)               */
#define PIO_MAXDELAY (LOGBUFSIZE/10) /* Max time for PIO (pre-RTOS) UART write*/

#define LOGGER_TCP_PORT 24

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
#if (LOGGER2_LEVEL > 0) /* Only define if logging enabled */

static UART_HandleTypeDef* Logger2_Uart = 0     ; /* UART in use              */
static int LoggerRunning                = false ; /* Logger task running      */
static int IRQ_Holdoff                  = false ; /* Plan B for IRQ logs      */

/* TxBuf is the buffer of individual messages into the larger TxQueue that    */
/* can have multiple messages queued up to send.                              */
/* TxQueue needs to be in uncached RAM_D2 space in order to be DMA-able!      */
static char TxBuf  [LOGBUFSIZE] = {0} ;
static char TxQueue[LOGBUFSIZE] IN_DMADD2 = {0} ;
static int TxWrPtr = 0 ; /* TxQueue write pointer */
static int TxRdPtr = 0 ; /* TxQueue read pointer */

static char ShortIRQMsg[32] IN_DMADD2 = {0} ;

static struct netconn *logconn    = NULL  ; /* Telnet connection (pre-connect)   */
static struct netconn *lognewconn = NULL  ; /* Telnet connection (post-connect)  */
static int    TelnetActive        = false ; /* Telnet active flag                */
#endif

/******************************************************************************/
/* External globals. How CubeMX does things instead of in an include file,    */
/* weird.                                                                     */
/******************************************************************************/
extern osThreadId Logger2TaskIDHandle;
extern osMessageQId LoggerQueueHandle;
extern osMutexId Logger2EnqueueHandle;
extern osThreadId ConEthRxTaskIDHandle;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
#if (LOGGER2_LEVEL != 0) /* If logging disabled, no need for this */
static int Logger2_Sendit(char*,int) ;
#endif

/* Local-ish */
void vApplicationStackOverflowHook( TaskHandle_t xTask, signed char *pcTaskName );

/******************************************************************************/
/* Routines                                                                   */
/******************************************************************************/

/*******************************************************************************
* Routine  : Logger2_SetUart
* Gazintas : *husart - UART handle for the logger
* IOs      : None
* Returns  : Nothing
* Globals  : Logger2_Uart - set
*
* This routine gets the intended UART handle for the logger messaging.  The
* handle is initialized to 0 so we can tell later if it isn't initialized on a
* call to write something.
*******************************************************************************/
void Logger2_SetUart(UART_HandleTypeDef *huart)
{
#if (LOGGER2_LEVEL > 0)
   Logger2_Uart = huart ;
#endif
}

/*******************************************************************************
* Routine  : Logger2_Msg, Logger2_LWIP
* Gazintas : level - Message level (see header file)
*          : timestamp - Include timestamp or not (t/f)
*          : format - printf format string
*          : ... data to print
* IOs      : None
* Returns  : 0 for no error, !0 for error (see .h)
* Globals  : Logger2_Level, TxBuf (potential problem)
*
* This routine writes a debug message to the UART if the level is at or below
* the Logger2_Level value.  If timestamp is true, the message is prepended with
* the value of the SysTick timer which is usually ms from boot.  Formatting
* for the string is standard printf formatting. There is a max of 255 characters
* in the string or it gets cut off.
*
* This routine can be called both before the RTOS (and Logger2Task) is running
* and after.  If called before, the write to the console will be using program
* IO (blocking).  If after Logger2Task is running, the message gets queued up
* to be sent as it can by the task.
*
* Logger2_LWIP is for the LWIP debug messaging calls and can only take the
* format and ... data.  So this is the same as Logger2_Msg, but assumes a
* level of 2 and timestamp on.  It clearly only runs if the RTOS is running too.
*
* Logger2_IRQMsg is for interrupt routines to use (vs. RTOS tasks).  As an
* interrupt message could interrupt critical (mutexed) code in RTOS messaging,
* this code will just print a 32-bit "backup" data instead.  This should be
* extremely rare!
*******************************************************************************/
int Logger2_Msg(int threshold,int level, int timestamp, const char* format, ...)
{
#if (LOGGER2_LEVEL == 0)       /* If logging disabled, just return error (and */
   return(LOG_ERR_NOLOGGING) ; /* hopefully get optimized out of existence).  */
#else /* otherwise if logging enabled... */

   va_list vargs        ; /* varg magic, dunno how to initialize   */
   int     rval   = 0   ; /* Routine return value                  */
   int     buffed = 0   ; /* bytes in buffer so far                */
   int     llr    = 0   ; /* Local copy of LoggerRunning           */

   /* Some routines (pre-RTOS calls and some ISRs) may send logging messages  */
   /* before Logger2 (or even indeed FreeRTOS itself) is up and running.  If  */
   /* so, revert to program IO.                                               */
   llr = LoggerRunning ;

   /* Only log if below or equal to defined logging level */
   if (level <= threshold)
   {
      if (llr)
      {
         /* If we get an IRQ that wants to send a message while we are in the       */
         /* middle of an RTOS message, it needs to get treated differently         */
         IRQ_Holdoff = true ;

         /* While the sprintf stuff is reentrant, I'm still sharing TxBuf.  Since   */
         /* multiple tasks can call this routine, I need a mutex.                   */
         osMutexWait (Logger2EnqueueHandle,osWaitForever) ;
      }

      /* if timestamp requested, write it to the buffer first */
      if (timestamp)
      {
         buffed = sprintf(TxBuf,"[%10ld] ",HAL_GetTick()) ;
      }

      /* print out the logging data to the buffer */
      va_start(vargs, format);
      buffed += vsnprintf(TxBuf+buffed, LOGBUFSIZE-buffed, format, vargs);
      va_end(vargs);

      if (llr)
      {
         /* If Logger2 task is running, queue it up and then release the mutex. */
         rval = Logger2_Sendit(TxBuf,buffed) ;
         osMutexRelease (Logger2EnqueueHandle) ;
         /* and now back to regularly scheduled IRQ messages... */
         IRQ_Holdoff = false ;
      }
      else
      {
         /*Otherwise program IO */
         HAL_UART_Transmit(Logger2_Uart,(uint8_t*)TxBuf,buffed,PIO_MAXDELAY) ;
      }
   }

   return(rval) ;
#endif
}

int Logger2_LWIP(const char* format, ...)
{
#if (LOGGER2_LEVEL == 0)       /* If logging disabled, just return error (and */
   return(LOG_ERR_NOLOGGING) ; /* hopefully get optimized out of existence).  */
#else /* otherwise if logging enabled... */
   va_list vargs             ; /* varg magic, dunno how to initialize     */
   int     rval = LOG_ERR_OK ; /* Default routine return value            */
   int     buffed = 0        ; /* bytes in buffer so far                  */

   /* Only log if blow or equal to defined logging level */
   if (LOG_SUPPORT <= Logger.EthLWIP)
   {
      /* The printf stuff isn't reentrant and since multiple tasks can call this */
      /* routine, need to sequence them! With incoming sequenced, we also need   */
      /* to worry about sharing TxBuf, so need a mutex for it too.               */
      osMutexWait (Logger2EnqueueHandle,osWaitForever) ;

      buffed = sprintf(TxBuf,"[%10ld] ",HAL_GetTick()) ;

      /* print out the logging data to the buffer */
      va_start(vargs, format);
      buffed += vsnprintf(TxBuf+buffed, LOGBUFSIZE-buffed, format, vargs);
      va_end(vargs);

      /* Send the message.  Blocking program IO for now. */
      rval = Logger2_Sendit(TxBuf,buffed) ;

      /* All done!  Release the mutexes */
      osMutexRelease (Logger2EnqueueHandle) ;
   }
   return(rval) ;
#endif
}

int Logger2_IRQMsg(int threshold,int level, int timestamp, uint32_t ShortForm, const char* format, ...)
{
#if (LOGGER2_LEVEL == 0)       /* If logging disabled, just return error (and */
   return(LOG_ERR_NOLOGGING) ; /* hopefully get optimized out of existence).  */
#else /* otherwise if logging enabled... */

   va_list vargs        ; /* varg magic, dunno how to initialize   */
   int     rval   = 0   ; /* Routine return value                  */
   int     buffed = 0   ; /* bytes in buffer so far                */
   int     llr    = 0   ; /* Local copy of LoggerRunning           */

   /* A shortform of 0 would be bad, so make it 0xbaadbeef instead */
   if (0==ShortForm) ShortForm = 0xbaadbeef ;

   /* Some routines (pre-RTOS calls and some ISRs) may send logging messages  */
   /* before Logger2 (or even indeed FreeRTOS itself) is up and running.  If  */
   /* so, revert to program IO.                                               */
   llr = LoggerRunning ;

   /* Only log if below or equal to defined logging level */
   if (level <= threshold)
   {
      if (IRQ_Holdoff)
      {
         /* If this interrupt happened exactly in the middle of an RTOS task  */
         /* queuing up data into the TxBuf buffer, we'd mess things up. This  */
         /* should be rare, but if it does, just queue up the ShortForm data  */
         /* in the message area instead of the full text.                     */
         /* See the description for Logger2_IRQMsg in the .h file for info.   */
         osMessagePut(LoggerQueueHandle,ShortForm,osWaitForever) ;
      }
      else
      {
         /* Otherwise no conflict!  Queue up the IRQ message normally         */
         if (llr)
         {
            /* While the sprintf stuff is reentrant, I'm still sharing TxBuf. */
            /* Since multiple tasks can call this routine, I need a mutex.    */
            osMutexWait (Logger2EnqueueHandle,osWaitForever) ;
         }

         /* if timestamp requested, write it to the buffer first */
         if (timestamp)
         {
            buffed = sprintf(TxBuf,"[%10ld] ",HAL_GetTick()) ;
         }

         /* print out the logging data to the buffer */
         va_start(vargs, format);
         buffed += vsnprintf(TxBuf+buffed, LOGBUFSIZE-buffed, format, vargs);
         va_end(vargs);

         if (llr)
         {
            /* If Logger2 task is running, queue it up and then release the   */
            /* mutex.                                                         */
            rval = Logger2_Sendit(TxBuf,buffed) ;
            osMutexRelease (Logger2EnqueueHandle) ;
         }
         else
        {
            /*Otherwise program IO */
            HAL_UART_Transmit(Logger2_Uart,(uint8_t*)TxBuf,buffed,PIO_MAXDELAY) ;
         }
      }
   }

   return(rval) ;
#endif
}

/*******************************************************************************
* Routine  : Logger2_Sendit
* Gazintas : buf - buffer to send over UART
*          : len - bytes to send
* IOs      : None
* Returns  : 0 for no error !0 for error
* Globals  : Logger2_Uart
*
* This routine sends a string to the logger sending task. The only error
* possible is if the queue doesn't have space for the message.
* No need to check for dynamic logger2_level as this routine is only called if
* logger2_level > 0.
*******************************************************************************/
#if (LOGGER2_LEVEL != 0) /* If logging disabled, no need for this */
static int Logger2_Sendit(char* buf, int len)
{
   uint32_t msg   = 0          ; /* Message to Logger2Task   */
   int      rval  = LOG_ERR_OK ; /* Routine return value     */
   int      avail = 0          ; /* Available bytes in Queue */
   int      i     = 0 ;        ; /* index counter            */

   /* UART pointer is NULL until it is assigned, if it is still NULL, user    */
   /* forgot to assgin a debug UART!                                          */
   /* Also, ISRs may try to send logger messages before the Logger2 task is   */
   /* actually running!  If it isn't running yet, just drop the message.      */
   if ((Logger2_Uart != 0) && (LoggerRunning))
   {
      /* First make sure there is room for the message in the logger2         */
      /* circular buffer                                                      */
      /* *** If I hadn't started the mutex above, this would be the place.*** */
      if (TxRdPtr<=TxWrPtr)
      {
	     avail = LOGBUFSIZE-TxWrPtr+TxRdPtr ;
      }
      else
      {
	     avail = TxRdPtr-TxWrPtr ;
      }

      if (len<=avail)
      {
         /* Create the message with the circular buffer starting point before */
         /* incrementing TxWrPtr to write the message.                        */
         /* The upper 8 bits will be zero which means the source is RTOS      */
         /* RTOS messages using TxQueue                                       */
         msg = TxWrPtr + (len<<12) ;

         /* Now copy the message to the circular queue. */
         for (i=0;i<len;i++)
         {
            TxQueue[TxWrPtr] = buf[i] ;
            TxWrPtr = (TxWrPtr+1)%LOGBUFSIZE ;
         }

         /* Send message to Logger2Task! */
         osMessagePut(LoggerQueueHandle,msg,osWaitForever) ;
      }
      else
      {
         /* If message longer than available queue space, return with error.  */
         rval = LOG_ERR_FULL ;
      }
   }
   return(rval) ;
}
#endif

/*******************************************************************************
* Routine  : Logger2_DispBytes
* Gazintas : dst - destination string
*          : src - source byte array
*          : len - length of byte array
*          : max - Mas # of bytes to display
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This is a helper routine to print out a byte array in ASCII.  It just
* writes to a string that then gets sent by Logger2_Msg(Logger.Boot,).  It first writes
* out the string length, then up to the max number of bytes, stopping if the
* actual array is bigger.  The destination string should be at least 6+3n
* bytes long where n is the number of bytes to display.  Add one byte for
* going above 100, 1 more for > 1000, etc.
******************************************************************************/
void Logger2_DispBytes(char* dst,void* src,int len, int max)
{
#if (LOGGER2_LEVEL != 0)       /* Only if logging is enabled */
   int      i      =  0   ;
   uint8_t* ptr    = NULL ;
   char     tmp[4] = {0}  ;

   /* start off with the data array actual length.  Show that length even     */
   /* though less may be actually printed.                                    */
   sprintf(dst,"(%d)",len) ;

   /* for actual printing, if array is > max to display, limit to max length. */
   if (len>max) len = max ;

   ptr = (uint8_t*)src ;
   for (i=0;i<len;i++)
   {
      sprintf(tmp," %2.2x",*(ptr++)) ;
      strcat(dst,tmp) ;
   }

#endif
}

/*******************************************************************************
* Routine  : Logger2Task
* Gazintas : None (argument isn't used)
* IOs      : None
* Returns  : Doesn't, this is a top level RTOS task
* Globals  : buffer
*
* This is the task to actually send logger information to the UART.  It waits
* for a LoggerQueue which contains the starting index and length of the message
* to send and then sends that message using DMA.  Once DMA is done, it updates
* the write pointer to mark the buffer as ready to be re-used.
*******************************************************************************/
void Logger2Task(void const * argument)
{
#if (LOGGER2_LEVEL == 0) /* If not logging, just end the task. */
   osThreadTerminate(Logger2TaskIDHandle) ;
#else /* the regular task */
   osEvent   event = {0}  ; /* event info (for incoming message) */
   err_t     err   =  0   ; /* LwIP error flag                   */
   int       src   =  0   ; /* Message source                    */
   int       idx   =  0   ; /* Index to start of message to send */
   int       len1  =  0   ; /* Message length, first part        */
   int       len2  =  0   ; /* Message length, second part       */

   /* Startup sequencing enforcement. See Options.h */
   osDelay(StartDelay_Logger2rTask) ;
   Logger2_Msg(Logger.LogTel,LOG_MAJOR,LOG_TIME,"Logger2rTask : Start\r\n") ;

   /* Tell Logger2_Sendit we are ready for messages! */
   LoggerRunning = true ;

   /* RTOS Task Infinite loop */
   for(;;)
   {
      /* Wait for a message */
      event = osMessageGet(LoggerQueueHandle,osWaitForever ) ;

      if ( event.status == osEventMessage) /* Only message I'm expecting */
      {
         /* Message is a uint32_t.  I'm saving mailbox overhead by just       */
         /* IDs for the source, starting index and length of the buffer into  */
         /* the uint32 message                                                */
         src  = ((event.value.v)>>24)&0xff  ;

         if (0==src)
         {
            /* A source of 0 means a regular RTOS message */
            idx  =  (event.value.v)&0xfff      ;
            len1 = ((event.value.v)>>12)&0xfff ;
            len2 = 0 ;

            /* If we wrapped in the circular buffer, shorten len1 to first part  */
            /* of the message and create len2 for second part.                   */
            if ((idx+len1)>=LOGBUFSIZE)
            {
               len2 = (idx+len1)-LOGBUFSIZE ;
               len1 = LOGBUFSIZE-idx ;
            }

            /* Send the message.  */
            if (TelnetActive)
            {
               err=netconn_write(lognewconn, TxQueue+idx, len1, NETCONN_COPY);
               if (0!=err) IncErrLog(LOGGGER2TASK_NETCONN_WRITE1,ERRLOG_SHOW) ;

            }
            else
            {
               /* I don't check for DMA busy as I can't get here if it is. */
               /* I don't check for errors as there isn't much to do if there is one */
               HAL_UART_Transmit_DMA(Logger2_Uart, (uint8_t*)TxQueue+idx,(int32_t) len1) ;


               /* Wait for the DMA to be done.  Only signal to this thread is from  */
               /* the DMA.                                                          */
               event = osSignalWait (0x00,osWaitForever);
            }

            /* If the message wrapped the TxQueue buffer, send out the second    */
            /* part now.                                                         */
            if (len2)
            {
               if (TelnetActive)
               {
                  err=netconn_write(lognewconn, TxQueue, len2, NETCONN_COPY);
                  if (0!=err) IncErrLog(LOGGGER2TASK_NETCONN_WRITE2,ERRLOG_SHOW) ;
               }
               else
               {
                  HAL_UART_Transmit_DMA(Logger2_Uart, (uint8_t*)TxQueue,(int32_t) len2) ;
                  event = osSignalWait (0x00,osWaitForever);
               }
            }

            /* finally, update the read pointer and loop to wait for next msg.   */
            TxRdPtr = (idx+len1+len2)%LOGBUFSIZE ;
         }
         else
         {
            /* A non-zero source means we have a curtailed interrupt message. */
            /* Now the message is all the info we have.  Just print out the   */
            /* four bytes of the message.                                     */
            /* Yea, cheating a bit, just re-using stack variables instead of  */
            /* creating new ones.                                             */
            idx  = ((event.value.v)>>16)&0xff ;
            len1 = ((event.value.v)>> 8)&0xff ;
            len2 = ((event.value.v)    )&0xff ;
            sprintf(ShortIRQMsg,"IRQ Backup: %2.2x %2.2x %2.2x %2.2x\n",src,idx,len1,len2) ;

            if (TelnetActive)
            {
               err=netconn_write(lognewconn, ShortIRQMsg,24, NETCONN_COPY);
               if (0!=err) IncErrLog(LOGGGER2TASK_NETCONN_WRITE3,ERRLOG_SHOW) ;
            }
            else
            {
               HAL_UART_Transmit_DMA(Logger2_Uart, (uint8_t*)ShortIRQMsg,(int32_t)24) ;
               event = osSignalWait (0x00,osWaitForever);
            }
         }
      }
   }
#endif
}

/*******************************************************************************
* Routine  : Logger2TxComplete
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine gets called when the DMA for the logger UART is complete.  Just
* send a signal to the Logger2 task, it is waiting.
* It won't get called if logging is disabled, and even if it does get called,
* no harm.
*******************************************************************************/
void Logger2TxComplete(void)
{
   osSignalSet (Logger2TaskIDHandle,0x01);
}

/*******************************************************************************
* Routine  : vApplicationStackOverflowHook
* Gazintas : xTask - The Offending task handle
*          : pcTaskName - The text name of the task
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This is a pre-defined routine name that FreeRTOS calls if stack checking is
* enabled (it takes code space and time) and there is a problem.
* This needs to stay even if logging is disabled as disabling the LWIP
* functions that call it is messy.  Since Logger2_Msg(Logger.Boot,) is a null routine,
* nothing happens, so not a big deal to leave it.
*******************************************************************************/
void vApplicationStackOverflowHook( TaskHandle_t xTask, signed char *pcTaskName )
{
   Logger2_Msg(Logger.LogTel,LOG_MAJOR,LOG_TIME,"OverflowHook: Task %s\r\n",pcTaskName) ;
}

/*******************************************************************************
* Routine  : LoggerEthRxTask
* Gazintas : None
* IOs      : None
* Returns  : Never
* Globals  : TBD
*
* This is the task for managing the Telnet interface for the logger.  We set up
* the listening port and then just wait.  If someone connects we (currently)
* just ignore any incoming data, but set the TelnetActive flag to tell
* Logger2Task to direct output to the Ethernet interface instead of UART. That
* continues until the user disconnects Telnet in which case Logger reverts back
* to UART for logging messages.
*******************************************************************************/
void LoggerEthRxTask(void const * argument)
{
   struct netbuf *buf         = NULL ; /* Buffer for incoming TCP data */
   u16_t         len          = 0    ; /* payload length               */
   err_t         err          = 0    ; /* Result code                  */
   static void   *Telnet_data = NULL ; /* Telnet data to Console       */

   /* First wait on Logger2Task and Ethernet being up.  I have to explicitly  */
   /* check for Ethernet as I do purposely start up the Logger task before    */
   /* Ethernet for Ethernet logging messages!  Those will be reported via     */
   /* UART only clearly.                                                      */
   while ((!LoggerRunning) || (!EthernetUp)) osDelay(10) ;
   Logger2_Msg(Logger.LogTel,LOG_MAJOR,LOG_TIME,"LoggerEthRxTask: Start\r\n") ;

   /* Create a new Ethernet port and bind it to the logger port ID */
   /* Currently port 24 +1 from standard Telnet.                   */
   logconn = netconn_new(NETCONN_TCP);
   Logger2_Msg(Logger.LogTel,LOG_SUPPORT,LOG_TIME,"LoggerEthRxTask: netconn_new (0x%8.8x)\r\n",(uint32_t)logconn) ;
   err = netconn_bind(logconn, IP_ADDR_ANY, LOGGER_TCP_PORT);
   Logger2_Msg(Logger.LogTel,LOG_SUPPORT,LOG_TIME,"LoggerEthRxTask: netconn_bind (%d,0x%8.8x)\r\n",err,(uint32_t)logconn) ;

   /* Go into listening mode. */
   netconn_listen(logconn);

   while (1) /* Task infinite loop */
   {
      /* Wait for a connection... */
      Logger2_Msg(Logger.LogTel,LOG_SUPPORT,LOG_TIME,"LoggerEthRxTask: Waiting for a connection\r\n") ;
      err = netconn_accept(logconn, &lognewconn);
      Logger2_Msg(Logger.LogTel,LOG_SUPPORT,LOG_TIME,"LoggerEthRxTask: Telnet Connection (%d)\r\n",err) ;

      /* Tell Logger2Task we connected! */
      TelnetActive = true ;

      /* If connected, start processing incoming data */
      if (err == ERR_OK)
      {
         /* Blocking wait for data. */
         while ((err = netconn_recv(lognewconn, &buf)) == ERR_OK)
         {
            do
            {
               /* get any incoming payload and just toss it, don't care about */
               /*it.                                                          */
               netbuf_data(buf, &Telnet_data, &len);

            } while (netbuf_next(buf) >= 0);
            netbuf_delete(buf); /* all done, free the pbuf */
         }
         /* We get here if anythign goes wrong with the connection.  99% of   */
         /* time this will be because the user disconnected, but could be for */
         /* other reasons too.                                                */
         /* Tell Logger2Task we disconnected and close the connection.        */
         TelnetActive = false ;

         /* Wait just a bit in case any data is pending and close connection. */
         /* We then just loop around and wait for another connection.         */
         osDelay(100) ;
         netconn_close(lognewconn);
         netconn_delete(lognewconn);
      }
   }
}
