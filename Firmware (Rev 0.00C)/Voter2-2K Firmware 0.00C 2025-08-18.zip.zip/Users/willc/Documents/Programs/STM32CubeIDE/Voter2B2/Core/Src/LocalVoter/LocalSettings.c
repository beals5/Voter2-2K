/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/* ************************************************************************** */
/* This is the LocalSettings file, in charge of the settings for local mode.  */
/* The settings for local mode are separated from the main set/show/settings  */
/* code as there can be different local modes and each will have different    */
/* settings structures.  These are the settings for the "default" Voter2      */
/* mode unless replaced by something else.                                    */
/* This contains the segregated code that would be the equivalent of what is  */
/* in the set/show commands and settings commands.                            */
/******************************************************************************/
/* Public routines are:                                                       */
/*  - LocalSettingsInit - Set factory defaults.                               */
/*  - LocalSettingsRead - process and NVM TLV read                            */
/*  - LocalSettingsWrite - Write settings to NVM                              */
/*  - SetLocal - CLI Change local mode settings                               */
/*  - ShowLocal - CLI Display local mode settings                             */
/*                                                                            */
/******************************************************************************/
// To Do:
//  -

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>

#include "Options.h"
#ifdef LOCALVOTER

#include "Utils.h"
#include "ConsoleTask.h"
#include "Settings.h"
#include "LocalVoter/LocalSettings.h"
#include "Setshow.h"
#include "AnalogIO.h"
#include "Rx_DSP.h"
#include "Tx_DSP.h"

/******************************************************************************/
/* Local defines (including enums)                                            */
/******************************************************************************/
enum
{
   LOC_MODE = 1,
   LOC_CWSPEED,
   LOC_PLFREQ,
   LOC_DEEMPH,
   LOC_PRECW,
   LOC_POSTCW,
   LOC_IDTIME,
   LOC_HANGTIME,
   LOC_PLL,
   LOC_ID,
   LOC_PROC,
} LOCALBLOCK_ENUMS ;

enum
{
   OFF_NONE = 0,
   OFF_SIM,
   OFF_TRIGGER,
   OFF_REPEATER
} OFFLINEMODE_ENUMS ;

enum
{
   TLVT_LOCMODE = 1,
   TLVT_LOCCWS = 2,
   TLVT_LOCPLF = 3,
   TLVT_LOCDEEMPH = 4,
   TLVT_LOCPRECW = 5,
   TLVT_LOCPOSTCW = 6,
   TLVT_LOCIDTIME = 7,
   TLVT_LOCHANGTIME = 8,
   TLVT_LOCPLL = 9,
   TLVT_LOCID = 10,
   TLVT_LOCPROC = 11,
} OFFLINE_TLVTS ;

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
LOCALSETTINGS LocalSettings = {0} ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TOKENLIST LocalCliCmds[] =
{
   {"mode"    ,LOC_MODE    },
   {"cwspd"   ,LOC_CWSPEED },
   {"plfreq"  ,LOC_PLFREQ  },
   {"deemph"  ,LOC_DEEMPH  },
   {"precw"   ,LOC_PRECW   },
   {"postcw"  ,LOC_POSTCW  },
   {"idtime"  ,LOC_IDTIME  },
   {"hangtime",LOC_HANGTIME},
   {"pllevel" ,LOC_PLL     },
   {"id"      ,LOC_ID      },
   {"proc"    ,LOC_PROC    },
   {NULL      ,0           }
} ;

static TOKENLIST OfflineModes[] =
{
   {"none"    ,OFF_NONE    },
   {"simplex" ,OFF_SIM     },
   {"trigger" ,OFF_TRIGGER },
   {"repeater",OFF_REPEATER},
   {NULL      ,0           }
};

static TOKENLIST PLTones[] =
{
   {"67.0" ,CTCSS_670},
   {"71.9" ,CTCSS_719},
   {"74.4" ,CTCSS_744},
   {"77.0" ,CTCSS_770},
   {"79.7" ,CTCSS_797},
   {"82.5" ,CTCSS_825},
   {"85.4" ,CTCSS_854},
   {"88.5" ,CTCSS_885},
   {"91.5" ,CTCSS_915},
   {"94.8" ,CTCSS_948},
   {"97.4" ,CTCSS_974},
   {"100.0",CTCSS_1000},
   {"103.5",CTCSS_1035},
   {"107.2",CTCSS_1072},
   {"110.9",CTCSS_1109},
   {"114.8",CTCSS_1148},
   {"118.8",CTCSS_1188},
   {"123.0",CTCSS_1230},
   {"127.3",CTCSS_1273},
   {"131.8",CTCSS_1318},
   {"136.5",CTCSS_1365},
   {"141.3",CTCSS_1413},
   {"146.2",CTCSS_1462},
   {"151.4",CTCSS_1514},
   {"156.7",CTCSS_1567},
   {"162.2",CTCSS_1622},
   {"167.9",CTCSS_1679},
   {"173.8",CTCSS_1738},
   {"179.9",CTCSS_1799},
   {"186.2",CTCSS_1862},
   {"192.8",CTCSS_1928},
   {"203.5",CTCSS_2035},
   {"210.7",CTCSS_2107},
   {"218.1",CTCSS_2181},
   {"225.7",CTCSS_2257},
   {"233.6",CTCSS_2336},
   {"241.8",CTCSS_2418},
   {"250.3",CTCSS_2503},
   {NULL   ,0         }
} ;


/******************************************************************************/
/* External globals. CubeMX has you define them as externs in each file       */
/* instead of an include file, weird.                                         */
/******************************************************************************/

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/
static void SyncSettings(void) ;
static void CheckCWids(void) ;

/*******************************************************************************
* Routine  : LocalSettingsInit
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : LocalSettings
*
* This routine fills in the LocalSettings structure with the factory default
* settings.  If LOCALVOTER is defined (enabling the default local mode), then
* SettingsInit calls this routine on power-up if NVM is corrupted.
*******************************************************************************/
void LocalSettingsInit(void)
{
   LocalSettings.OfflineMode    =    0 ; /* Offline mode                 */
   LocalSettings.OffineCwSpd    =   20 ; /* Offline CW speed (WPM)       */
   LocalSettings.OffinePLF      =    8 ; /* Offline CTCSS Freq (index)   */
   LocalSettings.OffineDeemph   = true ; /* Offline Rx De-emphasis (TF)  */
   LocalSettings.OffinePreCw    =  500 ; /* Offline Pre CW delay (ms)    */
   LocalSettings.OffinePostCw   =  500 ; /* Offline Post CW delay (ms)   */
   LocalSettings.OffineIdTime   =  600 ; /* Offline ID period (secs)     */
   LocalSettings.OffineHangTime = 1500 ; /* Offline Rx Hang time (ms)    */
   LocalSettings.OffinePLL      =    3 ; /* Offline CTCSS level (int)    */

   strcpy(LocalSettings.OfflineID  ,"N0CALL/R") ; /* Offline station ID  */
   strcpy(LocalSettings.OfflineProc,"L"       ) ; /* Offline Proceed ID  */

   /* Finally, sync up the global versions of some local settings */
   SyncSettings() ;
} ;

/*******************************************************************************
* Routine  : LocalSettingsRead
* Gazintas : tag - The TLV T (tag) value
*          : buf - the TLV V data  (note L is implied by this point)
* IOs      : None
* Returns  : Nothing
* Globals  : LocalSettings
*
* This routine processes Local Mode settings being read from NVM.  As entries
* are read, the main code looks at the group setting and if for local mode,
* calls this routine to process it.
*******************************************************************************/
void LocalSettingsRead(uint8_t tag,uint8_t* buf)
{
   switch (tag)
   {
      case TLVT_LOCMODE    : memcpy(&LocalSettings.OfflineMode     ,buf,1) ; break ;
      case TLVT_LOCCWS     : memcpy(&LocalSettings.OffineCwSpd     ,buf,1) ; break ;
      case TLVT_LOCPLF     : memcpy(&LocalSettings.OffinePLF       ,buf,1) ; break ;
      case TLVT_LOCDEEMPH  : memcpy(&LocalSettings.OffineDeemph    ,buf,1) ; break ;
      case TLVT_LOCPRECW   : memcpy(&LocalSettings.OffinePreCw     ,buf,2) ; break ;
      case TLVT_LOCPOSTCW  : memcpy(&LocalSettings.OffinePostCw    ,buf,2) ; break ;
      case TLVT_LOCIDTIME  : memcpy(&LocalSettings.OffineIdTime    ,buf,2) ; break ;
      case TLVT_LOCHANGTIME: memcpy(&LocalSettings.OffineHangTime  ,buf,2) ; break ;
      case TLVT_LOCPLL     : memcpy(&LocalSettings.OffinePLL       ,buf,1) ; break ;
      case TLVT_LOCID      : memcpy(&LocalSettings.OfflineID       ,buf,SETTINGS_CWID_LEN) ; break ;
      case TLVT_LOCPROC    : memcpy(&LocalSettings.OfflineProc     ,buf,SETTINGS_CWID_LEN) ; break ;
      default              :                                                 break ;
   }

   /* Finally, sync up the global versions of some local settings.  Yea, this */
   /* seems a bit inefficient to resync all settings after every single       */
   /* settings read, but reality is the sync time is rounding error compared  */
   /* to the NVM read, so not too worried about it.                           */
   SyncSettings() ;
}

/*******************************************************************************
* Routine  : LocalSettingsWrite
* Gazintas : None
* IOs      : memaddr
* Returns  : Nothing
* Globals  : LocalSettings
*
* This routine gets called by the 'settings save' command to save all the local
* settings if local mode is enabled.  memaddr is the I2C write address that
* gets incremented after each write based on the bytes in the TLV entry.
*******************************************************************************/
void LocalSettingsWrite(uint32_t* memaddr)
{
   write_tlv_i1 (memaddr,TGRP_LOCAL,TLVT_LOCMODE    ,&LocalSettings.OfflineMode     ) ;
   write_tlv_i1 (memaddr,TGRP_LOCAL,TLVT_LOCCWS     ,&LocalSettings.OffineCwSpd     ) ;
   write_tlv_i1 (memaddr,TGRP_LOCAL,TLVT_LOCPLF     ,&LocalSettings.OffinePLF       ) ;
   write_tlv_i1 (memaddr,TGRP_LOCAL,TLVT_LOCPLL     ,&LocalSettings.OffinePLL       ) ;
   write_tlv_i1 (memaddr,TGRP_LOCAL,TLVT_LOCDEEMPH  ,&LocalSettings.OffineDeemph    ) ;
   write_tlv_i2 (memaddr,TGRP_LOCAL,TLVT_LOCPRECW   ,&LocalSettings.OffinePreCw     ) ;
   write_tlv_i2 (memaddr,TGRP_LOCAL,TLVT_LOCPOSTCW  ,&LocalSettings.OffinePostCw    ) ;
   write_tlv_i2 (memaddr,TGRP_LOCAL,TLVT_LOCIDTIME  ,&LocalSettings.OffineIdTime    ) ;
   write_tlv_i2 (memaddr,TGRP_LOCAL,TLVT_LOCHANGTIME,&LocalSettings.OffineHangTime  ) ;
   write_tlv_str(memaddr,TGRP_LOCAL,TLVT_LOCID      ,&LocalSettings.OfflineID       ,SETTINGS_CWID_LEN) ;
   write_tlv_str(memaddr,TGRP_LOCAL,TLVT_LOCPROC    ,&LocalSettings.OfflineProc     ,SETTINGS_CWID_LEN) ;
}

/*******************************************************************************
* Routine  : SetLocal
* Gazintas : argc - argument count for the whole line including "set local"
*          : argv - arguments (argv[0]="set", argv[1] = "local")
* IOs      : None
* Returns  : Nothing
* Globals  : Settings
*
* This is the CLI support routine for local mode settings.  If the CLI code
* gets 'set local' it just defers to this routine for any subsequent parsing.
* It only does that is LOCALVOTER is defined just as any of this code only gets
* compiled if LOCALVOTER is defined.
*******************************************************************************/
void SetLocal (int argc,char** argv)
{
   int     error = false ; /* Parsing error flag */
   int     Token = 0     ; /* Command token      */
   int32_t tmp   = 0     ; /* Temporary value    */

   /* Argument count should be exactly four */
   if (4!=argc) error = true ;

   /* See which setting command */
   if (!error) Token = parse_token(LocalCliCmds,argv[2],&error) ;

   if (error)
   {
      Console_printf("Not a recognized local setting, enter 'show local' for list.\n") ;
   }
   else
   {
      switch(Token)
      {
         case LOC_MODE     : SetList ("Voter2 Local Mode:"                 ,argv[3],                 &LocalSettings.OfflineMode,OfflineModes,true) ; break ;
         case LOC_CWSPEED  : SetNum  ("Voter2 Local CW Speed (wpm):"       ,argv[3],  5,  50,&tmp) ;  LocalSettings.OffineCwSpd = tmp              ; break ;
         case LOC_PLFREQ   : SetList ("Voter2 Local CTCSS Freq (hz):"      ,argv[3],                 &LocalSettings.OffinePLF,PLTones,true)        ; break ;
         case LOC_DEEMPH   : SetOnOff("Voter2 Local De-Emphasis:"          ,argv[3],                 &LocalSettings.OffineDeemph)                  ; break ;
         case LOC_PRECW    : SetNum  ("Voter2 Local Pre-CW delay (ms):"    ,argv[3],100,5000,&tmp) ;  LocalSettings.OffinePreCw = tmp              ; break ;
         case LOC_POSTCW   : SetNum  ("Voter2 Local Post-CW delay (ms):"   ,argv[3],100,5000,&tmp) ;  LocalSettings.OffinePostCw = tmp             ; break ;
         case LOC_IDTIME   : SetNum  ("Voter2 Local ID spacing (sec):"     ,argv[3], 60, 600,&tmp) ;  LocalSettings.OffineIdTime = tmp             ; break ;
         case LOC_HANGTIME : SetNum  ("Voter2 Local hang time (ms):"       ,argv[3],100,5000,&tmp) ;  LocalSettings.OffineHangTime = tmp           ; break ;
         case LOC_PLL      : SetNum  ("Voter2 Local PL tone volume (0-10):",argv[3],  0,  10,&tmp) ;  LocalSettings.OffinePLL = tmp                ; break ;
         case LOC_ID       : SetStr  ("Voter2 Local CW ID:"                ,argv[3],                  LocalSettings.OfflineID,SETTINGS_CWID_LEN)   ; break ;
         case LOC_PROC     : SetStr  ("Voter2 Local Proceed ID:"           ,argv[3],                  LocalSettings.OfflineProc,SETTINGS_CWID_LEN) ; break ;
         default           : /* Unsupported tokens */                                                                                                break ;
      }
      /* Check the CW ID strings to be sure they are valid */
      CheckCWids() ;

      /* Finally, sync up the global versions of some local settings */
      SyncSettings() ;
   }
}

/*******************************************************************************
* Routine  : ShowLocal
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : Settings
*
* This is the CLI support routine for displaying mode settings.  If the CLI code
* gets 'show local' it just defers to this routine for any subsequent parsing.
* Since there are relatively few local mode settings, there are no parameters,
* I just display them all.
* The main CLI code only does this if LOCALVOTER is defined just as any of this
* code only gets compiled if LOCALVOTER is defined.
*******************************************************************************/
void ShowLocal (void)
{
   /* For showing local settings, just show them all */
   Console_printf("              Local Mode (%8s): %s\n",LocalCliCmds[ 0].token,OfflineModes[LocalSettings.OfflineMode].token ) ;
   Console_printf(" Local ID CW Speed (wpm) (%8s): %d\n",LocalCliCmds[ 1].token,             LocalSettings.OffineCwSpd        ) ;
   Console_printf("        Local CTCSS Freq (%8s): %s\n",LocalCliCmds[ 2].token,PLTones     [LocalSettings.OffinePLF].token   ) ;
   Console_printf("       Local De-Emphasis (%8s): %s\n",LocalCliCmds[ 3].token,Booleans    [LocalSettings.OffineDeemph].token) ;
   Console_printf(" Local Pre-CW delay (ms) (%8s): %d\n",LocalCliCmds[ 4].token,             LocalSettings.OffinePreCw        ) ;
   Console_printf("Local Post-CW delay (ms) (%8s): %d\n",LocalCliCmds[ 5].token,             LocalSettings.OffinePostCw       ) ;
   Console_printf(" Local ID Interval (sec) (%8s): %d\n",LocalCliCmds[ 6].token,             LocalSettings.OffineIdTime       ) ;
   Console_printf("    Local Hang Time (ms) (%8s): %d\n",LocalCliCmds[ 7].token,             LocalSettings.OffineHangTime     ) ;
   Console_printf("Local CTCSS level (0-10) (%8s): %d\n",LocalCliCmds[ 8].token,             LocalSettings.OffinePLL          ) ;
   Console_printf("       Local callsign ID (%8s): %s\n",LocalCliCmds[ 9].token,             LocalSettings.OfflineID          ) ;
   Console_printf("        Local Proceed ID (%8s): %s\n",LocalCliCmds[10].token,             LocalSettings.OfflineProc        ) ;
   CheckCWids() ;
}

/*******************************************************************************
* Routine  : SyncSettings
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : Settings
*
* This syncs up the necessary global settings after any update to the local
* settings.  Because there can be different local mode implementations, each
* with their own settings structures, the common code needs some shared global
* settings to react to no matter which local implementation is being used.
* These are those common settings.
*******************************************************************************/
static void SyncSettings(void)
{
   LocalDeemph    = LocalSettings.OffineDeemph ;
   Local_PLL_Lvl  = LocalSettings.OffinePLL ;
   Local_PLL_Freq = LocalSettings.OffinePLF ;
}

/*******************************************************************************
* Routine  : CheckCWids
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : LocalSettings.OfflineID, LocalSettings.OfflineProc
*
* This routine checks the above two settings to make sure they are decent for
* sending out as Morse Code.  That is, upper case A-Z, 0-9, and /.  I support
* some other characters too, but warn the user if they are getting into iffy
* characters.
*******************************************************************************/
void CheckCWids(void)
{
   int i = 0 ;
   int uhoh = false ;

   while ((i<SETTINGS_CWID_LEN) && (LocalSettings.OfflineID[i]))
   {
      /* Yea, this is some pretty crazy logic that needed some formatted      */
      /* parsing to get it right.  Weird part is I got it right on the first  */
      /* try!                                                                 */
      if (!(
             ((LocalSettings.OfflineID[i]>='0') && (LocalSettings.OfflineID[i]<='9')) ||
             ((LocalSettings.OfflineID[i]>='A') && (LocalSettings.OfflineID[i]<='Z')) ||
              (LocalSettings.OfflineID[i]=='/')
        ))
      {
        uhoh = true ;
      }
      i++ ;
   }

   i = 0 ;
   while ((i<SETTINGS_CWID_LEN) && (LocalSettings.OfflineProc[i]))
   {
      if (!(
             ((LocalSettings.OfflineProc[i]>='0') && (LocalSettings.OfflineProc[i]<='9')) ||
             ((LocalSettings.OfflineProc[i]>='A') && (LocalSettings.OfflineProc[i]<='Z')) ||
              (LocalSettings.OfflineProc[i]=='/')
        ))
      {
        uhoh = true ;
      }
      i++ ;
   }

   if (uhoh)
   {
      Console_printf("\nWARNING: The Repeater callsign or proceed ID has characters\n"
                  "outside upper case A-Z, 0-9, or /.\n"
                  "This may have unpredictable results.\n\n") ;
   }
}

#endif /* #ifdef LOCALVOTER */
