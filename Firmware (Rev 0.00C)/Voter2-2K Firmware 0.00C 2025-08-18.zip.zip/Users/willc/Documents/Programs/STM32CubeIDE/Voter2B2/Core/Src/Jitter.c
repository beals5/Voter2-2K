/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Jitter file.  It is in charge of the CLI jitter command that   */
/* logs and displays audio packet jitter.                                     */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Cmd_jitter - Status CLI command                                         */
/*  - Jitter_Log - Called by IP processing routine on receipt a packet.       */
/*                                                                            */
/******************************************************************************/
// TO DO:
//
/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "cmsis_os.h"
#include "string.h" /* for memset */

#include "Options.h"
#include "main.h"
#include "Utils.h"
#include "ConsoleTask.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/
extern TIM_HandleTypeDef htim2 ;

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
enum
{
   CMD_OOPS = 0,
   CMD_START,
   CMD_STOP,
   CMD_RESET,
   CMD_SHOW
} JITTER_ENUMS ;

#define JITTER_ENTRIES 25
#define JITTER_BINSIZE 4 /* in ms */

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
char* cmd_jitter_cmd  = "jitter" ;
char* cmd_jitter_help = "jitter - [start|stop|reset|show] Audio packet jitter measurer controls\n"
                        "         start - start measuring\n"
                        "         stop - stop measuring\n"
                        "         reset - reset counters\n"
                        "         show - show jitter histogram\n" ;


/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TOKENLIST JitterCmds[] =
{
   {"start",CMD_START},
   {"stop" ,CMD_STOP },
   {"reset",CMD_RESET},
   {"show" ,CMD_SHOW },
   {NULL   ,0        }
} ;

/* The histogram table */
static uint16_t Jitter_Histogram[JITTER_ENTRIES] = {0}   ; /* The table   */
static int      Measure_Jitter                   = false ; /* On/off flag */

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void Jitter_Reset(void) ;
static void Jitter_Show(void) ;
static void Jitter_Graph(int,int) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : Cmd_jitter
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command sets or shows the time from the RTC.
*******************************************************************************/
int Cmd_jitter(int argc, char* argv[])
{
   int error = false ; /* Parsing error flag */
   int Token = 0     ; /* Command token      */

   /* See which jitter command */
   if (2==argc)
   {
      Token = parse_token(JitterCmds,argv[1],&error) ;
   }
   else
   {
      error = true ;
   }

   if (error)
   {
      Console_printf("Invalid parameter, see help.\n") ;
   }
   else
   {
      switch(Token)
      {
         case CMD_START : Measure_Jitter = true  ; break ;
         case CMD_STOP  : Measure_Jitter = false ; break ;
         case CMD_RESET : Jitter_Reset()         ; break ;
         case CMD_SHOW  : Jitter_Show()          ; break ;
         default        :                          break ; /* Shouldn't happen */
      }
   }

   return (0) ;
}

/*******************************************************************************
* Routine  : Jitter_Reset
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : Jitter_Histogram
*
* This function clears out the Jitter table.
*******************************************************************************/
static void Jitter_Reset(void)
{
   memset(Jitter_Histogram,0,sizeof(Jitter_Histogram)) ;
}

/*******************************************************************************
* Routine  : Jitter_Show
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : Jitter_Histogram
*
* This function displays the histogram contents.
*******************************************************************************/
static void Jitter_Show(void)
{
   int i   = 0 ; /* General counter                            */
   int max = 0 ; /* Max value in histogram table (for scaling) */

   /* Go find the max value */
   for (i=0;i<JITTER_ENTRIES;i++)
   {
      if (Jitter_Histogram[i]>max) max = Jitter_Histogram[i] ;
   }

   /* The fixed header info... */
   Console_printf("Audio Packet Jitter Histogram\n") ;
   Console_printf("  ms    value graph\n") ;
   Console_printf("======= ===== ==================================================\n") ;

   /* The first 49 regular entries... */
   for (i=0;i<JITTER_ENTRIES-1;i++)
   {
      Console_printf("%3d-%3d %5d ",i*JITTER_BINSIZE,(i+1)*JITTER_BINSIZE-1,Jitter_Histogram[i]) ;
      Jitter_Graph(Jitter_Histogram[i],max) ;
   }

   /* The last entry is the "everything greater" bin, so different formatting */
   Console_printf("   >%3d %5d ",JITTER_BINSIZE*(JITTER_ENTRIES-1),Jitter_Histogram[JITTER_ENTRIES-1]) ;
   Jitter_Graph(Jitter_Histogram[i],max) ;
}

/*******************************************************************************
* Routine  : Jitter_Graph
*   Inputs : value - value to graph
*          : max - max value (represents full [50 char]) graph
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This function displays a line of asterisk's proportional to the max value,
* so if value = max, 50 stars, if 1/5 of max, 25 stars.
*******************************************************************************/
static void Jitter_Graph(int value, int max)
{
   int  nstars  =  0  ; /* Stars to print        */
   char bar[52] = {0} ; /* String of those stars */

   /* Compute star count.  There are some weird cases where value>max, so     */
   /* just to be sure, make sure nstars can't be >50.                         */
   nstars = (value*50)/max ;
   if (nstars>50) nstars = 50 ;

   /* bar is already 52 nulls, so just memset the number of stars, terminate  */
   /* it with an LF and print it.  There will always be a null at the end.    */
   memset(bar,'*',nstars) ;
   bar[nstars] = '\n' ;
   Console_printf("%s",bar) ;
}

/*******************************************************************************
* Routine  : Jitter_Log
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : Jitter_Histogram
*
* This is the function called by the Ethernet packet handling routines, both
* uLaw and ADPCM.  I just get the TIM2 counter value incrementing ever 25ns and
* compare it to the previously read value to get the delta and then increment
* that histogram bin value.  If any of the entries gets to 50K before being
* stopped by the user I stop there automatically to preserve the integrity of
* the histogram.
*******************************************************************************/
void Jitter_Log(void)
{
   static uint32_t LastCount = 0 ; /* Last counter value to get a delta */

   uint32_t CurrentCount = 0 ; /* Current counter value */
   uint32_t Delta        = 0 ; /* Delta in ms           */
   int      bin          = 0 ; /* Histogram bin number  */

   /* Get the current count of Timer 2.                             */
   /* No need to worry about rollover, it's a feature not a bug! :) */
   CurrentCount = htim2.Instance->CNT ;

   /* Always get the current count (and save it below) so that even on first  */
   /* activation, we'll have an accurat delta.  Only do something with it if  */
   /* we are actually measuring.                                              */
   if (Measure_Jitter)
   {
      Delta = CurrentCount - LastCount ;

      /* The delta is in 25ns ticks, convert to ms */
      Delta = Delta/40000 ;

      /* Convert to a bin number and take care of a bin number overflow */
      bin = Delta/JITTER_BINSIZE ;
      if (bin>JITTER_ENTRIES-1) bin = JITTER_ENTRIES-1 ;

      /* Increment the bin unless any bin exceeds the max. */
      if (Jitter_Histogram[bin]<=50000)
      {
         Jitter_Histogram[bin]++ ;
      }
      else
      {
         Measure_Jitter = false ;
      }
   }

   /* Save the count so we can get delta to the next sample */
   LastCount = CurrentCount ;
}
