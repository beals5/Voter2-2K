/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the DialTask file. It has the top level supervisory RTOS task for  */
/* DIAL comms as well as all the helper routines that shuttle data between    */
/* the Audio ISRs and Ethernet task.                                          */
/* It is only enabled if Voter mode is enabled.                               */
/******************************************************************************/
/* Public routines are:                                                       */
/*  - Dial_Enqueue - DialTask message enqueuer                                */
/*  - DialEthRxTask - Task just for getting DIAL packets                      */
/*  - DialTask - The top level task for DIAL traffic handling                 */
/*                                                                            */
/******************************************************************************/
// To Do:
// Should there be a user-programmable timeout for Status packets to go back to disconnected?
// Clean up GPS/GP handling in Do_DIAL_Supervisory_Stuff()
// I think audio buffers could be cleaned up and optimized more
// See if this file can be split up, it is getting big (>1000 lines)
// Timestamping for ADPCM needs fixing.
//
/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>
#include <stdio.h>

#include "lwip.h"
#include "lwip/api.h"

#include "main.h"
#include "Options.h"
#include "Settings.h"
#include "logger2rt.h"
#include "EthernetTask.h"
#include "DialTask.h"
#include "Gpio.h"
#include "AnalogIO.h"
#include "Rx_DSP.h"
#include "Tx_DSP.h"
#include "Codecs.h"
#include "GPS.h"
#include "DialSettings.h"
#include "Utils.h"
#include "SetShow.h"
#include "Jitter.h"

/******************************************************************************/
/* Local defines (including enums)                                            */
/******************************************************************************/
#define DIALWATCHDOGTRIG 250 /* DIAL connection watchdog count (@50 tics/sec) */
#define NOTMASTER_DELAY  6   /* Delay in ms for data if not timing master     */

/* DIAL packet sizes */
#define VOTER_MINPLEN       24 /* DIAL Packet minimum size              */
#define VOTER_MAXPLEN      225 /* DIAL Packet maximum size              */
#define VOTER_PACKLEN_T0GP  25 /* Authorization packet size (Type 0 GP) */
#define VOTER_PACKLEN_T0GPS 24 /* Authorization packet size (Type 0 GPS)*/
#define VOTER_PACKLEN_T1   185 /* MuLaw packet size (Type 1)            */
#define VOTER_PACKLEN_T2GP  24 /* GPS packet size (Type 2 GP)           */
#define VOTER_PACKLEN_T2GPS 50 /* GPS packet size (Type 2 GPS)          */
#define VOTER_PACKLEN_T3   188 /* ADPCM packet size (Type 3)            */
#define VOTER_PACKLEN_T5   224 /* Ping packet size (Type 5) (variable!) */

#define DIAL_AUD_MAXPACKETSIZE 163 /* for uLaw or ADPCM (ADPCM biggest) */

/******************************************************************************/
/* Structures                                                                 */
/******************************************************************************/
/* These are the Voter packet structures.  The header is the same for  */
/* all of them, then have structures for each packet type starting     */
/* the common header.                                                  */
typedef struct
{
   uint32_t time_s        ; /* Time in seconds                     */
   uint32_t time_ns       ; /* Time in ns (voting) or counter (GP) */
   uint8_t  challenge[10] ; /* Challenge message                   */
   uint8_t  response[4]   ; /* Challenge response                  */
   uint16_t Payload_Type  ; /* Payload type identifier             */
} HEADER_T ;

typedef struct
{
   HEADER_T header        ; /* Payload header (common)             */
   uint8_t  FlagByte      ; /* Flags byte                          */
} PAYLOAD_T0_STRUCT  ;

typedef struct
{
   HEADER_T header        ; /* Payload header (common)             */
   uint8_t  Rssi          ; /* RSSI value                          */
   uint8_t  Audio[160]    ; /* Audio samples (160 samples or 20ms) */
} PAYLOAD_T1_STRUCT ;

typedef struct
{
   HEADER_T header        ; /* Payload header (common)             */
   uint8_t  Longitude[9]  ; /* GPS Longitude                       */
   uint8_t  Latitude[10]  ; /* GPS Latitude                        */
   uint8_t  Altitude[7]   ; /* GPS Altitude                        */
} PAYLOAD_T2_STRUCT ;

typedef struct
{
   HEADER_T header        ; /* Payload header (common)             */
   uint8_t  Rssi          ; /* RSSI value                          */
   uint8_t  Audio[163]    ; /* Audio data (163 bytes/320 samples)  */
} PAYLOAD_T3_STRUCT ;

typedef struct
{
   HEADER_T header        ; /* Payload header (common)             */
   uint8_t  PingData[200] ; /* Ping data (200 bytes max)           */
} PAYLOAD_T5_STRUCT ;

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
int      Rx_Active                = false ; /* Repeater Rx Active      */
uint32_t TxPackets[PAYLOAD_CNTRS] = {0}   ; /* Tx packet count by type */
uint32_t RxPackets[PAYLOAD_CNTRS] = {0}   ; /* Rx packet count by type */
uint8_t  DIAL_flagbyte            =  0    ; /* DIAL Server flag byte   */

/* For packet Timestamps */
uint32_t NewPktSecs = 0 ; /* Just-received packet timestamp (seconds) */
uint32_t NewPktNs   = 0 ; /* Just-received packet timestamp (ns)      */

/* For a sync check */
uint8_t  SyncCheck    = false     ; /* Sync check flag     */
uint32_t MySecs       = 0         ; /* Event local seconds */
uint32_t MynSecs      = 0         ; /* Event local ns      */
uint32_t DSSecs       = 0         ; /* DIAL server seconds */
uint32_t DSnSecs      = 0         ; /* DIAL server ns      */

uint32_t DIAL_ip      = 0         ; /* DIAL server resolved IP */
int      DIAL_State   = DIAL_DISC ; /* DIAL connection state   */
int      DIAL_Restart = false     ; /* DIAL Restart flag       */

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
#ifndef NODIALTASK

static struct netconn *DIALconn = NULL  ; /* netconn handle for DIAL server   */
static int      EnableRxQueue   = false ; /* Enable message queuing           */
static uint32_t FKGPS_Time      = 0     ; /* Fake GPS Time (seconds)          */
static uint32_t FKGPS_Tns       = 0     ; /* Fake GPS Time (ns)               */
static uint32_t GP_SeqNum       = 0     ; /* GP mode packet counter           */

static uint8_t   DIAL_Challenge[SETTINGS_CHALLENGE_LEN] = {0} ;/* Challenge string from the DIAL server         */
static ip_addr_t DIAL_Server_IP                         = {0} ; /* DIAL Sever IP address                        */

static PAYLOAD_T0_STRUCT Struct_AuthPacket    = {0} ; /* Auth packet (rtn data)*/
static PAYLOAD_T1_STRUCT Struct_MuLawRxPacket = {0} ; /* MuLaw Rx Data packet  */
static PAYLOAD_T2_STRUCT Struct_GPSTxPacket   = {0} ; /* GPS packet (rtn data) */
static PAYLOAD_T3_STRUCT Struct_ADPCMRxPacket = {0} ; /* ADPCM Rx Data packet  */
static PAYLOAD_T5_STRUCT Struct_PingPacket    = {0} ; /* Ping packet (rtn data)*/

/* Above packets just cast to byte arrays for easier sending/receiving */
#define AuthPacket    ((uint8_t*)&Struct_AuthPacket)
#define MuLawRxPacket ((uint8_t*)&Struct_MuLawRxPacket)
#define GPSTxPacket   ((uint8_t*)&Struct_GPSTxPacket)
#define ADPCMRxPacket ((uint8_t*)&Struct_ADPCMRxPacket)
#define PingPacket    ((uint8_t*)&Struct_PingPacket)

static int16_t Tx_Samples[APKT_SAMPLES*2] ; /* Decompressed samples (2x for ADPCM) */

static int DialWatchdog = 0     ; /* DIAL Comms watchdog counter */
static int DIAL_Offline = false ; /* DIAL Offline flag           */

/* For bring-up, this is data for a fake GPS location string */
static char* FakeLongitude = "3936476N"  ; /*  9 bytes */
static char* FakeLatitude  = "10451881W" ; /* 10 bytes */
static char* FakeAltitude  = "1757.4\0"  ; /*  8 bytes */
#endif /* #ifndef NODIALTASK */

/* CRC polynomial for the Voter challenge/response if using SW CRC.           */
/* The table is based on the polynomial 0x04c11db7 (0xedb88320 reversed) and  */
/* is just copied from voter1 source.                                         */
/* Only needed if not using the STM32's hardware CRC.                         */
#ifndef USE_HW_CRC
static const long crc_32_tab[] = {
0x00000000, 0x77073096, 0xee0e612c, 0x990951ba, 0x076dc419, 0x706af48f,
0xe963a535, 0x9e6495a3, 0x0edb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988,
0x09b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91, 0x1db71064, 0x6ab020f2,
0xf3b97148, 0x84be41de, 0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7,
0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec, 0x14015c4f, 0x63066cd9,
0xfa0f3d63, 0x8d080df5, 0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172,
0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b, 0x35b5a8fa, 0x42b2986c,
0xdbbbc9d6, 0xacbcf940, 0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59,
0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116, 0x21b4f4b5, 0x56b3c423,
0xcfba9599, 0xb8bda50f, 0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924,
0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d, 0x76dc4190, 0x01db7106,
0x98d220bc, 0xefd5102a, 0x71b18589, 0x06b6b51f, 0x9fbfe4a5, 0xe8b8d433,
0x7807c9a2, 0x0f00f934, 0x9609a88e, 0xe10e9818, 0x7f6a0dbb, 0x086d3d2d,
0x91646c97, 0xe6635c01, 0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e,
0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457, 0x65b0d9c6, 0x12b7e950,
0x8bbeb8ea, 0xfcb9887c, 0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65,
0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2, 0x4adfa541, 0x3dd895d7,
0xa4d1c46d, 0xd3d6f4fb, 0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0,
0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9, 0x5005713c, 0x270241aa,
0xbe0b1010, 0xc90c2086, 0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f,
0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4, 0x59b33d17, 0x2eb40d81,
0xb7bd5c3b, 0xc0ba6cad, 0xedb88320, 0x9abfb3b6, 0x03b6e20c, 0x74b1d29a,
0xead54739, 0x9dd277af, 0x04db2615, 0x73dc1683, 0xe3630b12, 0x94643b84,
0x0d6d6a3e, 0x7a6a5aa8, 0xe40ecf0b, 0x9309ff9d, 0x0a00ae27, 0x7d079eb1,
0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe, 0xf762575d, 0x806567cb,
0x196c3671, 0x6e6b06e7, 0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc,
0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5, 0xd6d6a3e8, 0xa1d1937e,
0x38d8c2c4, 0x4fdff252, 0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b,
0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60, 0xdf60efc3, 0xa867df55,
0x316e8eef, 0x4669be79, 0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236,
0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f, 0xc5ba3bbe, 0xb2bd0b28,
0x2bb45a92, 0x5cb36a04, 0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d,
0x9b64c2b0, 0xec63f226, 0x756aa39c, 0x026d930a, 0x9c0906a9, 0xeb0e363f,
0x72076785, 0x05005713, 0x95bf4a82, 0xe2b87a14, 0x7bb12bae, 0x0cb61b38,
0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7, 0x0bdbdf21, 0x86d3d2d4, 0xf1d4e242,
0x68ddb3f8, 0x1fda836e, 0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777,
0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c, 0x8f659eff, 0xf862ae69,
0x616bffd3, 0x166ccf45, 0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2,
0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db, 0xaed16a4a, 0xd9d65adc,
0x40df0b66, 0x37d83bf0, 0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9,
0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6, 0xbad03605, 0xcdd70693,
0x54de5729, 0x23d967bf, 0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94,
0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d
};
#endif

/******************************************************************************/
/* External globals. CubeMX has you define them as externs in each file       */
/* instead of an include file, weird.                                         */
/******************************************************************************/
extern osMessageQId DialQueueHandle;
extern CRC_HandleTypeDef hcrc;
extern osThreadId DialTaskIDHandle;
extern osThreadId DialEthRxTaskIDHandle;


/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
#ifndef NODIALTASK
static void    HandleRxAudio(uint32_t,uint32_t) ;
static void    Update_Counters(void) ;
static void    Do_DIAL_Supervisory_Stuff(void) ;

static uint8_t Get_RSSI(void) ;
static void    HandleEthData(uint8_t*,uint32_t) ;
static void    Tx_handleCR  (uint8_t*,uint8_t*) ;
static void    Rx_handleCR  (uint8_t*,uint8_t*) ;

static void    Tx_AuthPacket(void) ;
static void    Tx_MulawPacket(uint8_t*,uint8_t) ;
static void    Tx_ADPCMPacket(uint8_t*,uint8_t) ;
static void    Tx_GPSPacket(void) ;
static void    FillTimeStamp(uint32_t*, uint32_t*) ;
//static void  GPS_Syncer(uint8_t*,uint32_t,uint32_t,uint8_t) ;
static void    Package_MuLaw_Packet(uint32_t,uint32_t,uint8_t,uint8_t*) ;

static int     Rx_Auth_Packet    (void*,uint16_t,uint32_t,uint32_t) ;
static int     Rx_MuLaw_Packet   (void*,uint16_t,uint32_t,uint32_t) ;
static int     Rx_GPSInfo_Packet (void*,uint16_t                  ) ;
static int     Rx_ADPCM_Packet   (void*,uint16_t,uint32_t,uint32_t) ;
static int     Rx_Ping_Packet    (void*,uint16_t                  ) ;

static long    crc32_bufs(unsigned char *buf, unsigned char *buf1) ;
static void    SendDialPacket(uint8_t*,uint32_t) ;
#endif /* #ifndef NODIALTASK */

/******************************************************************************/
/* Finally, routines!                                                         */
/******************************************************************************/

#ifndef NODIALTASK
/*******************************************************************************
* Routine  : Dial_Enqueue
* Gazintas : StreamID - Stream Identifier
*          : BuffID - Buffer Identifier
*          : len - Buffer length
* IOs      : None
* Returns  : Nothing
* Globals  : EnableRxQueue - Semaphore to enable incoming packets
*
* This is the routine to queue up data for the DialEthTx Task.  For efficiency,
* we just queue up tags that imply where the data is, we don't put the actual
* data into the queue.
*
* There is only one queue surce now (RxDSP), so this has redundant overhead and
* could be simplified.
*******************************************************************************/
void Dial_Enqueue(uint32_t StreamID, uint32_t BuffID, uint32_t len)
{
  /* Only if enabled, send the message into the Dial Task!                   */
  /* If not enabled, data just gets lost.  That is fine.                     */
  /* Mostly needed as the ISRs fire up before the RTOS and try to send data  */
  /* before the RTOS has started and that *is* bad.                          */
  if (EnableRxQueue)
  {
     /* Just bit-stuff the three parameters into a 32-bit value and send the */
     /* message to the DIAL task.                                            */
     uint32_t msg = ((StreamID&0xff)<<24)
                  + ((BuffID&0xff)<<16)
                  + (len&0xffff) ;

     osMessagePut(DialQueueHandle,msg,0) ;
  }
}
#endif /* #ifndef NODIALTASK */

/*******************************************************************************
* Routine  : DialEthTxTask
* Gazintas : None (argument isn't used)
* IOs      : None
* Returns  : Doesn't, this is a top level RTOS task
* Globals  : EnableRxQueue - flag to enable incoming packets from ISR
*
* This is the RTOS task for sending data to DIAL.
* A separate task manages data from DIAL.
* Data comes in from RxDSP via a queue using Dial_Enqueue().
* This task also handles all of the DIAL server comms for authentication,
* keep-alive, etc.  Ideally this task does everything between (uncompressed)
* audio samples from/to the TxDSP/RxDSP routines and Ethernet packets to/from
* Ethernet.  That is, compression/decompression is handled here.
*******************************************************************************/
 void DialEthTxTask(void const * argument)
{
   /* Do our prescribed wait then say Hi on the logger interface */
   osDelay(StartDelay_DIALTask) ;
   Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialTask: Start\r\n") ;

#ifdef NODIALTASK
   Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialTask: Terminated\r\n") ;
   osDelay(10) ; /* Wait a bit for the message to go out */
   osThreadTerminate(DialTaskIDHandle) ;
#else
   osEvent   event     = {0} ; /* event info (for incoming message) */
   uint32_t  StreamID  =  0  ; /* Incoming Message Stream ID        */
   uint32_t  BufferID  =  0  ; /* Incoming Message Buffer index     */
   uint32_t  BufferLen =  0  ; /* Incoming Message length           */

   /* If the DIAL server IP address is static, plunk in the user-specified IP */
   /* address we want to contact.                                             */
   if (DIALIPMODE_STATIC==DIALSettings.IPMode)
   {
      IP_ADDR4(&DIAL_Server_IP,(DIALSettings.Static_IP>>24) & 0xff,
                               (DIALSettings.Static_IP>>16) & 0xff,
                               (DIALSettings.Static_IP>> 8) & 0xff,
                               (DIALSettings.Static_IP    ) & 0xff) ;
   }
   else /* else do a DNS lookup for the DIAL server IP address */
   {
      /* Loop forever if the lookup fails.  Can't do much without a DIAL IP      */
      /* address.  It may be because of no network connection or maybe a bad     */
      /* FQDN, so just keep retrying until resolved.                             */
      while ((netconn_gethostbyname(DIALSettings.fqdn,&DIAL_Server_IP))!= ERR_OK)
      {
         Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialTask: DIAL server DNS Lookup failed!\r\n") ;
         osDelay(1000) ;
      }
   }

   /* Save the resolved address just for CLI reporting */
   DIAL_ip = DIAL_Server_IP.addr ;

   /* Set up the UDP connection with the DIAL server. Note that this does not */
   /* generate any IP traffic.  I don't think it can fail.                    */
   /* Connect to the DIAL server using UDP.                                   */
   /* Note that this doesn't actually establish or confirm a connection!      */
   /* It "connects" even if a server isn't there.  This is normal.            */
   DIALconn = netconn_new(NETCONN_UDP);
   Logger2_Msg(Logger.Dial,LOG_SUPPORT,LOG_TIME,"DialTask: netconn_new (%8.8x)\r\n",(uint32_t)DIALconn) ;
   netconn_connect(DIALconn,&DIAL_Server_IP,DIALSettings.VoterPort);
   Logger2_Msg(Logger.Dial,LOG_SUPPORT,LOG_TIME,"DialTask: netconn_connect (%8.8x)\r\n",(uint32_t)DIALconn) ;

   /* OK, we're up!  Enable incoming Rx Audio messages and Ethernet packets!  */
   EnableRxQueue = true ;

   for(;;) /* RTOS Task Infinite loop */
   {
      /* Wait for a message to arrive... (blocking wait) */
      event = osMessageGet(DialQueueHandle,osWaitForever ) ;

      if ( event.status == osEventMessage) /* Only message type I'm expecting */
      {
         /* Message is a uint32_t.  The upper 8 bits are the stream           */
         /* identifier, the next 8 bits are the buffer identifier, and the    */
         /* lower 16 bits are the Buffer length.                              */
         StreamID  = ((event.value.v)>>24)&0xff ;
         BufferID  = ((event.value.v)>>16)&0xff ;
         BufferLen =  (event.value.v)&0xffff    ;

         /* Go handle the packet */
         if (DIALTASK_STREAMID_RXAUDIO == StreamID) HandleRxAudio(BufferID,BufferLen) ;
      }
   }
#endif /* #ifdef NODIALTASK */
}

#ifndef NODIALTASK

/*******************************************************************************
* Routine  : HandleRxAudio
* Gazintas : BufferID - Buffer location pointer
*          : BufferLen - Buffer data length (not currently used)
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine processes Rx Audio from the DSP routines.  First it takes care
* of some general maintenance stuff (counters and supervisory things) for
* care and feeding of the DIAL server, then actual sending of data to the DIAL
* server.
*******************************************************************************/
static void HandleRxAudio(uint32_t BufferID,uint32_t BufferLen)
{
   int16_t* buffer    = NULL  ; /* DSP'd data pointer         */
   uint16_t LocRSSI   = 0     ; /* Local RSSI value           */
   int      HaveData  = false ; /* Data available (for ADPCM) */

   static uint8_t Rx_Compressed[DIAL_AUD_MAXPACKETSIZE] ; /* Compressed audio buffer to DialTask */

   /* RxAudio generates a reliable hardware-based 20ms interrupt that happens */
   /* even if there is no carrier detect from the repeater, so can rely on it */
   /* for anything time-based.  Update our time and packet counters for       */
   /* General Purpose mode.  This is a handy place to also implement the      */
   /* forced comms restart timer.                                             */
   Update_Counters() ;

   /* Next, handle all the supervisory DIAL authentication stuff and  */
   /* keep-alive packet processing.                                   */
   Do_DIAL_Supervisory_Stuff() ;

   /* Finally start processing data! */
   switch (BufferID)
   {
      case DIALTASK_BUFID_ADC1 : buffer = Rx_ppbuf1 ; break ;
      case DIALTASK_BUFID_ADC2 : buffer = Rx_ppbuf1 ; break ;
      default                  : buffer = NULL      ; break ; /* Oops! */
   }

   if (NULL != buffer)
   {
      /* Send the packet of audio to the DIAL server if we are authorized and */
      /* and there is a valid signal or DIAL server says to send always.      */
      if (DIAL_AUTHORIZED && (Rx_Active||DIAL_ALWAYSAUDIO))
      {
         /* If Rx isn't active, leave LocRSSI at 0, otherwise figger it out   */
         if (Rx_Active)
         {
            /* Get RSSI from repeater in 0-4095 range and convert to 0-255 range.*/
            /* Cap it at 255 just in case too.                                   */
            /* THIS IS JUST A PLACEHOLDER, IT WILL NEED SOME WORK FOR REAL       */
            /* VOTING INCLUDING ABOVE BAND NOISE MEASURING.                      */
            LocRSSI = Get_RSSI()/16 ;
            if (LocRSSI>255) LocRSSI=255 ;

            /* Just for some integration testing, force RSSI to 254 */
            LocRSSI = 254 ;
         }

         /* Now for audio compression, either uLaw or ADPCM */
         if (!DIAL_USEADPCM)
         {
            /* For uLaw it is pretty simple, sample-for-sample 16-bit to 8-bit*/
            /* compression.  Compress it, then create a type 1 packet to send */
            /* it to the DIAL server.                                         */
            CompressuLaw(buffer,Rx_Compressed) ;
            Tx_MulawPacket(Rx_Compressed,LocRSSI) ;
         }
         else /* ADPCM */
         {
            /* We only get data back from the ADPCM compressor every other    */
            /* packet, HaveData says we have data (!).                        */
            HaveData = CompressADPCM(buffer,Rx_Compressed) ;
            if (HaveData)
            {
               Tx_ADPCMPacket(Rx_Compressed,LocRSSI) ;
            }
         }
      }
   }
}

/*******************************************************************************
* Routine  : Update_Counters
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : GP_SeqNum, FKGPS_Tns, FKGPS_Time
*          :  DIAL_Restart, DIAL_Offline
*
* This updates the two packet counters used for DIAL comms.  For General
* Purpose packets it is just a count that increments every 20ms.  For initial
* debugging I came up with a fake GPS mode where I'm temporarily cheating by
* getting the time from the DIAL server and then incrementing it by 20 million
* each 20ms.  It shouldn't be needed anymore, but keeping it for debugging.
*
* Also, here is where I deal with the forced offline mode.  If the semaphore
* to issue a restart gets set, this sets the local global DIAL_Offline for 2x
* the DIAL watchdog period to force a DIAL comms restart.
*******************************************************************************/
static void Update_Counters(void)
{
   static int Offline_Counter = 0 ; /* Timer counter for forced offline mode  */

   /* For Non-GPS audio, we simply send a sequence number in the time_ns part */
   /* of the header.  This must continuously increment even if not sending    */
   /* data.  This routine gets called every 20ms from the ISR even if there   */
   /* isn't a valid signal level, so fulfills that purpose.  Later, based on  */
   /* if there is a valid signal the packet will actually be sent to the DIAL */
   /* server or not.                                                          */
   /* Of note, if sending ADPCM packets, the counter value sent will          */
   /* actually increment by two each packet since they are sent every 40ms    */
	/* instead of every 20ms. This is what the spec says to do.               */
   GP_SeqNum++ ;

   /* For the rough time for non-GPS packets I capture the time from the      */
   /* authorization packet and then increment it every second.  For bring-up  */
   /* I have a fake GPS mode where I create a full timestamp to emulate a GPS */
   /* timed packet.  I do this by capturing the full time from the server     */
   /* (including ns), then increment the ns time by 20,000,000 each 20ms and  */
   /* update the seconds time on overflow.                                    */
   FKGPS_Tns +=20000000 ; /* 20ms in ns */

   if (FKGPS_Tns >=1000000000) /* billion ns to a s */
   {
      FKGPS_Tns -= 1000000000 ;
      FKGPS_Time++   ;
   }

   /* The CLI command set dial restart sets DIAL_Restart to true.  This code  */
   /* picks it up on the next packet tick and sets DIAL_Offline that tells    */
   /* the incoming packet handler to drop all packets and outgoing packet     */
   /* handler to not send out any packets.  time to do this is 2x the number  */
   /* of ticks to recognize a comms failure.                                  */
   if (DIAL_Restart)
   {
      DIAL_Restart = false ;
      DIAL_Offline = true ;
      Offline_Counter = DIALWATCHDOGTRIG*2 ;
   }

   if (Offline_Counter>0)
   {
      Offline_Counter-- ;
      if (0==Offline_Counter)
      {
         DIAL_Offline = false ;
      }
   }
}

/*******************************************************************************
* Routine  : Do_DIAL_Supervisory_Stuff
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  :
*
* This gets called every 20ms and handles all the DIAL supervisory comms.  In
* particular the sending of authentication packets when not connected and
* sending of GPS/Keep-alive packets when connected.
* NOTE!!  Temporarily, this code keeps on sending Authorization packets until
* we get back an authorization packet acknowledging we are in General Purpose
* mode!!  This will need cleaning up once I get GPS mode coded and debugged.
*******************************************************************************/
static void Do_DIAL_Supervisory_Stuff(void)
{
   static int counter = 0 ; /* State counter */

   /* Increment our state counter for whatever is next... */
   counter++ ;

   /* Special case of a sync check, send a spontaneous auth packet */
   if (SYNCCHECK_START==SyncCheck)
   {
	   Tx_AuthPacket() ;
	   SyncCheck = SYNCCHECK_RUNNING ;
   }

   /* We start off in un-authorized mode, so send authorization packets until*/
   /* a connection is established.  Sending of audio data is disabled        */
   /* elsewhere while unauthorized.                                          */
   if (DIAL_NOTAUTHORIZED)
   {
      /* Send an authorization packet at the authorization rate.  If/when we */
      /* get a packet back from the server, the code receiving the packet    */
      /* will update DIAL_State.                                             */
      if (counter>(DIALSettings.Unauth_Rate/20))
      {
         counter = 0 ;
         Tx_AuthPacket() ;
      }
   }
   else /* if authorized */
   {
      /* If authorized, just send GPS packets at the authorization rate as a  */
      /* keep-alive message. In non-GPS mode this is just a dummy packet.     */
       if (counter>(DIALSettings.Unauth_Rate/20))
      {
         counter = 0 ;
         Tx_GPSPacket() ;
      }

      /* Also, make sure we're still talking to the DIAL server.  Increment   */
      /* the watchdog counter below each call (20ms) and if we ever get to    */
      /* the trigger value, assume we've lost contact.  Even if no audio is   */
      /* being exchanged, keepalive packets should be coming in every second. */
      DialWatchdog++ ;

      if (DialWatchdog>DIALWATCHDOGTRIG)
      {
         /* Uh-oh, lost comms! */
         DIAL_State = DIAL_DISC ;
         //Show_State(CONNECTED_STATE,false) ;
         Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialTask: Lost DIAL Server comms!\r\n") ;
         DialWatchdog=0 ; /* Reset count so no weirdness on restoration */
      }
   }
 }

/*******************************************************************************
* Routine  : Get_RSSI
* Gazintas : None
* IOs      : None
* Returns  : 0-255 RSSI value for the DIAL server
* Globals  : Many (fill in later)
*
* This is the top level routine to get the RSSI value.  Sources for RSSI depend
* on the users rssimode setting, analog or HPF.  If RxActive is not active, then
* the return RSSI is forced to 0 regardless of the analog or HPF value.
*******************************************************************************/
static uint8_t Get_RSSI(void)
{
   uint8_t rval = 0 ; /* RSSI value */

   if (Rx_Active) /* Only override default of 0 if Rx is active. */
   {
      if      (RSSI_ANALOG==Settings.RssiMode) rval = Get_Analog_RSSI() ;
      else if (RSSI_HPF   ==Settings.RssiMode) rval = Hpf_RSSI          ;
   }

   return(rval) ;
}

/*******************************************************************************
* Routine  : DialEthRxTask
* Gazintas : None (argument isn't used)
* IOs      : None
* Returns  : Doesn't, this is a top level RTOS task
* Globals  : DIALconn - The DIAL connection
*          : EnableRxQueue - enable DIAL messages
*
* This task handles UDP packets coming from the DIAL server.
* The task DialEthTxTask handles packets from the DIAL server.
* This task first waits for DialEthTxTask to set up the port, then has a
* blocking wait for data.  It does a bit of sanity checking, then passes on
* the packet for interpreting.
*******************************************************************************/
 void DialEthRxTask(void const * argument)
{
#ifdef NODIALTASK
   osThreadTerminate(DialEthRxTaskIDHandle) ;
#else

   err_t         err     = ERR_OK ; /* Called routine result code */
   struct netbuf *rx_buf = NULL   ; /* Rx packet buffer handle    */

   /* First wait on DialTask getting its Ethernet stuff set up.  It signals */
   /* is ready by setting EnableRxQueue to true.                            */
   /* Yea, I could do the whole sempahore/signal thing, but this is simpler.*/
   while (!EnableRxQueue) osDelay(10) ;
   Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialEthRxTask: Start\r\n") ;

   /* Ready!  Now just wait on packets and if one comes along, queue it up    */
   /* for DialTask.                                                           */
   for(;;) /* RTOS Task Infinite loop */
   {
      err = netconn_recv(DIALconn, &rx_buf) ;
      if (0!=err) IncErrLog(DIALETHRXTASK_NETCONN_RECV,ERRLOG_SHOW) ;

      //Logger2_Msg(Logger.Dial,LOG_REGIO,LOG_TIME,"DialEthRxTask: Rx Data (%d,%d)\r\n",err,err?0:rx_buf->p->tot_len) ;

      /* If no Rx error and a reasonable packet length, process it! */
      /* *NEW* If forced offline mode, just ignore the packet */
      if ((ERR_OK==err) && (rx_buf->p->tot_len >= VOTER_MINPLEN) && (rx_buf->p->tot_len <= VOTER_MAXPLEN) && !DIAL_Offline)
      {
         /* Go process the packet */
         HandleEthData(rx_buf->p->payload,rx_buf->p->tot_len) ;
      }
      /* and finally release the netbuf */
      if (rx_buf) netbuf_delete(rx_buf) ;
      /* "The Internet" says to delete and re-request a netbuf each time,     */
      /* don't try to just re-use the same netbuf over and over.              */
      /* I still tried to re-used it and it didn't go well! :)                */
   }
#endif /* #ifdef NODIALTASK */
}

/*******************************************************************************
* Routine  : HandleEthData
* Gazintas : DialEthRxPkt - Buffer of data
*          : BufferLen - Buffer data length
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine processes Ethernet packets from the DIAL server.  These are just
* UDP packets with a simple length (VOTER_MINPLEN/VOTER_MAXPLEN) check.
* Enough bytes for the header and less than the max possible DIAL packet.
*******************************************************************************/
static void HandleEthData(uint8_t* DialEthRxPkt,uint32_t BufferLen)
{
   bool     err    = true ; /* Packet error flag      */
   HEADER_T header = {0}  ; /* Packet header contents */

   /* The general flow is first looking at the header see if it makes sense,  */
   /* then doing the challenge/response since it is common to all packets,    */
   /* then handing it off to each packet type for handling that packet types  */
   /* payload.  If anything is bad about the packet, it is simply dropped.    */

   /* Not yet, but check things like source IP address, port, and other stuff?*/

   /* To keep track if we are still connected to the DIAL server, I have      */
   /* essentially a comms watchdog.  It gets incremented every 20ms by the    */
   /* HandleRxAudio() routine.  Getting data here resets that counter to 0,   */
   /* so if that counter reaches the timeout value, we declare we've lost     */
   /* comms and go back to the unauthorized state.  For this routine, just    */
   /* Zero the watchdog count.                                                */
   DialWatchdog = 0 ;

   /* Still double-check the payload length to be enough for a header.        */
   if (BufferLen >= 24)
   {
      /* Copy the header bytes (in any byte alignment) from the UDP packet    */
      /* to the word-aligned header structure for parsing.                    */
      memcpy(&header,DialEthRxPkt,sizeof(HEADER_T)) ;
      /* do the net to host conversions for ints. */
      header.time_s = ntohl(header.time_s) ;
      header.time_ns = ntohl(header.time_ns) ;
      header.Payload_Type = ntohs(header.Payload_Type) ;

      /* Challenge response is common to all packets, so handle here */
      Rx_handleCR((uint8_t*)(DialEthRxPkt+8),(uint8_t*)(DialEthRxPkt+18)) ;

      /* Head off to the various routines based on the Payload Type.  They    */
      /* will do further payload-type-specific checking from there.           */
      /* Since DialEthRxPkt gets re-used after this, routines must make local */
      /* copies of any data they want to keep before returning.               */
      switch (header.Payload_Type)
      {
         case PAYLOAD_T0AUTH    :  err=Rx_Auth_Packet   (DialEthRxPkt,BufferLen,header.time_s,header.time_ns) ; break ;
         case PAYLOAD_T1MULAW   :  err=Rx_MuLaw_Packet  (DialEthRxPkt,BufferLen,header.time_s,header.time_ns) ; break ;
         case PAYLOAD_T2GPSINFO :  err=Rx_GPSInfo_Packet(DialEthRxPkt,BufferLen                             ) ; break ;
         case PAYLOAD_T3ADPCM   :  err=Rx_ADPCM_Packet  (DialEthRxPkt,BufferLen,header.time_s,header.time_ns) ; break ;
         case PAYLOAD_T5PING    :  err=Rx_Ping_Packet   (DialEthRxPkt,BufferLen                             ) ; break ;
         default                :  err=true                                                                   ; break ;
      }
   }
   else /* Payload < 24 bytes */
   {
      err = true ;
   }

   /* If any error, increment the error packet counter. */
   if (err) RxPackets[PAYLOAD_ERR]++ ;
}

/*******************************************************************************
* Routine  : Rx_handleCR
* Gazintas : New_DIAL_Challenge - incoming DIAL challenge string
*          : DIAL_CR_Response - DIALs response to the voters challenge string.
* IOs      : None
* Returns  :
* Globals  :DIAL_State
*
* This routine parses the challenge response info of any packet.  The challenge
* string from the DIAL server just gets stored so the response can be computed
* on the transmit side.  The challenge response from the DIAL server is
* compared to the expected response and DIAL_State is updated based on the
* result.
*******************************************************************************/
static void Rx_handleCR(uint8_t* New_DIAL_Challenge,uint8_t* DIAL_CR_Response)
{
   uint32_t expected_response = 0 ; /* Expected challenge response  */
   uint32_t actual_response   = 0 ; /* Challenge response from DIAL */
   int      LastState         = 0 ; /* For tracking a state change  */

   /* Just copy the DIALs challenge string for use later. */
   memcpy(DIAL_Challenge,New_DIAL_Challenge,SETTINGS_CHALLENGE_LEN) ;

   /* Compute the expected challenge response from the voter challenge string */
   /* and the system password, then get the challenge response from the       */
   /* received packet to compare (copying byte string to uint32).             */
   expected_response = ntohl(crc32_bufs((unsigned char*)DIALSettings.Voter_Challenge,(unsigned char*)DIALSettings.Host_Password)) ;
   memcpy(&actual_response,DIAL_CR_Response,4) ;

   /* Refresh the DIAL connection state.  Log a message only if a change. */
   if (0 == actual_response)
   {
      /* A challenge response of 0 forces unauthorized state */
      if (DIAL_UNAUTH != DIAL_State) Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialTask: De-Authorized by DIAL!\r\n") ;
      DIAL_State = DIAL_UNAUTH ;
      //Show_State(CONNECTED_STATE,false) ;
   }
   else if (expected_response == actual_response)
   {
      LastState = DIAL_State ;
      /* Matching challenge/response - a good start!  But need to be sure the */
      /* DIAL server agrees with our timing mode too. It may not initially.   */
      if (((PKTTIM_GP   ==DIALSettings.PacketTiming) &&  DIAL_GENPURPOSE ) ||
          ((PKTTIM_GPS  ==DIALSettings.PacketTiming) && !DIAL_GENPURPOSE ) ||
          ((PKTTIM_FKGPS==DIALSettings.PacketTiming) && !DIAL_GENPURPOSE )   )
      {
         /* While I insist the DIAL server give back the right timing mode, I */
         /* do just accept the compression mode.                              */
         DIAL_State = DIAL_USEADPCM?DIAL_ADPCM:DIAL_MULAW ;
      }

      /* If something changed, note it */
      if (DIAL_State != LastState)
      {
         Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialTask: Authorized! (%s)\r\n",DIAL_USEADPCM?"ADPCM":"MuLaw") ;
         //Show_State(CONNECTED_STATE,true) ;
      }
   }
   else
   {
      /* Got a non-zero response, but it didn't match */
      if (DIAL_UNAUTH != DIAL_State) Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialTask: DIAL failed challenge/response!\r\n") ;
      DIAL_State = DIAL_UNAUTH ;
      //Show_State(CONNECTED_STATE,false) ;
   }
}

/*******************************************************************************
* Routine  : Tx_handleCR
* Gazintas : Voter_Challenge - Outgoing challenge from voter to DIAL server
*          : Voter_CR_Response - Voters response to the servers challenge string.
* IOs      : None
* Returns  :
* Globals  :None
*
* This routine parses the challenge response info of any outgoing packet to
* the DIAL server.  The challenge string from the voter just gets plunked into
* the challenge string of the outgoing packet.  If not authorized, the challenge
* response is 0, otherwise the challenge response gets computed from the DIAL
* server challenge string and the voters password and sent back to the server.
*******************************************************************************/
static void Tx_handleCR(uint8_t* Voter_Challenge,uint8_t* Voter_CR_Response)
{
   uint32_t response = 0 ; /* Challenge response to DIAL */

   /* Just copy the Voters challenge string into the outgoing packet. */
   memcpy(Voter_Challenge,DIALSettings.Voter_Challenge,10) ;

   /* Whether authorized or not, just compute a challenge response and send   */
   /* it back.  If not authorized it will be junk, if authorized it will be   */
   /* good.  OK either way.                                                   */

   /* Compute the challenge response from the DIAL challenge string and the   */
   /* Voter password and plunk it in the response field.                      */
   response = htonl(crc32_bufs((unsigned char*)DIAL_Challenge,(unsigned char*)DIALSettings.Voter_Password)) ;

   memcpy(Voter_CR_Response,&response,4) ;
}

/*******************************************************************************
* Routine  : Tx_AuthPacket
* Gazintas : None (yet)
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine sends out a Type 0 authorization packet. As the actual
* authentication is handled by Tx_handleCR() shared with all payload types,
* this routine doesn't do much, just fills in the header and flag byte.
* For GP mode we set the GP bit, for GPS and fake GPS modes we clear the GP bit.
*
* NOTE: Well above is that the protocol spec implies.  In reality, it seems that
* if you want GPS-timed mode you send this packet without data and only send
* the data if the Flag Byte is non-zero (for GP mode)???
*******************************************************************************/
static void Tx_AuthPacket(void)
{
   /* Fill in all the other header stuff. */
   FillTimeStamp(&Struct_AuthPacket.header.time_s,&Struct_AuthPacket.header.time_ns) ;
 //Struct_AuthPacket.header.time_s       = htonl(FKGPS_Time) ;
 //Struct_AuthPacket.header.time_ns      = 0 ; /* not used for Auth packets?  */
   Struct_AuthPacket.header.Payload_Type = htons(PAYLOAD_T0AUTH) ;
   Struct_AuthPacket.FlagByte            = DIALFLAG_GENPURPOSE ; /* If sent, it's this */
   /* Challenge/response is handled later as it is common to all packets */

   Logger2_Msg(Logger.Dial,LOG_SUPPORT,LOG_TIME,"DialTask: Sending Auth len %d\r\n",
               (PKTTIM_GP==DIALSettings.PacketTiming)?VOTER_PACKLEN_T0GP:VOTER_PACKLEN_T0GPS) ;

   /* Packet ready: if GPS mode, only send the header.  If General Purpose    */
   /* mode, include the payload byte saying it's general purpose.             */
   SendDialPacket(AuthPacket,(PKTTIM_GP==DIALSettings.PacketTiming)?VOTER_PACKLEN_T0GP:VOTER_PACKLEN_T0GPS) ;
   TxPackets[PAYLOAD_T0AUTH]++ ;
}

/*******************************************************************************
* Routine  : Tx_MulawPacket
* Gazintas : buffer - 160 compressed audio samples
*          : rssi - signal strength
* IOs      : None
* Returns  : Nothing
* Globals  : Struct_MuLawRxPacket - Datagram ready to send via Ethernet
*
* This takes the sample data and creates the datagram to send via Ethernet
* to the DIAL server.  For GPS and fake GPS, the full time (s+ns) is
* in the header, for General Purpose mode, it is the rough time in the seconds
* field (same as fake GPS) and the General Purpose sequence number in the ns
* field.
*******************************************************************************/
static void Tx_MulawPacket(uint8_t* buffer,uint8_t rssi)
{
   static uint32_t Prev_GPS_Sec = 0 ; /* Previous GPS-based time (secs) */
   static uint32_t Prev_GPS_ns  = 0 ; /* Previous GPS-based time (ns)   */

   /* Start off clean, then fill in values */
   memset ((uint8_t*)&Struct_MuLawRxPacket,0,VOTER_PACKLEN_T1)   ;

   switch(DIALSettings.PacketTiming)
   {
      case PKTTIM_GP  :   Package_MuLaw_Packet(FKGPS_Time,GP_SeqNum,rssi,buffer) ;
                          break ;
      case PKTTIM_GPS :   /* The time now is at the end of the current audio  */
                          /* packet.  The time stamp needs to be for the      */
                          /* beginning of the packet which is actually the    */
                          /* end of the last packet, so use the time at the   */
                          /* end of the last packet now, then update that     */
                          /* time after sending out this packet.              */

                          /* This packet of samples is synchronized to the    */
                          /* sample clock which drifts from the GPS clock.    */
                          /* Adjust the sample data as needed so sync it up   */
                          /* to the GPS clock.  It's complicated, see the     */
                          /* header for this routine.                         */
                          /* As this incoming packet can generate 0, 1, or 2  */
                          /* outgoing packets, the routine takes care of      */
                          /* actual sending of packets.                       */
                          //GPS_Syncer(buffer,Prev_GPS_Sec,Prev_GPS_ns,rssi) ;
                          Package_MuLaw_Packet(Prev_GPS_Sec,Prev_GPS_ns,rssi,buffer) ;

                          /* As it is very time sensitive, I get the new time */
                          /* stamp in the RxDSP routines ASAP after getting   */
                          /* the interrupt.  Getting it here after all the    */
                          /* RTOS context swap messiness was innacurate.      */
                          Prev_GPS_Sec = NewPktSecs ;
                          Prev_GPS_ns  = NewPktNs   ;
                          break ;
      case PKTTIM_FKGPS : Package_MuLaw_Packet(FKGPS_Time,FKGPS_Tns,rssi,buffer) ;
                          break ;
      default           : break ;
   }
}

/*******************************************************************************
* Routine  : Package_MuLaw_Packet
* Gazintas : Pkt_Sec - Packet time seconds
*          : Pkt_ns - Packet time nanoseconds
*          : rssi - RSSI value
*          : buffer - 160 samples
* IOs      : None
* Returns  : Nothing
* Globals  : TxPackets, more?
*
* Since different routines can create a T1 (uLaw) packet depending on the timing
* mode, this is just all the common code to package up a packet to save code
* duplication.
*******************************************************************************/
static void Package_MuLaw_Packet(uint32_t Pkt_Sec, uint32_t Pkt_ns, uint8_t rssi, uint8_t* buffer)
{
   static uint32_t Prev_Pkt_Sec = 0 ; /* Previous Packet time (secs)    */
   static uint32_t Prev_Pkt_ns  = 0 ; /* Previous Packet time (ns)      */
   int32_t         delta        = 0 ; /* Delta from last packet (ns)    */

   Struct_MuLawRxPacket.header.time_s       = htonl(Pkt_Sec)         ;
   Struct_MuLawRxPacket.header.time_ns      = htonl(Pkt_ns)          ;
   Struct_MuLawRxPacket.header.Payload_Type = htons(PAYLOAD_T1MULAW) ;
   Struct_MuLawRxPacket.Rssi                = rssi                   ;
   memcpy(&Struct_MuLawRxPacket.Audio,buffer,APKT_SAMPLES) ;
   /* Challenge/response is handled later as it is common to all packets */

   /* Figger out the delta time from the last packet in ns */
   delta = (Pkt_Sec-Prev_Pkt_Sec)*1000000000+Pkt_ns-Prev_Pkt_ns ;
   Logger2_Msg(Logger.Dial,LOG_REGIO,LOG_TIME,"DialTask: uLaw TS: %u.%09u delta %6d\r\n",Pkt_Sec,Pkt_ns,delta) ;
   Prev_Pkt_Sec = Pkt_Sec ;
   Prev_Pkt_ns  = Pkt_ns  ;

   /* If the DIAL server says we're not the master, wait 6ms.    */
   /* **** This seems too simple,  makes me a bit nervous!!!**** */
   if (!DIAL_IMMASTER) osDelay(NOTMASTER_DELAY) ;

   SendDialPacket(MuLawRxPacket,VOTER_PACKLEN_T1) ;
   TxPackets[PAYLOAD_T1MULAW]++ ;
}

/*******************************************************************************
* Routine  : Tx_GPSPacket
* Gazintas : None (yet)
* IOs      : None
* Returns  : Nothing
* Globals  : DIALSettings.PacketTiming,FKGPS_Time,FKGPS_Tns
*
* This routine sends out a Type 2 GPS Information packet.  For General Purpose
* packets, this has nothing other than the header.  For fake GPS I have a
* static value, for real GPS I plunk in the data from the GPS.
*******************************************************************************/
static void Tx_GPSPacket(void)
{
   int  packet_size =  0  ; /* Packet sisze to send */
   char tmpstr[16]  = {0} ; /* Temporary string */

   /* Header first, ns field is 0 for GP, ns value for GPS modes */
   FillTimeStamp(&Struct_AuthPacket.header.time_s,&Struct_AuthPacket.header.time_ns) ;
 //Struct_GPSTxPacket.header.time_s       = htonl(FKGPS_Time) ;
 //Struct_GPSTxPacket.header.time_ns      = htonl((PKTTIM_GP==DIALSettings.PacketTiming)?0:FKGPS_Tns) ;
   Struct_GPSTxPacket.header.Payload_Type = htons(PAYLOAD_T2GPSINFO) ;

   if (PKTTIM_GP==DIALSettings.PacketTiming)
   {
      /* If GP mode, the packet is ready since it is only the header! */
      packet_size = VOTER_PACKLEN_T2GP ;
   }
   else if (PKTTIM_GPS==DIALSettings.PacketTiming)
   {
      /* In GPS mode, copy the GPS data */
      sprintf((char*)Struct_GPSTxPacket.Longitude,"%7.7s%c",GPSData.Longitude,GPSData.LongDir) ;
      sprintf((char*)Struct_GPSTxPacket.Latitude,"%8.8s%c",GPSData.Latitude,GPSData.LatDir) ;
      /* sprintf could overflow on an int, so using a temporary string intermediary */
      sprintf(tmpstr,"%4.4d.0",GPSData.Altitude) ;
      memcpy(Struct_GPSTxPacket.Altitude,tmpstr,7) ;
      packet_size = VOTER_PACKLEN_T2GPS ;
   }
   else
   {
      /* In fake GPS mode, copy our hard coded location string for now */
      memcpy(Struct_GPSTxPacket.Longitude,FakeLongitude,9 ) ;
      memcpy(Struct_GPSTxPacket.Latitude ,FakeLatitude ,10) ;
      memcpy(Struct_GPSTxPacket.Altitude ,FakeAltitude ,7 ) ;
      packet_size = VOTER_PACKLEN_T2GPS ;
   }

   /* If the DIAL server says we're not the master, wait 6ms */
   /* **** This makes me a bit nervous!!!               **** */
   if (!DIAL_IMMASTER) osDelay(NOTMASTER_DELAY) ;

   SendDialPacket(GPSTxPacket,packet_size) ;
   TxPackets[PAYLOAD_T2GPSINFO]++ ;

}

/*******************************************************************************
* Routine  : Tx_ADPCMPacket
* Gazintas : buffer - 163 compressed audio samples
*          : rssi - signal strength
* IOs      : None
* Returns  : Nothing
* Globals  : Struct_MuLawRxPacket - Datagram ready to send via Ethernet
*
* This takes the sample data and creates the datagram to send via Ethernet
* to the DIAL server.  For GPS and fake GPS, the full time (s+ns) is
* in the header, for General Purpose mode, it is the rough time in the seconds
* field (same as fake GPS) and the General Purpose sequence number in the ns
* field.
*******************************************************************************/
static void Tx_ADPCMPacket(uint8_t* buffer,uint8_t rssi)
{
   uint32_t GPS_Sec = 0 ; /* GPS-based time (secs) */
   uint32_t GPS_ns  = 0 ; /* GPS-based time (ns)   */

   /* Start off clean, then fill in values */
   memset ((uint8_t*)&Struct_ADPCMRxPacket,0,VOTER_PACKLEN_T3)   ;

   switch(DIALSettings.PacketTiming)
   {
      case PKTTIM_GP  :   Struct_ADPCMRxPacket.header.time_s  = htonl(FKGPS_Time) ;
                          Struct_ADPCMRxPacket.header.time_ns = htonl(GP_SeqNum ) ;
                          break ;
      case PKTTIM_GPS :   Get_GPSTime(&GPS_Sec,&GPS_ns) ;
                          Struct_ADPCMRxPacket.header.time_s  = htonl(GPS_Sec) ;
                          Struct_ADPCMRxPacket.header.time_ns = htonl(GPS_ns) ;
                          break ;
      case PKTTIM_FKGPS : Struct_ADPCMRxPacket.header.time_s  = htonl(FKGPS_Time) ;
                          Struct_ADPCMRxPacket.header.time_ns = htonl(FKGPS_Tns ) ;
                          break ;
      default           : break ;
   }

   Struct_ADPCMRxPacket.header.Payload_Type = htons(PAYLOAD_T3ADPCM)    ;
   Struct_ADPCMRxPacket.Rssi                = rssi ;
   memcpy(&Struct_ADPCMRxPacket.Audio,buffer,163) ;
   /* Challenge/response is handled later as it is common to all packets */

   /* If the DIAL server says we're not the master, wait 6ms */
   /* **** This makes me a bit nervous!!!               **** */
   if (!DIAL_IMMASTER) osDelay(NOTMASTER_DELAY) ;

   SendDialPacket(ADPCMRxPacket,VOTER_PACKLEN_T3) ;
   TxPackets[PAYLOAD_T3ADPCM]++ ;
}

/*******************************************************************************
* Routine  : FillTimeStamp
* Gazintas : None
* IOs      : secs  - Timestamp seconds (filled in)
*          : nsecs - Timestamp nanoseconds filled in)
* Returns  : Nothing
* Globals  :FKGPS_Time, FKGPS_Tns
*
* This routine fills in the timestamp header for a packet.  The timestamp to
* use is based on the packet timing mode and the format is converted to
* network format.  Data filled in is as follows:
*  - General Purpose: Current seconds based on server time, ns set to 0
*  - GPS: The time right now--including ns (very accurate)
*  - Fake GPS: Time at the start of the last packet (so 0-20ms late)
*******************************************************************************/
static void FillTimeStamp(uint32_t* secs, uint32_t* nsecs)
{
   uint32_t ts,tns ; /* Temp stuff for debugging */

   switch(DIALSettings.PacketTiming)
   {
      case PKTTIM_GP  :   *secs  = htonl(FKGPS_Time) ;
                          *nsecs = 0                 ;
                          break ;
      case PKTTIM_GPS :   Get_GPSTime(&ts,&tns) ;
                          tns -= 2000 ; /* +1us */
                          if (tns>1000000000) {tns+=2000 ; ts-- ; } ; /* overflow */
                          *secs  = htonl(ts)  ;
                          *nsecs = htonl(tns) ;

                          //Get_GPSTime(secs,nsecs) ;
                          //*secs  = htonl(*secs)  ;
                          //*nsecs = htonl(*nsecs) ;
                          break ;
      case PKTTIM_FKGPS : *secs  = htonl(FKGPS_Time) ;
                          *nsecs = htonl(FKGPS_Tns)  ;
                          break ;
      default           : break ;
   }
}

/*******************************************************************************
* Routine  : Rx_Auth_Packet
* Gazintas : payload - pointer to Ethernet packet payload bytes (all of them)
*          : len - payload length
*          : Packet_Time - Server time (seconds)
*          : Packet_Tns - Server time (ns)
* IOs      : None
* Returns  : error flag
* Globals  :
*
* This routine parses a Type 0 (Authorization) packet.  For messages from the
* host, this is a fixed length packet (Flag byte is mandatory for host)
* This just handles timing and the flag byte, actual authorization is part of
* every packet and handled in Rx_handleCR().
*******************************************************************************/
static int Rx_Auth_Packet (void* payload,uint16_t len,uint32_t Packet_Time,uint32_t Packet_Tns)
{
   bool     err     = true ; /* General error flag */

   RxPackets[PAYLOAD_T0AUTH]++ ;
   if (VOTER_PACKLEN_T0GP == len)
   {
      /* There isn't anything to verify about the DIAL time.  Since it is the */
      /* DIAL servers time though, store it so it can be used to send back an */
      /* approximate time for non-GPS audio packets.  The spec says for       */
      /* non-GPS packets to use the ns field for a counter that starts at 0   */
      /* on authorization and increments every 20ms from there, so reset that */
      /* counter to 0 here.                                                   */
      FKGPS_Time = Packet_Time ;
      FKGPS_Tns  = Packet_Tns  ;
      GP_SeqNum = 0           ;

      /* If a sync check has been requested and an auth packet sent, then     */
      /* this auth return packet has our timestamp data!  Save all the time   */
      /* values and flag that the sync check is complete.  Code in            */
      /* Stat_Sync() does all the math and reporting.                         */
      if (SYNCCHECK_RUNNING==SyncCheck)
      {
         Get_GPSTime(&MySecs,&MynSecs) ;
         DSSecs    = Packet_Time    ;
         DSnSecs   = Packet_Tns     ;
         SyncCheck = SYNCCHECK_IDLE ;
      }

      /* For fake GPS mode, I need a bit of an offset */
      FKGPS_Tns +=20000000 ; /* 20ms in ns */

      if (FKGPS_Tns >=1000000000) /* billion ns to a s */
      {
         FKGPS_Tns -= 1000000000 ;
         FKGPS_Time++   ;
      }

      /* Save the flag byte - crazy typecasting! */
      DIAL_flagbyte = *(((uint8_t*)payload)+24) ;

      /* A new flag byte could have changed some of the DSP filters, go       */
      /* re-initialized them with the current settings.                       */
      Rx_FilterInit() ;

      Logger2_Msg(Logger.Dial,LOG_REGIO,LOG_TIME,"DialTask: RxAuth: Time = 0x%8.8x, Host Flag Byte: 0x%2.2x\r\n",FKGPS_Time,DIAL_flagbyte) ;

      /* Regardless of CR result, packet itself is good. */
      err = false ;
   }
   return (err) ;
}

/*******************************************************************************
* Routine  : Rx_MuLaw_Packet
* Gazintas : payload - pointer to Ethernet packet payload bytes (all of them)
*          : len - payload length
*          : Packet_Time - Server time (seconds)
*          : Packet_Tns - Server time (ns)
* IOs      : None
* Returns  : error flag
* Globals  : Tx_Samples - decompressed contents to transmit
*
* This routine parses a Type 1 (MuLaw) packet.  The header is verified good, so
* double-check that it is the right length for RSSI and samples before
* decompressing it and sending the decompressed data to the DAC handlers.
*******************************************************************************/
static int Rx_MuLaw_Packet (void* payload,uint16_t len,uint32_t Packet_Time,uint32_t Packet_Tns)
{
   bool err = true ;

   /* Jitter logging tool */
   Jitter_Log() ;

   RxPackets[PAYLOAD_T1MULAW]++ ;
   /* A type 1 (MuLaw) packet is fixed length, so only one length possible.   */
   /* For the payload itself (1 RSSI byte and 160 audio samples, nothing more */
   /* to check.                                                               */
   /* Copy the data (since pbuf is going to be freed on returning) and send   */
   /* the data to the audio task.                                             */
   if (VOTER_PACKLEN_T1 == len)
   {
      /* As long as we are authorized, send the data to the DIAL Task. */
      if (DIAL_AUTHORIZED)
      {
         DecompressuLaw (payload+25,Tx_Samples) ;  /* Decompress just the data part */
         Tx_EnqPacket(Tx_Samples,DIAL_GENPURPOSE?GENERAL_TIMED:GPS_TIMED,Packet_Time,Packet_Tns) ;
      }
      err = false ;
   }

   return (err) ;
}

/*******************************************************************************
* Routine  : Rx_GPSInfo_Packet
* Gazintas : payload - pointer to Ethernet packet payload bytes (all of them)
*          : len - payload length
* IOs      : None
* Returns  : error flag
* Globals  : TBD
*
* This routine parses a Type 2 (GPS Information) packet.  As this is coming
* from the DIAL server, I'm expecting it to not have any info, just be a blank
* "keep alive" packet.
*******************************************************************************/
static int Rx_GPSInfo_Packet (void* payload,uint16_t len)
{
   RxPackets[PAYLOAD_T2GPSINFO]++ ;
   return (false) ;
}

/*******************************************************************************
* Routine  : Rx_ADPCM_Packet
* Gazintas : payload - pointer to Ethernet packet payload bytes (all of them)
*          : len - payload length
*          : Packet_Time - Server time (seconds)
*          : Packet_Tns - Server time (ns)
* IOs      : None
* Returns  : error flag
* Globals  : Tx_Samples - decompressed contents to transmit
*
* This routine parses a Type 3 (ADPCM) packet.  The header is verified good, so
* double-check that it is the right length for RSSI and samples before
* decompressing it and sending the decompressed data to the DAC handlers.
* NOTE: For ADPCM a single Ethernet packet (164 payload bytes) generates two
* "regular" 160-sample packets of decompressed data.
*******************************************************************************/
static int Rx_ADPCM_Packet (void* payload,uint16_t len,uint32_t Packet_Time,uint32_t Packet_Tns)
{
   /* Jitter logging tool */
   Jitter_Log() ;

   bool err = true ;

   RxPackets[PAYLOAD_T3ADPCM]++ ;
   /* A type 3 (ADPCM) packet is fixed length, so only one length possible.   */
   /* For the payload itself (1 RSSI byte and 163 compressed audio bytes,     */
   /* nothing more to check.                                                  */
   /* Decompress the data into another buffer (since pbuf is going to be      */
   /* freed on returning) and send the data to the DAC handlers.              */
   if (VOTER_PACKLEN_T3 == len)
   {
      /* As long as we are authorized, send the data to the DIAL Task. */
      if (DIAL_AUTHORIZED)
      {
         /* ADPCM generates two 160-sample audio packets for every 163- */
         /* byte Ethernet packet.  Decompress the full Ethernet packet  */
         /* and then queue up both audio packets.                       */
         DecompressADPCM(payload+25,Tx_Samples) ;
         Tx_EnqPacket(Tx_Samples,DIAL_GENPURPOSE?GENERAL_TIMED:GPS_TIMED,Packet_Time,Packet_Tns) ;

         /* For the second packet I need to increment the time by 20ms if in  */
         /* GPS-timed mode or increment the counter in the ns field if in     */
         /* general purpose mode.                                             */
         if (PKTTIM_GP==DIALSettings.PacketTiming)
         {
            Packet_Tns++ ;
         }
         else
         {
            Packet_Tns +=20000000 ; /* +20ms in ns */
            if (Packet_Tns>1000000000)
            {
               Packet_Time++ ;
               Packet_Tns -= 1000000000 ;
            }
            Tx_EnqPacket(Tx_Samples+160,DIAL_GENPURPOSE?GENERAL_TIMED:GPS_TIMED,Packet_Time,Packet_Tns) ;
         }
      }
      err = false ;
   }

   return (err) ;
}


/*******************************************************************************
* Routine  : Rx_Ping_Packet
* Gazintas : payload - pointer to Ethernet packet payload bytes (all of them)
*          : len - payload length
* IOs      : None
* Returns  : error flag
* Globals  : PingPacket
*
* This routine parses a Type 5 (Ping) packet.  Header is good, so only check
* is the ping payload should be 200 bytes or less with no known checks on the
* payload contents.  If legit, just return the payload back to the host.
*******************************************************************************/
static int Rx_Ping_Packet (void* payload,uint16_t len)
{
   bool err = true ;

   RxPackets[PAYLOAD_T5PING]++ ;
   /* This is a variable length packet, so just make sure the incoming packet */
   /* isn't too long.  VOTER_PACKLEN_T5 is for the whole packet including the */
   /* header, so 224 for max 200 byte ping payload.  No need for a minimum    */
   /* size check as that was done during header parsing.                      */
   if (len <= VOTER_PACKLEN_T5)
   {
      /* Create the ping return packet */
      Struct_PingPacket.header.time_s       = htonl(FKGPS_Time) ;
      Struct_PingPacket.header.time_ns      = 0 ; /* 0 for pings? */
      Struct_PingPacket.header.Payload_Type = htons(PAYLOAD_T5PING) ;
      memcpy(Struct_PingPacket.PingData,payload+24,len-24) ;
      /* Challenge/response is handled later as it is common to all packets */

      /* Packet ready to send, send it! */
      SendDialPacket(PingPacket,len) ;
      TxPackets[PAYLOAD_T5PING]++ ;
      err = false ;
   }

   return (err) ;
}

/*******************************************************************************
* Routine  : crc32_bufs
* Gazintas : buf1 - buffer #1 (null terminated challenge)
*          : buf2 - buffer #2 (null terminated password)
* IOs      : None
* Returns  : CRC32 of the concatenated buffers.
* Globals  : crc_32_tab
*
* This computes the CRC32 of two concatenated null-terminated strings. This is
* initially 100% copied from Voter1, then just tweaked a bit for my coding
* style.
* Also included is the use of the STM32H750s Hardware CRC calculator
* if enabled.  The STM32H750 has a hardware CRC calculator, but for very
* small variable length strings, the overhead of setting it up means the HW
* solution takes roughly the same time.  The real advantage of using the HW
* solution is saving the 1KByte of memory the SW CRC table consumes.
*******************************************************************************/
static long crc32_bufs(unsigned char *buf1, unsigned char *buf2)
{

   long crc32 = 0xFFFFFFFF ; /* CRC32 accumulator */

#ifndef USE_HW_CRC

   while(buf1 && *buf1)
   {
      crc32 = crc_32_tab[(crc32 ^ *buf1++) & 0xff] ^ ((unsigned long)crc32 >> 8);
   }

   while(buf2 && *buf2)
   {
      crc32 = crc_32_tab[(crc32 ^ *buf2++) & 0xff] ^ ((unsigned long)crc32 >> 8);
   }

#else

           HAL_CRC_Calculate  (&hcrc,(uint32_t*)buf1,strlen((char*)buf1)) ;
   crc32 = HAL_CRC_Accumulate (&hcrc,(uint32_t*)buf2,strlen((char*)buf2)) ;

#endif

   return ~crc32;

}

/*******************************************************************************
* Routine  : SendDialPacket
* Gazintas : packet - pointer to packet to send
*          : len - Packet length
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This is the common routine to actually send a DIAL packet over Ethernet.
* This takes care of the Challenge/Response processing, then sends the packet
* on.  It is aware of the header format, but doesn't need to know or care
* about the payload other than length.
*******************************************************************************/
static void SendDialPacket(uint8_t* packet, uint32_t len)
{
   err_t err = 0 ;
   struct netbuf *tx_buf = NULL    ; /* Tx packet buffer handle    */

   /* Take care of Challenge/Response negotiating */
   Tx_handleCR(packet+8,packet+18) ;

   if (!DIAL_Offline) /* Unless forcing an offline mode, send the data! */
   {
      /* Create a netbuf for the data, fill it out, send it, and then free it */
      tx_buf = netbuf_new();
      if (NULL==tx_buf)
      {
         IncErrLog(ERRLOG_SENDDIALPACKET_NETBUF_NEW,ERRLOG_SHOW) ;
      }
      else
      {
         netbuf_alloc(tx_buf,len);
         if (NULL==tx_buf)
         {
            IncErrLog(ERRLOG_SENDDIALPACKET_NETBUF_ALLOC,ERRLOG_SHOW) ;
         }
         else
         {
            err=pbuf_take(tx_buf->p, (const void *)packet,len);
            if (ERR_OK!=err)
            {
               IncErrLog(ERRLOG_SENDDIALPACKET_PBUF_TAKE,ERRLOG_SHOW) ;
            }
            else
            {
               err = netconn_sendto(DIALconn,tx_buf,&DIAL_Server_IP,DIALSettings.VoterPort);
               if (ERR_OK!=err)
               {
                  IncErrLog(ERRLOG_SENDDIALPACKET_NETCONN_SENDTO,ERRLOG_SHOW) ;
               }
            }
         }
         /* Even if errors after netbuf_new, always delete the netbuf */
         netbuf_delete(tx_buf);
      }
   }

   //Logger2_Msg(Logger.Dial,LOGGER2_DIALTASK,LOG_TIME,"DialTask: Sent UDP T:%d %d len:%d err:%d\r\n",packet[22],packet[23],len,err) ;
}

#endif /* #ifndef NODIALTASK */
