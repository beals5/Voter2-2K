#ifndef INC_UTILS_H_
#define INC_UTILS_H_

/* For ReadHex */
#define SOLOPARAM 0
#define JUSTDIGITS 1

typedef struct
{
   char* token ;
   int   tag   ; /* 0 reserved for no match!! */
} TOKENLIST;

int      parse_token (TOKENLIST*,char*,int*) ;
int      parse_num (char*,int,int,int*) ;
uint32_t ReadHex (char*,int,int,int*) ;
uint32_t ReadHexVar (char*,int*) ;
void     strntcpy(char*,char*,int) ;

#endif /* INC_UTILS_H_ */
