This Readme assumes you are mostly familiar with the STM32CubeIDE toolset and structure, but just for a quick few points on important directories and files if you are just poking around:

The Core directory is where 95% if the application resides.  The src and inc directories are exactly what you think they are and startup is the initial assembly file to set up the stack, heap, and variables before calling main.

The Drivers directory is ST drivers.

Lib has just one library, the CMSIS DSP library.

LWIP has the low-level platform specific drivers for Ethernet, these are initially ST provided, but separate as they are normally (and indeed are) user-modified.

Middlewares eventually contains the source for two libraries, FreeRTOS and LwIP.  In general I haven't modified these, I think the only part I tinker with occasionally is some weird settings for certain debugging modes.

The "good stuff" is almost entirely in Core/Src and Core/Inc.  In Core/Src I have two subdirectories for Local modes.  The real one is LocalVoter which is the real local mode code.  VoterDummy is a do-nothing local mode just there to test that I can swap our LocalVoter for something else.  A third party local mode is coming, but not an open source one.  In Core/Inc I only have a header file for LocalSettings as I hope all Local modes will share the same API.  Time will tell.

If poking around for the first time, the files I suggest looking at first in rough order are:
 - Inc/Options.h: This is the high level options selection file governing major features that have global reach.
 - Src/main.c: Shows how stuff gets started up before firing up the RTOS.  Good overview of the hardware involved.  Also the place where I try to list and quantify memory usage in the main comment header.
 - Src/MainTask.c: Not much here, but gives an idea of an independent task.
 - Voter2B2.pdf: Output of STM32CubeMX's configurator.  All about hardware and peripheral setup.

After that, hopefully the source filenames will guide you based on what you want to look at.  If the filename ends in Task, that means it has an RTOS task routine in it.

If you want to follow the path of audio through the Voter2, this sequence covers most of it:
 - AnalogIO.c
 - Rx_DSP.c (then xxxFilter.c for DSP routines)
 - /LocalVoter/LocalMode.c for Local mode
 - DialTask.c for Voting
 - Tx_DSP.c

While not part of the source tree, do chase down the interprocess comms diagram.  It shows all the hardware blocks and what ISR routines and/or RTOS tasks manage them.

will