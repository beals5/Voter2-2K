#ifndef INC_LOCALVOTER_LOCALSETTINGS_H_
#define INC_LOCALVOTER_LOCALSETTINGS_H_

#ifdef LOCALVOTER

typedef struct
{
   /* Offline settings                                                */
   uint16_t OffinePreCw      ; /* Offline Pre CW delay (ms)    */
   uint16_t OffinePostCw     ; /* Offline Post CW delay (ms)   */
   uint16_t OffineIdTime     ; /* Offline ID period (secs)     */
   uint16_t OffineHangTime   ; /* Offline Rx Hang time (ms)    */
   uint8_t  OfflineMode      ; /* Offline mode                 */
   uint8_t  OffineCwSpd      ; /* Offline CW speed (WPM)       */
   uint8_t  OffinePLF        ; /* Offline CTCSS Freq (index)   */
   uint8_t  OffinePLL        ; /* Offline CTCSS level (0-10)   */
   uint8_t  OffineDeemph     ; /* Offline Rx De-emphasis (TF)  */
   char     OfflineID[SETTINGS_CWID_LEN]   ; /* Offline station ID */
   char     OfflineProc[SETTINGS_CWID_LEN] ; /* Offline Proceed ID */
} LOCALSETTINGS;

extern LOCALSETTINGS LocalSettings ;

void LocalSettingsInit (void) ;
void LocalSettingsRead (uint8_t,uint8_t*) ;
void LocalSettingsWrite(uint32_t*) ;

void SetLocal (int,char**) ;
void ShowLocal(void      ) ;

#endif /* LOCALVOTER */

#endif /* INC_LOCALVOTER_LOCALSETTINGS_H_ */
