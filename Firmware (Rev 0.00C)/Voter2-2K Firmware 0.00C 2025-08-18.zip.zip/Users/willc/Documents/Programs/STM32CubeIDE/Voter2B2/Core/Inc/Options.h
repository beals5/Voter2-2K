/* ************************************************************************** */
/* These are the high level defines controlling major project features as     */
/* well as project-wide includes.  The idea is this header file should be in  */
/* every project source code file that I touch.                               */
/* ************************************************************************** */
#ifndef INC_OPTIONS_H_
#define INC_OPTIONS_H_

/* PCB Revision tracking.  Define the supported*/
/* revs, then define the rev compiling for.    */
#define V2_2K_100 101    /* Voter2-2K V1.00    */
#define V2_2K_110 102    /* Voter2-2K V1.10    */
#define V2_SA_100 201    /* Voter2-SA V1.00    */
#define PCBREV V2_2K_110 /* Current target     */

/* Project name and SW Version. Displayed at   */
/* login and used for firmware updates         */
#define PROJECTNAME "Voter2-2K"
#define PROJECTREV "0.00T"
#define PROJECTDATE "2025-08-18"

/* The Voter2 can support different Local Mode */
/* implementations.  Un-comment the Local Mode */
/* implementation you want to use (only one!)  */
#define LOCALVOTER   /* The default local mode */
//#define LOCALDUMMY /* A dummy local mode     */
//#define LOCAL7330  /* Dave's 7330 local mode */

/* For a local mode only implementation, this  */
/* define disables the DIAL task.              */
//#define NODIALTASK

/* If the DIAL task isn't running, then the    */
/* packet size can be something other than 160 */
/* samples.  Allow that here.                  */
#ifndef NODIALTASK
#define SAMPLESIZE 160 /* DON'T CHANGE!!       */
#else
#define SAMPLESIZE 80 /* OK to change          */
/* If in local-only mode, you can also dumb    */
/* down TIM2 to be a simple clock divider for  */
/* the sample clock.  MUCH simpler than the    */
/* PLL code!!  You also lose ns-class time     */
/* stamping.                                   */
//#define DUMBTIMERMODE
#endif

/* System Includes I want everywhere           */
#include <stdint.h>
#include <stdbool.h>

/* Special places in memory                    */
#define IN_QSPINOR __attribute__((section(".QSPINOR_Section")))
#define IN_DMADD2  __attribute__((section(".DMAd_D2_Section")))
#define IN_ITCM    __attribute__((section(".ITCM_Section")))
#define IN_DTCM    __attribute__((section(".DTCM_Section")))
#define IN_BBSRAM  __attribute__((section(".BBSRAM_Section")))

/* For the console, if you don't want security,*/
/* this will bypass the login steps.           */
//#define CONSOLE_NOLOGIN

/* The STM32H750 has a hardware CRC calculator,*/
/* this #define selects it over a SW           */
/* implementation. It doesn't end up being     */
/* much faster, just just uses less memory.    */
#define USE_HW_CRC

/* This implements certain filters using the   */
/* CMSIS library rather than "regular" C       */
/* routines in this codebase.  This is only    */
/* done for some (bigger) filters, namely:     */
/*  - Voice_Filters (Rx_DSP)                   */
/*  - RSSI_Filter (Rx_DSP)                     */
#define USE_CMSIS_DSP

/* For very simple character-by-character UART */
/* Rx IRQ handling, the HAL code is *very*     */
/* heavy. This bypasses the HAL IRQ handling   */
/* just for Rx, doing it directly. I still use */
/* the HAL for Tx (direct and DMAd).           */
#define UART7_HALIRQ_BYPASS /* Ser2Net */
#define UART8_HALIRQ_BYPASS /* Console */

/* Enable LWIP debug logging.                  */
/* What to log is in bottom of lwipopts.h      */
/* See logger2.h for other #defines needed     */
//#define LOGGER2_LWIP

/* Enable the CubeMX IDE to monitor FreeRTOS   */
/* task/queue/etc activity.                    */
/* See adders to FreeRTOSConfig.h  in /inc.    */
/* Set Optimization for tasks.c to -o0 too.    */
//#define FREERTOS_MONITORING

/* CubeMX just queues up all the defined tasks */
/* and then starts the RTOS, so the order in   */
/* which the tasks start is essentially random.*/
/* I have an osDelay call at the start of each */
/* independent task to force some predictable  */
/* sequencing. There are subordinate tasks that*/
/* trigger off these independent tasks.        */
#define StartDelay_Logger2rTask    0 /* All tasks need Logger2         */
#define StartDelay_EthernetTask   20 /* Needs Logger2 (+50ms to next!) */
#define StartDelay_DIALTask       70 /* Needs Ethernet                 */
#define StartDelay_ConsoleTask    80 /* Needs Ethernet                 */
#define StartDelay_Ser2NetTask    90 /* Needs Ethernet                 */
#define StartDelay_MainTask      100 /* Needs Ethernet and Console     */

/* The WWDG (Windowing Watchdog) is good for   */
/* regular code, but want it disabled for      */
/* development, so comment this out for debug. */
//#define WWDG_ENABLED

#endif /* INC_OPTIONS_H_ */
