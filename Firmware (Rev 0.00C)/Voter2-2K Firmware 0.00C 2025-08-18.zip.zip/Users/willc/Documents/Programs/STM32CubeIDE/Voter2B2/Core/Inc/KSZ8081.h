#ifndef INC_KSZ8081_H_
#define INC_KSZ8081_H_

#define KSZ8081_LINK_DOWN 0
#define KSZ8081_LINK_UP 1

#define KSZ8081_FIRSTPROCESS true
#define KSZ8081_LOOPPROCESS false

void UseMyMACAddr(uint8_t*) ;
void KSZ8081_Toggle_HWReset(void) ;
void KSZ8081_Init(void) ;
void KSZ8081_GetLinkState(int32_t*,uint32_t*,uint32_t*) ;
void KSZ8081_ProcessLinkState(struct netif *netif,int) ;

#endif /* INC_KSZ8081_H_ */
