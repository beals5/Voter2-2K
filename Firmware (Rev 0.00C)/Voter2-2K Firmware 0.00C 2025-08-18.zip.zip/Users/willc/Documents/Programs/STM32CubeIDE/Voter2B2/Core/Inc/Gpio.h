#ifndef INC_GPIO_H_
#define INC_GPIO_H_

/* The ShowIn_IRQ routines are called in very time sensitive code. */
/* Doing some inline stuff over slower HAL calls.                  */
#define  AISR_SHOWSTART IN_AISR_GPIO_Port->BSRR = IN_AISR_Pin     ;
#define  AISR_SHOWEND   IN_AISR_GPIO_Port->BSRR = IN_AISR_Pin<<16 ;
#define  DISR_SHOWSTART IN_DISR_GPIO_Port->BSRR = IN_DISR_Pin     ;
#define  DISR_SHOWEND   IN_DISR_GPIO_Port->BSRR = IN_DISR_Pin<<16 ;
#define  TISR_SHOWSTART IN_TISR_GPIO_Port->BSRR = IN_TISR_Pin     ;
#define  TISR_SHOWEND   IN_TISR_GPIO_Port->BSRR = IN_TISR_Pin<<16 ;

#define  AISR_TOGGLE   IN_AISR_GPIO_Port->ODR = (IN_AISR_GPIO_Port->ODR)^(IN_AISR_Pin) ;
#define  DISR_TOGGLE   IN_DISR_GPIO_Port->ODR = (IN_DISR_GPIO_Port->ODR)^(IN_DISR_Pin) ;
#define  TISR_TOGGLE   IN_TISR_GPIO_Port->ODR = (IN_TISR_GPIO_Port->ODR)^(IN_TISR_Pin) ;

/* Ditto for some other speed-critical GPIO, but making these optional */
#define FAST_GPIOS

#ifdef FAST_GPIOS
#define  SPIFLASH_CS_ASSERT   FSPI_NCS_GPIO_Port->BSRR = FSPI_NCS_Pin<<16
#define  SPIFLASH_CS_DEASSERT FSPI_NCS_GPIO_Port->BSRR = FSPI_NCS_Pin

#define  OPTIRQ_ASSERT   OPT_IRQ_GPIO_Port->BSRR = OPT_IRQ_Pin<<16
#define  OPTIRQ_DEASSERT OPT_IRQ_GPIO_Port->BSRR = OPT_IRQ_Pin
#else
#define  SPIFLASH_CS_ASSERT   SPICS_State(true)
#define  SPIFLASH_CS_DEASSERT SPICS_State(false)

#define  OPTIRQ_ASSERT   OPTIRQ_State(true)
#define  OPTIRQ_DEASSERT OPTIRQ_State(false)
#endif

typedef enum
{
   AISR_STATE = 0,
   DISR_STATE,
   TISR_STATE,
   RTF1_STATE,
   RTF2_STATE,
   HB_STATE,
   TX_STATE,
   RSSI_STATE,
   GPS_STATE,
   CONNECTED_STATE,
} SHOW_STATES ;

typedef enum
{
   RSSI_NOSIG = 0,
   RSSI_LOW,
   RSSI_GOOD,
   RSSI_HIGH
} RSSI_STATES ;

void Heartbeat(void) ;
void GPIO_RTOS_Splash(void) ;
void Show_State(int,int) ;
void PHY_Reset(int) ;
void PTT_State(int) ;
void SPICS_State(int) ;
void OPTIRQ_State(int) ;
int  COR_State(void) ;
int  RDSTAT_State(void) ;
int  V14_State(void) ;
int  ACFAIL_State(void) ;
int  SPI_CSID_State(void) ;

#endif /* INC_GPIO_H_ */
