#ifndef INC_STATUS_H_
#define INC_STATUS_H_

extern char* cmd_status_cmd ;
extern char* cmd_status_help ;

extern int  Cmd_status(int, char**) ;

#endif /* INC_STATUS_H_ */
