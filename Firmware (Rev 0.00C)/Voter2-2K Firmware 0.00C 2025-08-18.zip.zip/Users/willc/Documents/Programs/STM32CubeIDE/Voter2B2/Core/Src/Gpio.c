/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the GPIO file.  It is in charge of low level GPIO functions.       */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Heartbeat - Blinks the heartbeat LED.                                   */
/*  - GPIO_RTOS_Splash - Wiggle the LEDs on startup                           */
/*  - Show_State - Show demod status (for debugging)                          */
/*  - PHY_Reset - Set PHY Reset state                                         */
/*  - PTT_State - Set PTT output                                              */
/*  - SPICS_State - Set the SPINOR CS output                                  */
/*  - OPTIRQ_State - Set OPT_IRQ output                                       */
/*  - COR_State - Read Repeater COR state                                     */
/*  - RDSTAT_State - Read Repeater RDSTAT (CTCSS) state                       */
/*  - V14_State - Read 14V comparator state                                   */
/*  - ACFAIL_State - Read repeater ACFAIL state                               */
/*  - SPI_CSID_State - Read repeater Chip Select ID state                     */
/*                                                                            */
/******************************************************************************/
// TO DO:
//  - Console command to show LED status ?
//  - Tie heartbeat blink pattern to RTOS health
//  - Faster IO for OPTIRQ

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "cmsis_os.h"

#include "Options.h"
#include "main.h"
#include "GPIO.h"

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : Heartbeat
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine blinks the heartbeat LED.  It gets called by the timer sequencer
* every 50ms (20x/sec).  I want the heartbeat every second, so the loop counts
* to 20.
*
*******************************************************************************/
void Heartbeat(void)
{
   static int count = 0 ; /* our sequence counter     */

   /* do the counting 0-19 */
   count = (count+1)%20 ;
   Show_State(HB_STATE,!count) ; /* true only for count of 0 */
}

/*******************************************************************************
* routine  : GPIO_RTOS_Splash
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine just lights up the LEDs in sequence, also doing the three colors
* for the RSSI LED. The only surviving version now is the RTOS one using
* osDelay).
*******************************************************************************/
void GPIO_RTOS_Splash(void)
{
   Show_State(TX_STATE,false) ;
   Show_State(RSSI_STATE,RSSI_NOSIG) ;
   Show_State(CONNECTED_STATE,false) ;
   Show_State(GPS_STATE,false) ;

   Show_State(HB_STATE,true) ;
   osDelay(100);
   Show_State(HB_STATE,false) ;
   Show_State(TX_STATE,true) ;
   osDelay(100);
   Show_State(TX_STATE,false) ;
   Show_State(RSSI_STATE,RSSI_LOW) ;
   osDelay(100);
   Show_State(RSSI_STATE,RSSI_GOOD) ;
   osDelay(100);
   Show_State(RSSI_STATE,RSSI_HIGH) ;
   osDelay(100);
   Show_State(RSSI_STATE,RSSI_NOSIG) ;
   Show_State(GPS_STATE,true) ;
   osDelay(100);
   Show_State(GPS_STATE,false) ;
   Show_State(CONNECTED_STATE,true) ;
   osDelay(100);
   Show_State(CONNECTED_STATE,false) ;
   osDelay(100);
}

/*******************************************************************************
* routine  : Show_State
* Gazintas : state - The state to show (equates to a GPIO)
*          : value - value of the state (true = high, false = low)
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine just wiggles a GPIO based on state and value. These are for "UI"
* things like LEDs and debug pins.  IO for hardware are still seperate pins.
*
* NOTE: These are the nice but slower HAL calls.  See Gpio.h for the less
* portable but much faster direct register calls using #defines for the
* xISR_STATE calls. As these are for routines that are by definition
* time-critical code, the #defines make more sense.
*******************************************************************************/
void Show_State(int state, int value)
{
   GPIO_TypeDef* Port = 0 ; /* Port to wiggle */
   uint16_t      Pin  = 0 ; /* Pin to wiggle  */

   switch (state) /* omitting RSSI_STATE here, a special case */
   {
      case AISR_STATE     : Port = IN_AISR_GPIO_Port    ; Pin = IN_AISR_Pin    ; break ;
      case DISR_STATE     : Port = IN_DISR_GPIO_Port    ; Pin = IN_DISR_Pin    ; break ;
      case TISR_STATE     : Port = IN_TISR_GPIO_Port    ; Pin = IN_TISR_Pin    ; break ;
      case HB_STATE       : Port = LED_HB_GPIO_Port     ; Pin = LED_HB_Pin     ; break ;
      case TX_STATE       : Port = LED_TX_GPIO_Port     ; Pin = LED_TX_Pin     ; break ;
      case GPS_STATE      : Port = LED_GPS_GPIO_Port    ; Pin = LED_GPS_Pin    ; break ;
      case CONNECTED_STATE: Port = LED_CONN_GPIO_Port   ; Pin = LED_CONN_Pin   ; break ;
      default             :                                                      break ;
   } ;

   if (RSSI_STATE == state) /* special case since it's four states */
   {
      switch (value)
      {
         case RSSI_NOSIG : HAL_GPIO_WritePin(LED_RSSI_R_GPIO_Port,LED_RSSI_R_Pin,GPIO_PIN_RESET) ;
                           HAL_GPIO_WritePin(LED_RSSI_G_GPIO_Port,LED_RSSI_G_Pin,GPIO_PIN_RESET) ;
                           break ;
         case RSSI_LOW   : HAL_GPIO_WritePin(LED_RSSI_R_GPIO_Port,LED_RSSI_R_Pin,GPIO_PIN_SET  ) ;
                           HAL_GPIO_WritePin(LED_RSSI_G_GPIO_Port,LED_RSSI_G_Pin,GPIO_PIN_SET  ) ;
                           break ;
         case RSSI_GOOD  : HAL_GPIO_WritePin(LED_RSSI_R_GPIO_Port,LED_RSSI_R_Pin,GPIO_PIN_RESET) ;
                           HAL_GPIO_WritePin(LED_RSSI_G_GPIO_Port,LED_RSSI_G_Pin,GPIO_PIN_SET  ) ;
                           break ;
         case RSSI_HIGH  : HAL_GPIO_WritePin(LED_RSSI_R_GPIO_Port,LED_RSSI_R_Pin,GPIO_PIN_SET  ) ;
                           HAL_GPIO_WritePin(LED_RSSI_G_GPIO_Port,LED_RSSI_G_Pin,GPIO_PIN_RESET) ;
                           break ;
         default         : break ;
      }
   }

   else if (0 != Port) /* all the other valid states */
   {
      if (value)
      {
         HAL_GPIO_WritePin(Port,Pin,GPIO_PIN_SET) ;
      }
      else
      {
         HAL_GPIO_WritePin(Port,Pin,GPIO_PIN_RESET) ;
      }
   }
}

/*******************************************************************************
* Routine  : PHY_Reset
* Gazintas : State - true for asserting Reset (active low), false for not
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This Routine Wiggles the Ethernet PHY reset GPIO line
*******************************************************************************/
void PHY_Reset(int state)
{
   HAL_GPIO_WritePin(ETH_RST_GPIO_Port,ETH_RST_Pin,state?GPIO_PIN_RESET:GPIO_PIN_SET) ;
}

/*******************************************************************************
* Routine  : PTT_State
* Gazintas : State - true for asserting PTT (active low), false for not
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This Routine Wiggles the PTT GPIO line
*******************************************************************************/
void PTT_State(int state)
{
   HAL_GPIO_WritePin(MCU_PTT_GPIO_Port,MCU_PTT_Pin,state?GPIO_PIN_SET:GPIO_PIN_RESET) ;
}


/*******************************************************************************
* Routine  : SPICS_State
* Gazintas : State - true to assert CS, false to de-assert
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This Routine wiggles the SPINOR chip select.
* NOTE: This will likely be replaced by inline code for time sensitivity.
*******************************************************************************/
void SPICS_State(int state)
{
   HAL_GPIO_WritePin(FSPI_NCS_GPIO_Port,FSPI_NCS_Pin,state?GPIO_PIN_RESET:GPIO_PIN_SET) ;
}

/*******************************************************************************
* Routine  : OPTIRQ_State
* Gazintas : State - true to assert OPT_IRQ, false to de-assert
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This Routine wiggles the OPT_IRQ output.
*******************************************************************************/
void OPTIRQ_State(int state)
{
   HAL_GPIO_WritePin(OPT_IRQ_GPIO_Port,OPT_IRQ_Pin,state?GPIO_PIN_RESET:GPIO_PIN_SET) ;
}

/*******************************************************************************
* Routine  : COR_State
* Gazintas : None
* IOs      : None
* Returns  : COR state - true for carrier active, false for not
* Globals  : None
*
* This Routine samples the Repeater_COR GPIO line
*******************************************************************************/
int  COR_State(void)
{
   return (HAL_GPIO_ReadPin(MCU_COR_GPIO_Port,MCU_COR_Pin)) ;
}

/*******************************************************************************
* Routine  : RDSTAT_State
* Gazintas : None
* IOs      : None
* Returns  : COR state - true for carrier active, false for not
* Globals  : None
*
* This Routine samples the Repeater_COR GPIO line
*******************************************************************************/
int  RDSTAT_State(void)
{
   return (HAL_GPIO_ReadPin(RDSTAT_GPIO_Port,RDSTAT_Pin)) ;
}

/*******************************************************************************
* Routine  : V14_State
* Gazintas : None
* IOs      : None
* Returns  : 14V status, true for good >11.9V, false for bad <11.9V.
* Globals  : None
*
* This Routine samples the Rpeater_14V gpio line
*******************************************************************************/
int  V14_State(void)
{
   return (HAL_GPIO_ReadPin(RPTR_VSENSE14_GPIO_Port,RPTR_VSENSE14_Pin)) ;

}

/*******************************************************************************
* Routine  : ACFAIL_State
* Gazintas : None
* IOs      : None
* Returns  : Repeater ACFAIL state.  True if AC has failed, false if not.
* Globals  : None
*
* This Routine samples the Rpeater_14V gpio line
*******************************************************************************/
int  ACFAIL_State(void)
{
   return (HAL_GPIO_ReadPin(ACFAIL_GPIO_Port,ACFAIL_Pin)) ;

}

/*******************************************************************************
* Routine  : SPI_CSID_State
* Gazintas : None
* IOs      : None
* Returns  : Chip Select ID state.  1 for read, 0 for write
* Globals  : None
*
* This Routine samples the Chip Select ID bit
*******************************************************************************/
int  SPI_CSID_State(void)
{
   return (!HAL_GPIO_ReadPin(MTRSPI_CSID_GPIO_Port,MTRSPI_CSID_Pin)) ;

}
