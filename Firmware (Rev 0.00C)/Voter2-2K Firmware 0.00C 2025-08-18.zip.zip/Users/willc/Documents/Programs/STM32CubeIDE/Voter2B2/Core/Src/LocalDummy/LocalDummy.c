/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/* ************************************************************************** */
/* This is the LocalDummy file. It is just a Dummy local mode implementaion   */
/* that echoes back audio if DIAL is unauthorized and Rx is active, nothing   */
/* else.  This exists just to test I can swap between two local mode          */
/* implementations and not for use in "real life".                            */
/******************************************************************************/
/* Public routines are:                                                       */
/*  - LocalModeSM - The state machine.                                        */
/*                                                                            */
/******************************************************************************/
// To Do:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>

#include "Options.h"
#include "AnalogIO.h"
#include "Tx_DSP.h"
#include "DialTask.h"

#ifdef LOCALDUMMY
/******************************************************************************/
/* Local defines (including enums)                                            */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static int16_t LocalAudio[APKT_SAMPLES] = {0}   ; /* Locally generated audio  */

/******************************************************************************/
/* External globals. CubeMX has you define them as externs in each file       */
/* instead of an include file, weird.                                         */
/******************************************************************************/

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : LocalModeSM
* Gazintas : RxAudio - Incoming audio sample buffer (160 samples)
*          : DIAL_State - DIAL connection state
*          : Rx_Active - Repeater COR state
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This is the Local Mode main state machine.  It gets called every 20ms by
* DialTask with 20ms of audio samples, the DIAL state and COR state.
* If DIAL_State is anything but unauthorized, the state machine resets as if
* authorized, we're not in local mode.  If COR is active we copy the received
* audio to the transmit side (if in repeater mode) otherwise it is either
* silence of any of the IDing options that may be requested.  PTT is taken care
* of later in the chain based on if audio samples are coming down or not.
*******************************************************************************/
void LocalModeSM(int16_t* RxAudio,int DIAL_State, int Rx_Active)
{
   /* Only echo audio if unauthorized and Rx is active */
   if (DIAL_UNAUTHORIZED && Rx_Active)
   {
      /* Copy the Rx Audio data since it may get recycled before being        */
      /* actually consumed here.                                              */
      memcpy(LocalAudio,RxAudio,APKT_SAMPLES*2) ;
      Tx_EnqPacket(LocalAudio,LOCAL_TIMED,0,0) ;
   }
}

#endif /* ifdef LOCALDUMMY */
