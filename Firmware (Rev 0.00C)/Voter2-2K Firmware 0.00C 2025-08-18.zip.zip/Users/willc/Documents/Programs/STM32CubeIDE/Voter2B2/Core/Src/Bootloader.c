/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the bootloader file.                                               */
/* This routine gets called by main() first thing, so before any other code   */
/* outside the assembly startup.  Most importantly, before any HAL init stuff.*/
/* This code needs to be completely self-contained since what it will be doing*/
/* is erasing/reprogramming all other non-volatile memory in the system!      */
/*  - This code starts running from STM flash but then loads up ITCM space    */
/*    with the code to erase and reprogram the STM and QSPI flash.            */
/*  - I expect it to be activated by a magic number in one of the RTC backup  */
/*    registers.                                                              */
/*  - As this must be self-contained, it is going to have copied code from    */
/*    other places in this project.  The original source will be noted.       */
/*  - A fully validated image is assumed to be in the external SPI flash      */
/*                                                                             */
/* At a high level, if activated, this bootcode updates both the STM32H7        */
/* internal flash and external QSPI flash from the external SPI flash in the     ***********************************************/
/* following way:                                                                                                               */
/*  - SPI Flash 0x0000_0000 - 0x001d_ffff to QSPI  Flash 0x0000_0000 - 0x001d_ffff (logical address 0x9000_0000 to 0x901d_ffff) */
/*  - SPI Flash 0x001e_0000 - 0x001f_ffff to STM32 Flash 0x0000_0000 - 0x001f_ffff (logical address 0x0800_0000 to 0x081f_ffff) */
/* Note that QSPI flash addresses 0x001e_0000 - 0x001f_ffff are essentially                                                     */
/* unusable as there is no way to update them from SPI flash.  That memory       ***********************************************/
/* got "stolen" to used for updating the STM32 flash.                           */
/* What makes this code challenging is I can't rely on any HAL/LL calls as in  */
/* bootloader mode, that code is getting erased/replaced!                     */
/*                                                                            */
/* This file (Bootloader.c) contains the code in "regular" flash that does    */
/* the initial checks, then loads the ITCM with the code that actually does   */
/* the flash erasing and reprogramming.  Bootloader2.c is all the ITCM code.  */
/* Note that there is a STRONG separation between these two sets of code!     */
/* Code in flash can't call ITCM code as it hasn't been loaded yet and code   */
/* in ITCM can't call any flash code as it's erasing it!  The only common     */
/* link is the call from Bootloader() to I_Bootloader2().                     */
/*                                                                            */
/* Hardware that this bootloader uses:                                        */
/*  - RTC    - For the magic number to activate Bootloading (soon)            */
/*  - SPI3   - for SPI flash (source data)                                    */
/*  - QSPI   - for QSPI flash (destination data)                              */
/*  - FLASH  - For STM32 internal flash                                       */
/*  - USART1 - For logging info                                               */
/*  - GPIO   - Just the heartbeat LED and SPI Chip select.                    */
/*                                                                            */
/* IMPORTANT: For the mainline code, the clock for SPI3 needs to be per_ck    */
/* (which is HSI).  The default is PLL1Q, but after a reset into this         */
/* bootloader the PLL is off.  The way the RCC works, both the previous       */
/* clock and new clock must BOTH be active in order to change clock sources   */
/* to a device (SPI3 in this case).  The default clock for SPI3 is PLL1Q      */
/* a reset, so I can't change its clock without having to fire up the PLL.    */
/* If I have per_ck as the source running the mainline code, it seems to be   */
/* remembered across a reset so it isn't locked up when I run this            */
/* bootloader.                                                                */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Bootloader - The bootloader.                                            */
/*                                                                            */
/* Additionally, the mainline QSPINOR setup code calls routines in here as    */
/* that code needs to set up the QSPI NOR inteface before the HAL routines    */
/* have run as have the HAL code in QSPI flash!  These routines are:          */
/*  - ConfigGpio - Initialize the GPIO pins                                   */
/*  - ConfigQspi - Initialize the QSPI interface and IO                       */
/*  - ReConfigQspi - Reconfigure the QSPI interface (not used by bootloader)  */
/*  - BL_QSPINOR_Init - Initialize the QSPI NOR device                        */
/*  - BL_QSPINOR_Cmd - Send command to QSPI flash                             */
/*  - BL_QSPINOR_WrDat -  Send data to QSPI flash (not used by Bootloader)    */
/*  - SW_msDelay - Software ms delay (not used by Bootloader)                 */
/*  - BL_QSPINOR_SetupXIP - Set up XIP mode (not used by Bootloader)          */
/*                                                                            */
/******************************************************************************/
// TO DO:

/******************************************************************************/
/* Includes                                                                   */
/* IMPORTANT: Other than register definitions and #define includes, there     */
/* can't be much else as the whole point of this code is not relying on       */
/* any other code outside this file!                                          */
/******************************************************************************/
#include "stm32h750xx.h"   /* STM32H7 Register definitions  */
#include "Options.h"       /* My system #defines            */
#include "Bootloader.h"    /* Bootloader externally visible */
#include "BootloaderCom.h" /* Bootloader Internal stuff     */
#include "MX25Lxx.h"       /* SPINOR register #defines      */

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
/* See BootloaderCom.h */

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static int BL_SPINOR_Type  = SPINOR_UNKNOWN ;
static int BL_QSPINOR_Type = SPINOR_UNKNOWN ;

/******************************************************************************/
/* External globals. How CubeMX does things instead of in an include file,    */
/* weird.                                                                     */
/******************************************************************************/

/******************************************************************************/
/* Local routine prototypes - Ones executed from STM32 Flash only.            */
/* These are the setup and copy-to-ITCM routines.                             */
/******************************************************************************/
/*     void Bootloader(void) ; not local but in this group */
static void ConfigRtc(void) ;
static void ConfigUart(void) ;
static void ConfigSpi(void) ;

static void BL_SPINOR_Init(void) ;
static void Load_ITCM_Image(void) ;

static void BL_QSPINOR_ReadData(uint32_t,uint32_t,uint8_t*) ;

/******************************************************************************/
/* Local routine prototypes - Support routines needed in both spaces.         */
/* These are support routines needed for both classes, so two copies of most. */
/******************************************************************************/
static void UartStr(char*) ;
static void UartHex(uint8_t) ;
static void RMW_Reg(volatile uint32_t*,uint32_t, uint32_t,int) ;
//static void HB_LED(int) ;
static void SPI_CS(int) ;
static void SW_usDelay(int) ;
static void BL_SPINOR_Cmd (uint8_t*,int,int) ;
static void BL_SPINOR_Read(uint8_t*,int,int) ;
static void SPI_Done(void) ;
static void BL_QSPINOR_RdReg(uint8_t,uint32_t,uint32_t,uint32_t,uint8_t*) ;

/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
/* ***** STM32 FLASH-only Routines                                      ***** */
/******************************************************************************/
/******************************************************************************/
/******************************************************************************/

/*******************************************************************************
* Routine  : Bootloader
* Gazintas : Nothing
* IOs      : None
* Returns  : Maybe
* Globals  : None
*
* This routine first checks to see if an update is pending using a magic number
* in an RTC register (its value survives reboots).  If not, it quickly returns
* and the Voter2 boots up normally.  If an update is pending it programs both
* the STM32 internal flash and XIP flash with the contents of the download
* flash.  As this code is deleting all "executable" flash, it cannot rely on any
* code in them so must be 100% self-contained code!
* Phase 1 of the bootbloader just loads all the ITCM code from flash into ITCM
* and then calls phase 2 that does the actual erasing and reprogramming.
*******************************************************************************/
void Bootloader(void)
{
   /* Again, we get here as the first call in main(), so other than the stack */
   /* and BSS setup, nothing has been initialized!  No peripheral has been    */
   /* touched!                                                                */
   /* We're running the default CPU clock (internal HSI @ 64MHz)              */
   /* No caches enabled, no MPU enabled...                                    */

   /* First, initialize the RTC and see if if backup register 0 has the magic */
   /* number or not.  If not, exit quickly, otherwise programming time!!!     */
   ConfigRtc() ;
   if (BOOTLOADER_MAGICNUM!=RTC->BKP0R) return ;

   /* Bootloader success or not, the next reboot is back to the mainline code.*/
   RTC->BKP0R = 0 ;

   /* Initialize all the peripherals needed for the bootloader                */
   ConfigGpio() ;
   ConfigUart() ;
   ConfigSpi()  ;
   ConfigQspi() ;

   UartStr("Bootloader (Step 1)...\r\n") ; /* HW running, say "Hi" from the bootloader.   */

   /* Verify we can talk to SPINOR and QSPINOR. (internal flash is implied!)  */
   BL_SPINOR_Init() ;
   BL_QSPINOR_Init(true) ;

   /* If any problems, stop before erasing anything irrecoverable! */
   if ((SPINOR_UNKNOWN==BL_SPINOR_Type) || (SPINOR_UNKNOWN==BL_QSPINOR_Type))
   {
      UartStr("Flash ID errors, aborting bootloading.\r\n") ;
      /* Undo the magic number - later */
      while (1) ;
   }

   /* Copy ITCM image from QSPI NOR to ITCM and jump to that code.            */
   /* ITCM code deletes this very flash code that called it!!!                */
   /* A return to 'here' would be very bad because 'here' got erased!         */
   /* (The ITCM code finishes with a reboot)                                  */
   Load_ITCM_Image() ;
   I_Bootloader2() ;

   /* A while(1) just in case for debugging during bring-up */
   while (1) ;
}

/*******************************************************************************
* Routine  : ConfigRtc
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine sets up the Real Time Clock hardware.  I don't think it needs
* much, just enable writes, then unlock the register interface.
*******************************************************************************/
static void ConfigRtc(void)
{
   RMW_Reg(&PWR->CR1 ,0x1,0x01,8) ; /* Enable writes to RTC */
   RTC->WPR = 0xCAU               ; /* Unlock the RTC */
   RTC->WPR = 0x53U               ; /* Unlock the RTC */

   /* Enable the Battery backed SRAM while we're at it. */
   RMW_Reg(&RCC->AHB4ENR ,0x1,0x01,28) ;
   __DSB() ;
} ;

/*******************************************************************************
* Routine  : ConfigGpio
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine sets up the MCO pin (to see the clock), the HB LED pin (to show
* life), and the GPIO for the SPI flash chip select.
*
* IMPORTANT: This routine also enables clocks to all the GPIO pins even if not
* used for classic GPIO!! Even for UART, SPI, and QSPI to work, I need to
* release reset and enabled clocks for all GPIO here.
*******************************************************************************/
void ConfigGpio(void)
{
   RMW_Reg(&RCC->AHB4RSTR ,0x1f,0x00,0 ) ; /* Release reset to GPIOs A-E */
   RMW_Reg(&RCC->AHB4ENR  ,0x1f,0x1f,0 ) ; /* Enable clocks to GPIOs A-E */

   RMW_Reg(&GPIOE->MODER  ,0x03,0x01,20) ; /* PE10 (LED_HB) to output    */
   RMW_Reg(&GPIOD->MODER  ,0x03,0x01, 0) ; /* PD0  (SPI_CS) to output    */

   RMW_Reg(&GPIOC->MODER  ,0x03,0x02,18) ; /* PC9 (MCO2) to alt func     */
   RMW_Reg(&GPIOC->AFR[1] ,0x0f,0x00, 4) ; /* PC9 (MCO2) alt to MCO2     */
   RMW_Reg(&GPIOC->OSPEEDR,0x03,0x03,18) ; /* PC9 (MCO2) to high speed   */
   RMW_Reg(&RCC  ->CFGR   ,0x07,0x00,29) ; /* Set MCO2 out to Sys Clock  */
}

/*******************************************************************************
* Routine  : ConfigUart
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine sets up USART1 for program IO Tx-only comms at 115,200 N81.
* 64MHz/115200 = 556 = 0x22c
*******************************************************************************/
static void ConfigUart(void)
{
   RMW_Reg(&GPIOA->MODER ,0x03,0x02,18) ; /* PA9 (UART1_TX) to alt func       */
   RMW_Reg(&GPIOA->AFR[1],0x0f,0x07, 4) ; /* PA9 (UART1_TX) alt to USART1_TX  */
   /* Not bothering with Rx, not using it.                                    */

   RMW_Reg(&RCC->D2CCIP2R,0x07,0x03, 3) ; /* hsi_ker_ck as clock for UART1,6  */
   RMW_Reg(&RCC->APB2ENR ,0x01,0x01, 4) ; /* Enable the clock                 */
   RMW_Reg(&RCC->APB2RSTR,0x01,0x00, 4) ; /* Make sure reset is disabled      */

   USART1->PRESC = 0x00000000 ; /* Don't prescale      */
   USART1->BRR   = 0x0000022c ; /* Baud rate divisor   */
   USART1->CR1   = 0x00000009 ; /* Enable Tx and UART! */
}

/*******************************************************************************
* Routine  : ConfigSpi
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine sets up SPI3.  See the inline comments for the particulars of
* the setup. Note that I use clk/8 on purpose, using clk/2 resulted in
* overflow errors with the default slow CPU speeds.
*******************************************************************************/
static void ConfigSpi(void)
{
   /* PC10 = CLK, PC11 = MOSI, PC12 = MISO. CS handled in GPIO Con fig   */
   RMW_Reg(&GPIOC->MODER  , 0x3f, 0x2a,20) ; /* PC10,11,12 to alt func   */
   RMW_Reg(&GPIOC->AFR[1] ,0xfff,0x666, 8) ; /* PC10,11,12 alt to SPI    */
   RMW_Reg(&GPIOC->OSPEEDR, 0x3f, 0x3f,20) ; /* PC10,11,12 high speed io */

   //RMW_Reg(&RCC->APB1LRSTR,0x01,0x01,15) ; /* Make sure reset is asserted     */
   RMW_Reg(&RCC->D1CCIPR  ,0x03,0x00,28) ; /* per_ck to HSI (this is default) */
   RMW_Reg(&RCC->D2CCIP1R ,0x07,0x04,12) ; /* Select per_ck clock for SPI1,2,3*/
   RMW_Reg(&RCC->APB1LENR ,0x01,0x01,15) ; /* Enable the clock                */
   //RMW_Reg(&RCC->APB1LRSTR,0x01,0x00,15) ; /* Make sure reset is disabled     */

   /* Order here mattered more than I expected!                               */
   SPI3->CFG1 = 0x20070007 ; /* clk/8, 8-bit data/CRC     */
   SPI3->CR2  = 0x00000001 ; /* Transfer size of 1        */
   SPI3->CR1  = 0x00001000 ; /* Enable the SSI bit first  */
   SPI3->CFG2 = 0x84400000 ; /* SSM=1,SPI master (CPOL/CHPA?) AFCNTR = 1  */
   SPI3->IFCR = 0x00000ff8 ; /* Clear any existing errors */
}

/*******************************************************************************
* Routine  : ConfigQspi
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine sets up QSPI1.  See the inline comments for the particulars of
* the setup.  ClkSrc should be QSPI_HSICLK for pre-HAL calls, QSPI_HCLK3 for
* post-HAL calls.
*******************************************************************************/
void ConfigQspi(void)
{
   /* Start off with QSPI reset. */
   RMW_Reg(&RCC->AHB3RSTR ,0x01,0x01,14) ; /* Reset the QSPI (if not already so */

   /* PB2 = CLK, PB10 = CS */
   RMW_Reg(&GPIOB->MODER  ,0x00300030,0x00200020,0) ; /* PB2,10 to alt func   */
   RMW_Reg(&GPIOB->AFR[0] ,      0x0f,      0x09,8) ; /* PB2 alt to QSPI      */
   RMW_Reg(&GPIOB->AFR[1] ,      0x0f,      0x09,8) ; /* PB10 alt to SPI      */
   RMW_Reg(&GPIOB->OSPEEDR,0x00300030,0x00300030,0) ; /* PB2,10 high speed io */

   /* PD11 = D0, PD12 = D1, PD13 = D3 */
   RMW_Reg(&GPIOD->MODER  , 0x3f, 0x2a,22) ; /* PD11,12,13 to alt func   */
   RMW_Reg(&GPIOD->AFR[1] ,0xfff,0x999,12) ; /* PD11,12,13 alt to QSPI   */
   RMW_Reg(&GPIOD->OSPEEDR, 0x3f, 0x3f,22) ; /* PD11,12,13 high speed io */

   /* PE2 = D2 */
   RMW_Reg(&GPIOE->MODER  ,0x03,0x02, 4) ; /* PE2 to alt func   */
   RMW_Reg(&GPIOE->AFR[0] ,0x0f,0x09, 8) ; /* PE2 alt to QSPI   */
   RMW_Reg(&GPIOE->OSPEEDR,0x03,0x03, 4) ; /* PE2 high speed io */

   RMW_Reg(&RCC->D1CCIPR  ,0x03,0x00,28) ; /* per_ck to HSI (this is default) */
   RMW_Reg(&RCC->D1CCIPR  ,0x03,0x03, 4) ; /* Select per_ck clock for QSPI  */
   RMW_Reg(&RCC->AHB3ENR  ,0x01,0x01,14) ; /* Enable the clock                */
   RMW_Reg(&RCC->AHB3RSTR ,0x01,0x00,14) ; /* Disable reset                   */

   /* Remarkably little peripheral initialization! */
   QUADSPI->DCR = (QSPI_FSIZE<<QUADSPI_DCR_FSIZE_Pos) ; /* Only bits are flash size */
   QUADSPI->CR  = (4<<QUADSPI_CR_PRESCALER_Pos) | QUADSPI_CR_EN ; /* Prescale 4 (/5), Enable QSPI */
}

/*******************************************************************************
* Routine  : ReConfigQspi
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine reconfigures the QSPI interface for optimal speed once all the
* system clocks are set up.  The original config is pre-HAL, so limited to the
* HSI clock as a reference.
*
* IMPORTANT! This routine needs to disable and re-enable the QSPI interface!!
* Make sure some other IRQ-based code doesn't try to run from it!  This routine
* assumes the caller disables interrupts before and restores them afterwards.
*******************************************************************************/
void ReConfigQspi(void)
{
   QUADSPI->CR = QUADSPI_CR_ABORT         ; /* Abort memory mapped mode       */
   while (QUADSPI->CR & QUADSPI_CR_ABORT) ; /* Wait for abort to finish       */
   while (QUADSPI->SR & QUADSPI_SR_BUSY)  ; /* Confirm not busy               */

   QUADSPI->CR = 0                      ; /* disable the QSPI interface       */
   RMW_Reg(&RCC->D1CCIPR ,0x03,0x00, 4) ; /* Select hclk3 clock for QSPI      */
 //QUADSPI->DCR = (QSPI_FSIZE<<QUADSPI_DCR_FSIZE_Pos) ; /* Only bits are flash size */
   QUADSPI->CR  = (1<<QUADSPI_CR_PRESCALER_Pos) | QUADSPI_CR_EN ; /* Prescale 1 (/2), Enable QSPI */
}

/*******************************************************************************
* Routine  : BL_SPINOR_Init
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine gets called after the ConfigSpi() routine that sets up the
* SPI interface.  This resets SPI NOR chip (there is no hardware reset line)
* and reads the Chip ID so we know what size device we are working with.
*******************************************************************************/
static void BL_SPINOR_Init(void)
{
   uint8_t cmd[4]    = {0} ; /* Command buffer     */
   uint8_t ChipID[2] = {0} ; /* ID read from flash */

   /* First, send the reset command--well really reset enable, then the reset */
   /* command!                                                                */
   cmd[0]= RESET_ENABLE_CMD ;
   BL_SPINOR_Cmd(cmd,1,CS_INACTIVE) ;
   cmd[0]= RESET_MEMORY_CMD ;
   BL_SPINOR_Cmd(cmd,1,CS_INACTIVE) ;
   SW_usDelay(25) ; /* Datasheet says reset takes 20us max */

   /* Now that we have the NOR's attention (parent joke), read the Chip ID.   */
   cmd[0]= READ_IDS_CMD ; /* 2nd-4th bytes already 0 */
   BL_SPINOR_Cmd (cmd,4,CS_ACTIVE) ;
   BL_SPINOR_Read(ChipID,2,CS_INACTIVE) ;

   /* Note the Chip ID bytes */
   UartStr(" SPINOR: Chip ID ") ;
   UartHex(ChipID[0]) ;
   UartHex(ChipID[1]) ;

   /* Note the device type in local global BL_SPINOR_Type for other code to   */
   /* know.                                                                   */
   if ((MACRONIX_MFR_ID==ChipID[0])&&(MX25L3233_DEVICE_ID==ChipID[1]))
   {
      UartStr(": MX25L3233\r\n") ;
      BL_SPINOR_Type = SPINOR_MX25L3233 ;
   }
   else if ((MACRONIX_MFR_ID==ChipID[0])&&(MX25L25645_DEVICE_ID==ChipID[1]))
   {
      UartStr(": MX25L25645\r\n") ;
      BL_SPINOR_Type = SPINOR_MX25L25645 ;
   }
   else
   {
      UartStr(": Unknown\r\n") ;
   }
}

/*******************************************************************************
* Routine  : BL_QSPINOR_Init
* Gazintas : verbose - echo chip info to the UART.
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine gets called after the ConfigQspi() routine that sets up the
* QSPI interface.  This resets QSPI NOR chip (there is no hardware reset line)
* and reads the Chip ID so we know what device we are working with.
*******************************************************************************/
void BL_QSPINOR_Init(int verbose)
{
   uint8_t ChipID[2] = {0} ; /* ID read from flash */

   /* First, send the reset command--well really reset enable, then the reset */
   /* command!                                                                */
   BL_QSPINOR_Cmd(RESET_ENABLE_CMD,0,0) ;
   BL_QSPINOR_Cmd(RESET_MEMORY_CMD,0,0) ;
   SW_usDelay(25) ; /* Datasheet says reset takes 20us max */

   /* Read the Chip ID.   */
   BL_QSPINOR_RdReg(READ_IDS_CMD,0x00000000,QSPI_ADDRSIZE_24|QSPI_ADMODE_1BIT,2,ChipID) ;

   if (verbose)
   {
      /* Note the Chip ID bytes */
      UartStr("QSPINOR: Chip ID ") ;
      UartHex(ChipID[0]) ;
      UartHex(ChipID[1]) ;

      /* Note the device type in local global BL_QSPINOR_Type for other code  */
      /* to know.                                                             */
      if ((MACRONIX_MFR_ID==ChipID[0])&&(MX25L3233_DEVICE_ID==ChipID[1]))
      {
         UartStr(": MX25L3233\r\n") ;
         BL_QSPINOR_Type = SPINOR_MX25L3233 ;
      }
      else if ((MACRONIX_MFR_ID==ChipID[0])&&(MX25L25645_DEVICE_ID==ChipID[1]))
      {
         UartStr(": MX25L25645\r\n") ;
         BL_QSPINOR_Type = SPINOR_MX25L25645 ;
      }
      else
      {
         UartStr(": Unknown\r\n") ;
      }
   }
}

/*******************************************************************************
* Routine  : Load_ITCM_Image
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine copies the ITCM image from the QSPI flash to ITCM.
* Coincidentally, SPI address 0 maps to STM32 Address 0 at the start of ITCM.
*******************************************************************************/
static void Load_ITCM_Image(void)
{
   uint32_t Addr = 0 ;

   for(Addr=0;Addr<ITCMSIZE;Addr+=QSPI_BLKLENB)
   {
      BL_QSPINOR_ReadData(Addr,QSPI_BLKLENB,(uint8_t*)Addr) ;
   }
}

/*******************************************************************************
* Routine  : BL_QSPINOR_ReadData
* Gazintas : cmd - Command
*          : Addr - Address
*          : DataLen - length of data to retrieve
*          : buf - buffer for read data
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine reads data from the QSPINOR device
*******************************************************************************/
static void BL_QSPINOR_ReadData (uint32_t Addr, uint32_t DataLen,uint8_t* buf)
{
   /* Clear out any old flags and queue up the data size */
   QUADSPI->FCR = QSPI_FCR_ALLBITS ;
   QUADSPI->DLR = DataLen-1 ;

   /* The command control write first. Always 1-bit for instruction and data  */
   /* phases and obviously a read too.                                        */
   QUADSPI->CCR = QSPI_IMODE_1BIT|QSPI_FMODE_READ|QSPI_DMODE_1BIT|QSPI_ADMODE_1BIT|QSPI_ADDRSIZE_24| READ_DATA_CMD ;
   QUADSPI->AR  = Addr ;
   __DSB() ; /* make sure it's all sent before polling */

   /* Start polling for return data */
   while (DataLen)
   {
      while (((QUADSPI->SR)&(QUADSPI_SR_TCF|QUADSPI_SR_FTF))==0) ; /*Wait on FIFO threshold or terminal count   */
      *buf = *(__IO uint8_t*)(&QUADSPI->DR) ; /* read byte (force a byte read)*/
      buf++ ;
      DataLen-- ;
   }
}


/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
/* ***** Support Routines                                               ***** */
/******************************************************************************/
/******************************************************************************/
/******************************************************************************/

/*******************************************************************************
* Routine  : UartStr
* Gazintas : str - string to send
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine sends a string to USART1 in program IO mode (blocking).
*******************************************************************************/
static void UartStr(char* str)
{
   while (*str)
   {
      while (!(USART1->ISR&0x40)) ; /* Wait on TC = 0 (busy) */
      USART1->TDR = *str ;
      str++ ;
   }
}

/*******************************************************************************
* Routine  : UartHex
* Gazintas : val - Byte to write out as ASCII hex
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine converts a byte to ASCII hex and sends it to USART1 in program
* IO mode (blocking).
*******************************************************************************/
static void UartHex(uint8_t val)
{
   char str[4] = {0} ;

   str[0] = val/16 + '0' ; if (str[0]>'9') str[0] += 'a'-'9'-1 ;
   str[1] = val%16 + '0' ; if (str[1]>'9') str[1] += 'a'-'9'-1 ;
   str[2] = ' ' ;
   UartStr(str) ;
}

/*******************************************************************************
* Routine  : RMW_Reg
* Gazintas : Addr - Register address
*          : mask - mask of bits to clear out (shifted to LSB)
*          : val - new value to replace
*          : shift - shift to where the bits need to be
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine is a generic read/modify/write for a register.  The mask and new
* value are in the LSBs for easier coding then get shifted as needed.  Yea this
* could be a #define, but keeping it to somethign I can easily understand.
*******************************************************************************/
static void RMW_Reg(volatile uint32_t* Addr,uint32_t mask, uint32_t val, int shift)
{
   volatile uint32_t tmp = *Addr ;
   tmp = tmp & ~(mask<<shift) ;
   tmp = tmp |  (val <<shift) ;
   *Addr = tmp ;
}

/*******************************************************************************
* Routine  : HB_LED, SPI_CS
* Gazintas : ToOn/Assert
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine wiggles the heartbeat LED or SPI chip select.
* True for LED on (high) or CS asserted (low), false for off/unasserted.
*******************************************************************************/
#if 0 /* Not used yet - to avoid compiler warnings */
static void HB_LED(int ToOn)
{
   GPIOE->BSRR = ToOn?0x400:0x4000000 ;
}
#endif

static void SPI_CS(int Assert)
{
   GPIOD->BSRR = Assert?0x00010000:0x00000001 ;
}

/*******************************************************************************
* Routine  : SW_msDelay, SW_usDelay
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine is a delay function.  Without any hardware support I'm winging it
* in software.  It is only roughly calibrated using a scope.  You touchie the
* CPU clock, this goes bad! :)
* NOTE!!  Count values differ a lot between running from flash and ITCM, about
* 4.5x faster!
*******************************************************************************/
void SW_msDelay(int ms)
{
   volatile int i = 0 ;

   while (ms>0)
   {
      for (i=0;i<2564;i++) ;
      ms-- ;
   }
}

static void SW_usDelay(int us)
{
   int count = 0 ;
   volatile int i = 0 ;

   count = (us*2915)/1000 ;

   for (i=0;i<count;i++) ;
}

/*******************************************************************************
* Routine  : BL_SPINOR_Cmd
* Gazintas : cmd - Command string
*          : len - length of command string
*          : cs_end - flag to de-assert CS after command
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine sends a command string to the SPINOR.  It assumes CS is de-
* asserted before, asserts it, and then sends the command.  If there is no
* data read or write after the command, the cs_end flag tells the routing to
* go ahead and de-assert CS after the command.
*
* NOTE: This isn't very efficient code!  I'm not sure it matters as the flash
* should be by far the bottleneck.  I can look at it later for optimizing if
* convinced it matters.
*******************************************************************************/
static void BL_SPINOR_Cmd (uint8_t* cmd, int len,int cs_end)
{
   SPI_CS(true) ; /* assert CS */

   /* Fire up the SPI controller. */
   SPI3->CR2 = len                   ; /* Transfer size      */
   RMW_Reg(&SPI3->CFG2,0x03,0x00,17) ; /* Full duplex Change to simplex transmit?????? */
   RMW_Reg(&SPI3->CR1 ,0x01,0x01, 0) ; /* Enable SPI         */
   RMW_Reg(&SPI3->CR1 ,0x01,0x01, 9) ; /* Start (CSTART bit) */

   while (len)
   {
      /*Wait for TXP flag (should never wait, the FIFO should be ready) */
      while (!(SPI3->SR&0x02)) ;
      *(uint8_t*)(&SPI3->TXDR) = *cmd ; /* write a byte (force byte write) */
      cmd++ ;
      len-- ;
   }

   /* FIFO writes can get ahead of data, so wait for all data to be sent      */
   /* before next step of (maybe) de-asserting CS.                            */
   while (!(SPI3->SR&0x08)) ; /* Wait until end of transfer flag              */
   if (CS_INACTIVE==cs_end) SPI_CS(false) ;

   /* All done, shut down SPI controller. */
   SPI_Done() ;
}

/*******************************************************************************
* Routine  : BL_SPINOR_Read
* Gazintas : buf - Buffer to fill
*          : len - bytes to read
*          : cs_end - De-assert CS at the end flag
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine reads data from the SPI interface.  It assumes the command to
* say what to read has been sent (and CS left de-asserted) before this routine
* gets called.
*******************************************************************************/
static void BL_SPINOR_Read(uint8_t* buf,int len,int cs_end)
{
   /* Fire up the SPI controller. */
   SPI3->CR2 = len                   ; /* Transfer size         */
   RMW_Reg(&SPI3->CFG2,0x03,0x02,17) ; /* Simplex receiver mode */
   RMW_Reg(&SPI3->CR1 ,0x01,0x01, 0) ; /* Enable SPI            */
   RMW_Reg(&SPI3->CR1 ,0x01,0x01, 9) ; /* Start transfer bit    */

   while (len)
   {
      while (!(SPI3->SR&0x01)) ; /*Wait for RXP flag */
      *buf = *(__IO uint8_t*)(&SPI3->RXDR) ; /* read a byte (force byte read) */
      buf++ ;
      len-- ;
   }

   /* All done, de-assert CS. */
   if (CS_INACTIVE==cs_end) SPI_CS(false) ;

   /* Shut down SPI controller. */
   SPI_Done() ;
}

/*******************************************************************************
* Routine  : SPI_Done
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* Just a quick routine for the common code at the end of a SPI transfer.
*******************************************************************************/
static void SPI_Done(void)
{
   RMW_Reg(&SPI3->CR1,0x01,0x00,0) ; /* Turn off SPI */
   SPI3->IFCR  = 0x00000ff8 ; /* Clear any existing errors/done flags */
}

/*******************************************************************************
* Routine  : BL_QSPINOR_Cmd
* Gazintas : cmd - Command
*          : Addr - Address (or at least bytes after the command)
*          : modes - Comm modes (for CCR)  Only ones that make sense are
*          :         ADDRSIZE and ADMODE
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine sends a one-off command to the SPI flash (no data).
* Reminder the QSPI controller only needs/wants the necessary register writes
* after the control write that are actually needed to start.  With just a
* command, the only possible data is an address or data that would part of the
* address field.
*******************************************************************************/
void BL_QSPINOR_Cmd (uint8_t cmd, uint32_t Addr, uint32_t modes)
{
   int timeout = 0 ;

   /* Clear out any old flags then write the command control word  */
   QUADSPI->FCR = QSPI_FCR_ALLBITS ;
   QUADSPI->CCR = QSPI_IMODE_1BIT | modes | cmd ;

   /* Only write address register if an address is to be sent */
   if (modes&QSPI_ADMODE_4BIT) QUADSPI->AR  = Addr ;
   __DSB() ; /* make sure it's all written before polling */

   /* Wait for the command to complete */
   while(QUADSPI->SR & QUADSPI_SR_BUSY) /* Busy flag */
   {
      SW_usDelay(1) ;
      timeout++ ;
      if (timeout>10000) /* 10ms */
      {
         return ;
      }
   }
}

/*******************************************************************************
* Routine  : BL_QSPINOR_WrDat
* Gazintas : cmd - Command
*          : len - Number of data bytes after command
*          : data - data to send
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine sends non-memory data to the QSPI flash.
* Reminder the QSPI controller only needs/wants the necessary register writes
* after the control write that are actually needed to start.
*******************************************************************************/
void BL_QSPINOR_WrDat (uint8_t cmd, int len, uint8_t* data)
{
   int timeout = 0 ;

   /* Clear out any old flags then write the command control word  */
   QUADSPI->FCR = QSPI_FCR_ALLBITS ;
   QUADSPI->CCR = QSPI_IMODE_1BIT | QSPI_DMODE_1BIT | cmd ;
   QUADSPI->DLR = len-1 ;

   __DSB() ; /* make sure it's all written before polling */

   /* The QSPI controller should be ready, start sending data */
   while (!(QUADSPI->SR & QUADSPI_SR_TCF)) /* Loop until all data sent */
   {
      while (!(QUADSPI->SR & QUADSPI_SR_FTF)) ; /* If FIFO full, wait */
      QUADSPI->DR = *data ;
      data++ ;
   }

   /* Wait for the command to complete */
   while(QUADSPI->SR & QUADSPI_SR_BUSY) /* Busy flag */
   {
      SW_usDelay(1) ;
      timeout++ ;
      if (timeout>10000) /* 10ms */
      {
         return ;
      }
   }
}

/*******************************************************************************
* Routine  : BL_QSPINOR_RdReg
* Gazintas : cmd - Command
*          : Addr - Address (or at least bytes after the command)
*          : modes - Comm modes (for CCR)  Only ones that make sense are
*          :         ADDRSIZE and ADMODE
*          : DataLen - length of data to receive afterwards
*          : buf - buffer for read data
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine reads register data from the QSPINOR device
*******************************************************************************/
static void BL_QSPINOR_RdReg (uint8_t cmd, uint32_t Addr, uint32_t modes, uint32_t DataLen,uint8_t* buf)
{
   /* Clear out any old flags and queue up the data size */
   QUADSPI->FCR = QSPI_FCR_ALLBITS ;
   QUADSPI->DLR = DataLen-1 ;

   /* The command control write first. Always 1-bit for instruction and data  */
   /* phases and obviously a read too.                                        */
   QUADSPI->CCR = QSPI_IMODE_1BIT|QSPI_FMODE_READ|QSPI_DMODE_1BIT| modes | cmd ;

   /* Only write address register if an address is to be sent */
   if (modes&QSPI_ADMODE_4BIT) QUADSPI->AR  = Addr ;
   __DSB() ; /* make sure it's all sent before polling */

   /* Start polling for return data */
   while (DataLen)
   {
      while (((QUADSPI->SR)&(QUADSPI_SR_TCF|QUADSPI_SR_FTF))==0) ; /*Wait on FIFO threshold or terminal count   */
      *buf = *(__IO uint8_t*)(&QUADSPI->DR) ; /* read byte (force a byte read)*/
      buf++ ;
      DataLen-- ;
   }
}

/*******************************************************************************
* Routine  : BL_QSPINOR_SetupXIP
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine enables the QSPI XIP or memory mapped mode using Quad IO.
*******************************************************************************/
void BL_QSPINOR_SetupXIP(void)
{
   uint32_t CcrVal = 0 ;

   /* There are a lotta bits in the CCR, so calculate it separately first,    */
   /* then write it once.  Odds are the compiler will just make it a single   */
   /* write anyway.                                                           */
   CcrVal  = READ4_INOUT_FAST_READ_CMD ;
   CcrVal |= QSPI_IMODE_1BIT ;
   CcrVal |= QSPI_ADMODE_4BIT ;
   CcrVal |= QSPI_ADDRSIZE_24 ;
   CcrVal |= (READ4_NUMDUMMYCYCLES)<<18 ;
   CcrVal |= QSPI_DMODE_4BIT ;
   CcrVal |= QSPI_FMODE_MMAP ;

   /* Clear out any old flags then write the command control word  */
   QUADSPI->FCR = QSPI_FCR_ALLBITS ;
   QUADSPI->CCR = CcrVal ;

   __DSB() ; /* make sure it's all written before polling */

   SW_msDelay(2) ; /* Seems prudent to wait just a bit... */
}
