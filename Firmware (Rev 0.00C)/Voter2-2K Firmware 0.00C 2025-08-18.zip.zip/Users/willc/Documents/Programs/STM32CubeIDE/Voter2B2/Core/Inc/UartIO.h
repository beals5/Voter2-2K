#ifndef INC_UARTIO_H_
#define INC_UARTIO_H_

extern void My_UART3_FinishInit(void) ;
extern void My_UART7_FinishInit(void) ;
extern void My_UART8_FinishInit(void) ;

#endif /* INC_UARTIO_H_ */
