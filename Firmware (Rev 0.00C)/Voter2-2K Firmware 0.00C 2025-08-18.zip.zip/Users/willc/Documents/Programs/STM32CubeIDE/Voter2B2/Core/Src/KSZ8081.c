/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the KSX8081 file.  It is in charge of all the low level IO for the */
/* KSZ8081 Ethernet PHY.                                                      */
/******************************************************************************/
/* Public routines are:                                                       */
/*  - UseMyMACAddr - Set MAC address (not 8081 related, but best place for it */
/*  - KSZ8081_Toggle_HWReset - Asserts then de-asserts the HW Reset           */
/*  - KSZ8081_Init - Initializes the PHY                                      */
/*  - KSZ8081_GetLinkState - Gets the current link state                      */
/*  - KSZ8081_ProcessLinkState - set up link based on connection              */
/******************************************************************************/
// To Do:
//  - Need to set up MAC addressing (OTP vs NVM)
/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>
#include "netif/ethernet.h"
#include "cmsis_os.h"

#include "Options.h"
#include "main.h"
#include "Settings.h"
#include "logger2rt.h"
#include "KSZ8081.h"
#include "Gpio.h"

/******************************************************************************/
/* Local defines (including enums)                                            */
/******************************************************************************/
#define PHY_HWRESET_TIME 10 /* Reset time in ms */
#define PHY_MDIO_ADDR    1   /* KSZ8081 MDIO bus address */

/* For KSZ8081 registers and bits of interest, only doing the ones I care     */
/* about which is actually a surprisingly small list!                         */

#define CONTROL_REG  0x00   /* KSZ8081 Control         register MDIO address */
#define STATUS_REG   0x01   /* KSZ8081 Status          register MDIO address */
#define ANAR_REG     0x04   /* KSZ8081 Autonegotiation register MDIO address */
#define STRAP_REG    0x16   /* KSZ8081 Strap           register MDIO address */
#define PHYCON1_REG  0x1E   /* KSZ8081 PHY Control 1   register MDIO address */

/* Control register bits of interest */
#define CTRL_RESET  0x8000 /* Software reset */
#define CTRL_SPEED  0x2000 /* Link Speed     */
#define CTRL_ANEN   0x1000 /* Autonegotiation enable */
#define CTRL_GOAUTO 0x0200 /* Start autonegotiation */
#define CTRL_DUPLEX 0x0100 /* Duplex mode    */

/* Status register bits of interest */
#define STAT_AUTODONE 0x0020 /* Auto Negotiation status */
#define STAT_LINKISUP 0x0004 /* Link status             */

/* Autonegotiation Register bits of interest */
#define ANAR_100BTX_FD              0x0100
#define ANAR_100BTX_HD              0x0080
#define ANAR_10BT_FD                0x0040
#define ANAR_10BT_HD                0x0020
#define ANAR_SELECTOR_DEFAULT       0x0001

/* PHY CONTROL 1 Operational mode bits */
#define PHYCON1_OP_MODE_MASK       0x0007
#define PHYCON1_OP_MODE_AUTONEG    0x0007
#define PHYCON1_OP_MODE_10BT_HD    0x0001
#define PHYCON1_OP_MODE_100BT_HD   0x0002
#define PHYCON1_OP_MODE_10BT_FD    0x0005
#define PHYCON1_OP_MODE_100BT_FD   0x0006
#define PHYCON1_LINKISUP           0x0100


/******************************************************************************/
/* Local structures                                                           */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/

/******************************************************************************/
/* External globals. CubeMX has you define them as externs in each file       */
/* instead of an include file, weird.                                         */
/******************************************************************************/
extern ETH_HandleTypeDef heth;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : UseMyMACAddr
* Gazintas : None
* IOs      : MACAddr - MAC address
* Returns  : Nothing
* Globals  : Settings
*
* With CubeMX you have to put in a MAC address into their configurator.
* In low_level_init() in ethernetif.c they do provide a user area to put in an
* override. That user area has a call to this routine.
*******************************************************************************/
void UseMyMACAddr(uint8_t* MACAddr)
{
   memcpy(MACAddr,Settings.MyMACAddr,6) ;
}

/*******************************************************************************
* Routine  : KSZ8081_Toggle_HWReset
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This cycles the HW reset to the KSZ8081 PHY.  It needs to be separate from
* (and before) the LWIP low_level_init() call as something in the MAC times
* out if the PHY is still being held in reset.
* Note that the reset line initializes low at boot, so the first call after boot
* just un-asserts reset.
*******************************************************************************/
void KSZ8081_Toggle_HWReset(void)
{
   /* Hardware reset the PHY */
   PHY_Reset(true)  ;
   HAL_Delay(PHY_HWRESET_TIME)   ;
   PHY_Reset(false) ;
   HAL_Delay(PHY_HWRESET_TIME)   ;
}

/*******************************************************************************
* Routine  : KSZ8081_Init
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  :
*
* This initializes the PHY.  After lots of struggling to get Ethernet working,
* this code has devolved to essentially nothing.  I'm leaving in all the
* code I thought I'd need #if'd out just in case.  I assert the hardware reset
* earlier and the PHY turns out to not need anything beyond the reset state!
*******************************************************************************/
void KSZ8081_Init(void)
{
#if 0
   uint32_t retval = 0 ; /* Register read success/fail status */
   uint32_t regval = 0 ; /* Status register value             */
#endif

#if 0
   /* Assert the SW reset bit.  It self-clears.  This fires off auto-         */
   /* negotiation too.                                                        */
   Logger2_Msg(Logger.KSZ8081,LOG_REGIO,LOG_TIME,"KSZ8081: SW Reset start.\r\n") ;
   HAL_ETH_WritePHYRegister(&heth,PHY_MDIO_ADDR,CONTROL_REG,CTRL_RESET) ;

   do /* Wait for the reset to clear... */
   {
      retval = HAL_ETH_ReadPHYRegister(&heth,PHY_MDIO_ADDR,CONTROL_REG,&regval) ;
      osDelay(10);
   }
   while ((HAL_OK != retval) || (regval & CTRL_RESET)) ;
   Logger2_Msg(Logger.KSZ8081,LOG_REGIO,LOG_TIME,"KSZ8081: SW Reset complete.\r\n") ;
#endif

#if 0
   do /* Wait for Autonegotiation to complete... */
   {
      retval = HAL_ETH_ReadPHYRegister(&heth,PHY_MDIO_ADDR,STATUS_REG,&regval) ;
      osDelay(10);
   }
   while ((HAL_OK != retval) || (!(regval & STAT_AUTODONE))) ;
   Logger2_Msg(Logger.KSZ8081,LOG_REGIO,LOG_TIME,"KSZ8081: Negotiation complete.\r\n") ;
#endif

#if 0
   osDelay(1000) ;
   //Restore default auto-negotiation advertisement parameters
   HAL_ETH_WritePHYRegister(&heth,PHY_MDIO_ADDR,ANAR_REG, /*
		                    ANAR_100BTX_FD | ANAR_100BTX_HD |
		                    ANAR_10BT_FD   | */ ANAR_10BT_HD   |
							ANAR_SELECTOR_DEFAULT);

   Logger2_Msg(Logger.KSZ8081,LOG_REGIO,LOG_TIME,"KSZ8081: Re-negotiating...\r\n") ;
   HAL_ETH_WritePHYRegister(&heth,PHY_MDIO_ADDR,CONTROL_REG,CTRL_GOAUTO) ;

   do /* Wait for Autonegotiation to complete... */
   {
      retval = HAL_ETH_ReadPHYRegister(&heth,PHY_MDIO_ADDR,PHYCON1_REG,&regval) ;
      osDelay(10);
   }
   //while ((HAL_OK != retval) || ((regval & PHYCON1_OP_MODE_MASK)==PHYCON1_OP_MODE_AUTONEG)) ;
   while ((HAL_OK != retval) || ((regval & PHYCON1_LINKISUP)==0)) ;
   Logger2_Msg(Logger.KSZ8081,LOG_REGIO,LOG_TIME,"KSZ8081: Re-negotiation link up (%4.4x).\r\n",regval) ;

   do /* Wait for Autonegotiation to complete... */
   {
      retval = HAL_ETH_ReadPHYRegister(&heth,PHY_MDIO_ADDR,PHYCON1_REG,&regval) ;
      osDelay(10);
   }
   while ((HAL_OK != retval) || ((regval & PHYCON1_OP_MODE_MASK)==PHYCON1_OP_MODE_AUTONEG)) ;
   Logger2_Msg(Logger.KSZ8081,LOG_REGIO,LOG_TIME,"KSZ8081: Re-negotiation Speed set. (%4.4x).\r\n",regval) ;
#endif

#if 0
   /* enable auto-negotiation */
   HAL_ETH_WritePHYRegister(&heth,PHY_MDIO_ADDR,CONTROL_REG,CTRL_ANEN) ;
   Logger2_Msg(Logger.KSZ8081,LOG_REGIO,LOG_TIME,"KSZ8081: Future Autonegotiations enabled.\r\n") ;
#endif
}

/*******************************************************************************
* Routine  : KSZ8081_GetLinkState
* Gazintas : None
* IOs      : PHYLinkState - Current link state
*          : duplex - Current duplex state (if lunk)
*          : speed - Current speed (if lunk)
* Returns  : Nothing
* Globals  : None
*
* This returns the link state of the PHY.  Duplex and speed clearly only make
* sense if the link is up.  The KSZ8081 is set up to auto-negotiate, so this
* just polls the result.
*******************************************************************************/
void KSZ8081_GetLinkState(int32_t* PHYLinkState, uint32_t* duplex, uint32_t* speed)
{
   uint32_t retval      = 0 ; /* Register read success/fail status */
   uint32_t PHY1_regval = 0 ; /* PHY Control1 register value       */

   /* Default returns if things don't go well */
   *PHYLinkState = KSZ8081_LINK_DOWN   ;
   *duplex       = ETH_HALFDUPLEX_MODE ;
   *speed        = ETH_SPEED_10M       ;

   /* Read the PHY Control 1 register */
   retval = HAL_ETH_ReadPHYRegister(&heth,PHY_MDIO_ADDR,PHYCON1_REG,&PHY1_regval) ;

#if 0 /* For a quick full register dump */
   volatile uint32_t allregs[32] = {0} ;
   int i = 0 ;
   if (HAL_OK == retval) /* Extra read for debugging */
   {
      for (i=0;i<32;i++) HAL_ETH_ReadPHYRegister(&heth,PHY_MDIO_ADDR,i,allregs+i) ;
   }
#endif

   /* If both reads OK, process the status bits to return the state */
   if (HAL_OK == retval)
   {
      //Logger2_Msg(Logger.KSZ8081,LOGGER2_KSZ8081,LOG_TIME,"KSZ8081: GetLinkState (%4.4x).\r\n",PHY1_regval) ;
      *PHYLinkState = (PHY1_regval&PHYCON1_LINKISUP)? KSZ8081_LINK_UP:KSZ8081_LINK_DOWN ;
      switch (PHY1_regval&PHYCON1_OP_MODE_MASK)
      {
         case PHYCON1_OP_MODE_10BT_HD : *duplex = ETH_HALFDUPLEX_MODE ; *speed = ETH_SPEED_10M  ; break ;
         case PHYCON1_OP_MODE_10BT_FD : *duplex = ETH_FULLDUPLEX_MODE ; *speed = ETH_SPEED_10M  ; break ;
         case PHYCON1_OP_MODE_100BT_HD: *duplex = ETH_HALFDUPLEX_MODE ; *speed = ETH_SPEED_100M ; break ;
         case PHYCON1_OP_MODE_100BT_FD: *duplex = ETH_FULLDUPLEX_MODE ; *speed = ETH_SPEED_100M ; break ;
         default                      : *PHYLinkState = KSZ8081_LINK_DOWN                       ; break ;
      }
   } /* if problems reading register, return with default of link down. */
}

/*******************************************************************************
* Routine  : KSZ8081_ProcessLinkState
* Gazintas : netif - network interface handle
*          : first - First or looped call flag
* IOs      : None
* Returns  : Nothing
* Globals  :
*
* This routine polls the Ethernet link state and tells LWIP if it changed. This
* function is needed in the init code and polling code, and is 95% the same,
* so combining into one routine.  For the first call we set the netif calls
* based only one the KSZ8081 link state.  For looped calls we only set netif
* calls if there is a change in state.
*******************************************************************************/
void KSZ8081_ProcessLinkState(struct netif *netif, int first)
{
   ETH_MACConfigTypeDef MACConf = {0};
   int32_t  PHYLinkState = 0  ; /* Network Up/down state    */
   uint32_t speed        = 0U ; /* Ethernet Speed           */
   uint32_t duplex       = 0U ; /* Ethernet Duplex mode     */
   int      netif_isup   = 0  ; /* Current netif link state */

   KSZ8081_GetLinkState(&PHYLinkState,&duplex,&speed);

   netif_isup = netif_is_link_up(netif) ;

   if((first || netif_isup) && (PHYLinkState == KSZ8081_LINK_DOWN))
   {
      HAL_ETH_Stop_IT(&heth);
      netif_set_down(netif);
      netif_set_link_down(netif);
   }
   else if((first || !netif_isup) && (PHYLinkState == KSZ8081_LINK_UP))
   {
      /* Get MAC Config MAC */
      HAL_ETH_GetMACConfig(&heth, &MACConf);
      MACConf.DuplexMode = duplex;
      MACConf.Speed = speed;
      HAL_ETH_SetMACConfig(&heth, &MACConf);

      HAL_ETH_Start_IT(&heth);
      netif_set_up(netif);
      netif_set_link_up(netif);
      Logger2_Msg(Logger.KSZ8081,LOG_MAJOR,LOG_TIME,"KSZ8081: Link up (%s/%s).\r\n",(speed==ETH_SPEED_10M)?"10M":"100M",(duplex==ETH_HALFDUPLEX_MODE)?"HDX":"FDX") ;
    }
}

