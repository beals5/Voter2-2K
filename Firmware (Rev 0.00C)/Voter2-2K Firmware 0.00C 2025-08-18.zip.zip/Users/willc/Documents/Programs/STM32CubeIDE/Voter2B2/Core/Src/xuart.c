/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the xuart file.  Right now this is simply a piece of test code for */
/* verifying the UART works by sending a test pattern (0x00 through 0xff) and */
/* assuming a loop-back connector is plugged into the DE9 connector on the    */
/* DUT board.  Dave will replace this with the target functions for the UARt. */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Cmd_xuart - Test Tone CLI command                                       */
/*                                                                            */
/******************************************************************************/
// TO DO:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "cmsis_os.h"

#include "string.h"
#include "Options.h"
#include "main.h"
#include "ConsoleTask.h"
#include "Utils.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/
extern UART_HandleTypeDef huart4 ;

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
char* cmd_xuart_cmd  = "xuart" ;
char* cmd_xuart_help = "xuart - (no params) Run the loopback test.\n" ;

void XUARTTxComplete(void) ;
void XUARTRxComplete(void) ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static volatile int TxDMA_Done = false ;
static volatile int RxDMA_Done = false ;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : Cmd_xuart
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command just runs the UART test,
*******************************************************************************/
int Cmd_xuart(int argc, char* argv[])
{
   static uint8_t TxBuf[256] IN_DMADD2 = {0} ;
   static uint8_t RxBuf[256] IN_DMADD2 = {0} ;
   int i      =  0  ;
   int errors =  0  ;

   Console_printf("Running test assuming a loopback connector is installed...\n") ;

   /* Fill the TxBuf with incrementing values and clear RxBuf */
   for (i=0;i<256;i++)
   {
      TxBuf[i]=i ;
      RxBuf[i]=0 ;
   }

   /* UART params all set up, set up the Rx DMA to get 256 bytes, then set up */
   /* a Tx DMA to send 256 bytes!                                             */
   TxDMA_Done = false ;
   RxDMA_Done = false ;
   HAL_UART_Receive_DMA (&huart4,RxBuf,256) ;
   HAL_UART_Transmit_DMA (&huart4,TxBuf,256) ;

   /* Wait for the DMAs to finish. At 9600 baud, 256 bytes should take about  */
   /* 270ms.  Give it 300ms.                                                  */
   osDelay(300) ;

   if (!TxDMA_Done) Console_printf("Data didn't send. (failure)\n") ;
   if (!RxDMA_Done) Console_printf("Data not received. (failure)\n") ;
   Console_printf("UART State: 0x%8.8x\n",HAL_UART_GetState(&huart4)) ;

   /* If data sent and received, check it */
   if (TxDMA_Done && RxDMA_Done)
   {
      Console_printf("Data sent and received...\n") ;
      errors = 0 ;
      for (i=0;i<256;i++)
      {
         if (RxBuf[i]!=i) errors++ ;
      }

      if (errors>0) /* if any errors */
      {
         Console_printf("Data invalid (%d/256 errors)\n",errors) ;
      }
      else
      {
         Console_printf("Data valid! (pass)\n") ;
      }
   }

   return (0) ;
}

void XUARTTxComplete(void)
{
   TxDMA_Done = true ;

}
void XUARTRxComplete(void)
{
   RxDMA_Done = true ;
}
