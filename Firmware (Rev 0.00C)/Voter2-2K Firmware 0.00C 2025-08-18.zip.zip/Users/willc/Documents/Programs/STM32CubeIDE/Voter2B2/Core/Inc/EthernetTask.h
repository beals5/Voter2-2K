#ifndef INC_ETHERNETTASK_H_
#define INC_ETHERNETTASK_H_

typedef enum
{
   MYIPMODE_STATIC = 0,
   MYIPMODE_DHCP
} MYIPMODES ;

extern int EthernetUp ;

extern void  EthernetTask(void const * argument);
extern char* ActualIPstr(void) ;

#endif /* INC_ETHERNETTASK_H_ */
