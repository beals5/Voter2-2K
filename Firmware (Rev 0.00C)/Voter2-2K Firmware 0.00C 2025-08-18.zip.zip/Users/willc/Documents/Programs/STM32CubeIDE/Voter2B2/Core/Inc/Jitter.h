#ifndef INC_JITTER_H_
#define INC_JITTER_H_

extern char* cmd_jitter_cmd ;
extern char* cmd_jitter_help ;

extern int  Cmd_jitter(int, char**) ;
extern void Jitter_Log(void) ;

#endif /* INC_JITTER_H_ */
