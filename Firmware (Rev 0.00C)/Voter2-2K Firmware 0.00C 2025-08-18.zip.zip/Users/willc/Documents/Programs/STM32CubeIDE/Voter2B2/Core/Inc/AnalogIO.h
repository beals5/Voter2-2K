#ifndef INC_ANALOGIO_H_
#define INC_ANALOGIO_H_

#define APKT_SAMPLERATE 8000 /* Audio sample rate */
#define APKT_SAMPLES SAMPLESIZE /* Samples in a standard Audio Packet */
#define APKT_RXDMABUF_SIZE (APKT_SAMPLES*2) /* Rx Audio DMA buffer (Ping+Pong buffers)  */
#define APKT_TXDMABUF_SIZE (APKT_SAMPLES*4) /* Tx Audio DMA buffer (Ping+Pong & stereo) */
#define RSSI_DMABUF_SIZE 5

#define A2DDAC_CLK_LOCAL 0
#define A2DDAC_CLK_GPS   1

extern uint16_t ADC_buf_buf[APKT_RXDMABUF_SIZE] ;

void     MY_ADC1_FinishInit(void) ;
void     MY_DAC1_FinishInit(void) ;
void     MY_DAC2_FinishInit(void) ;
void     MY_Analog_DMA_FinishInit(void) ;
uint8_t  Get_Analog_RSSI(void) ;

#endif /* INC_ANALOGIO_H_ */
