/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/* ************************************************************************** */
/* This is the LocalMode file, in charge of implementing Local Mode.          */
/* LocalModeSM() is the state machine that runs everything and gets called    */
/* every 20ms by RxDSP regardless of being in local mode or not or if         */
/* there is active Rx audio or not.  It handles repeating received audio      */
/* (easy part) as well as IDing, proceed tones, hangtails, etc.               */
/* To support Dave's 7330 implementation, this code now supports a variable   */
/* sized packet--just for test purposes with DIAL support disabled.           */
/******************************************************************************/
/* Public routines are:                                                       */
/*  - LocalModeSM - The state machine.                                        */
/*                                                                            */
/******************************************************************************/
// To Do:
//  - In SendCWstr, tone figgering could use optimizing
//  - Implement local modes (hardcoded only for repeater mode now)

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>
#include "cmsis_os.h"

#include "Options.h"
#include "main.h"
#include "logger2rt.h"
#include "DialTask.h"
#include "Settings.h"
#include "LocalVoter/LocalSettings.h"
#include "AnalogIO.h"
#include "Tx_DSP.h"

#ifdef LOCALVOTER
/******************************************************************************/
/* Local defines (including enums)                                            */
/******************************************************************************/
enum { /* States for the local mode state machine */
   LSM_IDLE = 0,
   LSM_RXACTIVE,
   LSM_RXMIX,
   LSM_RXTIMEOUT,
   LSM_HANGTIME,
   LSM_PRECW,
   LSM_CWID,
   LSM_POSTCW,
};

/* Receiver Timeout */
#define TIMEOUT_SECS (180)
#define TIMEOUT_TICKS (TIMEOUT_SECS*50)

/* ID Timer */
#define IDTIMER_SECS (60)
#define IDTIMER_TICKS (IDTIMER_SECS*50)

/* For the 1KHz sine wave table, 11 volume levels 0-10 (yea, tempting to have */
/* a volume level of 11, but...) and then 8 samples at an 8KHz sampling rate  */
/* gets you 1KHz.                                                             */
#define NVOLS 11
#define NSAMPS 8

/* For the Morse timing table, it is a max of 6 dits or dahs per character    */
/* and a limitied character range.                                            */
#define MORSE_MAXDDS 6
#define MORSE_CHRBASE '!'
#define MORSE_CHRMAX 'Z'
#define MORSE_VOLUME 6 /* Volume is fixed for now, may stay that way */

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static int16_t LocalAudio[APKT_SAMPLES] = {0}   ; /* Locally generated audio  */
static uint8_t ProceedFlag              = false ; /* Flag for proceed ID      */
static uint8_t CwidFlag                 = false ; /* Flag for repeater ID     */
static uint32_t ToneTimes[MORSE_MAXDDS][2] = {0} ; /* CW Tone on/off times    */

/* We should need only A-Z, 0-9, and /, but filling out as best I can.  The   */
/* only missing ones from Wikipedia are $ (7 dits/dah's) and underscore (past */
/* Z and I decided to stop there).                                            */
/* I'm also skipping space since it is a special case--one I actually can     */
/* ignore for IDing use, but would need handing for general use.              */
/* Yea, I could go binary over ASCII encoding for this table, but keeping it  */
/* human readable is nice, so going to leave it this way.                     */
static const uint8_t MorseTable[MORSE_CHRMAX-MORSE_CHRBASE+1][MORSE_MAXDDS] = {
   "-.-.--", // ASCII "!"
   ".-..-.", // ASCII """
   "      ", // ASCII "#"
   "      ", // ASCII "$"
   "      ", // ASCII "%"
   "      ", // ASCII "&"
   ".----.", // ASCII "'"
   "-.--. ", // ASCII "("
   "-.--.-", // ASCII ")"
   "      ", // ASCII "*"
   ".-.-. ", // ASCII "+"
   "--..--", // ASCII ","
   "-....-", // ASCII "-"
   ".-.-.-", // ASCII "."
   "-..-. ", // ASCII "/"
   "----- ", // ASCII "0"
   ".---- ", // ASCII "1"
   "..--- ", // ASCII "2"
   "...-- ", // ASCII "3"
   "....- ", // ASCII "4"
   "..... ", // ASCII "5"
   "-.... ", // ASCII "6"
   "--... ", // ASCII "7"
   "---.. ", // ASCII "8"
   "----. ", // ASCII "9"
   "---...", // ASCII ":"
   "-.-.-.", // ASCII ";"
   "      ", // ASCII "<"
   "-...- ", // ASCII "="
   "      ", // ASCII ">"
   "..--..", // ASCII "?"
   ".--.-.", // ASCII "@"
   ".-    ", // ASCII "A"
   "-...  ", // ASCII "B"
   "-.-.  ", // ASCII "C"
   "-...  ", // ASCII "D"
   ".     ", // ASCII "E"
   "..-.  ", // ASCII "F"
   "--.   ", // ASCII "G"
   "....  ", // ASCII "H"
   "..    ", // ASCII "I"
   ".---  ", // ASCII "J"
   "-.-   ", // ASCII "K"
   ".-..  ", // ASCII "L"
   "--    ", // ASCII "M"
   "-.    ", // ASCII "N"
   "---   ", // ASCII "O"
   ".--.  ", // ASCII "P"
   "--.-  ", // ASCII "Q"
   ".-.   ", // ASCII "R"
   "...   ", // ASCII "S"
   "-     ", // ASCII "T"
   "..-   ", // ASCII "U"
   "...-  ", // ASCII "V"
   ".--   ", // ASCII "W"
   "-..-  ", // ASCII "X"
   "-.--  ", // ASCII "Y"
   "--..  ", // ASCII "Z"
} ;

/* Our table to get a 1KHz sine wave.  It takes 8 samples at an 8KHz sampling */
/* rate to get 1KHz and I have volumes 10 (full scale) down to 0 (silent).    */
#if 0
/* Before some code refactoring, I was doing this in the compressed domain.   */
/* Creating the table below of compressed uLaw values for all volumes was a   */
/* real pain.  There is a chance I may go back to compressed samples, so      */
/* Leaving this table here #if'd out in cases I need it again.                */
static uint8_t Sin1KHz_uL[NVOLS][NSAMPS] =
{
   {0xff,0x89,0x80,0x89,0xff,0x09,0x7f,0x09}, // Vol 10
   {0xff,0x99,0x8f,0x99,0xff,0x19,0x0f,0x19}, // Vol 9
   {0xff,0xa8,0x9f,0xa8,0xff,0x28,0x1f,0x28}, // Vol 8
   {0xff,0xb8,0xaf,0xb8,0xff,0x38,0x2f,0x38}, // Vol 7
   {0xff,0xc7,0xbe,0xc7,0xff,0x47,0x3e,0x47}, // Vol 6
   {0xff,0xd5,0xcd,0xd5,0xff,0x55,0x4d,0x55}, // Vol 5
   {0xff,0xe1,0xdb,0xe1,0xff,0x61,0x5b,0x61}, // Vol 4
   {0xff,0xec,0xe7,0xec,0xff,0x6c,0x67,0x6c}, // Vol 3
   {0xff,0xf4,0xef,0xf4,0xff,0x74,0x6f,0x74}, // Vol 2
   {0xff,0xf9,0xf7,0xf9,0xff,0x79,0x77,0x79}, // Vol 1
   {0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff}, // Vol 0
} ;
#endif

static int16_t Sin1KHz_raw[NVOLS][NSAMPS] =
{
   {0x0000,0x5A82,0x8000,0x5A82,0x0000,0xA57E,0x8000,0xA57E}, // Vol 10
   {0x0000,0x2D41,0x4000,0x2D41,0x0000,0xD2BF,0xC000,0xD2BF}, // Vol 9
   {0x0000,0x16A1,0x2000,0x16A1,0x0000,0xE95F,0xE000,0xE95F}, // Vol 8
   {0x0000,0x0B51,0x1000,0x0B51,0x0000,0xF4AF,0xF000,0xF4AF}, // Vol 7
   {0x0000,0x05A9,0x0800,0x05A9,0x0000,0xFA57,0xF800,0xFA57}, // Vol 6
   {0x0000,0x02D5,0x0400,0x02D5,0x0000,0xFD2B,0xFC00,0xFD2B}, // Vol 5
   {0x0000,0x016B,0x0200,0x016B,0x0000,0xFE95,0xFE00,0xFE95}, // Vol 4
   {0x0000,0x00B6,0x0100,0x00B6,0x0000,0xFF4A,0xFF00,0xFF4A}, // Vol 3
   {0x0000,0x005B,0x0080,0x005B,0x0000,0xFFA5,0xFF80,0xFFA5}, // Vol 2
   {0x0000,0x002E,0x0040,0x002E,0x0000,0xFFD2,0xFFC0,0xFFD2}, // Vol 1
   {0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000}  // Vol 0
} ;

/******************************************************************************/
/* External globals. CubeMX has you define them as externs in each file       */
/* instead of an include file, weird.                                         */
/******************************************************************************/

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/
static int SM_Idle      (int,int*) ;
static int SM_RxActive  (int,int*) ;
static int SM_InTimeout (int,int*) ;
static int SM_Hangtime  (int,int*,uint16_t,int,int) ;
static int SM_Cwids     (int) ;
static int SendCWstr    (char*,int*) ;
static int FiggerCWTimes(char,int,int*) ;

/*******************************************************************************
* Routine  : LocalModeSM
* Gazintas : RxAudio - Incoming audio sample buffer (160 samples)
*          : DIAL_State - DIAL connection state
*          : Rx_Active - Repeater COR state
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This is the Local Mode main state machine.  It gets called every 20ms by
* Rx_EnqPacket() in RxDSP.c with 20ms of audio samples, the DIAL state and COR
* state.
* If DIAL_State is anything but unauthorized, the state machine resets as if
* authorized, we're not in local mode.  If COR is active we copy the received
* audio to the transmit side (if in repeater mode) otherwise it is either
* silence of any of the IDing options that may be requested.  PTT is taken care
* of later in the chain based on if audio samples are coming down or not.
*******************************************************************************/
void LocalModeSM(int16_t* RxAudio,int DIAL_State, int Rx_Active)
{
   static int LocalState = LSM_IDLE ; /* The main state machine state  */
   static int StateTimer = 0        ; /* State timer                   */
   static int IDTimer    = 0        ; /* Repeater ID timer             */
   int        NextState  = LSM_IDLE ; /* The next state                */
   int        ToXmit     = false    ; /* Transmit during Timeout flag  */
   int        FirstID    = false    ; /* ID on first xmit flag         */

   /* This input overrides everything, so easy first check */
   if (DIAL_AUTHORIZED)
   {
      NextState  = LSM_IDLE ; /* Force Local state to idle if DIALed */
      StateTimer = 0        ; /* Start any new state clean           */
   }
   else
   {
       /* Based on the current state and inputs, figger out the next state */
      switch (LocalState)
      {
         case LSM_IDLE      : NextState = SM_Idle     (Rx_Active,&StateTimer)                                                    ; break ;
         case LSM_RXACTIVE  : NextState = SM_RxActive (Rx_Active,&StateTimer)                                                    ; break ;
         case LSM_RXMIX     : /* May not use, TBD still */                                                                         break ;
         case LSM_RXTIMEOUT : NextState = SM_InTimeout(Rx_Active,&ToXmit)                                                        ; break ;
         case LSM_HANGTIME  : NextState = SM_Hangtime (Rx_Active,&StateTimer,LocalSettings.OffineHangTime,LSM_HANGTIME,LSM_IDLE) ; break ; /* Using this routine, but not this state */
         case LSM_PRECW     : NextState = SM_Hangtime (Rx_Active,&StateTimer,LocalSettings.OffinePreCw   ,LSM_PRECW   ,LSM_CWID) ; break ;
         case LSM_CWID      : NextState = SM_Cwids    (Rx_Active)                                                                ; break ;
         case LSM_POSTCW    : NextState = SM_Hangtime (Rx_Active,&StateTimer,LocalSettings.OffinePostCw  ,LSM_POSTCW  ,LSM_IDLE) ; break ;
         default            : NextState = LSM_IDLE ;  /* Shouldn't happen, reset if so */                                          break ;
      }
   }

   /* If the state changed (and appropriate logging is enabled), say so */
   if (NextState != LocalState)
   {
      Logger2_Msg(Logger.Local,LOG_REGIO,LOG_TIME,"LocalMode: New State: %d\r\n",NextState) ;
   }

   /* For the ID timer the counter at 0 means the repeater hasn't transmitted,*/
   /* since the last ID, so don't count.  On any transmit, we increment the   */
   /* counter and keep on incrementing regardless of transmitting or not until*/
   /* we get to the ID time. Then, set the CwidFlag flag.  If the repeater is */
   /* currently receiving or in any other transient states, let those finish  */
   /* and fire up once we cycle back to idle. If Receiving during the timeout,*/
   /* The CWIDer will see the flag and send the ID.                           */

   /* Also have the special case of if it is the first activity after the     */
   /* timer expired, then initiate and ID right away.                         */
   if ((LSM_RXACTIVE==LocalState) && (0==IDTimer)) FirstID = true ;

   /* Now for the regular incrementing if timing is already in motion.        */
   if ((LSM_RXACTIVE==LocalState) || (IDTimer)) IDTimer++ ;

   if ((IDTimer>LocalSettings.OffineIdTime*50) || FirstID)
   {
	   CwidFlag = true ;
	   if (LSM_IDLE == LocalState) NextState = LSM_PRECW ;
	   /* If not a first ID, reset the timer, otherwise let it run */
	   if (!FirstID) IDTimer = 0 ;
   }

   /* Based on the new state, manage outputs.  Locally generated audio        */
   /* doesn't have timestamps, so just passing 0's.  This may get more        */
   /* complicated later.                                                      */
   switch (NextState)
   {
      case LSM_IDLE      : /* Don't send nuthin' */                               break ;
      case LSM_RXACTIVE  : Tx_EnqPacket(RxAudio,LOCAL_TIMED,0,0)                ; break ;
      case LSM_RXMIX     : /* Not currently used */                               break ;
      case LSM_RXTIMEOUT : if (ToXmit) Tx_EnqPacket(LocalAudio,LOCAL_TIMED,0,0) ; break ;
      case LSM_HANGTIME  : Tx_EnqPacket(LocalAudio,LOCAL_TIMED,0,0)             ; break ;
      case LSM_PRECW     : Tx_EnqPacket(LocalAudio,LOCAL_TIMED,0,0)             ; break ;
      case LSM_CWID      : Tx_EnqPacket(LocalAudio,LOCAL_TIMED,0,0)             ; break ;
      case LSM_POSTCW    : Tx_EnqPacket(LocalAudio,LOCAL_TIMED,0,0)             ; break ;
      default            :                                                        break ;
   }
   /* All done, make the next state our initial state for the next call */
   LocalState = NextState ;
}

/*******************************************************************************
* Routine  : SM_Idle
* Gazintas : Rx_Active - Repeater COR state
* IOs      : Timer - State timer
* Returns  : Next State
* Globals  : TBD
*
* This takes care of the idle state.  Only ways out of here are if we get some
* RX audio.  A timeout for a station identifier is handled elsewhere.
*******************************************************************************/
static int SM_Idle (int Rx_Active,int* Timer)
{
   int Return_State = LSM_IDLE ; /* Default return state */

   /* If we got some audio, go to the Rx Active state */
   if (Rx_Active) Return_State = LSM_RXACTIVE  ;

   /* Keep State Timer at 0 until we exit */
   *Timer = 0 ;

   return(Return_State) ;
}

/*******************************************************************************
* Routine  : SM_RxActive
* Gazintas : Rx_Active - Repeater COR state
* IOs      : Timer - State timer
* Returns  : Next State
* Globals  : TBD
*
* This takes care of the Rx Active state (getting audio from the repeater
* receiver).  This doesn't repeat the audio, later logic in LocalModeSM() does
* that by seeing we're in this state.  Here we look for the exit conditions
* which are:
*  - No more audio : Flag proceed tone only, go to Pre-CW next
*  - Timeout Genie : Flag Timeout and proceed tones, go to Pre-CW next.
*  - ID Time: As with SM_Idle, handled elsewhere.
*******************************************************************************/
static int SM_RxActive(int Rx_Active,int* Timer)
{
   int Return_State = LSM_RXACTIVE ; /* Default return state */

   /* Increment the state timer */
   (*Timer)++ ;

   /* If Rx ends normally, just go to the Pre-CW hang time flagging we need   */
   /* to send the Proceed tone.                                               */
   if (!Rx_Active)
   {
      *Timer = 0 ;
      ProceedFlag = true ;
      Return_State = LSM_PRECW  ;
   }

   /* If timeout genie, go to the LSM_RXTIMEOUT state to handle the timeout.  */
   /* Still set the ProceedFlag to send it after the timeout ends.            */
   if (*Timer > TIMEOUT_TICKS)
   {
      *Timer = 0 ;
      ProceedFlag = true ;
      Return_State = LSM_RXTIMEOUT  ;
   }

   return(Return_State) ;
}

/*******************************************************************************
* Routine  : SM_InTimeout
* Gazintas : Rx_Active - Repeater COR state
* IOs      : Xmit - flag to send audio (for tones only)
* Returns  : Next State
* Globals  : TBD
*
* This takes care of handling a timeout.  Upon entering this state, we send out
* a CW "TO", then stop transmitting until the Rx signal ends.  When the Rx does
* end, then fire up the transmitter again sending out any pending CWIDs.
*******************************************************************************/
static int SM_InTimeout(int Rx_Active,int* Xmit)
{
   static int First        = true     ; /* First call for new CWID */
   int        Return_State = LSM_CWID ; /* Default return state    */
   static int done         = false    ; /* Done with a CWID        */

   if (First)
   {
      Logger2_Msg(Logger.Local,LOG_SUPPORT,LOG_TIME,"LocalMode: Timeout!\r\n") ;
   }

   if (!done)
   {
      done = SendCWstr("TO",&First) ;
      *Xmit = true ;
      Return_State = LSM_RXTIMEOUT ;
   }
   else
   {
      /* After we've sent "TO", just hang out here sending nothing until COR     */
      /* drops.                                                                  */
      *Xmit = false ; /* stop transmitting */
      if (Rx_Active)
      {
         Return_State = LSM_RXTIMEOUT ;
      }
      else
      {
    	  First = true ;
          ProceedFlag = true ;
          Return_State = LSM_PRECW  ;
      }
   }

   return(Return_State) ;
}

/*******************************************************************************
* Routine  : SM_Hangtime
* Gazintas : Rx_Active - Repeater COR state
*          : Hangtime - Hang time in ms
*          : SameState - State to stay in if no change
*          : NextState - State on conclusion
* IOs      : Timer - State timer
* Returns  : Next State
* Globals  : TBD
*
* This takes care of the hang time between things to send.  After the
* prescribed hand time, just go to the CWID state and it will look at any
* pending things to send.
*******************************************************************************/
static int SM_Hangtime(int Rx_Active,int* Timer,uint16_t HangTime,int SameState,int NextState)
{
   int Return_State = SameState ; /* Default return state */

   /* Increment the state timer and make sure we send silence */
   (*Timer)++ ;
   memset(LocalAudio,0,APKT_SAMPLES*2) ; /* The sound of silence */

   /* If someone starts transmitting, go back to Rx Active state */
   if (Rx_Active)
   {
      *Timer = 0 ;
      Return_State = LSM_RXACTIVE  ;
   }

   /* Wait for the hang time.  User parameter is ms, a tick is 20ms */
   if (*Timer > (HangTime/20))
   {
      *Timer = 0 ;
      Return_State = NextState  ;
   }

   return(Return_State) ;
}

/*******************************************************************************
* Routine  : SM_Cwids
* Gazintas : Rx_Active - Repeater COR state
* IOs      : None
* Returns  : Next State
* Globals  : CwidFlag, ProceedFlag
*
* This takes care of sending out CW messages, these include (in order they'd be
* sent out), Repeater ID and proceed.  Timeout is handled separately.
*******************************************************************************/
static int SM_Cwids(int Rx_Active)
{
   static int First        = true     ; /* First call for new CWID */
   int        Return_State = LSM_CWID ; /* Default return state    */
   int        done         = false    ; /* Done with a CWID        */
   int        donedone     = false    ; /* Done with all CWIDs     */

   /* If someone transmits, that overrides any IDing going on */
   if (Rx_Active)
   {
      Return_State = LSM_RXACTIVE  ;
   }

   /* Checks are in order of priority if there are multiple ones pending */
   if (CwidFlag) /* First priority */
   {
      if (First) Logger2_Msg(Logger.Local,LOG_SUPPORT,LOG_TIME,"LocalMode: Sending Station ID.\r\n") ;
      done = SendCWstr(LocalSettings.OfflineID,&First) ;
      if (done)
      {
         CwidFlag = false ;
         First    = true  ;
      }
   }
   else if (ProceedFlag) /* Last priority */
   {
      if (First) Logger2_Msg(Logger.Local,LOG_SUPPORT,LOG_TIME,"LocalMode: Sending Proceed ID.\r\n") ;
      done = SendCWstr(LocalSettings.OfflineProc,&First) ;
      if (done)
      {
         ProceedFlag = false ;
         First       = true  ;
      }
   }
   else
   {
      /* If all CWIDs done, we are done done! */
      done = true ;
      donedone = true ;
   }

   /* If we are done with the current ID, return to either the pre-CW state if*/
   /* there are other IDs still pending or post-CW state if we are completely */
   /* done.                                                                   */
   if (done)
   {
      Return_State = donedone?LSM_POSTCW:LSM_PRECW ;
   }

   return(Return_State) ;
}

/*******************************************************************************
* Routine  : SendCWstr
* Gazintas : str - string to send
* IOs      : First - First (start) flag
* Returns  : Next State
* Globals  : TBD
*
* This takes care of sending out a CW message. The message is provided in str,
* then this code takes care of getting that message sent out in 20ms chunks
* over repeated calls.  To do that takes a lot of state variables, so the logic
* here gets pretty interesting!
*******************************************************************************/
static int SendCWstr(char* str,int* First)
{
   static int stridx  =   0   ; /* Index to character in string being sent    */
   static int pktidx  =   0   ; /* Index of sample # in the CWID sequence     */
   static int dittime = 480   ; /* Dit time (in samples)                      */
   static int endofCW =   0   ; /* End of CW message (in samples)             */
   int    done        = false ; /* Completed sending string flag              */
   int    i           =   0   ; /* General index                              */
   int    j           =   0   ; /* General index                              */

   /* If starting a new CWID string, time for the one-off set up stuff */
   if (*First)
   {
      /* Reset the pointer to the first character in the string */
      stridx = 0 ;

      /* The user changing the CW speed is completely asynchronous to this    */
      /* state machine, so just re-calcualte the samples/dit on each new CWID */
      /* string.  The basic unit of time for Morse code is a dit.  The dit    */
      /* time in secs is 60sec/(50dit times/word * WPM).  With 8K samples/sec,*/
      /* the samples/dit is 8000*60/(50*wpm).                                 */
      dittime = APKT_SAMPLERATE*60/(50*LocalSettings.OffineCwSpd) ;

      /* Figger out the timing for all the dits and dah's in the first        */
      /* character in the string.                                             */
      done = FiggerCWTimes(str[stridx++],dittime,&endofCW) ;

      /* All done with setup, let's go send some CW */
      pktidx = 0     ; /* sample counter for CW stop/start times */
      *First = false ; /* All done with setup for this string    */
   }

   /* The process is to just start filling in samples of a 1KHz tone into the */
   /* transmit buffer.  This is kinda weird as we are only filling buffers in */
   /* 20ms (160 sample) chunks.                                               */
   for (i=0;i<APKT_SAMPLES;i++)
   {
      LocalAudio[i] = 0 ; /* default is silence unless it is tone time */
      for (j=0;j<MORSE_MAXDDS;j++)
      {
         /* There are up to six "tone times" (dits or dah's) per character.   */
         /* The ToneTimes array has the start and stop times for those tones. */
         /* See if we are in between the start and end pairs, and if so,      */
         /* replace the silent sample above with an entry from the sine wave  */
         /* table. If the character has less than 6 tones, ToneeTime[j][1]     */
         /* will be 0 for unused tones.                                       */

         /* I check all six start/stop times every time.  Seems this could be */
         /* more efficient by tracking and only checking the "active" pair.   */
         if ((ToneTimes[j][1]>0) &&(pktidx+i>=ToneTimes[j][0]) && (pktidx+i<ToneTimes[j][1]))
         {
        	 LocalAudio[i] = Sin1KHz_raw[MORSE_VOLUME][i%8] ;
         }
      }
   }

   /* OK, filled out that packet, increment our packet index by 160 samples   */
   /* so we'll have the right starting point for the next packet.             */
   pktidx += APKT_SAMPLES ;

   /* endofCW is the time (in samples) of the end of the character, so if we  */
   /* get to that value, we're done with the current character.  Note here    */
   /* that I'm only checking at the end of a packet, so the intra-character   */
   /* space will have some jitter (up to a packet length) of extra time before*/
   /* the next character starts.  I'm deciding this is OK as this is only 160 */
   /* samples and even at 20wpm the dit time is 480 samples, so pretty minor. */
   if (pktidx>endofCW)
   {
      /* If there are more characters to go, get the next, otherwise done!    */
      if (str[stridx])
      {
          /* If another character, get its timing numbers and also reset the  */
    	  /* packet index back to 0 for that next character.                  */
    	  done = FiggerCWTimes(str[stridx++],dittime,&endofCW) ;
    	  pktidx = 0 ;
      }
      else
      {
         /* If no more characters left, we are done! */
         done = true ;
      }
   }

   return(done) ;
}

/*******************************************************************************
* Routine  : FiggerCWTimes
* Gazintas : chr - character to parse out
*          : dittime - dit time (in samples)
* IOs      : endofCW - time (in samples) of the end of the CW for the chr
* Returns  : true if done with string (space or NULL)
* Globals  : ToneTimes - table for tone on/of times
*
* This takes the supplied character and converts it into tone on/off times in
* 8KHz samples.  It fills the ToneTime array with times for up to six tones and
* the silent time in between tones.  The times are in cumulative sample counts
* from the beginning of the character time.
*******************************************************************************/
static int FiggerCWTimes(char chr,int dittime,int* endofCW)
{
   int done  = false ; /* Done with string flag               */
   int idx   = 0     ; /* character index in MorseTable table */
   int accum = 0     ; /* Time accumulator                    */
   int i     = 0     ; /* general counter                     */

   /* If the char is out of range, just say we're done with this character */
   if ((chr <MORSE_CHRBASE) || (chr>MORSE_CHRMAX))
   {
      done = true ;
   }

   /* Get a nice array index just to make coding cleaner looking */
   idx = chr-MORSE_CHRBASE ;

   /* If the first character in the morse table is a space, it is an          */
   /* unsupported character--abort.                                           */
   if (' '==MorseTable[idx][0])
   {
      done = true ;
   }

   Logger2_Msg(Logger.Local,LOG_REGIO,LOG_TIME,"LocalMode: Sending '%c'\r\n",chr) ;
   /* OK, we've failed to fail, so go fill up the ToneTimes array.  There are */
   /* up to six dits or dahs for each character. Each entry is a pair of      */
   /* times representing the sample time for the start of the tone and then   */
   /* the end of the tone.  The time adder to the start of the next symbol    */
   /* will be either 2 or 4 dittimes if the tone is a dit or a dah to get one */
   /* dittime of silence between symbols.  After the last symbol, add two     */
   /* more dittimes of silence for the inter-character gap.                   */
   /* For characters with less than 6 symbols, a ToneTime entry of 0,0 means  */
   /* all done.                                                               */
   if (!done)
   {
      for (i=0;i<MORSE_MAXDDS;i++)
      {
         switch(MorseTable[idx][i])
         {
            case '.' : ToneTimes[i][0] = accum ; ToneTimes[i][1] = accum + dittime   ; accum += dittime*2 ; break ;
            case '-' : ToneTimes[i][0] = accum ; ToneTimes[i][1] = accum + dittime*3 ; accum += dittime*4 ; break ;
            case ' ' : ToneTimes[i][0] = 0     ; ToneTimes[i][1] = 0                                      ; break ;
            default  :                                                                                      break ;
         }
      }
   }

   /* Add the extra time for the inter-character gap after the last symbol */
   accum += dittime*2 ;
   *endofCW = accum ;
   return (done) ;
}
#endif /* ifdef LOCALVOTER */
