#include "Options.h"

#include "RSSIFilter.h"

#ifdef RSSIFILTER1

int16_t rssi_filter_taps[RSSIFILTER_TAP_NUM] = {
  128,
  402,
  -1225,
  1927,
  -1674,
  164,
  1729,
  -2249,
  54,
  4461,
  -9036,
  10962,
  -9036,
  4461,
  54,
  -2249,
  1729,
  164,
  -1674,
  1927,
  -1225,
  402,
  128
};

/******************************************************************************/
/* If using the CMSIS DSP library, we don't need any of the structures and    */
/* routines below, just the coefficient table.                                */
/******************************************************************************/
#ifndef USE_CMSIS_DSP

void RSSIFilter_init(RSSIFilter* f) {
  int i;
  for(i = 0; i < RSSIFILTER_TAP_NUM; ++i)
    f->history[i] = 0;
  f->last_index = 0;
}

void RSSIFilter_put(RSSIFilter* f, int16_t input) {
  f->history[f->last_index++] = input;
  if(f->last_index == RSSIFILTER_TAP_NUM)
    f->last_index = 0;
}

int16_t RSSIFilter_get(RSSIFilter* f) {
  int32_t acc = 0;
  int index = f->last_index, i;
  for(i = 0; i < RSSIFILTER_TAP_NUM; ++i) {
    index = index != 0 ? index-1 : RSSIFILTER_TAP_NUM-1;
    acc += (int32_t)f->history[index] * rssi_filter_taps[i];
  };
  return acc >> 16;
}

#endif
#endif

#ifdef RSSIFILTER2

static int32_t filter_taps[RSSIFILTER_TAP_NUM] = {
  -530,
  982,
  -1118,
  580,
  464,
  -1518,
  2458,
  -4115,
  7955,
  -14783,
  23469,
  -30964,
  33941,
  -30964,
  23469,
  -14783,
  7955,
  -4115,
  2458,
  -1518,
  464,
  580,
  -1118,
  982,
  -530
};

void RSSIFilter_init(RSSIFilter* f) {
  int i;
  for(i = 0; i < RSSIFILTER_TAP_NUM; ++i)
    f->history[i] = 0;
  f->last_index = 0;
}

void RSSIFilter_put(RSSIFilter* f, int32_t input) {
  f->history[f->last_index++] = input;
  if(f->last_index == RSSIFILTER_TAP_NUM)
    f->last_index = 0;
}

int32_t RSSIFilter_get(RSSIFilter* f) {
  int32_t acc = 0;
  int index = f->last_index, i;
  for(i = 0; i < RSSIFILTER_TAP_NUM; ++i) {
    index = index != 0 ? index-1 : RSSIFILTER_TAP_NUM-1;
    acc += f->history[index] * filter_taps[i];
  };
  return acc >> 16;
}

#endif

#ifdef RSSIFILTER3

static int32_t filter_taps[RSSIFILTER_TAP_NUM] = {
  640,
  -1842,
  3371,
  -4434,
  4311,
  -2842,
  378,
  2917,
  -7694,
  15130,
  -25629,
  37544,
  -47273,
  51051,
  -47273,
  37544,
  -25629,
  15130,
  -7694,
  2917,
  378,
  -2842,
  4311,
  -4434,
  3371,
  -1842,
  640
};

void RSSIFilter_init(RSSIFilter* f) {
  int i;
  for(i = 0; i < RSSIFILTER_TAP_NUM; ++i)
    f->history[i] = 0;
  f->last_index = 0;
}

void RSSIFilter_put(RSSIFilter* f, int16_t input) {
  f->history[f->last_index++] = input;
  if(f->last_index == RSSIFILTER_TAP_NUM)
    f->last_index = 0;
}

int16_t RSSIFilter_get(RSSIFilter* f) {
  int32_t acc = 0;
  int index = f->last_index, i;
  for(i = 0; i < RSSIFILTER_TAP_NUM; ++i) {
    index = index != 0 ? index-1 : RSSIFILTER_TAP_NUM-1;
    acc += (int32_t)f->history[index] * filter_taps[i];
  };
  return acc >> 16;
}

#endif
