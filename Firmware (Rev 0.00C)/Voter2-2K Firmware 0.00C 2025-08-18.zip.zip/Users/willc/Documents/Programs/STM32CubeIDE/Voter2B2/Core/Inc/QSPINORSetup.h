#ifndef INC_QSPINORSETUP_H_
#define INC_QSPINORSETUP_H_

void QSPINOR_NOHAL_Setup1(void) ;
void QSPINOR_NOHAL_Setup2(void) ;
void QSPINOR_HAL_Setup(QSPI_HandleTypeDef*) ;
void QSPINOR_Verify(void) ;

#endif /* INC_QSPINORSETUP_H_ */
