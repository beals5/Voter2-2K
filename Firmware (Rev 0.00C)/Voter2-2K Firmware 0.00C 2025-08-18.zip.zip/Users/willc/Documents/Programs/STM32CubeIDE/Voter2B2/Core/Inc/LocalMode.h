#ifndef INC_LOCALMODE_H_
#define INC_LOCALMODE_H_

/* In theory, this is the only call for any local mode implementation.        */
/* The first paramater is a pointer to an array of 16-bit signed audio        */
/* samples of length APKT_SAMPLES.                                            */
/* The second parameter is the DIAL connection state (if voting is enabled)   */
/* or set to DIAL_UNAUTH if local mode only).                                 */
/* The third parameter is if Rx is active, however that is determined.        */
/* Likely some combination of COR, CTCSS, and/or RSSI.                        */
/* Note that LocalModeSM is called ALWAYS, even if Rx isn't active or if the  */
/* DIAL state is connected.  It is called every 20ms (160 audio samples) if   */
/* Voting is enabled to match the DIAL packet size, but if Voting is disabled,*/
/* the packet size (and therefor calling frequency can be variable.           */

extern void LocalModeSM(int16_t*,int,int) ;

/* While LocalModeSM() is called every audio packet regardless of it being    */
/* valid data or even in local mode, it should only call Tx_EnqPacket() if it */
/* has audio to transmit. PTT is driven by having valid audio packets sent to */
/* Tx_EnqPacket().                                                            */

#endif /* INC_LOCALMODE_H_ */
