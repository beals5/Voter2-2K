#ifndef INC_SPINOR_H_
#define INC_SPINOR_H_

/* For SpiNor_erase */
#define ERASE_SECTOR 0
#define ERASE_ALL 1

typedef enum
{
   SPINOR_NONE = 0,
   SPINOR_MX25L3233,
   SPINOR_MX25L25645
} SPINOR_TYPES ;

extern int SPINOR_Type ;

/* Pre-RTOS functions */
void SPINOR_Init(void) ;

/* In-RTOS functions */
void SpiNor_erase(int,uint32_t) ;
void SpiNor_read(uint8_t*,uint32_t,uint32_t) ;
void SpiNor_write(uint8_t*,uint32_t,uint32_t) ;

void SpiNor_readOTP(uint8_t*,uint32_t,uint32_t) ;
void SpiNor_writeOTP(uint8_t*,uint32_t,uint32_t) ;
void SpiNor_lockOTP(void) ;


#endif /* INC_SPINOR_H_ */
