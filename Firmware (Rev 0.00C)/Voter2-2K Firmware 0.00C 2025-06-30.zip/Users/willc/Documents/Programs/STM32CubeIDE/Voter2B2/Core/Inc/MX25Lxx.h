/* ************************************************************************** */
/* Macronix MX25L3233 and MX25L25645 SPI-NOR parameters                       */
/* Device parameters                                                          */
/* ************************************************************************** */

/* The QSPI defines below are for the MX25L3233 only */
#define QSPI_FLASH_SIZE                      21
#define QSPI_PAGE_SIZE                       256
#define QSPI_DEV_SIZE                        0x400000
#define QSPI_START_ADRESS                    0x90000000

#define MACRONIX_MFR_ID                      0xC2
#define MX25L3233_DEVICE_ID                  0x15
#define MX25L25645_DEVICE_ID                 0x18
#define FASTREAD_NUMDUMMYCYCLES              4
#define READ4_NUMALTCYCLES                   2
#define READ4_NUMDUMMYCYCLES                 6

/* ************************************************************************** */
/* Commands                                                                   */
/* ************************************************************************** */

/* Reset Commands (currently hard coded) */
#define RESET_ENABLE_CMD                     0x66
#define RESET_MEMORY_CMD                     0x99

/* ID Commands */
#define READ_IDS_CMD                         0x90
#define READ_SR_CMD                          0x05

/* Block Lock/Unlock Commands */
#define GLOBAL_BLOCK_LOCK                    0x7e
#define GLOBAL_BLOCK_UNLOCK                  0x98

/* Erase commands */
#define SECTOR_ERASE_4KB_CMD                 0x20
#define BLOCK_ERASE_64KB_CMD                 0xD8
#define CHIP_ERASE_CMD                       0x60

/* Write commands */
#define WRITE_STATUS_REG_CMD                 0x01
#define WRITE_ENABLE_CMD                     0x06
#define PAGE_PROG_CMD                        0x02

/* Read commands */
#define READ_STATUS_REG_CMD                  0x05
#define READ_DATA_CMD                        0x03
#define QUAD_INOUT_FAST_READ_CMD             0x6B
#define READ4_INOUT_FAST_READ_CMD            0xEB

/* 4 byte commands for MX25L25645 */
#define READ4B_DATA_CMD                      0x13
#define SECTOR_ERASE4B_4KB_CMD               0x21
#define PAGE_PROG4B_CMD                      0x12

/* OTP Commands */
#define ENTER_OTP_MODE_CMD                   0xb1
#define EXIT_OTP_MODE_CMD                    0xc1
#define READ_SECURITY_REG_CMD                0x2b
#define WRITE_SECURITY_REG_CMD               0x2f
