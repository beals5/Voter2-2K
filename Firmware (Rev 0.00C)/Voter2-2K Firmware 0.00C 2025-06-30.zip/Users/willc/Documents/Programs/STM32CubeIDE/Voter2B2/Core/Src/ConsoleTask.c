/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the ConsoleTask file.  It is in charge of the console interface.   */
/* Console IO with the user is via a line-based CLI. This code currently      */
/* supports two interfaces, telnet and UART (well, USB via a USB-to-UART FTDI */
/* chip).  The console swaps between the two interfaces if a character comes  */
/* from the inactive interface.  It logs out as part of the swap too.         */
/* Other routines "register" their commands with this task and if their       */
/* command is typed in the console, the console calls that routine with the   */
/* standard argc/argv parameters.                                             */
/******************************************************************************/
/* Public routines are:                                                       */
/*  - ConEthRxTask - The RTOS task for incoming Ethernet traffic              */
/*  - ConsoleTask - The RTOS task console itself                              */
/*  - MyCLI_Register - For an external routine to register a CLI command      */
/*  - Console_printf - For an external command routine to print to the console*/
/*  - Console_puts - For an external command routine to print to the console  */
/*  - ConUARTTxComplete - Console UART Tx DMA complete ISR                    */
/*  - ConUARTRxComplete - Console UART Rx character available ISR             */
/*                                                                            */
/* SEE WARNING ABOUT USAGE OF printf and puts IN ROUTINE HEADERS.             */
/******************************************************************************/
// To Do:
// - This file is getting big, but can't see a clean split point.
// - Protect the RootMode variable a bit more?
//
/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>
#include <stdio.h>
#include <stdarg.h>

#include "cmsis_os.h"
#include "lwip.h"
#include "lwip/opt.h"
#include "lwip/sys.h"
#include "lwip/api.h"

#include "Options.h"
#include "main.h"
#include "logger2rt.h"
#include "Settings.h"
#include "EthernetTask.h"
#include "ConsoleTask.h"
#include "Timers.h"
#include "Utils.h"

/******************************************************************************/
/* Local defines (including enums)                                            */
/******************************************************************************/
//#define PRINTFD /* uncomment to enable this function (it isn't needed now)  */

#define CONSOLE_CMD_CONNECT (-1)
#define CONSOLE_CMD_DISCONNECT (-2)

typedef enum { /* Console Queue Stream IDs */
   CONSOLEIO_STRID_TELNET = 0,
   CONSOLEIO_STRID_UART,
} CONSOLE_STREAMIDs;

typedef enum { /* Console Queue Flags */
   CONSOLEIO_FLAGS_COLLECTING = 0,
   CONSOLEIO_FLAGS_DISCONNECT,
   CONSOLEIO_FLAGS_CONNECT,
   CONSOLEIO_FLAGS_DATA,
} CONSOLE_FLAGS;

typedef enum { /* Console state machine return codes */
   CONSOLEIO_OK = 0,
   CONSOLEIO_UNKNOWN,
   CONSOLEIO_NOMSG,
   CONSOLEIO_TOOLONG,
   CONSOLEIO_BUFFULL,
} CONSOLEIO_RTN;

typedef enum {  /* States the console can be in */
   CONSTATE_DISCONNECTED = 0,
   CONSTATE_LOGIN_UNAME,
   CONSTATE_LOGIN_PWD,
   CONSTATE_GETCMD,
   CONSTATE_CMD_RUNNING,
} CONSTATES;

typedef enum { /* Command "looker upper" result codes */
   MYCLI_SUCCESS = 0,
   MYCLI_NOSUCHCOMMAND,
   MYCLI_NOCOMMAND,
   MYCLI_LOGOUT
} MYCLI_RESULTCODES ;

#define TELNET_PORT 23

#define COMMAND_SIZE    128 /* Command line buffer size                     */
#define USERNAMPWD_SIZE SETTINGS_PASSWORD_LEN /* Username and password max  */
#define NTOKENS          25 /* max argv tokens                              */
#define NCOMMANDS        50 /* max supported commands                       */
#define PRINTF_LINELEN  255 /* max _printf line length                      */
#define PUTS_LINELEN    128 /* _puts chunk size                             */

/* Console_printfD and Console_putsD explicit destinations */
#define DEST_DEFAULT 0
#define DEST_TELNET 1
#define DEST_UART 2

#define ASCII_DEL 0x7f
#define ASCII_BS  0x08

/******************************************************************************/
/*  typedefs                                                                  */
/******************************************************************************/
typedef struct
{
   char* cmd_text ;
   char* cmd_help ;
   int   (*cmd_routine)(int,char**) ;
} MYCLI_CMDSTRUCT ;

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
int     RootMode      = false ; /* Root/Guest flag                    */
uint8_t UART_RxChar   =  0    ; /* Console UART Rx character          */

char* cmd_help_cmd    = "help" ;
char* cmd_help_help   = "help - help with commands\n"
                        " 'help' lists all commands\n"
                        " 'help [command] shows command syntax\n" ;
char* cmd_logout_cmd  = "logout" ;
char* cmd_logout_help = "logout - Log out of the terminal session\n" ;
char* cmd_reboot_cmd  = "reboot" ;
char* cmd_reboot_help = "reboot - reboot the device\n" ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static int    EnableRxQueue    = false ; /* Enable message queuing            */
static struct netconn *conn    = NULL  ; /* Telnet connection (pre-connect)   */
static struct netconn *newconn = NULL  ; /* Telnet connection (post-connect)  */
static void   *Telnet_data     = NULL  ; /* Telnet data to Console            */

static char UserName[USERNAMPWD_SIZE] = {0}   ; /* Supplied user name         */
static char UserPwd[USERNAMPWD_SIZE]  = {0}   ; /* Supplied password          */

/* Various text messages */
static char* LineEchoCmd     = "\xff\xfb\x01\xff\xfb\x03\xff\xfe\x22" ; /* WILL Echo, WONT GA, DONT Linemode */
static char* WelcomeMsg1    = "Welcome to the " ;
static char* WelcomeMsg2    = " (Serial #%d,SW Rev " PROJECTREV ", " PROJECTDATE ")\n" ;
static char* UserNamePrompt = "Username: " ;
static char* PasswordPrompt = "Password: " ;
static char* PasswordErr    = "Invalid username/password\n" ;
static char* FactoryReset   = "Resetting NVM to factory settings, please reboot then save settings.\n" ;
static char* HiGuest        = "Greetings Guest!\n" ;
static char* HiRoot         = "Greetings Master!\n" ;
static char* GuestPrompt    = "Guest" ;
static char* RootPrompt     = "root" ;
#ifdef CONSOLE_NOLOGIN
static char* NoLogPrompt    = "OK" ;
#endif
static char* CleanPrompt     = ">" ;
static char* DirtyPrompt     = "*>" ;

/* CLI command structure */
static MYCLI_CMDSTRUCT MyCLI_Commands[NCOMMANDS] = {0} ;
static int MyCLI_nCommands = 0 ;

/* Strings for the three "system" commands */

/* _printf and _puts destination and buffers */
static int ActiveConsole = DEST_TELNET ; /* Active Console interface          */
static char printfBuf[PRINTF_LINELEN] = {0} ; /* The line buffer for printf   */
static char putsBuf[PUTS_LINELEN] IN_DMADD2 = {0} ; /* Line buffer for puts   */

/* UART interface stuff */
static volatile int UART_Complete = true ; /* UART DMA Tx complete flag       */

static int PwdMode = false ; /* Password mode (echo stars) */

/******************************************************************************/
/* External globals. How CubeMX does things instead of in an include file,    */
/* weird.                                                                     */
/******************************************************************************/
extern osThreadId ConsoleTaskIDHandle ;
extern osThreadId ConEthRxTaskIDHandle ;
extern osMessageQId ConsoleQueueHandle ;
extern osMutexId ConsoleInHandle ;
extern UART_HandleTypeDef huart8 ;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
/* Console support functions */
static void Console_Enqueue(uint8_t,uint8_t,uint8_t) ;
static int  Consoleio_gotc(uint8_t,char*,int) ;
static int  login_match(char*,char*,char*,char*) ;
static void Console_Prompt(void) ;

/* Command line interface support functions */
static int MyCLI_execute(char*) ;

/* Special versions of puts and printf that can select target */
static void Console_putsD(int,char*) ;
#ifdef PRINTFD
static int  Console_printfD(int,const char* format, ...) ;
#endif

/******************************************************************************/
/* Local routines (finally!)                                                  */
/******************************************************************************/

/*******************************************************************************
* Routine  : ConEthRxTask
* Gazintas : None (well, not used)
* IOs      : None
* Returns  : Never
* Globals  : EnableRxQueue - Semaphore to enable incoming packets
*          : conn, newconn - LWIP handles for the telnet interface
*          : Lots of others too!
*
* This is the task for incoming console messages via Ethernet.  LWIPs netconn
* API is blocking but the console is event driven, so I need a separate task
* that can wait on incoming data via Ethernet then queue it up as an event
* for the ConsoleTask.  The Console also can be connected by UART, so this is
* only one of two sources of data for the Console Task.
* This routine manages the Telnet interface and sends characters to the
* ConsoleTask via the ConsoleQueue.
*******************************************************************************/
void ConEthRxTask(void const * argument)
{
   struct netbuf *buf  = NULL ; /* Buffer for incoming TCP data */
   u16_t         len   = 0    ; /* payload length               */
   err_t         err   = 0    ; /* Result code                  */
   int           i     = 0    ; /* Counter                      */

   /* First wait on ConsoleTask getting set up.  It signals it is ready by    */
   /* setting EnableRxQueue to true.                                          */
   /* Yea, I could do the whole sempahore/signal thing, but this is simpler.  */
   while (!EnableRxQueue) osDelay(10) ;
   Logger2_Msg(Logger.Console,LOG_MAJOR,LOG_TIME,"ConEthRxTask: Start\r\n") ;

   /* Create a new Ethernet port and bind it to the telnet port ID */
   conn = netconn_new(NETCONN_TCP);
   netconn_bind(conn, IP_ADDR_ANY, TELNET_PORT);
   Logger2_Msg(Logger.Console,LOG_SUPPORT,LOG_TIME,"ConsoleTask: netconn_new (0x%8.8x)\r\n",(uint32_t)conn) ;

   /* Go into listening mode. */
   netconn_listen(conn);

   while (1) /* Task infinite loop */
   {
      /* Wait for a connection... */
      Logger2_Msg(Logger.Console,LOG_SUPPORT,LOG_TIME,"ConsoleTask: Waiting for a connection\r\n") ;
      err = netconn_accept(conn, &newconn);
      Logger2_Msg(Logger.Console,LOG_MAJOR,LOG_TIME,"ConsoleTask: Telnet Connection (%d)\r\n",err) ;
      /* Tell the console we connected! */
      ActiveConsole = DEST_TELNET ; /* make sure output returns to telnet */
      Console_Enqueue(CONSOLEIO_STRID_TELNET,CONSOLEIO_FLAGS_CONNECT,0) ;

      /* If connected, start processing incoming data */
      if (err == ERR_OK)
      {
         while ((err = netconn_recv(newconn, &buf)) == ERR_OK)
         {
            /* Above was a blocking wait for data. */
            Logger2_Msg(Logger.Console,LOG_REGIO,LOG_TIME,"ConsoleTask: Got Data (%d)\r\n",buf->p->len) ;
            do
            {
               /* get the payload and send it to get parsed */
               netbuf_data(buf, &Telnet_data, &len);

               /* If the console had been taken away by the UART, get it back */
               if (DEST_TELNET!=ActiveConsole)
               {
                  Console_Enqueue(CONSOLEIO_STRID_TELNET,CONSOLEIO_FLAGS_DISCONNECT,0) ;
                  ActiveConsole = DEST_TELNET ; /* make sure output returns to telnet */
                  Console_Enqueue(CONSOLEIO_STRID_TELNET,CONSOLEIO_FLAGS_CONNECT   ,0) ;
               }

               /* Send over the data a byte at a time */
               for (i=0;i<len;i++) Console_Enqueue(CONSOLEIO_STRID_TELNET,CONSOLEIO_FLAGS_DATA,((uint8_t*)Telnet_data)[i]) ;
            } while (netbuf_next(buf) >= 0) ;
            netbuf_delete(buf); /* all done, free the pbuf */
         }

         /* If the client disconnects or there is any kind of error, close    */
         /* the connection and discard connection identifier.                 */
         Logger2_Msg(Logger.Console,LOG_MAJOR,LOG_TIME,"ConsoleTask: Connection closed by client\r\n") ;
         Console_Enqueue(CONSOLEIO_STRID_TELNET,CONSOLEIO_FLAGS_DISCONNECT,0) ;
         netconn_close(newconn);
         netconn_delete(newconn);
      }
   }
}

/*******************************************************************************
* Routine  : ConUARTRxComplete
* Gazintas : None
* IOs      : None
* Returns  : Never
* Globals  : TBD
*
* This routine gets called on receipt of a character from the Console UART.
* If the UART isn't in control it takes over, but otherwise just forwards the
* character.
*******************************************************************************/
void ConUARTRxComplete(void)
{
   /* The HAL way of doing interrupt IO is based on filling up larger         */
   /* buffers, so way overkill for what I want.  This routine either gets     */
   /* called by the HAL routines or directly by the ISR if the HAL routines   */
   /* are being bypassed.  If HAL, the byte is already in UART_RxChar.  If    */
   /* not, then get the character before the common code.                     */
#ifdef UART8_HALIRQ_BYPASS
   UART_RxChar = (uint8_t)(huart8.Instance->RDR) ;
#endif

   //Logger2_Msg(Logger.Console,LOGGER2_CONSOLE,LOG_TIME,"ConsoleTask: UART 0x%2.2x\r\n",UART_RxChar) ;

   /* If the console had been taken away from the UART, get it back */
   if (DEST_UART!=ActiveConsole)
   {
      Console_Enqueue(CONSOLEIO_STRID_TELNET,CONSOLEIO_FLAGS_DISCONNECT,0) ;
      ActiveConsole = DEST_UART ; /* make sure output returns to the UART */
      Console_Enqueue(CONSOLEIO_STRID_TELNET,CONSOLEIO_FLAGS_CONNECT   ,0) ;
   }

   /* Send the character to the Console task */
   Console_Enqueue(CONSOLEIO_STRID_UART,CONSOLEIO_FLAGS_DATA,UART_RxChar) ;

#ifdef UART8_HALIRQ_BYPASS
   /* just need to clear the hardware interrupt. */
   /* Leave everything else alone.               */
   __HAL_UART_CLEAR_NEFLAG (&huart8) ;
#else
   /* HAL way is to fully re-start the IT call each character--ick */
   HAL_UART_Receive_IT(&huart8,&UART_RxChar,1) ;
#endif

}

/*******************************************************************************
* Routine  : Console_Enqueue
* Gazintas : StreamID - Stream Identifier
*          : flags - Flag bits
*          : data - byte to enqueue
*          : len - Buffer length
* IOs      : None
* Returns  : Nothing
* Globals  : EnableRxQueue - Semaphore to enable incoming packets
*
* This is the routine to queue up data for the Console Task.  There are multiple
* sources of data, but this is the common routine to get that data in the
* queue.  The three parameters are stuffed into a 16-bit message:
*  - 4 MSBs are the stream ID (Telnet or UART, rest RFU)
*  - Next 4 bits are flags (Connect, disconnect, or data)
*  - 8 LSBs are data (ASCII byte if flag indicates data)
*******************************************************************************/
static void Console_Enqueue(uint8_t StreamID, uint8_t flags, uint8_t data)
{
  /* Only if enabled, send the message into the Console Task!                */
  /* If not enabled, data just gets lost.  That is fine.                     */
  /* Mostly needed as the ISRs fire up before the RTOS and try to send data  */
  /* before the RTOS has started and that *is* bad.                          */
  if (EnableRxQueue)
  {
     /* Just bit-stuff the three parameters into a 16-bit value and send the */
     /* message to the DIAL task.                                            */
     uint16_t msg = ((StreamID&0xf)<<12) + ((flags&0xf)<<8) + (data&0xff) ;

     osMessagePut(ConsoleQueueHandle,msg,0) ;
  }
}

/*******************************************************************************
* Routine  : Consoleio_gets
* Gazintas : maxlen - max line length
* IOs      : line - line of text (EOS-terminated)
* Returns  : Result code
* Globals  : TBD
*
* This is Consoles "get a line" routine.  It implements the console command line
* interface.  Console inputs can come from multiple sources, right now it is
* Telnet and UART (which is USB via an FTDI chip).
*
* The Console is event driven with events mostly being ASCII bytes of text from
* the client (plus connect/disconnect events).  This routine can be called by
* the console task itself for console commands or called by a console routine
* looking for text input.
*
* While both Telnet and UART are character based text interfaces, Telnet and
* UART are quite different beasts when it comes to the handling character IO.
* Telnet is much * more line based, has special sequences, and assumes the
* terminal can do line editing.  For a UART terminal, it is much more character
* based and line editing implementation is done by the CLI. If the client is
* Telnet, I dumb it down to look more like a UART terminal (no local echo and
* not linemode).
*******************************************************************************/
int Consoleio_gets(char* line, int maxlen)
{
   int       status   =  0  ; /* Line gathering status             */
   osEvent   event    = {0} ; /* event info (for incoming message) */
   uint8_t   StreamID =  0  ; /* Incoming Message Stream ID        */
   uint8_t   Flags    =  0  ; /* Incoming Message Flags            */
   uint16_t  MsgData  =  0  ; /* Incoming Message data             */

   /* Start off with a clean line and in collecting mode... */
   status = CONSOLEIO_FLAGS_COLLECTING ;
   memset(line,0,maxlen) ;

   /* loop while still collecting */
   while (CONSOLEIO_FLAGS_COLLECTING==status)
   {
      /* Wait for a message to arrive... (blocking wait) */
      event = osMessageGet(ConsoleQueueHandle,osWaitForever ) ;

      if ( event.status == osEventMessage) /* Only message type I'm expecting */
      {
         /* Message is a uint16_t.  The upper 4 bits are the stream           */
         /* identifier, the next 4 bits are the flags, and the lower 8 bits   */
         /* is the ASCII character (if flag says data).                       */
         StreamID = ((event.value.v)>>12)&0xf ;
         Flags    = ((event.value.v)>> 8)&0xf ;
         MsgData  =  (event.value.v)&0xff     ;

         if ((MsgData>=' ')&&(MsgData<='~'))
         {
             Logger2_Msg(Logger.Console,LOG_REGIO,LOG_TIME,"ConsoleTask: Task Event (%d,%d,'%c')\r\n",StreamID,Flags,MsgData) ;
         }
         else
         {
             Logger2_Msg(Logger.Console,LOG_REGIO,LOG_TIME,"ConsoleTask: Task Event (%d,%d,0x%2.2x)\r\n",StreamID,Flags,MsgData) ;
         }

         /* Connect and disconnect handling is the same regardless of the     */
         /* StreamID                                                          */
         if (CONSOLEIO_FLAGS_CONNECT   ==Flags) status = CONSOLEIO_FLAGS_CONNECT    ;
         if (CONSOLEIO_FLAGS_DISCONNECT==Flags) status = CONSOLEIO_FLAGS_DISCONNECT ;

         /* If data, then StreamID matters.  Send right data to Consoleio_gotc*/
         if (CONSOLEIO_FLAGS_DATA==Flags)
         {
            if (CONSOLEIO_STRID_TELNET == StreamID) status = Consoleio_gotc(MsgData,line,maxlen) ;
            if (CONSOLEIO_STRID_UART   == StreamID) status = Consoleio_gotc(MsgData,line,maxlen) ;
         }
      }
   }

   /* If no longer gathering, return with the flag that ended thigns */
   return(status) ;
}

/*******************************************************************************
* Routine  : Consoleio_gotc
* Gazintas : c - character to enqueue
*          : maxlen - max line length
* IOs      : line - line of text accumulator
* Returns  : Nothing
* Globals  : TBD
*
* This is a character-by-character enqueuer whatever the source is.  Data gets
* accumulated until finally a CR, then once that comes, the line as a whole is
* sent to the Console state machine so it just deals with whole lines.
* This routine also filters out Telnet commands so the console doesn't have to.
*  - 0xff, 0xf0-0xfa general commands (2 bytes)
*  - 0xff, 0xfb, 0x?? WILL commands (3 bytes)
*  - 0xff, 0xfc, 0x?? WON'T commands (3 bytes)
*  - 0xff, 0xfd, 0x?? DO commands (3 bytes)
*  - 0xff, 0xfe, 0x?? DON'T commands (3 bytes)
*  - 0xff, 0xff (send an 0xff to the console)
* Right now I'm not handling subnegotiation blocks.  I believe if I don't
* support any of the above commands, they are not possible to request.
*******************************************************************************/
static int Consoleio_gotc(uint8_t c,char* line,int maxlen)
{
   static int CommandFlag = 0 ; /* Flag for filtering out command strings */
   static int idx         = 0 ; /* Index into command line (accumulator)  */

   int rval               = 0 ; /* function return value                  */
   char echo[4] = {0} ; /* For echoing characters back   */

   /* Default return value unless EOL */
   rval = CONSOLEIO_FLAGS_COLLECTING ;

   /* If in a command, CommandFlag is the # of bytes to drop.  For an         */
   /* initial IAC, it is 1 more byte, but if that second byte is a            */
   /* WILL/WONT/DO/DONT command, then skip one more byte.                     */
   /* I don't handle IAC+IAC, but since I only handle printable ASCII, no     */
   /* need (yet).                                                             */
   if (CommandFlag > 0)
   {
      if ((c>=250) && (c<255))
      {
         /* if a WILL/WONT/DO/DONT command, toss one more byte */
         CommandFlag = 1 ;
      }
      else
      {
         CommandFlag-- ;
      }
   }

   /* If not in a command sequence, see if it is the start of one */
   else if (0xff == c)
   {
      /* If IAC, then we need to toss at least one following byte */
	   CommandFlag = 1 ;
   }

   /* If backspace or DEL and the buffer isn't empty, handle it */
   else if ((idx>0) && ((ASCII_DEL==c)||(ASCII_BS==c)))
   {
      idx-- ;
      line[idx] =  0 ;

      echo[0]   =  ASCII_BS ;
      echo[1]   = ' '       ;
      echo[2]   =  ASCII_BS ;
      echo[3]   =  0        ;
      Console_puts(echo) ;
   }

   /* If not command flags, check for printable ASCII or CR (rest is tossed)  */
   else if ((0x0d == c) || ((c>=' ')&&(c<='~')) )
   {
      /* Store the character no matter what (overflow handled later) */
      line[idx] = c ;

      /* For echoing, if CR change to NEWLINE so it it gets changed to CR/LF  */
      /* Also, if in password mode, only echo stars.                          */
      echo[0] = c ;
      echo[1] = 0 ;
      if (0x0d==echo[0]) echo[0]='\n' ; /* Change CR to newline         */
      else if (PwdMode)  echo[0]='*'  ; /* Change to * if password mode */
      Console_puts(echo) ;

      /* If room for more, increment pointer.  This ordering is useful as it  */
      /* ensures on overflow that the last character will be the CR.          */
      if (idx<maxlen) idx++ ;

      /* All printable characters plus CR got stored, but if it was a CR, time   */
      /* to send that line on to the Console state machine.                      */
      if (0x0d == c)
      {
         /* ptr has to be at least 1 for the CR, so OK to decrement it. */
         idx-- ;

         /* Replace the ending CR with EOS instead. That gives the console a     */
         /* nice cleanly formatted string for parsing.                           */
         line[idx] = 0 ;

         /* We have a line, return with the flag saying so and reset the      */
         /* accumulator index for the next line.                              */
         rval = CONSOLEIO_FLAGS_DATA ;
         idx = 0 ;
      }
   }
   return(rval) ;
}

/*******************************************************************************
* Routine  : ConsoleTask
* Gazintas : None
* IOs      : None
* Returns  : Never
* Globals  : TBD
*
* This is main console task as well as state machine.
* It waits for line-based data or connect/disconnect events via the
* Consoleio_gets() routine.  That source can be telnet or UART, but by the time
* we get here, that is abstracted. This console takes care of logging in and
* presents a command line interface. It calls routines based on the command
* entered and provides a rudimentary argc/argv and gets/puts interface for
* those commands to interact with the user.
*******************************************************************************/
void ConsoleTask(void const * argument)
{
   int ConsoleState = CONSTATE_DISCONNECTED ; /* Start off disconnected          */
   int PrevConState = CONSTATE_DISCONNECTED ; /* for detecting a change          */
   int command      = 0                     ; /* Consoleio_gets result           */
   int result       = 0                     ; /* Command line interpreter result */
   char ConsoleCMD[COMMAND_SIZE]  = {0}     ; /* Command line to console         */

   /* Startup sequencing enforcement. See Options.h */
   osDelay(StartDelay_ConsoleTask) ;
   Logger2_Msg(Logger.Console,LOG_MAJOR,LOG_TIME,"ConsoleTask: Start\r\n") ;

   /* OK, we're ready.  Enable incoming messages (Ethernet and UART) */
   EnableRxQueue = true ;

   for(;;) /* Task forever loop */
   {
   command = Consoleio_gets(ConsoleCMD,COMMAND_SIZE) ;

   Logger2_Msg(Logger.Console,LOG_REGIO,LOG_TIME,"ConsoleTask: SM Event (%d)\r\n",command) ;

   /* Except for the disconnect event which overrides everything, how   */
   /* we react to the event depends on the mode the console is in.      */
   if (CONSOLEIO_FLAGS_DISCONNECT == command)
   {
       RootMode = false ; /* Just a bit of insurance */
       ConsoleState = CONSTATE_DISCONNECTED ;
   }
   else
   {
      if (CONSTATE_DISCONNECTED == ConsoleState)
      {
         RootMode = false ; /* Just a bit of insurance */
         /* In the disconnected state, the only message of interest is  */
         /* the connect message, all others are ignored.  When someone  */
         /* does connect, we say "hi".  If it is regular logging in, we */
         /* go on to request the username.  If no logging in is needed, */
         /* we go straight to root mode and wait for a command.         */
         /* FOR UART: If we get anything while disconnected, say "HI"   */
         /* and enter the connected state.                              */
         if ((CONSOLEIO_FLAGS_CONNECT == command) || (CONSOLEIO_FLAGS_DATA == command))
         {
            /* If a Telnet connection, disable line mode and local Echo */
            if (DEST_TELNET==ActiveConsole) Console_puts(LineEchoCmd) ;

            /* Say "Hi" and prompt for the user name */
            Console_puts(WelcomeMsg1) ;
            if (0!=Settings.Voter_Name[0])
            {
               Console_puts("'") ;
               Console_puts(Settings.Voter_Name) ;
               Console_puts("' ") ;
            }
            Console_puts(PROJECTNAME) ;
            Console_printf(WelcomeMsg2,Settings.MySerialNum) ;
#ifndef CONSOLE_NOLOGIN
            Console_puts(UserNamePrompt) ;
            ConsoleState = CONSTATE_LOGIN_UNAME ;
#else
            Console_puts(NoLogPrompt) ;
            Console_puts(CleanPrompt) ;
            ConsoleState = CONSTATE_GETCMD ;
            RootMode = true ;
#endif
         }
      }
      else if (CONSTATE_LOGIN_UNAME == ConsoleState)
      {
         /* Start off with a cleared username and password buffer */
         memset(UserName,0,USERNAMPWD_SIZE) ;
         memset(UserPwd ,0,USERNAMPWD_SIZE) ;

         /* In Username login state we're getting the username. */
         if (CONSOLEIO_FLAGS_DATA == command)
         {

            strntcpy(UserName,ConsoleCMD,USERNAMPWD_SIZE) ;

            /* and prompt for the password */
            Console_puts(PasswordPrompt) ;
            ConsoleState = CONSTATE_LOGIN_PWD ;
            PwdMode = true ;
         }
      }
      else if (CONSTATE_LOGIN_PWD == ConsoleState)
      {
         /* In Password login state we're getting the password.         */
         /* If good, on to the command state, if not, back to the login */
         /* state.                                                      */
         if (CONSOLEIO_FLAGS_DATA == command)
         {
            strntcpy(UserPwd,ConsoleCMD,USERNAMPWD_SIZE) ;
            PwdMode = false ;

            if (login_match(UserName,UserPwd,"root",Settings.Root_Password))
            {
               RootMode = true ;
               Console_puts(HiRoot) ;
               Console_Prompt() ;
               ConsoleState = CONSTATE_GETCMD ;
            }
            else if (login_match(UserName,UserPwd,"guest",Settings.Guest_Password))
            {
               RootMode = false ;
               Console_puts(HiGuest) ;
               Console_Prompt() ;
               ConsoleState = CONSTATE_GETCMD ;
            }
            /* A bit unorthodox instead of a button to do a factory reset,    */
            /* if you enter a username of factory and a password of reset     */
            /* ONLY ON THE UART INPUT so it is local, do an NVM factory reset.*/
            else if ((DEST_UART==ActiveConsole) && login_match(UserName,UserPwd,"factory","reset"))
            {
               Console_puts(FactoryReset) ;
               Settings_clear() ;
               RootMode = false ;
               Console_puts(UserNamePrompt) ;
               ConsoleState = CONSTATE_LOGIN_UNAME ;
            }
            else /* If not username/password match, back to the login state */
            {
               RootMode = false ; /* be really sure */
               Console_puts(PasswordErr) ;
               Console_puts(UserNamePrompt) ;
               ConsoleState = CONSTATE_LOGIN_UNAME ;
            }
         }
      }
      else if (CONSTATE_GETCMD == ConsoleState)
      {
         /* Call the Command line interpreter! */
         result = MyCLI_execute(ConsoleCMD) ;

         /* If command not recognized, say so, for the rest, nothing to say. */
         if (MYCLI_NOSUCHCOMMAND == result)
         {
            Console_printf ("Command not a recognized.\nEnter help for command list\n") ;
         }

         /* If logging out, go back to login state */
#ifndef CONSOLE_NOLOGIN
         if (MYCLI_LOGOUT == result)
         {
            RootMode = false ; /* be really sure */
            Console_puts(UserNamePrompt) ;
            ConsoleState = CONSTATE_LOGIN_UNAME ;
         }
         else /* anything else, print a prompt and await the next command */
#endif
         {
            Console_Prompt() ;
         }
      }
   }

   /* If a change in the console state, note it if debugging is enabled. */
   if (ConsoleState != PrevConState)
   {
      Logger2_Msg(Logger.Console,LOG_REGIO,LOG_TIME,"ConsoleTask: New State %d\r\n",ConsoleState) ;
      PrevConState = ConsoleState ;
   }
   }
}

/*******************************************************************************
* Routine  : Console_Prompt
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : Settings.Voter_Name,RootMode,CONSOLE_NOLOGIN,Settings.Dirty
*
* There are lots of inputs into what the command line prompt looks like and I
* need to print it from several places, so makes sense to have a routine do it.
*******************************************************************************/
static void Console_Prompt(void)
{
   if (0!=Settings.Voter_Name[0])
   {
      Console_puts(Settings.Voter_Name) ;
      Console_puts(":") ;
   }
#ifndef CONSOLE_NOLOGIN
   Console_puts(RootMode?RootPrompt:GuestPrompt) ;
#else
   Console_puts(NoLogPrompt) ;
#endif
   Console_puts(Settings.Dirty?DirtyPrompt:CleanPrompt) ;
}

/*******************************************************************************
* Routine  : login_match
* Gazintas : user_in - Username input
*          : pwd_in - Password input
*          : user_ref - Username to check against
*          : pwd_ref - Password to check agaisnt
* IOs      : None
* Returns  : true if match
* Globals  : None
*
* This checks the supplied username/password against a reference username and
* password and returns true if they match.  I suspect there are better ways of
* doing this more securely, but this isn't super-critical for telnet!
*******************************************************************************/
static int login_match(char* user_in,char* pwd_in,char* user_ref,char* pwd_ref)
{
   int match = false ;

   /* Basic length check first */
   if ( (strlen(user_in) == strlen(user_ref)) &&
		(strlen(pwd_in ) == strlen(pwd_ref )) )
   {
      /* If lengths equal, do string check */
      if ((!strncmp(user_in,user_ref,strlen(user_ref))) &&
          (!strncmp(pwd_in ,pwd_ref ,strlen(pwd_ref )))  )
      {
         match = true ;
      }
   }
   return(match) ;
}

/*******************************************************************************
* Routine  : MyCLI_execute
*   Inputs : cmdin - Command line from the user
*      IOs : None
*  Returns : result code
*  Globals : MyCLI_Commands - Command array
*
* This is the command line interpreter.  It accepts a line of text from the
* user, parses it into the equivalent of argc and argv that you'd get from an
* OS CLI, then calls the matching routine for that command.  The routines that
* want to be recognized call MyCLI_Register() to provide their command to be
* recognized. This routine waits for that command routine to return here then
* returns to the caller.  That means all commands run under the Console task.
*******************************************************************************/
static int MyCLI_execute(char* cmdin)
{
   int   result           =  MYCLI_NOSUCHCOMMAND ; /* CLI parser result code  */
   int   My_argc          =  0  ; /* My locally parsed argc                   */
   char* My_argv[NTOKENS] = {0} ; /* My locally parsed argvs                  */
   int   i                =  0  ; /* General counter                          */

   /* First parse the line into its components.  Note that this modifies      */
   /* cmdin.  I could copy it, but can't see any reason why, so will save the */
   /* memory.                                                                 */
   ParseLine(cmdin,&My_argc,My_argv) ;

   /* If we have something, search the command table to see if we have a      */
   /* matching command and if so, call it.                                    */
   if (My_argc > 0)
   {
      for (i=0;i<MyCLI_nCommands;i++)
      {
         if ((NULL != My_argv[0]) && (NULL != MyCLI_Commands[i].cmd_text))
         {
            if (!strcmp(My_argv[0],MyCLI_Commands[i].cmd_text))
            {
               MyCLI_Commands[i].cmd_routine(My_argc,My_argv) ;
               result = MYCLI_SUCCESS ;
            }
         }
      }
      /* Special case of "logout" to tell shell we're done */
      if (!strcmp(My_argv[0],"logout")) result = MYCLI_LOGOUT ;
   }
   else
   {
      result = MYCLI_NOCOMMAND ;
   }

   /* If something entered but no match, default is MYCLI_NOSUCHCOMMAND */
   return(result) ;
}

/*******************************************************************************
* Routine  : ParseLine
*   Inputs : cmdin - Full command line from the user
*      IOs : My_argc - number of arguments in the line
*          : My_argv - pointers to arguments in the line
*  Returns : result code?
*  Globals : TBD
*
* This is the command line parser, it takes the full line of text in and
* parses it out into individual tokens, returning the familiar argc/argv list
* that you get from an OS. Smarter folk do this with pointers,  I'm sticking
* to array indexes.
*******************************************************************************/
int ParseLine(char* cmdin,int* My_argc, char** My_argv)
{
   int largc   = 0     ; /* Local version of argc while parsing   */
   int largp   = 0     ; /* Pointer to command line while parsing */
   int inquote = false ; /* Inside a quote flag                   */
   int i       = 0     ; /* counters                              */
   int j       = 0     ; /* counters                              */
   int k       = 0     ; /* counters                              */

   /* If any leading spaces, take care of them */
   while ((' ' == cmdin[largp]) && (0 != cmdin[largp])) largp++ ;

   /* if nothing but spaces until EOS, then a blank line. */
   if ((0 == cmdin[largp]))
   {
      largc = 0 ;
      My_argv[0] = NULL ;
   }
   else /* else we have first argument! */
   {
      /* Loop to parse parameters... */
      while (0 != cmdin[largp])
      {
         /* Save the current argument first */
         My_argv[largc] = &cmdin[largp] ;
         largc++ ;

         /* skip until some white space outside a quote */
         while (((' ' != cmdin[largp]) || inquote) && (0 != cmdin[largp]))
         {
            if ('\"'==cmdin[largp]) inquote = !inquote ;
            largp++ ;
         }

         /* if whitespece (i.e. not EOS), terminate the argument with an EOS */
         if (0 != cmdin[largp])
         {
            cmdin[largp] = 0 ;
            largp++ ;
         }

         /* Skip any additional whitespace until next parameter (or EOS) */
         while ((' ' == cmdin[largp]) && (0 != cmdin[largp])) largp++ ;
      }
   }

   /* if any parameters had quotes, they are still in there, parse through    */
   /* the parameters and remove any quotes.                                   */
   if (largc>0) /* if any arguments */
   {
      for (i=1;i<largc;i++)
      {
         j = 0 ;
         k = 0 ;
         while(*(My_argv[i]+j))
         {
            if (*(My_argv[i]+j) =='\"')
            {
               j++ ;
            }
            else
            {
               *(My_argv[i]+k) = *(My_argv[i]+j) ;
               j++ ;
               k++ ;
            }
         }
         *(My_argv[i]+k) = 0 ;
      }
   }

   /* above loop was until EOS, so all done! */
   *My_argc = largc ;
   return(0) ;
}

/*******************************************************************************
* Routine  : MyCLI_Register
*   Inputs : cmdtext - actual command
*          : helptext - Help text for the command
*          : cmdroutine - the routine to execute for that command
*      IOs : None
*  Returns : 0 for success !0 for fail (only failure is overflow)
*  Globals : MyCLI_Commands
*
* This is the routine a command calls to get registered with the CLI.  For each
* command there is the command itself, its helptext, and pointer to the actual
* routine to execute.
*******************************************************************************/
int MyCLI_Register(char* cmdtext, char* helptext,int (*cmdroutine)(int,char**))
{
   int rval = 1 ; /* Result code */

   /* As long as we're not overflowing, add the command parameters to the array */
   if (MyCLI_nCommands < (NCOMMANDS-1))
   {
      MyCLI_Commands[MyCLI_nCommands].cmd_text    = cmdtext    ;
      MyCLI_Commands[MyCLI_nCommands].cmd_help    = helptext   ;
      MyCLI_Commands[MyCLI_nCommands].cmd_routine = cmdroutine ;
      MyCLI_nCommands++ ;
      rval = 0 ;
   }
   else
   {
      Logger2_Msg(Logger.Console,LOG_MAJOR,LOG_TIME,"ConsoleTask: Command table overflow!\r\n") ;
   }

   return(rval) ;
}

/*******************************************************************************
* Routine  : Cmd_help
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : MyCLI_Commands
*
* This is the help command.  It either lists all commands or syntax of a
* specific command.  All data is provided by the commands themselves when they
* register themselves.
*******************************************************************************/
int Cmd_help(int argc, char* argv[])
{
   int i     = 0     ; /* General counter */
   int found = false ; /* found flag      */

   if (1==argc) /* if no params, just list all commands */
   {
      Console_printf ("Commands are:\n") ;
      for(i=0;i<MyCLI_nCommands;i++)
      {
         Console_printf(" - %s\n",MyCLI_Commands[i].cmd_text) ;
      }
      Console_printf(" *> prompt means unsaved settings, > means all settings saved.\n") ;

   }
   else if (2==argc) /* help for a specific command */
   {
      for(i=0;i<MyCLI_nCommands;i++) /* Go through the command list for a match */
      {
         if ((NULL != argv[1]) && (NULL != MyCLI_Commands[i].cmd_text))
         {
            if (!strcmp(argv[1],MyCLI_Commands[i].cmd_text))
            {
               /* If a match, print that commands help string */
               Console_puts(MyCLI_Commands[i].cmd_help) ;
               found = true ;
            }
         }
      }

      /* If no match, try to be helpful */
      if (!found) Console_printf("Command not found.  Type 'help' for a full command list.\n") ;
   }
   else /* if more than one paramater, error */
   {
      Console_printf("Syntax error, 'help' for list of commands or 'help [command] for syntax\n") ;
   }
   return (0) ;
}

/*******************************************************************************
* Routine  : Cmd_logout
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : MyCLI_Commands
*
* This just confirms logging out.  Actual logging out is done at in the
* command task itself.  Parameters (if any) are ignored.
*******************************************************************************/
int Cmd_logout(int argc, char* argv[])
{
#ifndef CONSOLE_NOLOGIN
   Console_printf("Logging out...\n") ;
#else
   Console_printf("Logging in/out disabled!\n") ;
#endif
   return (0) ;
}

/*******************************************************************************
* Routine  : Cmd_reboot
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : DOESN'T!!!  Reboots the device
*  Globals : MyCLI_Commands
*
* This just calls the reboot command.  It obviously doesn't return.
*******************************************************************************/
int Cmd_reboot(int argc, char* argv[])
{
   Console_printf("Rebooting...\n") ;
   osDelay(100)    ; /* let the message get out   */
   RebootNow() ;

   /* If the reset didn't work, say I'm embarrassed. */
   Console_printf("Hmm, something didn't go right...\n") ;
   return (0) ;
}

/*******************************************************************************
* Routines : Console_puts and Console_printf
*
* These are the "normal" versions of Console_puts and Console_printf that
* print to the active console interface.  They are simply wrappers for
* Console_putsD and Console_printfD where the destination can be specifically
* selected.
*******************************************************************************/
int Console_printf(const char* format, ...)
{
   va_list vargs      ; /* varg magic, dunno how to initialize */
   int     rval   = 0 ; /* Routine return value                */
   int     buffed = 0 ; /* bytes in buffer so far              */

   va_start(vargs, format);
   buffed += vsnprintf(printfBuf+buffed, PRINTF_LINELEN-buffed, format, vargs);
   va_end(vargs);

   /* Send the message */
   Console_putsD(DEST_DEFAULT,printfBuf) ;
   return (rval) ;
} ;

void Console_puts(char* msg)
{
   Console_putsD(DEST_DEFAULT,msg) ;
} ;

#ifdef PRINTFD
/*******************************************************************************
* Routine  : Console_printfD
*   Inputs : dest - Destination
*          : format - printf format string
*          : ... - variable arguments
*      IOs : None
*  Returns : 0 for success
*  Globals : TBD
*
* Console_printfD() isn't currently used, so #ifdef-ing it out to avoid
* compiler warnings since it is static.
*
* This is the console version of printf, printing to a string first, then
* sending that string to the console port (initially telnet, but may become
* other things later).  Variable arguments for me are a bit of dark grey magic,
* so this could be buggy.
*
* This is the version that lets the caller specifically call out a destination
* (Telnet/UART) rather than just the active interface.
*
* IMPORTANT NOTES:
* Whatever is generated by this call is sent right away to the console port.
* This code is intended only to be called by routines running the console task!
*  - It isn't set up to be called from any other tasks (not re-entrant)
* While a bit arbitrary, the assumption generally one line of text per call so
* the buffer length is PRINTF_LINELEN which is (currently) 255 bytes.
*******************************************************************************/
static int Console_printfD(int dest, const char* format, ...)
{
   va_list vargs      ; /* varg magic, dunno how to initialize */
   int     rval   = 0 ; /* Routine return value                */
   int     buffed = 0 ; /* bytes in buffer so far              */

   va_start(vargs, format);
   buffed += vsnprintf(printfBuf+buffed, PRINTF_LINELEN-buffed, format, vargs);
   va_end(vargs);

   /* Send the message */
   Console_putsD(dest,printfBuf) ;
   return (rval) ;
}
#endif

/*******************************************************************************
* Routine  : Console_putsD
* Gazintas : dest - Destination
*          : msg - null-terminated message to send to the client
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This is the routine to send a string to the console client. The only
* processing (now) is converting LF to CRLF.  While Console_printf is limited
* to PRINTF_LINELEN bytes, this is not limited. If the string is more than
* PUTS_LINELEN bytes, it is sent in chunks.
*
* This is the version that lets the caller specifically call out a destination
* (Telnet/UART) rather than just the active interface.
*
*******************************************************************************/
static void Console_putsD(int dest, char* msg)
{
   char* dst    = putsBuf ; /* The place to put the parsed line     */
   int   copied = 0       ; /* bytes copied for overflow protection */

   /* copy the message to the putsbuf a character at a time, but save last    */
   /* byte for the EOS.                                                       */
   /* Outer loop is for the whole message regardless of size                  */
   while (*msg != 0)
   {
      /* Inner loop is if the message needs to be sent in chunks.             */
      while ((*msg != 0) && (copied<PUTS_LINELEN-1))
      {
         /* if an LF, copy a CR first! */
         if ('\n' == *msg)
         {
            *(dst++) = '\r' ;
            copied++ ;
         } ;

         /* still checking for space, copy the character now */
         if (copied<PUTS_LINELEN-1)
         {
            *(dst++) = *(msg++) ;
            copied++ ;
         }
      }

      /* Send what I have copied so far to the requested interface */
      if ((DEST_TELNET==dest) || ((DEST_DEFAULT==dest) && (DEST_TELNET==ActiveConsole)))
      {
         netconn_write(newconn, putsBuf, copied, NETCONN_COPY);
      }
      else
      {
    	  UART_Complete = false ;
          HAL_UART_Transmit_DMA(&huart8,(uint8_t*)putsBuf,copied) ;
          while (!UART_Complete) osDelay(1) ;
      }

      /* Reset destination pointers and counters in case there is still more  */
      dst = putsBuf ;
      copied = 0 ;
   }
}

/*******************************************************************************
* Routine  : ConUARTTxComplete
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : UART_Complete
*
* This routine gets called when the Tx DMA for the Console UART is complete.
* Just set UART_Complete to true.  I could have used a mutex (and did
* initially), but this seems just as effective for now.  May go mutexy later.
*******************************************************************************/
void ConUARTTxComplete(void)
{
   UART_Complete = true ;
}

