#ifndef INC_SETSHOW_H_
#define INC_SETSHOW_H_

extern char* cmd_set_cmd ;
extern char* cmd_show_cmd ;
extern char* cmd_ss_help ;

extern TOKENLIST Booleans[] ;

extern int  Cmd_set(int, char**) ;
extern int  Cmd_show(int, char**) ;

extern void SetNum   (char*,char*,int32_t,int32_t,int32_t* ) ;
extern void SetList  (char*,char*,uint8_t*,TOKENLIST*,int) ;
extern void SetOnOff (char*,char*,uint8_t* ) ;
extern void SetStr   (char*,char*,char*,int) ;
extern void SetIP    (char*,char*,uint32_t*) ;
extern void SetNot   (void                 ) ;
extern void ShowIP   (char*,uint32_t) ;

#endif /* INC_SETSHOW_H_ */
