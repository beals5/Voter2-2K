#ifndef INC_BOOTLOADER_H_
#define INC_BOOTLOADER_H_

/* These are just the externally visible items for the bootloader.  For       */
/* #defines, etc, that are common between Bootloader.c and Bootloader2.c, see */
/* BootloaderCom.h.                                                           */

/* This is the magic number that will activate a software update by the       */
/* bootloader on reboot.                                                      */
#define BOOTLOADER_MAGICNUM 0x4d62a3b9

extern void Bootloader(void) ;

#endif /* INC_BOOTLOADER_H_ */
