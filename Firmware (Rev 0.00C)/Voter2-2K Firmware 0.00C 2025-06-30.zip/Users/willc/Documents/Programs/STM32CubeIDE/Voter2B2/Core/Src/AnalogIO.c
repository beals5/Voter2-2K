/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the AnalogIO file.  It is in charge of low level Analog IO         */
/* functions.  These include the MCUs ADCs and DACs (handled indirectly using */
/* DMAs).                                                                     */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - MY_ADC1_FinishInit - Finish ADC1 initialization                         */
/*  - MY_DAC1_FinishInit - Finish DAC1 initialization                         */
/*  - MY_DAC2_FinishInit - Finish DAC1 initialization                         */
/*  - MY_Analog_DMA_FinishInit - Finish DMA initialization for ADC and DAC    */
/*  - Get_RSSI - Get averaged RSSI for last packet                            */
/* Sorta public (__weak overrides) routines are:                              */
/*  - HAL_ADC_ConvHalfCpltCallback - ISR for ADC DMA half-done (ping)         */
/*  - HAL_ADC_ConvCpltCallback - ISR for ADC DMA all done (pong)              */
/*  - HAL_DAC_ConvHalfCpltCallback - ISR for DAC DMA half-done (ping)         */
/*  - HAL_DAC_ConvCpltCallback - ISR for DAC DMA all done (pong)              */
/*                                                                            */
/******************************************************************************/
// TO DO:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "Options.h"
#include "main.h"
#include "AnalogIO.h"
#include "Rx_DSP.h"
#include "Tx_DSP.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/
extern ADC_HandleTypeDef hadc1;
extern ADC_HandleTypeDef hadc2;
extern DAC_HandleTypeDef hdac1;
extern SPI_HandleTypeDef hspi4;

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/********************************************b*********************************/
uint16_t ADC_buf[APKT_RXDMABUF_SIZE] IN_DMADD2 ; /* ADC Ping-Pong DMA buffer  */

/* The DAC buffer needs to be 32-bit aligned as even though the samples are   */
/* 16-bit, I'm DMAing to DAC1 (main output) and DAC2 (debug output) as a      */
/* stereo pair and tgat us a 32-bit write.                                    */
uint16_t DAC_buf[APKT_TXDMABUF_SIZE] IN_DMADD2 __attribute__ ((aligned (4))) ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static uint16_t RSSI_buf[RSSI_DMABUF_SIZE] IN_DMADD2 ; /* RSSI sample buffer  */

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static HAL_StatusTypeDef HAL_DAC_Start_DualDMA(DAC_HandleTypeDef* hdac, uint32_t* pData, uint32_t Length, uint32_t Alignment) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : MY_ADC1_FinishInit
* Gazintas : Nothing
* IOs      : None.
* Returns  : Nothing
* Globals  : hadc1
*
* This routine wraps up any final initialization of the ADC after the
* MX_INIT routines.  Code put here to lessen the likelihood of losing it.
*******************************************************************************/
void MY_ADC1_FinishInit(void)
{
   /* No finishing touches needed! After MX_INIT routines, can go straight to */
   /* the DMA routines.                                                       */
}
/*******************************************************************************
* Routine  : MY_DAC1_FinishInit, MY_DAC2_FinishInit
* Gazintas : Nothing
* IOs      : None.
* Returns  : Nothing
* Globals  : hdac1
*
* This routine wraps up any final initialization of the DACs after the
* MX_INIT routines.  Code put here to lessen the likelihood of losing it.
* Start off by manually setting the DAC output to 1/2 VCC ("ground"), then
* enabling it.
*******************************************************************************/
void MY_DAC1_FinishInit(void)
{
   /* Set the initial DAC value to "ground" (1/2 VREF) and enable it */
   HAL_DAC_SetValue(&hdac1,DAC_CHANNEL_1,DAC_ALIGN_12B_R,2048) ;
   HAL_DAC_Start(&hdac1,DAC_CHANNEL_1) ;
}

void MY_DAC2_FinishInit(void)
{
   /* Set the initial DAC value to "ground" (1/2 VREF) and enable it */
   HAL_DAC_SetValue(&hdac1,DAC_CHANNEL_2,DAC_ALIGN_12B_R,2048) ;
   HAL_DAC_Start(&hdac1,DAC_CHANNEL_2) ;
}

/*******************************************************************************
* Routine  : MY_Analog_DMA_FinishInit
* Gazintas : None.
* IOs      : None.
* Returns  : Nothing
* Globals  : hdac1,hdac3
*
* This routine wraps up any final initialization of the DMAs for the ADC and
* DAC after the MX_INIT routines.  Code put here to lessen the likelihood of
* losing it.
*
* Should the need arise to change the trigger source during operation, first
* call MY_Analog_DMA_Stop(), then call this again with the new trigger source.
*
* Setting up the DMA is the second step to conversions going.  This sets up
* a circular DMA twice the size needed for a packet (320 samples for 2x 160
* sample packets)** where I used the half-full interrupt and full interrupts
* to know which half just got filled.  This way means the DMA is "set and
* forget", no need to twiddle any pointers each interrupt.
* For the RSSI ADC, it is just a single 5-sample circular DMA.
* ** I now support variable packet sizes, so that is one example.
*******************************************************************************/
void MY_Analog_DMA_FinishInit(void)
{
   /* For the DAC, start off with a clean buffer of "0V" (mid value) for both */
   /* The ping and pong buffers and the main and debug channels for both.     */
   Tx_ClearPacket(DAC_buf,MAINBUF) ;
   Tx_ClearPacket(DAC_buf,DEBUGBUF) ;
   Tx_ClearPacket(DAC_buf+APKT_SAMPLES*2,MAINBUF) ;
   Tx_ClearPacket(DAC_buf+APKT_SAMPLES*2,DEBUGBUF) ;

   /* ADC and DAC should be ready for DMAing          */
   /* Set up the DMAs here...                         */
   /* Final step after this will be enabling TIM2.    */
   /* NOTE!!! HAL_DAC_Start_DualDMA() isn't an ST HAL */
   /* routine!! Weirdly, they don't have a HAL routine*/
   /* for dual DMA, so I wrote my own.  It is below.  */
   HAL_DAC_Start_DualDMA(&hdac1,(uint32_t*)DAC_buf,APKT_RXDMABUF_SIZE,DAC_ALIGN_12B_R) ;
   HAL_ADC_Start_DMA(&hadc1,(uint32_t*)ADC_buf,APKT_RXDMABUF_SIZE) ;

   /* Also set up DMA for ADC2 for RSSI info. */
   HAL_ADC_Start_DMA(&hadc2,(uint32_t*)RSSI_buf,RSSI_DMABUF_SIZE) ;

   /* The HAL enables full and half-full DMA interrupts by default. */
   /* I don't need or want them for RSSI sampling using ADC2!       */
   __HAL_DMA_DISABLE_IT(hadc2.DMA_Handle,DMA_IT_TC) ;
   __HAL_DMA_DISABLE_IT(hadc2.DMA_Handle,DMA_IT_HT) ;
}

/*******************************************************************************
* Routine  : Get_Analog_RSSI
* Gazintas : Nothing
* IOs      : None.
* Returns  : Averaged RSSI (0-255 range)
* Globals  : RSSI_buf
*
* The RSSI ADC free runs sampling the RSSI value every 4ms and plunks the
* results in a 5-sample ring buffer.  So, to get the RSSI of the last packet
* of digitized samples, just average the contents of that buffer, no need to
* know which is most recent, just all five samples. They likely aren't
* perfectly synchronized, but it is an average, so OK.
* For now I just take ADC values and divide by 16 to convert 0-4095 to 0-255.
* When I get to calibrating, this will get a bit more complicated.
*******************************************************************************/
uint8_t Get_Analog_RSSI(void)
{
   uint16_t tval = 0 ;

   /* Add up the five values.  Not worried about overflows as the A/D values  */
   /* are 12-bits max.                                                        */
   tval = RSSI_buf[0]+RSSI_buf[1]+RSSI_buf[2]+RSSI_buf[3]+RSSI_buf[4] ;

   /* Divide by five then by 16 for averaged 8-bit value */
   return(uint8_t)(tval/5/16) ;
}

/*******************************************************************************
* Routines : HAL_ADC_ConvCpltCallback
*            HAL_ADC_ConvHalfCpltCallback
* Gazintas : hdac - handle to DAC
* IOs      : None.
* Returns  : Nothing
* Globals  : None
*
* These are the ISRs for the ADC DMA. The buffer is twice the size needed
* for a packet, so the full and half-full IRQs are essentially the Ping and
* Pong interrupts for a ping pong buffer.
*  - HAL_ADC_ConvHalfCpltCallback means first half just got filled
*  - HAL_ADC_ConvCpltCallback means second half just got filled
* These routines just pass along the respective buffer address to the common
* packet handler in RxDSP.c.
* There shouldn't be any interrupts from other ADC DMAs, but checking the
* handle anyways.
*******************************************************************************/
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
   if (&hadc1==hadc)
   {
      Rx_EnqPacket(ADC_buf+APKT_SAMPLES) ;
   }
   /* ignore any IRQs from ADC2 or ADC3 */
}

void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *hadc)
{
   if (&hadc1==hadc)
   {
      Rx_EnqPacket(ADC_buf) ;
   }
   /* ignore any IRQs from ADC2 or ADC3 */
}

/*******************************************************************************
* Routines : HAL_DAC_ConvCpltCallbackCh1
*            HAL_DAC_ConvHalfCpltCallbackCh1
* Gazintas : hdac - handle to DAC
* IOs      : None.
* Returns  : Nothing
* Globals  : None
*
* These are the ISRs for the DAC DMA.  The DAC runs continuously with the
* DMA in circular mode with the buffer broken into a ping and pong buffer.
* Knowing which interrupt happened tells SW which buffer is active, so it
* should fill the other.
*  - HAL_DAC_ConvHalfCpltCallbackCh1 means first half just finished sending
*  - HAL_DAC_ConvCpltCallbackCh1 means second half just finished sending
*  These routines simply pass the buffer address to the common handler in
*  TxDSP.c
*  There is only one DAC, but I check the handle anyway.
*******************************************************************************/
void HAL_DAC_ConvCpltCallbackCh1 (DAC_HandleTypeDef *hdac)
{
   if (&hdac1==hdac)
   {
      Tx_DeqPacket(DAC_buf+APKT_SAMPLES*2) ;
   }
}

void HAL_DAC_ConvHalfCpltCallbackCh1 (DAC_HandleTypeDef *hdac)
{
   if (&hdac1==hdac)
   {
      Tx_DeqPacket(DAC_buf) ;
   }
}


/*******************************************************************************
* Routine  : HAL_DAC_Start_DualDMA
* Gazintas : pData - Pointer to data to DMA
*          : Length - DMA buffer length (in words)
*          : Alignment - Data alignment
* IOs      : hdac - DAC handle (must be Channel 1)
* Returns  : Error code
* Globals  : TBD
*
* This is a copy of ST's HAL_DAC_Start_DMA routine modified to support dual
* channels of a single DAC.  The HAL drivers seem to have missed support for this
* mode.  Parameters are all the same except for no channel parameter.  DMAing
* is centered around channel 1.  Main modifications are changing the DMA
* destination address to the dual registers of the DMA and enabling both
* channels.
*
* For setup in STM32CubeMX, set up both DACs outputs, but enable DMA for only
* channel 1 and set it up for word transfers, not half-word.
*******************************************************************************/
static HAL_StatusTypeDef HAL_DAC_Start_DualDMA(DAC_HandleTypeDef* hdac, uint32_t* pData, uint32_t Length, uint32_t Alignment)
{
  HAL_StatusTypeDef status;
  uint32_t tmpreg = 0U;

  /* Check the parameters */
  assert_param(IS_DAC_CHANNEL(Channel));
  assert_param(IS_DAC_ALIGN(Alignment));

  /* Process locked */
  __HAL_LOCK(hdac);

  /* Change DAC state */
  hdac->State = HAL_DAC_STATE_BUSY;

  /* Set the DMA transfer complete callback for channel1 */
  hdac->DMA_Handle1->XferCpltCallback = DAC_DMAConvCpltCh1;

  /* Set the DMA half transfer complete callback for channel1 */
  hdac->DMA_Handle1->XferHalfCpltCallback = DAC_DMAHalfConvCpltCh1;

  /* Set the DMA error callback for channel1 */
  hdac->DMA_Handle1->XferErrorCallback = DAC_DMAErrorCh1;

  /* Enable the DAC channel1 DMA request (will support both channels) */
  SET_BIT(hdac->Instance->CR, DAC_CR_DMAEN1);

  /* Select the right dual channel destination address for the DAC */
  switch(Alignment)
  {
    case DAC_ALIGN_12B_R:
      /* Get DHR12R1 address */
      tmpreg = (uint32_t)&hdac->Instance->DHR12RD;
      break;
    case DAC_ALIGN_12B_L:
      /* Get DHR12L1 address */
      tmpreg = (uint32_t)&hdac->Instance->DHR12LD;
      break;
    case DAC_ALIGN_8B_R:
      /* Get DHR8R1 address */
      tmpreg = (uint32_t)&hdac->Instance->DHR8RD;
      break;
    default:
      break;
  }

  /* Enable the DMA channel */
  /* Enable the DAC DMA underrun interrupt */
  __HAL_DAC_ENABLE_IT(hdac, DAC_IT_DMAUDR1);

  /* Enable the DMA channel */
  status = HAL_DMA_Start_IT(hdac->DMA_Handle1, (uint32_t)pData, tmpreg, Length);

  /* Process Unlocked */
  __HAL_UNLOCK(hdac);

  if (status == HAL_OK)
  {
    /* Enable both DAC channels */
    __HAL_DAC_ENABLE(hdac, DAC_CHANNEL_1);
    __HAL_DAC_ENABLE(hdac, DAC_CHANNEL_2);
  }
  else
  {
    hdac->ErrorCode |= HAL_DAC_ERROR_DMA;
  }

  /* Return function status */
  return status;
}
