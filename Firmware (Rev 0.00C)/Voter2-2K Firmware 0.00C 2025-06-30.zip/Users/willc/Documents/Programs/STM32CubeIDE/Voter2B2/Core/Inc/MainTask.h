#ifndef INC_MAINTASK_H_
#define INC_MAINTASK_H_

void MainTask(void const*) ;

#endif /* INC_MAINTASK_H_ */
