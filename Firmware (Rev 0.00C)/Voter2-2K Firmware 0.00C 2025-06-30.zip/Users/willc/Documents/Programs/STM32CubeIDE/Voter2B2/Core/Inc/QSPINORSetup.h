#ifndef INC_QSPINORSETUP_H_
#define INC_QSPINORSETUP_H_

void QSPINOR_Setup(QSPI_HandleTypeDef*) ;
void QSPINOR_Verify(void) ;

#endif /* INC_QSPINORSETUP_H_ */
