/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Update file.  It is the UI and functional part of the firmware */
/* updater--or at least it will be.  For now it is just a series of erase/    */
/* write/read tests for the update flash.                                     */
/******************************************************************************/
/* Here is how memory is mapped from build address space to SPI (download     */
/* flash) address pace to QSPI (execuable flash) address space back to build  */
/* address space.  Note that for downloads using the debugger, the SPI step   */
/* is bypassed.                                                               */
/*                                                                            */
/* Executable   QSPI        SPI                                               */
/* Image        Image       Image                                             */
/* ==========   =========== =============                                     */
/* 0x00000000   0x00000000  0x00000000                                        */
/* ITCM (64K)   ITCM (64K)  ITCM (64K)                                        */
/* 0x0000ffff   0x0000ffff  0x0000ffff                                        */
/*                                                                            */
/* 0x08000000   N/A, ST     0x001e0000                                        */
/* Int Flash    Internal    ST internal                                       */
/* (128K)       Flash       flash image                                       */
/* 0x0801ffff               0x001fffff                                        */
/*                                                                            */
/* 0x09010000   0x00010000  0x00010000                                        */
/* QSPI Flash   QSPI Flash  QSPI Flash                                        */
/* (4M-64K)     (4M-192K)   (4M-192K)                                         */
/* 0x091dffff   0x091dffff  0x091dffff                                        */
/*                                                                            */
/* Put into text, the first 64K of both the SPI and QSPI flash is where the   */
/* ITCM image goes.  The last 128K of the SPI flash is where the STM32's      */
/* internal flash image goes.  The last 128K of the QSPI flash is effectively */
/* unusable as it can't get loaded by the SPI flash.                          */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Cmd_update - Update CLI command (just starts a test for now)            */
/*                                                                            */
/******************************************************************************/
// TO DO:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "lwip.h"
#include "lwip/api.h"

#include "string.h"
#include "Options.h"
#include "main.h"
#include "ConsoleTask.h"
#include "Settings.h"
#include "SPINOR.h"
#include "Utils.h"
#include "Setshow.h"
#include "Tftp.h"
#include "Utils.h"
#include "SPINOR.h"
#include "RTC.h"
#include "Timers.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
//#define TESTMODE /* Temporary ability to #ifdef out my update code */

#ifdef TESTMODE

#define SECLEN 4096

#else

#define DLD_DOWNLOAD 1
#define DLD_VERIFY 2

#define VERSTRLEN   80 /* Server Firmware data string length     */
#define FNAMERLEN   40 /* Server Firmware filename string length */
#define NTOKENS      5 /* max argv tokens                        */
#define MAXSRECLINE 80 /* Max S-Record line length (by spec!)    */
#define SPIBUFLEN  256 /* SPI DMA Buffer length                  */

enum
{
   CMD_CHECK = 1,
   CMD_DOWNLOAD,
   CMD_VERIFY,
   CMD_DUMP,
   CMD_ERASE,
   CMD_PROGRAM
} UPDCOMMANDS ;

#endif

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
char* cmd_update_cmd  = "update" ;
#ifdef TESTMODE
char* cmd_update_help = "update - [nsecs] Tests the update flash\n"
                        "         nsecs - number of sectors to test\n";
#else
char* cmd_update_help = "update - [check|download|verify|program|erase|dump] Software update\n"
                        "         check - check for newer version\n"
                        "         download - download latest version\n"
                        "         verify - Verify download\n"
                        "         program - Program downloaded version\n"
                        "         erase - Erase download flash\n"
                        "         dump [addr] [len] - Dump download flash contents (hex params)\n" ;
#endif

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
#ifdef TESTMODE
static uint8_t buf[SECLEN] IN_DMADD2 = {0} ;
#else

static TOKENLIST UpdCmds[] =
{
   {"check"    ,CMD_CHECK    },
   {"download" ,CMD_DOWNLOAD },
   {"verify"   ,CMD_VERIFY   },
   {"dump"     ,CMD_DUMP     },
   {"erase"    ,CMD_ERASE    },
   {"program"  ,CMD_PROGRAM  },
   {NULL       ,0            }
} ;

static char DownloadFname[FNAMERLEN] = {0} ;
static uint8_t SpiBuf[SPIBUFLEN] IN_DMADD2 = {0} ;
static int good_download = false ;

#endif

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void Update_Check(void) ;
static void Update_DownVer(int) ;
static void Update_Dump(char*,char*) ;
static void Update_Erase(void) ;
static void Update_Program(void) ;
static int  GetTextLine(char*,int*,int,char*,int*) ;
static int  ParseSrecLine(char*,int*,uint32_t*,int*,uint8_t*) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

#ifdef TESTMODE
/*******************************************************************************
* Routine  : Cmd_update
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command initiates a test of the update flash. The first parameter is the
* number of sectors (4KBytes each) to test.  The sectors are erased, verified
* erased, then programmed with randomish data and the programmed data verified.
*******************************************************************************/
int Cmd_update (int argc, char* argv[])
{
   static int nonce = 5 ; /* more randomness for testing */

   int error  = false ; /* Parsing error flag */
   int errors = 0     ; /* byte error counter */
   int nsecs  = 0     ; /* Sectors to test    */
   int secnum = 0     ; /* Sector counter     */
   int i      = 0     ; /* General counter    */

   /* See if no arguments, invalid arguments, or too big for the MX24L3233.  */
   error = (2!=argc) ;
   if (!error) nsecs=parse_num(argv[1],1,8192,&error) ;
   if (!error) error |= ((SPINOR_MX25L3233==SPINOR_Type) && (nsecs>1024)) ;

   if (error)
   {
      Console_printf("Parameter must be the number of sectors to test.\n - 1024 max for MX25L3233, 8192 for MX25L256.\n") ;
      Console_printf("You have an %s.\n",(SPINOR_MX25L3233==SPINOR_Type)?"MX25L3233":"MX25L25645") ;
   }
   else /* ready to go! */
   {
      /* First erase all requested sectors */
      Console_printf("Erasing...\n") ;
      for (secnum=0;secnum<nsecs;secnum++)
      {
         SpiNor_erase(ERASE_SECTOR,secnum*SECLEN) ;
      }

      /* Verify each sector is erased */
      for (secnum=0;secnum<nsecs;secnum++)
      {
         memset(buf,0,SECLEN) ;
         SpiNor_read(buf,secnum*SECLEN,SECLEN) ;
         errors = 0 ;
         for (i=0;i<SECLEN;i++) if (buf[i]!=0xff) errors++ ;
         if (0!=errors)
         {
            Console_printf("Sector #%d: %d bytes not erased.\n",secnum,errors) ;
            error = true ;
         }
      }

      /* If erasing went OK time to start programming! */
      if (!error)
      {
         Console_printf("Erase successful, writing...\n") ;

         /* Write some random data to each sector */
         for (secnum=0;secnum<nsecs;secnum++)
         {
            /* Some random-ish data unique to index and sector number and a nonce */
            for (i=0;i<SECLEN;i++) buf[i] = (uint8_t)(0xff&(((i+secnum*37+nonce*57)*5971)%781)) ;
            SpiNor_write(buf,secnum*SECLEN,SECLEN) ;
        }

        /* Verify the written data in each sector */
         for (secnum=0;secnum<nsecs;secnum++)
         {
            memset(buf,0,SECLEN) ;
            SpiNor_read(buf,secnum*SECLEN,SECLEN) ;
            errors = 0 ;
            for (i=0;i<SECLEN;i++) if (buf[i]!= (uint8_t)(0xff&(((i+secnum*37+nonce*57)*5971)%781)) ) errors++ ;
            if (0!=errors)
            {
               Console_printf("Sector #%d: %d bytes didn't match.\n",secnum,errors) ;
               error = true ;
            }
         }
         if (!error) Console_printf("Write successful.\n") ;
      }
   }
   /* so that if the test is re-run, it won't the same random-ish data each time. */
   nonce += 3;
   return(0) ;
}
#else
/*******************************************************************************
* Routine  : Cmd_update
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command manages the software update process.  It is TFTP-based, the IP
* address of the TFTP server is a set command.
*
* With an argument of 'check', we download the file "PROJECTNAME.txt" (where
* PROJECTNAME is the #define in Options.h) from the TFTP server and that will
* have the version and filename of the latest software version.  That will be
* reported.
*
* With an argument of download, we download the filename noted in the check
* command into the download flash and verify its integrity.
*
* With an argument of program we program the XIP flash and STM32 internal flash
* with the verified image in the download flash.  We have to reboot into a
* download mode to do this, then boot again into the new code.
*******************************************************************************/
int Cmd_update (int argc, char* argv[])
{
   int error   = false ; /* Parsing error flag */
   int command = 0     ; /* Command token      */

   /* Expecting only one argument except for dump which has two */
   error = (argc<2) ;
   if (!error) command = parse_token(UpdCmds,argv[1],&error) ;
   error |= ((CMD_DUMP==command) && (argc!=4)) ;
   error |= ((CMD_DUMP!=command) && (argc!=2)) ;

   if (error)
   {
      Console_printf("First parameter must be check, download, verify, dump, or program.\n") ;
      Console_printf("Dump command requires a hex starting address and length.\n") ;
   }
   else
   {
      /* Go run the appropriate command! */
      switch (command)
      {
         case CMD_CHECK   : Update_Check()               ; break ;
         case CMD_DOWNLOAD: Update_DownVer(DLD_DOWNLOAD) ; break ;
         case CMD_VERIFY  : Update_DownVer(DLD_VERIFY)   ; break ;
         case CMD_DUMP    : Update_Dump(argv[2],argv[3]) ; break ;
         case CMD_ERASE   : Update_Erase()               ; break ;
         case CMD_PROGRAM : Update_Program()             ; break ;
         default          :                                break ;
      }
   }
   return (0) ;
}

/*******************************************************************************
* Routine  : Update_Check
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : DownloadFname
*
* This routine executes the check command, downloading the PROJECTNAME.txt file
* from the TFTP server and reporting the latest version available for download.
*******************************************************************************/
static void Update_Check(void)
{
   TFTP_CONTEXT Context       = {0} ; /* TFTP Session context    */
   char  fname[FNAMELEN]      = {0} ; /* Project filename        */
   char  VerString[VERSTRLEN] = {0} ; /* Server Version string   */
   int   bytes                =  0  ; /* Byte counter            */
   int   My_argc              =  0  ; /* My locally parsed argc  */
   char* My_argv[NTOKENS]     = {0} ; /* My locally parsed argvs */

   /* "Delete" any previously stored filename in case this read fails.        */
   memset(DownloadFname,0,FNAMERLEN) ;

   /* The file we want is the project name (PROJECTNAME #define).txt */
   strcpy(fname,PROJECTNAME) ;
   strcat(fname,".txt") ;

   /* Contact the TFTP Server... */
   ShowIP("Contacting TFTP server at",Settings.TFTP_Addr) ;

   TFTP_Init(Settings.TFTP_Addr,&Context) ;
   TFTP_SendRRQ(fname,TFTP_MODE_ASCII,&Context) ;
   /* No errors even possible yet! Keep plunking along */
   bytes = TFTP_GetData(&Context) ; /* Get the version string */
   Show_TFTP_Err(&Context) ; /* Prints error if one happened */

   /* If no error and <512 byte response, all good, send Ack. */
   if ((!Context.Error) && (512!=bytes)) TFTP_SendAck(&Context) ;

   /* If 512 bytes (or more), not expected, send back an error to the server  */
   if (512==bytes)
   {
      Context.Error = TFTPERR_BADLEN ;
      TFTP_SendErr(&Context) ;
   }

   /* If we got through all that without any errors, print out the version    */
   /* string we got.                                                          */
   if (!Context.Error)
   {
      strncpy(VerString,(char*)TFTP_Buf+4,VERSTRLEN) ;
      Console_printf("Version on server: %s\n",VerString) ;

      /* The filename is the 3rd parameter in the line, so use my CLI line    */
      /* parser to pick it out and save it in case the user wants to download */
      /* it.                                                                  */
      ParseLine((char*)TFTP_Buf+4,&My_argc,My_argv) ;
      strncpy(DownloadFname,My_argv[2],FNAMERLEN) ;
      Console_printf("Running version: %s %s\n",PROJECTREV,PROJECTDATE) ;
      Console_printf(" Server version: %s %s\n",My_argv[0],My_argv[1]) ;
      Console_printf(" Server    File: %s\n",DownloadFname) ;
   }
   else
   {
      Console_printf("Unable to obtain version from server.\n") ;
      memset(DownloadFname,0,FNAMERLEN) ;
   }

   /* All done, shut down the port. */
   TFTP_Terminate(&Context) ;
}

/*******************************************************************************
* Routine  : Update_DownVer
*   Inputs : mode: DLD_DOWNLOAD or DLD_VERIFY
*      IOs : None
*  Returns : Nothing
*  Globals : DownloadFname
*
* This routine downloads the Motorola S-Record file identified by the update
* check command and either programs it into the download flash or verifies that
* the image in flash matches the downloaded S-Record data.
* See address mapping in the file header.
*******************************************************************************/
static void Update_DownVer(int mode)
{
   TFTP_CONTEXT Context            = {0}   ; /* TFTP Session context          */
   char     SrecLine[MAXSRECLINE]  = {0}   ; /* S-record line                 */
   int      srec_srcidx            =  0    ; /* S-record source index         */
   int      srec_dstidx            =  0    ; /* S-record destination index    */
   int      bytes                  =  0    ; /* Byte counter                  */
   int      GotALine               = false ; /* Valid line flag               */
   int      SrecType               =  0    ; /* S-Record type                 */
   uint32_t SrecAddr               =  0    ; /* S-Record Address              */
   uint8_t  SrecBin[MAXSRECLINE/2] = {0}   ; /* S-Record data                 */
   int      NumBytes               =  0    ; /* Data field byte count         */
   uint32_t BytesProcessed         =  0    ; /* Total bytes processed         */
   uint32_t errors                 =  0    ; /* Verify errors accumulator     */
   uint32_t StartTime              =  0    ; /* Programming start time        */
   uint32_t ReportTime             =  0    ; /* Programming Report time       */
   int      i                      =  0    ; /* general counter               */

   /* Make sure we have a filename first */
   if (0==DownloadFname[0])
   {
      Console_printf("Please enter 'update check' first to check the version on server.\n") ;
   }
   else
   {
      /* If download mode, first erase the download flash */
      if (DLD_DOWNLOAD==mode)
      {
         Console_printf("Erasing download flash, this can take up to %d seconds...\n",(SPINOR_MX25L3233==SPINOR_Type)?30:210) ;
         SpiNor_erase(ERASE_ALL,0) ;
      }

      /* Contact the TFTP Server... */
      ShowIP("Contacting TFTP server at",Settings.TFTP_Addr) ;

      TFTP_Init(Settings.TFTP_Addr,&Context) ;
      TFTP_SendRRQ(DownloadFname,TFTP_MODE_ASCII,&Context) ;
      /* No errors even possible yet! Keep plunking along */
      StartTime = HAL_GetTick() ;
      ReportTime = StartTime+1000 ;

      /* OK, start reading data via TFTP parsing S-Records! */
      do
      {
        bytes = TFTP_GetData(&Context) ; /* Get a packet of data */
        if (!Context.Error) TFTP_SendAck(&Context) ;
        srec_srcidx = 0 ; /* With new packet, reset source index. */

        if (!Context.Error)
           {
              do /* while not end of the packet */
              {
                 GotALine = GetTextLine((char*)TFTP_Buf+4,&srec_srcidx,bytes,SrecLine,&srec_dstidx) ;
                 if (GotALine)
                 {
                    Context.Error = ParseSrecLine(SrecLine,&SrecType,&SrecAddr,&NumBytes,SrecBin) ;

                    /* Only care if no errors and S3 S-Record type.  Ignore   */
                    /* S0 and S7 record types, no data in them.               */
                    if ((!Context.Error) && ('3'==SrecType))
                    {
                       /* Translate Target XIP flash memory address space to  */
                       /* Download flash memory address space (and check for  */
                       /* valid addressing too).                              */
                       if ((SrecAddr>=0x08000000) && (SrecAddr+NumBytes<=0x0801ffff))
                       {
                          /* Map STM32 internal flash to end of SPI NOR */
                          SrecAddr += 0x001e0000 ;
                       }
                       else if ((SrecAddr>=0x90000000) && (SrecAddr+NumBytes<=((SPINOR_MX25L3233==SPINOR_Type)?0x903fffff:0x91ffffff)))
                       {
                          /* Map QSPI NOR to start of SPI NOR */
                          SrecAddr -= 0x90000000 ;
                       }
                       else
                       {
                          Context.Error = TFTPERR_BADADDR ;
                       }
                    }

                    /* If no errors, ready to program/verify SPI Flash!!! */
                    if ((!Context.Error) && ('3'==SrecType))
                    {
                       if (DLD_DOWNLOAD==mode)
                       {
                          /* Copy to DMA-able space, then program */
                          memcpy(SpiBuf,SrecBin,NumBytes) ;
                          SpiNor_write(SpiBuf,SrecAddr,NumBytes) ;
                          BytesProcessed += NumBytes ;
                       }
                       else
                       {
                          SpiNor_read(SpiBuf,SrecAddr,NumBytes) ;
                          for (i=0;i<NumBytes;i++) if (SpiBuf[i]!=SrecBin[i]) errors++ ;
                          BytesProcessed += NumBytes ;
                       }

                       /* Report progress every second */
                       if (HAL_GetTick()>ReportTime)
                       {
                          Console_printf("%d bytes processed\r",BytesProcessed) ;
                          ReportTime += 1000 ;
                       }
                    }

                    /* start off with S-Record line clean for the next line */
                    srec_dstidx = 0 ;
                    memset(SrecLine,0,MAXSRECLINE) ;

                 }
              } while (GotALine && (!Context.Error)) ; /* Keep getting lines until the buffer runs out */
           }
      } while ((bytes==512) && (!Context.Error)) ; /* until error or EOF */
   }

   if (!Context.Error)
   {
      // Do a CRC verification before declaring the download good.
      Console_printf("Download complete, %d bytes processed (%d%% of flash) in %d seconds\n",
         BytesProcessed,BytesProcessed*100/((SPINOR_MX25L3233==SPINOR_Type)?4194304:33554432),
         (HAL_GetTick()-StartTime)/1000) ;
      good_download = true ;

      /* Even if no TFTP errors, still report any verify errors if there were any */
      if (DLD_VERIFY==mode)
      {
         Console_printf("%d flash programming errors\n",errors) ;
         if (errors>0) good_download = false ;
      }
   }
   else
   {
      Show_TFTP_Err(&Context) ;
      Console_printf("Errors downloading the new image.\n") ;
      good_download = false ;
   }

   /* All done, shut down the port. */
   TFTP_Terminate(&Context) ;
}

/*******************************************************************************
* Routine  : Update_Dump
*   Inputs : taddr - starting address (ASCII hex)
*          : tlen - Number of bytes to dump  (ASCII hex)
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This routine dumps a range of memory from the SPI download flash.
*******************************************************************************/
static void Update_Dump(char* taddr, char* tlen)
{
   uint32_t saddr   = 0    ; /* Dump starting address */
   uint32_t len     = 0    ; /* Dump length           */
   uint32_t i       = 0    ; /* General counter       */
   uint32_t j       = 0    ; /* General counter       */
   int      success = true ; /* error counter         */

   /* parse the starting address and length */
   saddr = ReadHexVar(taddr,&success) ;
   len   = ReadHexVar(tlen ,&success) ;

   /* Print 16 bytes at a time in ASCII hex and ASCII (if printable) */
   if (success)
   {
      for (i=0;i<len;i+=16)
      {
         Console_printf("%8.8x: ",saddr+i) ;
         SpiNor_read(SpiBuf,saddr+i,16) ;
         for (j=0;j<16;j++)
         {
            Console_printf("%2.2x ",SpiBuf[j]) ;
         }
         Console_printf("| ") ;

         for (j=0;j<16;j++)
         {
            Console_printf("%c",isgraph(SpiBuf[j])?SpiBuf[j]:'.') ;
         }
         Console_printf("\n") ;
      }
   }
   else
   {
      Console_printf("Address/length parameter error") ;
   }
}

/*******************************************************************************
* Routine  : Update_Erase
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This routine erases the download flash.  It gets erased anyways as part of
* the download command too, so this is mainly for debugging.
*******************************************************************************/
static void Update_Erase(void)
{
   uint32_t MaxAddr = 0 ; /* Flash ending address         */
   uint32_t idx     = 0 ; /* Block check starting address */
   uint32_t percent = 0 ; /* Percent done                 */
   uint32_t i       = 0 ; /* General counter              */
   uint32_t errors  = 0 ; /* Error counter                */

   Console_printf("Erasing download flash, this can take up to %d seconds...\n",(SPINOR_MX25L3233==SPINOR_Type)?30:210) ;
   SpiNor_erase(ERASE_ALL,0) ;

   /* Max address depends on SPINOR attached */
   MaxAddr = (SPINOR_MX25L3233==SPINOR_Type)?4194304:33554432 ;

   Console_printf("Verifying erase...\n") ;
   /* Read in chunks of data and verify all 0sff's */
   for (idx=0;idx<MaxAddr;idx+=SPIBUFLEN)
   {
      SpiNor_read(SpiBuf,idx,SPIBUFLEN) ;
      for (i=0;i<SPIBUFLEN;i++) if (SpiBuf[i]!=0xff) errors++ ;
      if (idx>=percent*MaxAddr/100)
      {
         Console_printf("%2d%%...\r",percent) ;
         percent += 10 ;
      }
   }

   Console_printf("100%%..\n") ;
   Console_printf("Verification complete, %d errors.\n",errors) ;
   good_download = false ;

}

/*******************************************************************************
* Routine  : Update_Program
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This routine fires of the programming sequence to program the STM32 internal
* flash and QSPI flash with the image in the SPI download flash.  No real work
* here, I just program the magic number into the RTCMs non-volatile memory and
* initiate a reboot.  The downloader will recognize the magic number on reboot
* and do the update.  Or at least it will when I get it working! :)
*******************************************************************************/
static void Update_Program(void)
{
   if (!good_download)
   {
      Console_printf("No good image in download flash.\n") ;
   }
   else
   {
      Console_printf("Programming executable flash.  This involves two reboots.\n") ;
      Console_printf("The process can take up to 90 seconds.\n") ;
      Console_printf("Logging info is available on the debug ports UART pins.\n") ;
      HAL_Delay(200) ; /* Time for the above text to go out... */
      RTC_Bootloader_Enable(true) ;
      RebootNow() ;
   }
}

/*******************************************************************************
* Routine  : GetTextLine
*   Inputs : source - source data (512-byte chunks)
*          : srclen - Bytes in source data
*      IOs : srcidx - Index into source data for copying (gets updated)
*          : dest - The parsed out line
*          : dstidx - index into the destination (gets updated)
*  Returns : True if a line is ready, false if not yet.
*  Globals : None
*
* This routine copies a full line of text at a time from the source buffer that
* is fixed size and could contain multiple (or even fractional) lines in it.
* If the copying gets to the end of the source buffer without reaching the end
* of the line it returns a false expecting to be called back again with a new
* buffers worth of data.
* The end of the line can be any combination of CRs and LFs.
* The line is terminated by an EOS, the CRs and LFs are not copied.
*******************************************************************************/
static int GetTextLine(char* source, int* srcidx, int srclen, char* dest, int* dstidx)
{
   static int LastWasCrLf   = false ; /* For noting paired CR/LFs  */
   int        LineReady     = false ; /* Flag to say line is ready */
   int        HaveSomething = false ; /* Have parsed some data     */

   /* Copying stops if we get to the end of either buffer or a line of text   */
   while ((*srcidx<srclen) && (*dstidx<MAXSRECLINE) && !LineReady)
   {
      /* If printable ASCII copy it over */
      if ((source[*srcidx]>=' ') && (source[*srcidx]<='`'))
      {
         dest[*dstidx] = source[*srcidx] ;
         (*srcidx)++ ;
         (*dstidx)++ ;
         LastWasCrLf = false ;
         HaveSomething = true ;
      }
      /* If a CR/LF, terminate the destination string and if it was the first */
      /* CR/LF note that the destination line is ready to be parsed.          */
      else if (('\r'==source[*srcidx]) || ('\n'==source[*srcidx]))
      {
         (*srcidx)++ ;
         if (!LastWasCrLf) LineReady = true ;
         LastWasCrLf = true ;
      }
   }

   /* If we got to the end of the file and we have some source line material  */
   /* without a CR/LF at the end, make it legit.                              */
   if ((*srcidx==srclen) && (srclen<512) && HaveSomething) LineReady = true ;

   //if (LineReady) Console_printf("TFTP Line >%s<\n",dest) ;
   return (LineReady) ;
}

/*******************************************************************************
* Routine  : ParseSrecLine
*   Inputs : SrecLine - Line of text that should be an S-Record
*      IOs : SrecType - S-Record type (0,3,7 allowed)
*          : SrecAddr - Address of parsed S-Record data
*          : NumBytes  - Number of data bytes in S-Record data
*          : SrecBin - Data of parsed S-Record data
*          :
*  Returns : error state
*  Globals : None (yet)
*
* This routine parses out an S-Record line of text.  Supported S-Record types
* are 0 (header), 3 (32-bit addressed data) and 7 (32-bit terminator). I don't
* think I need to support type 5 (counter).
* Of note, I just have one error code, BADSREC.  Knowing the exact "badness" is
* only handy for initial debugging.  For actual use, just care if its good or
* bad only.  Details don't matter.
*******************************************************************************/
static int ParseSrecLine(char* SrecLine, int* SrecType, uint32_t* SrecAddr,int* NumBytes,uint8_t* SrecBin)
{
 //int      SrecType               =  0   ; /* S-Record type         */
   int      SrecLen                =  0   ; /* S-Record length       */
 //uint32_t SrecAddr               =  0   ; /* S-Record Address      */
 //uint8_t  SrecBin[MAXSRECLINE/2] = {0}  ; /* S-Record data         */
   uint8_t  SrecCheck              =  0   ; /* S-Record Checksum     */
   int      err                    =  0   ; /* Overall error flag    */
   int      success                = true ; /* Hex parser result     */
   int      AddrLen                =  0   ; /* Address field length  */
 //int      NumBytes               =  0   ; /* Data field byte count */
   int      i                      =  0   ; /* General counter       */

   /* Basic checks first, minimum line length and begins with an S */
   if ((strlen(SrecLine)<14) || (SrecLine[0]!='S')) err = TFTPERR_BADSREC ;

   /* Get the S-Record type, only legit types are 0, 3, and 7.  From that,    */
   /* remember the address length.                                            */
   if (!err)
   {
      *SrecType = SrecLine[1] ;
      switch (*SrecType)
      {
         case '0': AddrLen = 4           ; break ;
         case '3': AddrLen = 8           ; break ;
         case '7': AddrLen = 8           ; break ;
         default : err = TFTPERR_BADSREC ; break ;
      }
   }

   /* Get the bytes in the S-Record and make sure the line length matches.    */
   /* Also now I know the number of data bytes to expect.                     */
   if (!err)
   {
      SrecLen = ReadHex(SrecLine+2,2,JUSTDIGITS,&success) ;
      if (!success) err = TFTPERR_BADSREC ;
      if (strlen(SrecLine)!=SrecLen*2+4) err = TFTPERR_BADSREC ;
      *NumBytes = SrecLen-AddrLen/2-1 ;
      SrecCheck = SrecLen ;
   }

   /* Get the Address */
   if (!err)
   {
      *SrecAddr = ReadHex(SrecLine+4,AddrLen,JUSTDIGITS,&success) ;
      for (i=0;i<AddrLen/2;i++) SrecCheck += (*SrecAddr>>(i*8))&0xff ;
      if (!success) err = TFTPERR_BADSREC ;
   }

   /* If we got this far without errors, we know the line is already the      */
   /* right length, so go read in the data!                                   */
   if (!err)
   {
      for (i=0;i<*NumBytes+1;i++) /* include the checksum */
      {
         SrecBin[i] = ReadHex(SrecLine+4+AddrLen+i*2,2,JUSTDIGITS,&success) ;
         SrecCheck += SrecBin[i] ;
      }

      /* Since I included the checksum in the running checksum, the answer    */
      /* with it should be 0xff.                                              */
      if ((!success) || (0xff != SrecCheck)) err = TFTPERR_BADSREC ;
   }

   /* For Debugging, show results */
#if 0
   if (err)
   {
      Console_printf("TFTP: S-Record formatting error.\n") ;
   }
   else
   {
      Console_printf("S%c Len %d Addr %8.8x Data: ",*SrecType,SrecLen,*SrecAddr) ;
      if ('0'==*SrecType)
      {
         SrecBin[*NumBytes] = 0 ;
         Console_printf("%s\n",SrecBin) ;
      }
      else
      {
         for (i=0;i<*NumBytes;i++)
         {
            Console_printf("%2.2x",SrecBin[i]) ;
         }
         Console_printf(" Check %2.2x\n",SrecBin[*NumBytes]) ;
      }
   }
#endif

   return(err) ;
}

#endif
