/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the bootloader2 file                                               */
/* This is the second phase of the bootloader process, this file contains the */
/* ITCM code (only).  See the header for Bootloader.c for a description of    */
/* the full booloader process.                                                */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - I_Bootloader2 - The Phase 2 bootloader.                                 */
/*                                                                            */
/******************************************************************************/
// TO DO:
// - Not sure why I need I_BL_QSPI_PollWIP() at the start of I_BL_QSPINOR_WriteData()
// - Consider enabling a SysTick or TIMx interrupt to blink the LED.

/******************************************************************************/
/* Includes                                                                   */
/* IMPORTANT: Other than register definitions and #define includes, there     */
/* can't be much else as the whole point of this code is not relying on       */
/* any other code outside this file!                                          */
/******************************************************************************/
#include "stm32h750xx.h"   /* STM32H7 Register definitions  */
#include "Options.h"       /* My system #defines            */
#include "Bootloader.h"    /* Bootloader externally visible */
#include "BootloaderCom.h" /* Bootloader Internal stuff     */
#include "MX25Lxx.h"       /* SPINOR register #defines      */

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
/* See BootloaderCom.h */

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
#ifndef BOOTBYPASS

/* I need decent sized buffers for both QSPI and STM32 flash programming as   */
/* well as verification.  These are some global buffers (of the largest size  */
/* needed to be shared.  data2 is only needed for verification.               */
static uint8_t  data1[QSPI_BLKLENB] = {0} ;
#ifdef VERIFY_ERASE_PROG
static uint8_t  data2[QSPI_BLKLENB] = {0} ;
#endif

/******************************************************************************/
/* External globals. How CubeMX does things instead of in an include file,    */
/* weird.                                                                     */
/******************************************************************************/

/******************************************************************************/
/* Local routine prototypes - Ones executed from STM32 ITCM only.             */
/* These are the routines to erase and reprogram STM32 and QSPI flash.        */
/******************************************************************************/
static void IN_ITCM I_ReProgram_QSPI(void) ;
static void IN_ITCM I_BL_SPINOR_ReadData(uint32_t,uint32_t,uint8_t*) ;
#ifdef VERIFY_ERASE_PROG
static void IN_ITCM I_BL_QSPINOR_ReadData(uint32_t,uint32_t,uint8_t*) ;
#endif
static void IN_ITCM I_BL_QSPINOR_WriteData(uint32_t,uint32_t,uint8_t*) ;
static void IN_ITCM I_ReProgram_STM_Flash(void) ;

static void IN_ITCM I_ReProgram_STM_Flash(void) ;
static int  IN_ITCM I_FLASH_Unlock(void) ;
static int  IN_ITCM I_FLASH_Lock(void) ;
static int  IN_ITCM I_FLASH_Erase(void) ;
static int  IN_ITCM I_FLASH_Program_Word(uint32_t,uint32_t) ;
static int  IN_ITCM I_WaitForLastOperation(void) ;

/******************************************************************************/
/* Local routine prototypes - Support routines needed in both spaces.         */
/* These are support routines needed for both classes, so two copies of most. */
/******************************************************************************/
static void IN_ITCM I_UartStr(char*) ;
static void IN_ITCM I_UartDec(int) ;
static void IN_ITCM I_RMW_Reg(volatile uint32_t*,uint32_t, uint32_t,int) ;
static void IN_ITCM I_HB_LED(int) ;
static void IN_ITCM I_SPI_CS(int) ;
static void IN_ITCM I_SW_msDelay(int) ;
static void IN_ITCM I_SW_usDelay(int) ;
static void IN_ITCM I_BL_SPINOR_Cmd (uint8_t*,int,int) ;
static void IN_ITCM I_BL_SPINOR_Read(uint8_t*,int,int) ;
static void IN_ITCM I_SPI_Done(void) ;
static void IN_ITCM I_BL_QSPINOR_Cmd  (uint8_t,uint32_t,uint32_t) ;
static void IN_ITCM I_BL_QSPINOR_RdReg(uint8_t,uint32_t,uint32_t,uint32_t,uint8_t*) ;
static void IN_ITCM I_BL_QSPI_PollWIP(void) ;

/*******************************************************************************
* Routine  : I_Bootloader2
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This is the second stage of the bootloader, the part that runs from ITCM and
* actually erases the QSPI and STM32 flash and reprograms it!
*******************************************************************************/
void IN_ITCM I_Bootloader2(void)
{
   uint32_t RegVal = 0 ; /* Intermediate register value */

   I_UartStr("Bootloader (Step 2)...\r\n") ;
   I_ReProgram_QSPI() ;
   I_ReProgram_STM_Flash() ;

   /* Reboot back to the downloaded code using a software reset.  The ST      */
   /* code that does this preserves the Priority Group, so doing the same     */
   /* think here just in case.  Read the AIRCR register, keep the Priority    */
   /* bits and add the register key and system reset bit before writing the   */
   /* value back to reset the chip.                                           */
   RegVal = SCB->AIRCR ;
   RegVal = (RegVal&SCB_AIRCR_PRIGROUP_Msk) | 0x5fa0000 | SCB_AIRCR_SYSRESETREQ_Msk ;
   __DSB() ;
   SCB->AIRCR = RegVal ; /* night-night Gracey! */
   __DSB() ;

   /* Keeping this for now even though it will never execute */
   while (1)
   {
      I_HB_LED(true ) ;
      I_SW_msDelay(900) ;
      I_HB_LED(false) ;
      I_SW_msDelay(100) ;
   }
}

/*******************************************************************************
* Routine  : I_ReProgram_QSPI
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine first erases then programs the QPSI flash from the SPI flash.
* (see memory map above for address translation)
*******************************************************************************/
static void IN_ITCM I_ReProgram_QSPI(void)
{
   uint32_t index     =  0  ; /* General index        */
   uint32_t Threshold =  0  ; /* % progress threshold */

   /* Issue the QSPI Erase command and poll for it to be complete */
   I_UartStr(" QSPI: Erasing flash (30s max)...") ;
   I_BL_QSPINOR_Cmd(WRITE_ENABLE_CMD,0,0) ;
   I_BL_QSPINOR_Cmd(CHIP_ERASE_CMD,0,0) ;

   I_BL_QSPI_PollWIP() ;
   I_UartStr("Done.\r\n") ;

#ifdef VERIFY_ERASE_PROG
   /* This is more for debugging (and isolatable) to confirm that the flash   */
   /* is indeed erased.                                                       */
   int index2 = 0 ; /* Loop counter  */
   int errors = 0 ; /* error counter */

   I_UartStr(" QSPI: Verifying Erase...") ;
   for (index=0;index<QSPIS_SIZE;index+=QSPI_BLKLENB)
   {
      I_BL_QSPINOR_ReadData(QPSIS_DSTSTART+index,QSPI_BLKLENB,data2) ;
      for (index2=0;index2<QSPI_BLKLENB;index2++) if (data2[index2]!=0xff) errors++ ;
   }
   if (!errors)
   {
      I_UartStr("Erased.\r\n") ;
   }
   else
   {
      I_UartDec(errors) ;
      I_UartStr(" Errors.\r\n") ;
      while (1) ;
   }
#endif

   /* Now start programming the QSPI flash from the SPI flash 256 bytes at a  */
   /* time (the QSPI Flash page size).                                        */
   I_UartStr(" QSPI: Programming flash...\r\n") ;
   for (index=0;index<QSPIS_SIZE;index+=QSPI_BLKLENB)
   {
      I_BL_SPINOR_ReadData  (QPSIS_SPISTART+index,QSPI_BLKLENB,data1) ;
      I_BL_QSPINOR_WriteData(QPSIS_DSTSTART+index,QSPI_BLKLENB,data1) ;

      /* Update a progress counter every 10%. */
      if (index>=Threshold)
      {
         I_UartDec(index*100/QSPIS_SIZE) ;
         I_UartStr("%...\r") ;
         Threshold +=QSPIS_SIZE/10 ;
      }
   }
   I_UartStr(" QSPI: Programming flash Complete\r\n") ;

#ifdef VERIFY_ERASE_PROG
   /* Now verify that the data in the QSPI flash matches the SPI flash.       */
   errors = 0 ;

   I_UartStr(" QSPI: Verifying Programming...") ;
   for (index=0;index<QSPIS_SIZE;index+=QSPI_BLKLENB)
   {
      I_BL_SPINOR_ReadData (QPSIS_SPISTART+index,QSPI_BLKLENB,data1) ;
      I_BL_QSPINOR_ReadData(QPSIS_DSTSTART+index,QSPI_BLKLENB,data2) ;
      for (index2=0;index2<QSPI_BLKLENB;index2++) if (data1[index2]!=data2[index2]) errors++ ;
   }

   if (!errors)
   {
      I_UartStr("Verified.\r\n") ;
   }
   else
   {
      I_UartDec(errors) ;
      I_UartStr(" Errors.\r\n") ;
      while (1) ;
   }
#endif
}

/*******************************************************************************
* Routine  : I_BL_SPINOR_ReadData
* Gazintas : SrcAddr - SPI Flash address to start reading from
*          : DataLen - Number of bytes to read
* IOs      : buf - Place to put the read data
* Returns  : Nothing
* Globals  : TBD
*
* This routine reads a segment of the SPI NOR flash.
*******************************************************************************/
static void IN_ITCM I_BL_SPINOR_ReadData(uint32_t SrcAddr,uint32_t DataLen,uint8_t* buf)
{
   uint8_t cmd[4] = {0} ; /* Command buffer     */

   cmd[0] = READ_DATA_CMD      ;
   cmd[1] = (SrcAddr>>16)&0xff ;
   cmd[2] = (SrcAddr>> 8)&0xff ;
   cmd[3] = (SrcAddr    )&0xff ;
   I_BL_SPINOR_Cmd (cmd,4,CS_ACTIVE) ;
   I_BL_SPINOR_Read(buf,DataLen,CS_INACTIVE) ;
}

#ifdef VERIFY_ERASE_PROG
/*******************************************************************************
* Routine  : I_BL_QSPINOR_ReadData
* Gazintas : SrcAddr - SPI Flash address to read from
*          : DataLen - Number of bytes to read
* IOs      : buf - Place for the read data
* Returns  : Nothing
* Globals  : TBD
*
* This routine reads QSPI NOR flash.
*******************************************************************************/
static void IN_ITCM I_BL_QSPINOR_ReadData(uint32_t SrcAddr,uint32_t DataLen,uint8_t* buf)
{
   /* Clear out any old flags and queue up the data size */
   QUADSPI->FCR = QSPI_FCR_ALLBITS ;
   QUADSPI->DLR = DataLen-1 ;

   /* The command control write first. Always 1-bit for instruction and data  */
   /* phases and obviously a read too.                                        */
   QUADSPI->CCR = QSPI_IMODE_1BIT|QSPI_FMODE_READ|QSPI_DMODE_1BIT|QSPI_ADMODE_1BIT|QSPI_ADDRSIZE_24| READ_DATA_CMD ;
   QUADSPI->AR  = SrcAddr ;
   __DSB() ; /* make sure it's all sent before polling */

   /* Start polling for return data */
   while (DataLen)
   {
      while (((QUADSPI->SR)&QUADSPI_SR_FTF)==0) ; /*Wait on FIFO threshold    */
      *buf = *(__IO uint8_t*)(&QUADSPI->DR) ; /* read byte (force a byte read)*/
      buf++ ;
      DataLen-- ;
   }
}
#endif

/*******************************************************************************
* Routine  : I_BL_QSPINOR_WriteData
* Gazintas : DstAddr - SPI Flash address to start writing to
*          : DataLen - Number of bytes to read
* IOs      : buf - Place for the data to write
* Returns  : Nothing
* Globals  : TBD
*
* This routine writes a segment to the QSPI NOR flash.
*******************************************************************************/
static void IN_ITCM I_BL_QSPINOR_WriteData(uint32_t DstAddr,uint32_t DataLen,uint8_t* buf)
{
   /* Not sure why this is needed, but the poll at the end doesn't always seem*/
   /* to work, so polling here too ahead of setting the Write Enable bit.     */
   I_BL_QSPI_PollWIP() ;

   /* Now set the write enable bit */
   I_BL_QSPINOR_Cmd(WRITE_ENABLE_CMD,0,0) ;

   /* Clear out any old flags and queue up the data size */
   QUADSPI->FCR = QSPI_FCR_ALLBITS ;
   QUADSPI->DLR = DataLen-1 ;

   /* The command control write first. Always 1-bit for instruction and data  */
   /* phases and obviously a read too.                                        */
   QUADSPI->CCR = QSPI_FMODE_WRITE|QSPI_IMODE_1BIT|QSPI_ADMODE_1BIT|QSPI_DMODE_1BIT|QSPI_ADDRSIZE_24|PAGE_PROG_CMD ;
   QUADSPI->AR  = DstAddr ;
   __DSB() ; /* make sure it's all sent before polling to write */

   /* Start sending data */
   while (DataLen)
   {
      while (!(QUADSPI->SR&QUADSPI_SR_FTF)) ; /* Wait on FIFO data   */
      *(__IO uint8_t*)(&QUADSPI->DR) = *buf ; /* read byte (force a byte read)*/
      buf++ ;
      DataLen-- ;
      //__DSB() ; /* make sure it's all sent */
   }

   /* All done writing the block of data, now wait for the programming to     */
   /* complete.  Waiting on the busy flag.                                    */
   I_BL_QSPI_PollWIP() ;
}

/*******************************************************************************
* Routine  : I_ReProgram_STM_Flash
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine erases and programs the STM32s internal flash.  Just notes for
* now.
*  - Program in 256-byte chunks
*  - Writes are buffered (more than 1 write?)
*  - Consider adjusting wait states for faster access
*  - Set PG1 bit before programming (pg 151)
*  - Write sequence pg 151 too
*  - PSIZE bits on page 152
*  - Don't unlock and already-unlocked sector!
*  - Erase sequence on page 154
*
*******************************************************************************/
static void IN_ITCM I_ReProgram_STM_Flash(void)
{
   uint32_t Threshold = 0    ; /* STM32 flash destination address   */
   uint32_t index     = 0    ; /* Address index offset              */
   uint32_t FlashBuf[FLASH_WORDLENW] = {0} ; /* Programming buffer  */

   /* Unlock flash writes, erase the flash, then lock it again so I can       */
   /* verify it has been erased.                                              */
   /* We are way past the point of no return, so if any errors its game-over! */
   I_UartStr("STM32: Erasing flash (15s max)...") ;
   if (!I_FLASH_Unlock()) while (1) ;
   if (!I_FLASH_Erase())  while (1) ;
   if (!I_FLASH_Lock())   while (1) ;
   I_UartStr("Done.\r\n") ;

#ifdef VERIFY_ERASE_PROG
   /* This is more for debugging (and isolatable) to confirm that the flash   */
   /* is indeed erased.                                                       */
   uint32_t SrcAddr = 0 ; /* SPI flash source address */
   int      errors  = 0 ; /* error counter            */

   I_UartStr("STM32: Verifying Erase...") ;
   for (SrcAddr=STMS_DSTSTART;SrcAddr<=STMS_DSTEND;SrcAddr++)
   {
      if (*(uint8_t*)SrcAddr!=0xff) errors++ ;
   }
   if (!errors)
   {
      I_UartStr("Erased.\r\n") ;
   }
   else
   {
      I_UartDec(errors) ;
      I_UartStr(" Errors.\r\n") ;
      while (1) ;
   }
#endif

   /* OK, time to start programming!  */
   I_UartStr("STM32: Programming flash...\r\n") ;
   I_FLASH_Unlock() ;
   Threshold = 0 ;

  /* While data to program and no failures... */
   for (index=0;index<=STMS_SIZE;index+=FLASH_WORDLENB)
   {
      I_BL_SPINOR_ReadData(STMS_SPISTART+index,FLASH_WORDLENB,(uint8_t*)FlashBuf) ;
      I_FLASH_Program_Word(STMS_DSTSTART+index,(uint32_t)FlashBuf) ;

      /* Update a progress counter every 10%. */
      if (index>=Threshold)
      {
         I_UartDec(index*100/STMS_SIZE) ;
         I_UartStr("%...\r") ;
         Threshold +=STMS_SIZE/10 ;
      }
   }
   I_UartStr("STM32: Programming flash Complete.\r\n") ;

   /* All done, lock the flash so it is readable again */
   I_FLASH_Lock() ;

#ifdef VERIFY_ERASE_PROG
   /* Now verify that the data in the STM flash matches the SPI flash.        */
   uint32_t index2 = 0 ;

   I_UartStr("STM32: Verifying Programming...") ;
   errors = 0 ;
   for (index=0;index<STMS_SIZE;index+=QSPI_BLKLENB)
   {
      I_BL_SPINOR_ReadData (STMS_SPISTART+index,QSPI_BLKLENB,data2) ;
      for (index2=0;index2<QSPI_BLKLENB;index2++) if (*(uint8_t*)(STMS_DSTSTART+index+index2)!=data2[index2]) errors++ ;
   }

   if (!errors)
   {
      I_UartStr("Verified.\r\n") ;
   }
   else
   {
      I_UartDec(errors) ;
      I_UartStr(" Errors.\r\n") ;
      while (1) ;
   }
#endif
}

/*******************************************************************************
* Routine  : I_FLASH_Unlock
* Gazintas : Nothing
* IOs      : None
* Returns  : true if success (unlocked)
* Globals  : TBD
*
* This routine unlocks the STM32H750 internal flash. The datasheet is clear that
* unlocking an already unlocked flash is bad, so check first!
*******************************************************************************/
static int IN_ITCM I_FLASH_Unlock(void)
{
   /* Only unlock if locked */
   if (FLASH->CR1&FLASH_CR_LOCK)
   {
      /* Sequence to unlock */
      FLASH->KEYR1 = FLASH_KEY1 ;
      FLASH->KEYR1 = FLASH_KEY2 ;
   }

   /* return true if locked (however it happened) */
   return (!(FLASH->CR1&FLASH_CR_LOCK)) ;
}

/*******************************************************************************
* Routine  : I_FLASH_Lock
* Gazintas : Nothing
* IOs      : None
* Returns  : true if success (locked)
* Globals  : TBD
*
* This routine locks the STM32H750 internal flash.
*******************************************************************************/
static int IN_ITCM I_FLASH_Lock(void)
{
   /* Set the LOCK Bit to lock the FLASH Bank1 Control Register access */
   I_RMW_Reg(&FLASH->CR1,0x01,0x01,0) ; /* Set the lock bit */

   /* Return true if unlocked */
   return (FLASH->CR1&FLASH_CR_LOCK) ;
 }

/*******************************************************************************
* Routine  : I_FLASH_Erase
* Gazintas : Nothing
* IOs      : None
* Returns  : true if success (erased)
* Globals  : TBD
*
* This routine erases the one and only sector (Bank 1 sector 0) of the STM32H750
* flash using mass erase command.
*******************************************************************************/
static int IN_ITCM I_FLASH_Erase(void)
{
   int success = true ;

   /* Wait for any previous operation to be complete on Bank1 */
   if(I_WaitForLastOperation() != 0) success = false ;

   if(success)
   {
      /* Mass erase */
      FLASH->CR1 |= (FLASH_CR_BER | FLASH_CR_START);

      /* Wait for the erase operation to complete */
      if(I_WaitForLastOperation() != 0) success = false ;

      /* if the erase operation is completed, disable the Bank1 BER Bit */
      FLASH->CR1 &= (~FLASH_CR_BER);
   }
   return (success) ;
 }

/*******************************************************************************
* Routine  : I_FLASH_Program_Word
* Gazintas : FlashAddress - Destination address in flash
*          : DataAddress - source address for data to program
* IOs      : None
* Returns  : true for success
* Globals  : TBD
*
* This routine programs a flash words worth of data (256 bits or 32 bytes) to
* the STM32F750 internal flash.
*******************************************************************************/
static int IN_ITCM I_FLASH_Program_Word(uint32_t FlashAddress, uint32_t DataAddress)
{
   int            success   = true                          ;
   __IO uint32_t *dest_addr = (__IO uint32_t *)FlashAddress ;
   __IO uint32_t *src_addr  = (__IO uint32_t*)DataAddress   ;
   uint8_t       row_index  = FLASH_WORDLENW                ;

   /* Wait for any previous operation to be complete on Bank1 */
   if(I_WaitForLastOperation() != 0) success = false ;

   if(success)
   {
      /* Set PG bit */
      FLASH->CR1 |= FLASH_CR_PG ;

      __ISB();
      __DSB();

      /* Program the flash word */
      do
      {
         *dest_addr = *src_addr;
         dest_addr++;
         src_addr++;
         row_index--;
      } while (row_index != 0U);

      __ISB();
      __DSB();

      /* Wait for the write operation to be complete */
      if(I_WaitForLastOperation() != 0) success = false ;

      /* If the program operation is completed, disable the PG */
      FLASH->CR1 &= ~FLASH_CR_PG ;
   }

   return (success) ;
 }

 /*******************************************************************************
 * Routine  : I_WaitForLastOperation
 * Gazintas : Nothing
 * IOs      : None
 * Returns  : not 0 for any error flags
 * Globals  : TBD
 *
 * This routine waits for the last operation to finish and returns any error
 * flags if there were any set.
 *******************************************************************************/
static int IN_ITCM I_WaitForLastOperation(void)
 {
   uint32_t result = 0;

   /* Wait for the Queue flag to go away. I don't really have a provision for */
   /* it not going away!                                                      */
   while(FLASH->SR1&FLASH_SR_QW) ;

   /* Queue can go away but still have errors, check. */
   result = FLASH->SR1 & 0x07ee0000 ;

   /* Check FLASH End of Operation flag and clear if set  */
   if (FLASH->SR1 & FLASH_SR_EOP)
   {
      FLASH->SR1 = FLASH_SR_EOP ;
      //RMW_Reg(&FLASH->SR1,0x01,0x01,16) ;
   }

   return (result) ;
 }

/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
/* ***** Support Routines                                               ***** */
/******************************************************************************/
/******************************************************************************/
/******************************************************************************/

/*******************************************************************************
* Routine  : I_UartStr
* Gazintas : str - string to send
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine sends a string to USART1 in program IO mode (blocking).
*******************************************************************************/
static void IN_ITCM I_UartStr(char* str)
{
   while (*str)
   {
      while (!(USART1->ISR&0x40)) ; /* Wait on TC = 0 (busy) */
      USART1->TDR = *str ;
      str++ ;
   }
}

/*******************************************************************************
* Routine  : I_UartHex
* Gazintas : val - Byte to write out as ASCII hex
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine converts a byte to ASCII hex and sends it to USART1 in program
* IO mode (blocking).
*******************************************************************************/
#if 0 /* Not used yet - to avoid compiler warnings */
static void IN_ITCM I_UartHex(uint8_t val)
{
   char str[4] = {0} ;

   str[0] = val/16 + '0' ; if (str[0]>'9') str[0] += 'a'-'9'-1 ;
   str[1] = val%16 + '0' ; if (str[1]>'9') str[1] += 'a'-'9'-1 ;
   str[2] = ' ' ;
   UartStr(str) ;
}
#endif
/*******************************************************************************
* Routine  : I_UartDec
* Gazintas : val - Value to write out as ASCII decimal
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine converts an int to ASCII decimal and sends it to USART1 in
* program IO mode (blocking).
* NOTE!  I max at 999.
*******************************************************************************/
static void IN_ITCM I_UartDec(int val)
{
   char str[4] = {0} ;

   /* Limit things just in case. */
   if (val>999)
   {
      I_UartStr(">999") ;
   }
   else
   {
      str[0] = (val    )/100 + '0' ;
      str[1] = (val%100)/10  + '0' ;
      str[2] = (val% 10)     + '0' ;
      I_UartStr(str) ;
   }
}

/*******************************************************************************
* Routine  : I_RMW_Reg
* Gazintas : Addr - Register address
*          : mask - mask of bits to clear out (shifted to LSB)
*          : val - new value to replace
*          : shift - shift to where the bits need to be
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine is a generic read/modify/write for a register.  The mask and new
* value are in the LSBs for easier coding then get shifted as needed.  Yea this
* could be a #define, but keeping it to somethign I can easily understand.
*******************************************************************************/
static void IN_ITCM I_RMW_Reg(volatile uint32_t* Addr,uint32_t mask, uint32_t val, int shift)
{
   volatile uint32_t tmp = *Addr ;
   tmp = tmp & ~(mask<<shift) ;
   tmp = tmp |  (val <<shift) ;
   *Addr = tmp ;
}

/*******************************************************************************
* Routine  : I_HB_LED, I_SPI_CS
* Gazintas : ToOn/Assert
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine wiggles the heartbeat LED or SPI chip select.
* True for LED on (high) or CS asserted (low), false for off/unasserted.
*******************************************************************************/
static void IN_ITCM I_HB_LED(int ToOn)
{
   GPIOE->BSRR = ToOn?0x400:0x4000000 ;
}

static void IN_ITCM I_SPI_CS(int Assert)
{
   GPIOD->BSRR = Assert?0x00010000:0x00000001 ;
}

/*******************************************************************************
* Routine  : I_SW_msDelay, I_SW_usDelay
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine is a delay function.  Without any hardware support I'm winging it
* in software.  It is only roughly calibrated using a scope.  You touchie the
* CPU clock, this goes bad! :)
* NOTE!!  Count values differ a lot between running from flash and ITCM, about
* 4.5x faster!
*******************************************************************************/
static void IN_ITCM I_SW_msDelay(int ms)
{
   volatile int i = 0 ;

   while (ms>0)
   {
      for (i=0;i<11551;i++) ;
      ms-- ;
   }
}

static void IN_ITCM I_SW_usDelay(int us)
{
   int count = 0 ;
   volatile int i = 0 ;

   count = (us*13132)/1000 ;

   for (i=0;i<count;i++) ;
}

/*******************************************************************************
* Routine  : I_BL_SPINOR_Cmd
* Gazintas : cmd - Command string
*          : len - length of command string
*          : cs_end - flag to de-assert CS after command
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine sends a command string to the SPINOR.  It assumes CS is de-
* asserted before, asserts it, and then sends the command.  If there is no
* data read or write after the command, the cs_end flag tells the routing to
* go ahead and de-assert CS after the command.
*
* NOTE: This isn't very efficient code!  I'm not sure it matters as the flash
* should be by far the bottleneck.  I can look at it later for optimizing if
* convinced it matters.
*******************************************************************************/
static void IN_ITCM I_BL_SPINOR_Cmd (uint8_t* cmd, int len,int cs_end)
{
   I_SPI_CS(true) ; /* assert CS */

   /* Fire up the SPI controller. */
   SPI3->CR2 = len                     ; /* Transfer size      */
   I_RMW_Reg(&SPI3->CFG2,0x03,0x00,17) ; /* Full duplex Change to simplex transmit?????? */
   I_RMW_Reg(&SPI3->CR1 ,0x01,0x01, 0) ; /* Enable SPI         */
   I_RMW_Reg(&SPI3->CR1 ,0x01,0x01, 9) ; /* Start (CSTART bit) */

   while (len)
   {
      /*Wait for TXP flag (should never wait, the FIFO should be ready) */
      while (!(SPI3->SR&0x02)) ;
      *(uint8_t*)(&SPI3->TXDR) = *cmd ; /* write a byte (force byte write) */
      cmd++ ;
      len-- ;
   }

   /* FIFO writes can get ahead of data, so wait for all data to be sent      */
   /* before next step of (maybe) de-asserting CS.                            */
   while (!(SPI3->SR&0x08)) ; /* Wait until end of transfer flag              */
   if (CS_INACTIVE==cs_end) I_SPI_CS(false) ;

   /* All done, shut down SPI controller. */
   I_SPI_Done() ;
}

/*******************************************************************************
* Routine  : I_BL_SPINOR_Read
* Gazintas : buf - Buffer to fill
*          : len - bytes to read
*          : cs_end - De-assert CS at the end flag
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine reads data from the SPI interface.  It assumes the command to
* say what to read has been sent (and CS left de-asserted) before this routine
* gets called.
*******************************************************************************/
static void IN_ITCM I_BL_SPINOR_Read(uint8_t* buf,int len,int cs_end)
{
   /* Fire up the SPI controller. */
   SPI3->CR2 = len                     ; /* Transfer size         */
   I_RMW_Reg(&SPI3->CFG2,0x03,0x02,17) ; /* Simplex receiver mode */
   I_RMW_Reg(&SPI3->CR1 ,0x01,0x01, 0) ; /* Enable SPI            */
   I_RMW_Reg(&SPI3->CR1 ,0x01,0x01, 9) ; /* Start transfer bit    */

   while (len)
   {
      while (!(SPI3->SR&0x01)) ; /*Wait for RXP flag */
      *buf = *(__IO uint8_t*)(&SPI3->RXDR) ; /* read a byte (force byte read) */
      buf++ ;
      len-- ;
   }

   /* All done, de-assert CS. */
   if (CS_INACTIVE==cs_end) I_SPI_CS(false) ;

   /* Shut down SPI controller. */
   I_SPI_Done() ;
}

/*******************************************************************************
* Routine  : I_SPI_Done
* Gazintas : Nothing
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* Just a quick routine for the common code at the end of a SPI transfer.
*******************************************************************************/
static void IN_ITCM I_SPI_Done(void)
{
   I_RMW_Reg(&SPI3->CR1,0x01,0x00,0) ; /* Turn off SPI */
   SPI3->IFCR  = 0x00000ff8 ; /* Clear any existing errors/done flags */
}

/*******************************************************************************
* Routine  : I_BL_QSPINOR_Cmd
* Gazintas : cmd - Command
*          : Addr - Address (or at least bytes after the command)
*          : modes - Comm modes (for CCR)  Only ones that make sense are
*          :         ADDRSIZE and ADMODE
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine sends a one-off command to the SPI flash (no data).
* Reminder the QSPI controller only needs/wants the necessary register writes
* after the control write that are actually needed to start.  With just a
* command, the only possible data is an address or data that would part of the
* address field.
*******************************************************************************/
static void IN_ITCM I_BL_QSPINOR_Cmd (uint8_t cmd, uint32_t Addr, uint32_t modes)
{
   int timeout = 0 ;

   /* Clear out any old flags then write the command control word  */
   QUADSPI->FCR = QSPI_FCR_ALLBITS ;
   QUADSPI->CCR = QSPI_IMODE_1BIT | modes | cmd ;

   /* Only write address register if an address is to be sent */
   if (modes&QSPI_ADMODE_4BIT) QUADSPI->AR  = Addr ;
   __DSB() ; /* make sure it's all written before polling */

   /* Wait for the command to complete */
   while(QUADSPI->SR & QUADSPI_SR_BUSY) /* Busy flag */
   {
      I_SW_usDelay(1) ;
      timeout++ ;
      if (timeout>10000) /* 10ms */
      {
         return ;
      }
   }
}

/*******************************************************************************
* Routine  : I_BL_QSPINOR_RdReg
* Gazintas : cmd - Command
*          : Addr - Address (or at least bytes after the command)
*          : modes - Comm modes (for CCR)  Only ones that make sense are
*          :         ADDRSIZE and ADMODE
*          : DataLen - length of data to receive afterwards
*          : buf - buffer for read data
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine reads register data from the QSPINOR device
*******************************************************************************/
static void IN_ITCM I_BL_QSPINOR_RdReg (uint8_t cmd, uint32_t Addr, uint32_t modes, uint32_t DataLen,uint8_t* buf)
{
   /* Clear out any old flags and queue up the data size */
   QUADSPI->FCR = QSPI_FCR_ALLBITS ;
   QUADSPI->DLR = DataLen-1 ;

   /* The command control write first. Always 1-bit for instruction and data  */
   /* phases and obviously a read too.                                        */
   QUADSPI->CCR = QSPI_IMODE_1BIT|QSPI_FMODE_READ|QSPI_DMODE_1BIT| modes | cmd ;

   /* Only write address register if an address is to be sent */
   if (modes&QSPI_ADMODE_4BIT) QUADSPI->AR  = Addr ;
   __DSB() ; /* make sure it's all sent before polling */

   /* Start polling for return data */
   while (DataLen)
   {
      //while (((QUADSPI->SR)&(QUADSPI_SR_TCF|QUADSPI_SR_FTF))==0) ; /*Wait on FIFO threshold or terminal count   */
      while (((QUADSPI->SR)&(QUADSPI_SR_FTF))==0) ; /*Wait on FIFO threshold or terminal count   */
      *buf = *(__IO uint8_t*)(&QUADSPI->DR) ; /* read byte (force a byte read)*/
      buf++ ;
      DataLen-- ;
   }
}

/*******************************************************************************
* Routine  : I_BL_QSPI_PollWIP
* Gazintas : none
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine polls the QSPI's status register waiting for the WIP (write in
* process) and WEL (write enable latch) to both go away.
*******************************************************************************/
static void IN_ITCM I_BL_QSPI_PollWIP(void)
{
   uint8_t ChipStatus = 0 ; /* Read buffer */

   do
   {
      I_BL_QSPINOR_RdReg(READ_SR_CMD,0,0,1,&ChipStatus) ;
   } while (ChipStatus&0x03) ;
}

#endif /* #ifndef BOOTBYPASS */
