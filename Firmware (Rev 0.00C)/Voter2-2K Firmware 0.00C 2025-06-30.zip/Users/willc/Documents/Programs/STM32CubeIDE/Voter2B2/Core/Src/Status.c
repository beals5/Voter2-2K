/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Status file.  It is in charge of the CLI status command.       */
/* I have a feeling some other background monitoring tasks may get added later*/
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Cmd_status - Status CLI command                                         */
/*                                                                            */
/******************************************************************************/
// TO DO:
//
/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "cmsis_os.h"

#include "Options.h"
#include "main.h"
#include "ConsoleTask.h"
#include "AnalogIO.h"
#include "Gpio.h"
#include "GPS.h"
#include "Rx_DSP.h"
#include "DialTask.h"
#include "Settings.h"
#include "Utils.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/
extern I2C_HandleTypeDef hi2c1;
extern ADC_HandleTypeDef hadc3;

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
enum
{
   CMD_OOPS = 0,
   CMD_14V,
   CMD_DIAL,
   CMD_GPS,
   CMD_POWER,
   CMD_RSSI,
   CMD_SYNC,
   CMD_TEMPR
} STATUS_ENUMS ;

#define TEMPR_ADDRESS0 0x90 /* Shifted Address for on-board sensor  */
#define TEMPR_ADDRESS1 0x92 /* Shifted Address for off-board sensor */
#define TEMPR_ADDRESS2 0x94 /* Shifted Address for off-board sensor */
#define TEMP_CONV_MS     10 /* Max ms for temperature conversion    */

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
char* cmd_status_cmd  = "status" ;
char* cmd_status_help = "status - [14v|dial|gps|power|rssi|sync|tempr] Show Voter2 status info\n"
                        "         14v - check 14V supply\n"
                        "         dial - check DIAL connection status\n"
                        "         gps - check GPS status\n"
                        "         power - check repeater AC power\n"
                        "         rssi [sec]- display RSSI value for x seconds.\n"
                        "         sync - check GPS vs DIAL sync\n"
                        "         tempr - check MCU/PCB temperature\n" ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TOKENLIST StatCmds[] =
{
   {"14v"  ,CMD_14V  },
   {"dial" ,CMD_DIAL },
   {"gps"  ,CMD_GPS  },
   {"power",CMD_POWER},
   {"rssi" ,CMD_RSSI },
   {"sync" ,CMD_SYNC },
   {"tempr",CMD_TEMPR},
   {NULL  ,0        }
} ;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
void RssiBar(int,char*) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/
void Stat_14V(void) ;
void Stat_DIAL(void) ;
void Stat_GPS(void) ;
void Stat_Power(void) ;
void Stat_RSSI(int, char**) ;
void Stat_Sync(void) ;
void Stat_Tempr(void) ;

/*******************************************************************************
* Routine  : Cmd_status
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command sets or shows the time from the RTC.
*******************************************************************************/
int Cmd_status(int argc, char* argv[])
{
   int error = false ; /* Parsing error flag */
   int Token = 0     ; /* Command token      */

   /* See which settings command */
   Token = parse_token(StatCmds,argv[1],&error) ;

   if (error)
   {
      Console_printf("Invalid parameter, see help.\n") ;
   }
   else
   {
      switch(Token)
      {
         case CMD_14V   : Stat_14V()           ; break ;
         case CMD_DIAL  : Stat_DIAL()          ; break ;
         case CMD_GPS   : Stat_GPS()           ; break ;
         case CMD_POWER : Stat_Power()         ; break ;
         case CMD_RSSI  : Stat_RSSI(argc,argv) ; break ;
         case CMD_SYNC  : Stat_Sync()          ; break ;
         case CMD_TEMPR : Stat_Tempr()         ; break ;
         default        :                        break ; /* Shouldn't happen */
      }
   }

   return (0) ;
}

/*******************************************************************************
* Routine  : Stat_14V
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command checks the comparator that is checking the 14V supply. It
* triggers at 11.9V
*******************************************************************************/
void Stat_14V(void)
{
   Console_printf("The 14V supply is %c the 11.9V threshold.\n",V14_State()?'>':'<');
}

/*******************************************************************************
* Routine  : Stat_DIAL
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command reports back the DIAL connection status
*******************************************************************************/
void Stat_DIAL(void)
{
   Console_printf("DIAL Connection state: %s\n\n",DIAL_AUTHORIZED?"Connected":"Not Connected (local mode)") ;

   /* If connected, show the status byte */
   if (DIAL_AUTHORIZED)
   {
      Console_printf("         DIAL Flag Byte : 0x%2.2x\n",DIAL_flagbyte) ;
      Console_printf("          Flat Audio (1): %s\n",DIAL_FLATAUDIO?"Yes":"No (de-emphasized)") ;
      Console_printf("   Send Audio Always (2): %s\n",DIAL_ALWAYSAUDIO?"Yes":"No") ;
      Console_printf("   Don't filter CTCSS(4): %s\n",DIAL_NOSUBAUDIO?"Yes (don't filter)":"No (filter it)") ;
      Console_printf("Master Timing Source (8): %s\n",DIAL_IMMASTER?"Yes":"No") ;
      Console_printf("        Audio Codec (16): %s\n",DIAL_USEADPCM?"ADPCM":"uLaw") ;
      Console_printf("        Timing Mode (32): %s\n",DIAL_GENPURPOSE?"General Purpose":"GPS Timed") ;
      Console_printf("           Reserved (64): %d\n",(DIAL_flagbyte&64)/64) ;
      Console_printf("          Reserved (128): %d\n",(DIAL_flagbyte&128)/128) ;
   }
}

/*******************************************************************************
* Routine  : Stat_GPS
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command reports the status of the GPS receiver.
*******************************************************************************/
void Stat_GPS(void)
{
   int i = 0 ; /* counter */
   int j = 0 ; /* counter */

   Console_printf("    GPS 1PPS: %s\n",GPSLocked?"Locked":"Not Locked");
   Console_printf("Sample Clock: %s\n",GPSUsed?"GPS Synchronized":"Local Crystal");

   /* While it was a HW issue, I had a case where there was NO data at all    */
   /* coming from the GPS, so the status byte was still NULL.  Handling that  */
   /* case here too just in case.                                             */
   if (!GPSData.Status)
   {
      Console_printf("  GPS Status: No NMEA Data.\n");
   }
   else
   {
      Console_printf("  GPS Status: \"%c\" (A=Valid, V=Invalid)\n",GPSData.Status);
   }

   if ('A'==GPSData.Status)
   {
      Console_printf("   Longitude: %s%c\n",GPSData.Longitude,GPSData.LongDir);
      Console_printf("    Latitude: %s%c\n",GPSData.Latitude,GPSData.LatDir);
      Console_printf("    Altitude: %dm (%dft)\n",GPSData.Altitude,(GPSData.Altitude*328)/100) ;
      Console_printf("    UTC Date: %2.2d/%2.2d/%2.2d\n",GPSData.UTC_Year,GPSData.UTC_Month,GPSData.UTC_Day) ;
      Console_printf("    UTC Time: %2.2d:%2.2d:%2.2d.%3.3d\n\n",GPSData.UTC_Hour,GPSData.UTC_Min,GPSData.UTC_Sec,GPSData.UTC_mSec) ;

      Console_printf("   # of Sats: %d\n",SatStatus.nSats);
      Console_printf("        HDOP: %d.%2.2dm\n",SatStatus.hdop/100,SatStatus.hdop%100);
      Console_printf("       Speed: %d.%1.1dkts :)\n",SatStatus.Speed/10,SatStatus.Speed%10);

      Console_printf("  Sat Signal: [CH#, Sat#, SNR] for 12 max");
      for (i=0;i<MAXSATS;i=i+3)
      {
         Console_printf("\n              ");
         for (j=i;j<i+3;j++)
         {
            if (j<SatStatus.nSats)
            {
               Console_printf("[%2d %2d %2d] ",j,SatStatus.SatDat[j].SatNum,SatStatus.SatDat[j].SatSNR);
            }
         }
      }
      Console_printf("\n");
   }
}

/*******************************************************************************
* Routine  : Stat_Power
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command reports the Repeater power state (just the state of the
* ACFAIL signal.
*******************************************************************************/
void Stat_Power(void)
{
    if (ACFAIL_State())
    {
       Console_printf("AC has failed, repeater must be on battery power!\n") ;
    }
    else
    {
	   Console_printf("Repeater running normally on AC.\n") ;
    }
}

/*******************************************************************************
* Routine  : Stat_RSSI
*   Inputs : argc,argv
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command gets the RSSI (in DAC value) and shows it in DAC-ese, Volts, and
* dBm.  If an argument is provided, the RSSI value is sampled that many times
* at 1-second intervals.
*******************************************************************************/
void Stat_RSSI(int argc, char* argv[])
{
   int      count       =  1    ; /* Sample count (default is 1) */
   int      err         = false ; /* Error flag                  */
   int      i           =  0    ; /* Loop counter                */
   char     abar[27]    = {0}   ;
   char     hbar[27]    = {0}   ;

   if (3==argc)
   {
	   count = parse_num(argv[2],1,300,&err) ;
   }

   if (err)
   {
      Console_printf("Parameter error, sample count can be 1-300.\n") ;
      count = 1 ;
   }

   for (i=0;i<count*10;i++)
   {
      RssiBar(Get_Analog_RSSI(),abar) ;
      RssiBar(Hpf_RSSI,hbar) ;
      Console_printf("RSSI ADC: %3d %26s HPF %3d %26s\n",Get_Analog_RSSI(),abar,Hpf_RSSI,hbar);

      if (count>1) osDelay(100) ; /* Only delay if >1 sample */
   }

}

/*******************************************************************************
* Routine  : RssiBar
*   Inputs : level (0-255)
*      IOs : bar (the signal strength bar)
*  Returns : Nothing
*  Globals : None
*
* This routine creates a signal strength bar with one character per 10 points
* on the bar, so 26 chars max for 0-255.  The incoming string should be 27
* characters for the EOS.
*******************************************************************************/
void RssiBar(int level,char* bar)
{
   int i = 0 ;

   /* Bound it just in case, I make a direct access below */
   if (level<  0) level = 0   ;
   if (level>255) level = 255 ;

   /* Make the core part of the bar */
   for (i=0;i<26;i++)
   {
      bar[i] = (i<level/10)?'=':'.' ;
      if ((i%5)==0) bar[i] = '|' ;
   }

   /* Put the tip on the bar and terminate the string */
   bar[level/10]='>' ;
   bar[26] = 0 ;
}

/*******************************************************************************
* Routine  : Stat_Sync
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command checks the local GPS time vs the time from the DIAL server.  It
* does this by setting a flag for the DIALTask to send an auth packet.  The
* return auth packet has the servers timestamp.  The DIALTask captures the
* local timestamp of when that Auth packet comes back and the two are compared
* below.  About 1ms later is normal for network delay on a home network.
*******************************************************************************/
void Stat_Sync(void)
{
   int     i      = 0 ; /* Just a counter    */
   int32_t delta  = 0 ; /* DIAL-GPS    delta */
   int32_t delta1 = 0 ; /* DIAL-GPS s  delta */
   int32_t delta2 = 0 ; /* DIAL-GPS ns delta */

   /* Fire of the Sync Check (runs in the DIALTask) */
   SyncCheck = SYNCCHECK_START ;

   /* Wait for it to complete, should take less than 1 sec */
   while ((i++<100)&&(SyncCheck!=SYNCCHECK_IDLE)) osDelay(10) ;

   if (SYNCCHECK_IDLE==SyncCheck)
   {
      Console_printf("DIAL Time:%10.10u.%9.9u\r\n",DSSecs,DSnSecs) ;
      Console_printf("  MY Time:%10.10u.%9.9u\r\n",MySecs,MynSecs) ;

      /* Figger out the delta and print it.  This is messy as I'm trying to   */
      /* do 64-bit math, but can't figure out how to get printf to support    */
      /* 64 bit integers.  Not helping is wanting to do signed math with      */
      /* unsigned values!  I'm sure there is a cleaner way.                   */
      delta1 = ((int32_t)MySecs-(int32_t)DSSecs)*1000000  ; /* Iffy conversion*/
      delta2 = ((int32_t)MynSecs-(int32_t)DSnSecs)/1000 ;   /* Safe conversion*/
      delta  = delta1+delta2 ;
      Console_printf("Local vs DIAL Time delta (us): %d\r\n",delta) ;
   }
   else
   {
      Console_printf("Sync Check failed, no DIAL server response.\n");
   }
}

/*******************************************************************************
* Routine  : Stat_Tempr
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This command reads and displays the temperature of the on-board P3T1755
* temperature sensor.  It also reads the STM32s internal temperature sensor.
* I do share the I2C1 hardware with the NVM code in settings.c, but can't yet
* see a way they could conflict.  Both are CLI-driven routines and only one
* CLI command can be run at a time.
*******************************************************************************/
void Stat_Tempr(void)
{
   static int8_t i2c_tempr IN_DMADD2  = 0 ; /* DMAable buffer for I2C read    */
   uint16_t      itemp_ADCv           = 0 ; /* Internal temperature ADC value */
   int           itemp                = 0 ; /* Internal temperature (integer) */
   int           i                    = 0 ; /* General counter                */
   int           err                  = 0 ; /* Error accumulator              */
   uint16_t      *TS_CAL1=(uint16_t *)0x1FF1E820; /* Ref Temp value at  30C   */
   uint16_t      *TS_CAL2=(uint16_t *)0x1FF1E840; /* Ref Temp value at 110C   */

   /* First do an ADC calibration in single-ended mode. Yea this only needs   */
   /* to be done once, this is going to be run rarely.                        */
   if (HAL_ADCEx_Calibration_Start(&hadc3, ADC_CALIB_OFFSET_LINEARITY, ADC_SINGLE_ENDED) != HAL_OK) err++ ;

   /* Start the conversion */
   if (!err)
   {
	   if (HAL_ADC_Start(&hadc3) != HAL_OK) err++ ;
   }

   /* Wait for up to 10ms for the end of conversion */
   if (!err)
   {
      i = 0 ; /* redundant, but I like it */
      while ((HAL_ADC_PollForConversion(&hadc3,0) != HAL_OK) && (i<TEMP_CONV_MS))
      {
         i++ ;
         osDelay(1) ;
      }

      /* If we got to TEMP_CONV_MS, OOPS! */
      if (TEMP_CONV_MS==i) err++ ;
   }

   /* If we got this far without error, all set! */
   if (!err)
   {
      /* Get the converted value of regular channel */
      itemp_ADCv = HAL_ADC_GetValue(&hadc3);

      /* During production, ST measures the A/D conversion value for          */
      /* temperature at 30C (TS_CAL1) and 110C (TS_CAL2).  Linearly           */
      /* extrapolate using those two points to convert the current reading to */
      /* temperature.                                                         */
      /* The example code uses floating point math.  Yea the H750 does        */
      /* floating point (and does it fast), but I just like integer arithmetic*/
      /* for something this simple.  Main thing to not get tripped up is to   */
      /* do all the multiplies first to get big numbers before dividing.      */
      /* That avoids weird rounding errors                                    */
      itemp = 30+(80*(itemp_ADCv-*TS_CAL1))/(*TS_CAL2-*TS_CAL1) ;

      Console_printf("MCU temperature:  %2dC, %3dF.\n",itemp,(itemp*9)/5+32) ;
   }
   else
   {
      Console_printf("Error reading MCU temperature.\n") ;
   }

   /* Read the two bytes of PCB temperature sensor register address 0.        */
   /* (the temperature)                                                       */
   HAL_I2C_Mem_Read_DMA(&hi2c1,TEMPR_ADDRESS0,0,I2C_MEMADD_SIZE_8BIT,(uint8_t*)&i2c_tempr,1) ;
   Waiton_I2C_DMA(true) ;

   Console_printf("PCB temperature:  %2dC, %3dF.\n",i2c_tempr,(i2c_tempr*9)/5+32) ;

   /* Those are the guaranteed temperature sensors.  Now go scan for any more */
   /* P3T1755s that may have been added externally.  Up to 7 more.            */

   for (i=1;i<8;i++)
   {
      /* Temp sensor I2C address is base plus index times two */
	   if (HAL_OK==HAL_I2C_IsDeviceReady(&hi2c1,TEMPR_ADDRESS0+i*2,2,3))
      {
         /* Read the two bytes of off-board temperature sensor register       */
	     /*address 0. (the temperature)                                       */
         HAL_I2C_Mem_Read_DMA(&hi2c1,TEMPR_ADDRESS0+i*2,0,I2C_MEMADD_SIZE_8BIT,(uint8_t*)&i2c_tempr,1) ;
         Waiton_I2C_DMA(true) ;
         Console_printf("Ext temperature%d: %2dC, %3dF.\n",i,i2c_tempr,(i2c_tempr*9)/5+32) ;
      }
   }
}

