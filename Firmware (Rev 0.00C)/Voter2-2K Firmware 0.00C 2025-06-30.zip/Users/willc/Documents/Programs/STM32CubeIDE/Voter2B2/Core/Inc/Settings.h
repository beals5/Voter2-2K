#ifndef INC_SETTINGS_H_
#define INC_SETTINGS_H_

/******************************************************************************/
/* #defines                                                                   */
/******************************************************************************/
/* For NVM storage, these are the group IDs.  All IDs are defined here even   */
/* if the code may or many not be included.  This is to define and reserve    */
/* the group IDs and ensure they stay unique for each group.                  */
/* Each one of these groups has its own settings structure.  Common is always */
/* present, the rest are only present if that module is included.  See        */
/* Options.h for the #defines that decide what modules are in and out.        */
typedef enum
{
   TGRP_COMMON = 0,
   TGRP_LOCAL,
   TGRP_ASTERISK,
   TGRP_7330
} TLVT_GROUPS ;

#define SETTINGS_CHALLENGE_LEN 10
#define SETTINGS_PASSWORD_LEN 16
#define SETTINGS_FQDN_LEN 40
#define SETTINGS_CWID_LEN 10
#define SETTINGS_NAME_LEN 16

/* Logger2rt initial display options by group    */
#define LOGINIT_BOOT       LOG_SUPPORT
#define LOGINIT_MAINAPP    LOG_MAJOR
#define LOGINIT_ETHAPP     LOG_MAJOR
#define LOGINIT_ETHDVR     LOG_MAJOR
#define LOGINIT_KSZ8081    LOG_MAJOR
#define LOGINIT_ETHLL_IO   LOG_MAJOR
#define LOGINIT_CONSOLE    LOG_MAJOR
#define LOGINIT_I2C        LOG_MAJOR
#define LOGINIT_DIALTASK   LOG_MAJOR
#define LOGINIT_GPSCODE    LOG_MAJOR
#define LOGINIT_LOGTELNET  LOG_MAJOR
#define LOGINIT_LOCAL      LOG_MAJOR
#define LOGINIT_SPINOR     LOG_MAJOR
#define LOGINIT_SER2NET    LOG_MAJOR
#define LOGINIT_SPIMTR     LOG_MAJOR
#define LOGINIT_TFTP       LOG_MAJOR

#define TTONE_NONE         0xffff /* Flag for no tone*/

#define NFLAGS 8

typedef enum
{
   MAGIC_GOOD = 0,
   MAGIC_PGM,
   MAGIC_BAD,
} MAGIC_ENUMS ;

typedef enum
{
   PROBE_NONE = 0,
   PROBE_RXIN,
   PROBE_RXDEM,
   PROBE_RXVOICE,
   PROBE_TXSRC,
   PROBE_TXPL,
   PROBE_TXOUT,
   PROBE_RSSSIG,
   PROBE_RSSLVL,
} PROBE_ENUMS ;

/******************************************************************************/
/* Structures                                                                 */
/******************************************************************************/
/* These are the common settings, always present in any flavor of the Voter2  */
typedef struct
{
   uint32_t My_StaticIP      ; /* Device IP address (if static)*/
   uint32_t My_StaticSubnet  ; /* Device Subnet (static)       */
   uint32_t My_StaticGateway ; /* Gateway IP address (static)  */
   uint32_t My_StaticDNS     ; /* DNS IP address (static)      */
   uint32_t MySerialNum      ; /* Voter2 serial number         */ /*Saved in OTP     */
   uint32_t TFTP_Addr        ; /* TFTP Server IP address       */
   uint32_t GPS_Baud         ; /* GPS receiver baud rate       */
   uint16_t MyHwRev          ; /* Voter2 Hardware Revision     */ /*Saved in OTP     */
   uint16_t S2N_Port         ; /* Ser2Net TCP/IP Port          */
   uint16_t S2N_PollTime     ; /* Ser2Net Poll interval (ms)   */
   uint16_t TTone_lvl        ; /* Test Tone volume (or off)    */
   uint16_t TTone_freq       ; /* Test Tone frequency          */ /*Not saved in NVM */
   uint8_t  Initialized      ; /* Initialized flag             */ /*Not saved in NVM */
   uint8_t  MyMACAddr[6]     ; /* Device MAC Address           */ /*Saved in OTP     */
   uint8_t  My_IPMode        ; /* Voter IP aquisition mode     */
   uint8_t  Dirty            ; /* Dirty data flag              */ /*Not saved in NVM */
   uint8_t  GPS_PPSEdge      ; /* GPS receiver baud rate       */
   uint8_t  RxMode           ; /* RX mode (COR/CTCSS)          */
   uint8_t  RssiMode         ; /* RSSI mode (Analog/HPF)       */

   char Guest_Password [SETTINGS_PASSWORD_LEN]  ; /* User Account Password  */
   char Root_Password  [SETTINGS_PASSWORD_LEN]  ; /* Root Account Password  */
   char Voter_Name     [SETTINGS_NAME_LEN]      ; /* Voter's Name (for CLI) */
} SETTINGS ;

typedef struct
{
   uint8_t Boot    ; /* Logging mode for Booting          */
   uint8_t MainApp ; /* Logging mode for MainTask         */
   uint8_t EthApp  ; /* Logging mode for Ethernet app     */
   uint8_t EthLWIP ; /* Logging mode for Ethernet LWIP    */
   uint8_t KSZ8081 ; /* Logging mode for Ethernet PHY     */
   uint8_t Console ; /* Logging mode for ConsoleTask      */
   uint8_t i2c     ; /* Logging mode for I2C drivers      */
   uint8_t Dial    ; /* Logging mode for DialTask         */
   uint8_t GPS     ; /* Logging mode for GPS drivers      */
   uint8_t LogTel  ; /* Logging mode for Logger Telnet    */
   uint8_t Local   ; /* Logging mode for Local mode       */
   uint8_t Ser2Net ; /* Logging mode for Ser2Net task     */
   uint8_t SpiNor  ; /* Logging mode for SPINOR drivers   */
   uint8_t SpiMtr  ; /* Logging mode for SPI MTR2K intf   */
   uint8_t Tftp    ; /* Logging mode for TFTP Comms       */
} LOGGER_SETTINGS ;

/******************************************************************************/
/* Global Variables                                                           */
/******************************************************************************/
extern char* cmd_settings_cmd ;
extern char* cmd_settings_help ;

extern SETTINGS Settings ;
extern LOGGER_SETTINGS Logger ;
extern uint8_t Probe ;
extern uint8_t Flags[NFLAGS] ;

/******************************************************************************/
/* Global Routines                                                            */
/******************************************************************************/
extern void Settings_init(void) ;
extern void Settings_clear(void) ;
extern int  Cmd_settings(int, char**) ;
extern void Waiton_I2C_DMA (int) ;

void write_tlv_str  (uint32_t*,uint8_t,uint8_t,void*,int) ;
void write_tlv_i4   (uint32_t*,uint8_t,uint8_t,void*) ;
void write_tlv_i2   (uint32_t*,uint8_t,uint8_t,void*) ;
void write_tlv_i1   (uint32_t*,uint8_t,uint8_t,void*) ;

#endif /* INC_SETTINGS_H_ */
