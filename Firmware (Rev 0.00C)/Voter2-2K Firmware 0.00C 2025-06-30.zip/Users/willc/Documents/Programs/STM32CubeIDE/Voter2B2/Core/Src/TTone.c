/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the TTone file.  It is the UI part of the test tone generator.     */
/* This allows the user to change Settings.TTone_lvl and Settings.TTone_freq  */
/* that then gets interpreted in real-time by Tx_AddTones in Tx_DSP.c to      */
/* generate test tones.                                                       */
/* NOTE1: On purpose, Test Tone settings are not preserved across reboots.    */
/* NOTE2: Enabling tones also enables PTT.                                    */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Cmd_ttone - Test Tone CLI command                                       */
/*                                                                            */
/******************************************************************************/
// TO DO:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "string.h"
#include "Options.h"
#include "main.h"
#include "ConsoleTask.h"
#include "Settings.h"
#include "Utils.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
enum
{
   CMD_OOPS = 0,
   CMD_OFF,
   CMD_LEVEL,
   CMD_FREQ,
} TTONE_ENUMS ;

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
char* cmd_ttone_cmd  = "ttone" ;
char* cmd_ttone_help = "ttone - [off|level #|freq #]\n"
                       "        off - Disables test tone (normal operation)\n"
                       "        level - Tone amplitude (0-4096 or 0%-100%)\n"
                       "        freq - Tone frequency (1-4000)\n"
                       "        if no params, tone settings will be shown.\n";

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TOKENLIST TtoneCmds[] =
{
   {"off"  ,CMD_OFF  },
   {"level",CMD_LEVEL},
   {"freq" ,CMD_FREQ },
   {NULL   ,0        }
} ;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void TTone_Show_State(void) ;
static void TTone_off(void) ;
static void TTone_level(int, char*) ;
static void TTone_freq(int,char*) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : Cmd_ttone
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command sets up or shows the state of the test tone generator.
*******************************************************************************/
int Cmd_ttone(int argc, char* argv[])
{
   int error = false ; /* Parsing error flag */
   int Token = 0     ; /* Command token      */

   /* If no arguments, show test tone status */
   if (1==argc)
   {
      TTone_Show_State() ;
   }
   else /* at least one argument! */
   {
      /* See which settings command */
      Token = parse_token(TtoneCmds,argv[1],&error) ;

      if (error)
      {
         Console_printf("Parameter must be off, level or freq.\n") ;
      }
      else
      {
         switch(Token)
         {
            case CMD_OFF  : TTone_off  ()             ;  break ;
            case CMD_LEVEL: TTone_level(argc,argv[2]) ;  break ;
            case CMD_FREQ : TTone_freq (argc,argv[2]) ;  break ;
            default : /* Shouldn't happen */             break ;
         }
      }
   }

   return (0) ;
}

/*******************************************************************************
* Routine  : TTone_Show_State
*   Inputs : None
*      IOs : None
*  Returns : 0 for success always
*  Globals : Settings
*
* This shows the state of the Test Tone generator
*******************************************************************************/
static void TTone_Show_State(void)
{

   /* If Level is special value, means tone genertor is off */
   if (TTONE_NONE==Settings.TTone_lvl)
   {
      Console_printf("Test Tone disabled. (Set level to enable)\n") ;
   }
   else /* Test Tone is enabled! */
   {
      Console_printf("Test Tone enabled.\n") ;
      Console_printf("Amplitude %d/4096 or %d%%\n",Settings.TTone_lvl,Settings.TTone_lvl*100/4096) ;
      Console_printf("Frequency %dHz\n",Settings.TTone_freq) ;
   }

   Console_printf("NOTE: Test Tone settings are not preserved on reboot.\n") ;
}

static void TTone_off(void)
{
   Settings.TTone_lvl = TTONE_NONE ;
   Console_printf("Test Tone disabled.\n") ;
}

static void TTone_level(int argc, char* arg2)
{
   int newval = 0 ;
   int error = false ; /* Parsing error flag */

   if (argc!=3)
   {
      error = true ;
   }
   else
   {
      /* Handle percentage */
      if('%'==arg2[strlen(arg2)-1])
      {
         /* Kill the % char and parse the percent */
         arg2[strlen(arg2)-1]=0 ;
         newval=parse_num(arg2,0,100,&error)*4096/100 ;
      }
      else
      {
         /* Otherwise just the raw DAC range */
         newval=parse_num(arg2,0,4096,&error) ;
      }
   }

   if (error)
   {
      Console_printf("Level should be 0-4096 or 0%%-100%%.\n") ;
   }
   else
   {
      Settings.TTone_lvl = newval ;
      Console_printf("Level set to %d/4096 or %d%%\n",Settings.TTone_lvl,Settings.TTone_lvl*100/4096) ;
      Console_printf("NOTE: If in local mode and CTCSS enabled,\nTest Tone level is reduced by CTCSS level.\n") ;
   }
}

static void TTone_freq(int argc,char* arg2)
{
   int newval = 0 ;
   int error = false ; /* Parsing error flag */

   if (argc!=3)
   {
      error = true ;
   }
   else
   {
      newval=parse_num(arg2,1,4000,&error) ;
   }

   if (error)
   {
      Console_printf("Frequency should be 1-4000.\n") ;
   }
   else
   {
      Settings.TTone_freq = newval ;
      Console_printf("Frequency set to %dHz\n",Settings.TTone_freq) ;
   }
}
