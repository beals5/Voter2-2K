#ifndef __CONSOLETASK_H
#define __CONSOLETASK_H

/* There is an available external #define called CONSOLE_NOLOGIN that will    */
/* bypass the login sequence if there is no need for that feature.  If        */
/* defined, there is just a prompt 'OK>' on connecting and after each command */
/* is complete.  In this mode, the state is root mode as well.                */
/* For This project, the (optional) place for that #define is in the          */
/* Options.h file.                                                            */

#define LEN_EOS -1 /* "length" that says data is a null-terminated string.    */

extern uint8_t UART_RxChar   ;
extern int     RootMode      ;

/* The three system command descriptors */
extern char* cmd_help_cmd    ;
extern char* cmd_help_help   ;
extern char* cmd_logout_cmd  ;
extern char* cmd_logout_help ;
extern char* cmd_reboot_cmd  ;
extern char* cmd_reboot_help ;

/* The three system CLI commands */
extern int  Cmd_help  (int, char**) ;
extern int  Cmd_logout(int, char**) ;
extern int  Cmd_reboot(int, char**) ;

extern void ConEthRxTask(void const*) ;
extern void ConsoleTask(void const*) ;
extern int  MyCLI_Register(char*, char*,int (*cmd_routine)(int,char**)) ;
extern int  ParseLine(char*,int*,char**) ;

extern int  Console_printf(const char* format, ...) ;
extern void Console_puts(char*) ;
extern int  Consoleio_gets(char*,int) ;
extern void ConUARTRxComplete(void) ;
extern void ConUARTTxComplete(void) ;

#endif /* __CONSOLETASK_H */
