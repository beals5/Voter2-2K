#ifndef INC_GPS_H_
#define INC_GPS_H_

#define COORDSTRLEN 16
#define MAXSATS 12

/* I only see a max sentence length of 78, but going to make this longer just */
/* just in case.  I have the circular buffer 2x a sentence, but is isn't a    */
/* ping pong buffer, so likely can reduce this a lot too (+5-10 vs 2x).       */
#define MAX_SENTENCE_LEN 128                /* Max possible NMEA Sentence     */
#define GPS_RX_BUFSIZE (MAX_SENTENCE_LEN*2) /* Enough for TWO sentences       */

typedef enum
{
   GPS_SENT_OK = 0,
   GPS_SENT_BADSTR,
   GPS_SENT_BADCHECK,
   GPS_SENT_IGNORED
} GPS_SENT_STATUS ;

typedef struct
{
   char     Status                 ; /* 'A' for good, 'V' for invalid */
   char     Longitude[COORDSTRLEN] ; /* string form only              */
   char     Latitude[COORDSTRLEN]  ; /* string form only              */
   char     LongDir                ; /* N/S                           */
   char     LatDir                 ; /* E/W                           */
   uint16_t Altitude               ; /* In meters, ignoring decimal   */
   uint8_t  UTC_Year               ;
   uint8_t  UTC_Month              ;
   uint8_t  UTC_Day                ;
   uint8_t  UTC_Hour               ;
   uint8_t  UTC_Min                ;
   uint8_t  UTC_Sec                ;
   uint16_t UTC_mSec               ;
} GPS_STRUCT ;

typedef struct
{
   uint8_t SatNum ; /* GPS Satellite number   */
   uint8_t SatSNR ; /* SNR for that satellite */
} SATDAT ;

typedef struct
{
   uint8_t  nSats           ; /* Number of satellites received    */
   uint16_t Speed           ; /* Ground speed (knots)             */
   uint16_t hdop            ; /* Horizontal dilution of precision */
   SATDAT   SatDat[MAXSATS] ; /* Data for up to 12 satellies      */
} SAT_STATUS ;

extern GPS_STRUCT GPSData     ; /* The necessary stuff      */
extern SAT_STATUS SatStatus   ; /* The informational stuff  */
extern uint8_t    GPSRx_buf[GPS_RX_BUFSIZE] ; /* UART char  */

extern void GPS_1PPS_Handler(uint32_t,int32_t) ;
extern void MY_UART3_Svc(void) ;
extern void Get_GPSTime(uint32_t*,uint32_t*) ;

#endif /* INC_GPS_H_ */
