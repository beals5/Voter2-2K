/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Ser2NetTask file.  It is in charge of implementing the Ser2Net */
/* function (remote UART access via Telnet+RFC2217).  It does operate pretty  */
/* much independently from the rest of Voter2, it is just an Ethernet bridge  */
/* to the UART for controlling the repeater using Telnet+RFC2217.             */
/* This isn't a complete RFC2217 implementation, just what I need for this    */
/* project.  So far it is just option commands 1-4, so basic UART Tx/Rx but   */
/* no flow control or error handling.                                         */
/******************************************************************************/
/* Public routines are:                                                       */
/*  - Ser2NetRxTask - The RTOS task for incoming Ethernet traffic             */
/*  - S2NUARTTxComplete - Ser2Net UART Tx DMA complete ISR                    */
/******************************************************************************/
// To Do:
//  - Make Port # and Rx Timeout user programmable.
/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>

#include "cmsis_os.h"
#include "lwip.h"
#include "lwip/opt.h"
#include "lwip/sys.h"
#include "lwip/api.h"

#include "Options.h"
#include "main.h"
#include "logger2rt.h"
#include "Settings.h"
#include "EthernetTask.h"
#include "Ser2NetTask.h"

/******************************************************************************/
/* Local defines (using enums)                                                */
/******************************************************************************/
typedef enum { /* COMPORT Subnegotiation commands */
   CPCMD_SIG = 0,
   CPCMD_BAUD,
   CPCMD_DBITS,
   CPCMD_PARITY,
   CPCMD_STOP,
   CPCMD_CONTROL,
} COMPORT_SN_COMMANDS ;

#define S2N_SBSIZE      16 /* Subnegotiaion message max size  */
#define S2N_IOBUFSIZE  128 /* IO buffer size (UART Tx).       */

/* Supported TelNet commands */
#define CMD_DATA   0 /* This is for data (not a command) */
#define CMD_IAC  255
#define CMD_WILL 251
#define CMD_WONT 252
#define CMD_DO   253
#define CMD_DONT 254
#define CMD_SB   250
#define CMD_SE   240

/* Supported Telnet Options */
#define TELNET_BINARY 0
#define TELNET_COMPORT 44

/******************************************************************************/
/*  typedefs                                                                  */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
/* The DMAd circular buffer and netconn out buffer */
uint8_t S2NRx_buf   [S2N_RX_BUFSIZE   ] IN_DMADD2 = {0} ;
uint8_t S2NRxOut_buf[S2N_RXDMA_BUFSIZE]           = {0} ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static struct netconn *S2Nconn    = NULL  ; /* Telnet connection (pre-connect)*/
static struct netconn *S2Nnewconn = NULL  ; /* Telnet connection (post-connect)*/

/* Telnet Options status. For a VNT they all start off false */
static int Telnet_Binary  = false ;
static int Telnet_Comport = false ;

/* The UART Tx ring buffer */
static uint8_t S2NTxQueue[S2N_IOBUFSIZE] IN_DMADD2 = {0} ; /* UART Tx data */
static int     S2NTxWrPtr = 0 ; /* Tx queue write pointer */
static int     S2NTxRdPtr = 0 ; /* Tx queue read pointer  */

static volatile int UART_TXBusy = false ; /* UART DMA Tx busy flag  */
static int TxDataBytes          = 0     ; /* Data bytes in a packet */

static char* Parities[] =
{
   "Query",
   "None" ,
   "Odd"  ,
   "Even" ,
} ;

static char* StopBits[] =
{
   "Query",
   "1"    ,
   "2"    ,
   "1.5"  ,
} ;

/******************************************************************************/
/* External globals. How CubeMX does things instead of in an include file,    */
/* weird.                                                                     */
/******************************************************************************/
extern osThreadId Ser2NetRxTaskIDHandle ;
extern UART_HandleTypeDef huart7 ;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
void Telnet_gotc   (uint8_t) ;
int  Telnet_RxWill (uint8_t) ;
int  Telnet_RxWont (uint8_t) ;
int  Telnet_RxDo   (uint8_t) ;
int  Telnet_RxDont (uint8_t) ;
int  Telnet_RxSub  (uint8_t) ;
void ComPort_SN    (uint8_t*,int) ;

void CpCmd_Baud    (uint8_t*) ;
void CpCmd_DBits   (uint8_t*) ;
void CpCmd_Parity  (uint8_t*) ;
void CpCmd_Stop    (uint8_t*) ;
void CpCmd_Control (uint8_t*) ;

void Change_UART   (int,uint32_t) ;
void CpCmdAck      (int,uint8_t*,int) ;

void Telnet_TxDo   (uint8_t) ;
void Telnet_TxDont (uint8_t) ;
void S2N_ToUART    (uint8_t) ;

/******************************************************************************/
/* Local routines (finally!)                                                  */
/******************************************************************************/

/*******************************************************************************
* Routine  : Ser2NetRxTask
* Gazintas : None
* IOs      : None
* Returns  : Never
* Globals  : EnableS2NQueue - Semaphore to enable incoming packets
*          : S2Nconn, S2Nnewconn - LWIP handles for the telnet interface
*          : Lots of others too!
*
* This is the task for incoming packets via Ethernet that also polls the UART
* Rx DMA circular queue for any pending data.  LWIPs netconn API is (mostly)
* blocking but I cheat a bit.  While waiting on IP data, I do so with a
* timeout.  At each timeout I check if there is any UART Rx data and if so,
* send it on to netconn.  UART Rx data is just DMA'd into a circular queue,
* so no CPU overhead other than the polling in this loop which is only if
* there is an active netconn connection.
*******************************************************************************/
void Ser2NetRxTask(void const * argument)
{
   static int    LastIndex = 0    ; /* End of last buff pointer     */
   int           ThisIndex = 0    ; /* End of current buff pointer  */
   int           CopyIndex = 0    ; /* Copying pointer              */
   int           DMAd_len  = 0    ; /* New buffer data size         */
   int           dst       = 0    ; /* DMA destination pointer      */

   struct netbuf *buf      = NULL ; /* Buffer for incoming TCP data */
   u16_t         len       = 0    ; /* payload length               */
   err_t         err       = 0    ; /* Result code                  */
   uint8_t*      data      = NULL ; /* Telnet data to be parsed     */

   /* Startup sequencing enforcement. See Options.h */
   osDelay(StartDelay_Ser2NetTask) ;
   Logger2_Msg(Logger.Ser2Net,LOG_MAJOR,LOG_TIME,"Ser2NetRxTask: Start\r\n") ;

   /* Create a new Ethernet port and bind it to the Ser2Net port ID */
   S2Nconn = netconn_new(NETCONN_TCP);
   netconn_bind(S2Nconn, IP_ADDR_ANY, Settings.S2N_Port);
   Logger2_Msg(Logger.Ser2Net,LOG_SUPPORT,LOG_TIME,"Ser2NetRxTask: netconn_new (0x%8.8x)\r\n",(uint32_t)S2Nconn) ;

   /* Go into listening mode. */
   netconn_listen(S2Nconn);

   while (1) /* Task infinite loop */
   {
      /* Wait for a connection... */
      Logger2_Msg(Logger.Ser2Net,LOG_SUPPORT,LOG_TIME,"Ser2NetRxTask: Waiting for a connection\r\n") ;
      err = netconn_accept(S2Nconn, &S2Nnewconn);
      Logger2_Msg(Logger.Ser2Net,LOG_MAJOR,LOG_TIME,"Ser2NetRxTask: Telnet Connection (%d)\r\n",err) ;

      /* For receive data, instead of blocking, have a user settable timeout. */
      /* This lets me poll for UART Rx data in the same task.                 */
      netconn_set_recvtimeout(S2Nnewconn,Settings.S2N_PollTime) ;

      /* If connected, start processing incoming data */
      if (err == ERR_OK)
      {
         /* Happy looping as long as no errors or (allowable) timeout error   */
         while ((ERR_OK==err) || (ERR_TIMEOUT==err))
         {
            /* Get data or a timeout */
            err = netconn_recv(S2Nnewconn, &buf) ;
            /* Whether a timeout or even if we got netconn data, first see if */
            /* any UART Rx data is pending.                                   */

            /* Data is being DMAd into a circular buffer. We have the end of  */
            /* the last poll, get the end of the current DMA position.        */
            /* The DMA counter is bytes DMAd, so index is size-count.         */
            ThisIndex = S2N_RX_BUFSIZE - __HAL_DMA_GET_COUNTER(huart7.hdmarx) ;
            /* The index actually points to the byte after the last byte, so  */
            /* go back 1.  Fancy math to gracefully handle wraps.             */
            ThisIndex = (ThisIndex+S2N_RX_BUFSIZE-1)%S2N_RX_BUFSIZE ;
            /* Get the message length, with same fancy wraparound math.       */
            DMAd_len = (ThisIndex+S2N_RX_BUFSIZE-LastIndex)%S2N_RX_BUFSIZE ;

            /* The Rx data may generate multiple netconn writes, so a loop if */
            /* it does                                                        */
            while (DMAd_len>0)
            {
               Logger2_Msg(Logger.Ser2Net,LOG_REGIO,LOG_TIME,"Ser2NetRxTask: UART Rx data (%d)\r\n",DMAd_len) ;

               /* Copy UART Rx data to the netconn buffer translating 0xff    */
               /* data to double-IAFs and ending early if we run into the end */
               /* of the netconn buffer.                                      */

               /* LastIndex was the last byte from the last poll, so +1 for   */
               /* first byte of the current buffer.                           */
               CopyIndex = (LastIndex+1)%S2N_RX_BUFSIZE ;
               dst = 0 ;

               /* I stop at S2N_RXDMA_BUFSIZE-2 so that I don't have to       */
               /* handle wraps on a double-IAF.                               */
               while ((DMAd_len>0)&&(dst<S2N_RXDMA_BUFSIZE-1))
               {
                  /* if src data is 0xff, we want a double-IAF.               */
                  if (0xff==S2NRx_buf[CopyIndex]) S2NRxOut_buf[dst++] = 0xff ;

                  /* Copy either second IAF or just regular data if not IAF.  */
                  S2NRxOut_buf[dst++] = S2NRx_buf[CopyIndex++] ;

                  /* dst can't wrap, but src can */
                  CopyIndex = CopyIndex%S2N_RX_BUFSIZE ;
                  DMAd_len-- ;
               }
               /* End at either no data left (DMAd_len=0) or the end of the   */
               /* output buffer.  If the latter, we'll loop back to finish it.*/

               /* Write what we got! */
               Logger2_Msg(Logger.Ser2Net,LOG_REGIO,LOG_TIME,"Ser2NetRxTask: UART Rx DMA out (%d)\r\n",dst) ;
               netconn_write(S2Nnewconn,&S2NRxOut_buf,dst,NETCONN_COPY) ;
            }

            /* All done, save the current EOS to be the ref for next time.    */
            LastIndex = ThisIndex ;

            /* That was UART Rx data, now onto netconn incoming data (if any) */
            if (ERR_OK==err)
            {
               /* If we got data from netconn_recv, queue it up for sending   */
               /* over the UART.                                              */
               if (buf->p->len>0)
               {
                  /* For debugging only, count IO (vs command) bytes.         */
                  TxDataBytes = 0 ;

                  Logger2_Msg(Logger.Ser2Net,LOG_REGIO,LOG_TIME,"Ser2NetRxTask: Got IP Data (%d)\r\n",buf->p->len) ;
                  do
                  {
                     /* get the payload and send it to get parsed one byte at a time */
                     netbuf_data(buf, (void*)(&data), &len);
                     while (len>0)
                     {
                        Telnet_gotc(*(data++)) ;
                        len-- ;
                     }
                  } while (netbuf_next(buf) >= 0);
                  netbuf_delete(buf); /* all done, free the pbuf */
                  Logger2_Msg(Logger.Ser2Net,LOG_REGIO,LOG_TIME,"Ser2NetRxTask: UART Tx data: (%d)\r\n",TxDataBytes) ;
               }
            }
         } /* while no errors */

         /* Close connection and discard connection identifier. */
         Logger2_Msg(Logger.Ser2Net,LOG_MAJOR,LOG_TIME,"Ser2NetRxTask: Connection closed by client\r\n") ;
         netconn_close(S2Nnewconn);
         netconn_delete(S2Nnewconn);
      }
   }
}


/*******************************************************************************
* Routine  : Telnet_gotc
* Gazintas : data - single byte of data from Telnet
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine takes characters from the Ethernet and processes the one byte
* at a time.  The various escape codes make this important to handle that way.
* For escape sequences, this may result in UART parameters being changed and/or
* reply sequences send back to Ethernet.  For "regular" data, it is queued up
* to be sent to the UART.
*
* This is the top level routine (along with subroutines) that implement the
* core parts of the RFC854 (Telnet) and RFC2217 (Telnet Com Port Control) protocols.
*******************************************************************************/
void Telnet_gotc(uint8_t data)
{
   static int CmdState = CMD_DATA ;

   if (CMD_DATA==CmdState)
   {
      /* If in "Normal state", just echo anything unless it is an IAC.  If    */
      /* an IAC, just remember that and wait for the next byte                */
      if (CMD_IAC==data)
      {
         CmdState = CMD_IAC ;
      }
      else
      {
         S2N_ToUART(data) ;
      }
   }
   else if (CMD_IAC==CmdState) /* we are in a command state */
   {
      /* After an IAC, if another IAC, just send 0xff to the UART.  If a      */
      /* supported command, save it, if an unsupported command, ignore it.    */
      if (CMD_IAC==data)
      {
    	  S2N_ToUART(data) ;
    	  CmdState = CMD_DATA ;
      }
      else if ((data>=CMD_SB)&&(data<=CMD_DONT))
      {
         /* For WILL/WONT/DO/DONT and SB just remember the command and act on */
         /* the next byte.                                                    */
         CmdState = data ;
      }
      /* If anything else, just drop it */
   }
   else
   {
      /* Only thing left is we're the byte after a supported command.         */
      /* All commands except for SB finish after this byte.  For SB, we just  */
      /* keep sending bytes to the SB handler that will accumulate them until */
      /* we get an (IAC SE)                                                   */
      switch (CmdState)
      {
         case CMD_WILL : CmdState = Telnet_RxWill(data) ; break ;
         case CMD_WONT : CmdState = Telnet_RxWont(data) ; break ;
         case CMD_DO   : CmdState = Telnet_RxDo  (data) ; break ;
         case CMD_DONT : CmdState = Telnet_RxDont(data) ; break ;
         case CMD_SB   : /* all these go to the subnegotiation handler */
         case CMD_SE   :
         case CMD_IAC  : CmdState = Telnet_RxSub (data) ; break ;
         default       : /* Should never happen */        break ;
      }
   }
}

/*******************************************************************************
* Routine  : Telnet_RxWill
* Gazintas : data - Option Byte
* IOs      : None
* Returns  : next state (always CMD_DATA)
* Globals  : None
*
* This routine handles the Telnet WILL command.  I expect WILL/WONT commands
* from the client (the other PC) and will respond with DO/DONT commands.
* WILL commands I'm expecting are:
*  -  0: Binary Option (was expecting it, but hub0com doesn't send it!)
*  - 44: COM Port Option
*  For the supported options I will reply with DO commands, for all other
*  options I will reply with DONT commands.
*  Per spec, if the option is already enabled, don't reply at all!
*******************************************************************************/
int Telnet_RxWill(uint8_t data)
{
   Logger2_Msg(Logger.Ser2Net,LOG_SUPPORT,LOG_TIME,"Ser2NetRxTask: Rx WILL(%d)\r\n",data) ;

   /* For each supported option, set its support to true.  Only if already    */
   /* not already set, respond with a DO                                      */
   /* This is ripe for a macro or subroutine, do it later.                    */
   if (TELNET_BINARY==data)
   {
      if (!Telnet_Binary) Telnet_TxDo(TELNET_BINARY) ;
      Telnet_Binary = true ;
   }
   else if (TELNET_COMPORT==data)
   {
      if (!Telnet_Comport) Telnet_TxDo(TELNET_COMPORT) ;
      Telnet_Comport = true ;
   }
   else
   {
      Telnet_TxDont(data) ;
   }

   return(CMD_DATA) ;
}

/*******************************************************************************
* Routine  : Telnet_RxWont
* Gazintas : data - Option Byte
* IOs      : None
* Returns  : next state (always CMD_DATA)
* Globals  : TBD
*
* This routine handles the Telnet WONT command.  I expect WILL/WONT commands
* from the client (the other PC) and will respond with DO/DONT commands.
* I'm not expecting any WONT commands.
*******************************************************************************/
int Telnet_RxWont(uint8_t data)
{
   Logger2_Msg(Logger.Ser2Net,LOG_SUPPORT,LOG_TIME,"Ser2NetRxTask: Rx WONT(%d)\r\n",data) ;
   return(CMD_DATA) ;
}

/*******************************************************************************
* Routine  : Telnet_RxDo
* Gazintas : data - Option Byte
* IOs      : None
* Returns  : next state (always CMD_DATA)
* Globals  : TBD
*
* This routine handles the Telnet DO command.  As I'm the access server, I'm
* not expecting to receive DO commands, just send them.
*******************************************************************************/
int Telnet_RxDo  (uint8_t data)
{
   Logger2_Msg(Logger.Ser2Net,LOG_SUPPORT,LOG_TIME,"Ser2NetRxTask: Rx DO(%d)\r\n",data) ;
   return(CMD_DATA) ;
}

/*******************************************************************************
* Routine  : Telnet_RxDont
* Gazintas : data - Option Byte
* IOs      : None
* Returns  : next state (always CMD_DATA)
* Globals  : TBD
*
* This routine handles the Telnet DONT command.  As I'm the access server, I'm
* not expecting to receive DONT commands, just send them.
*******************************************************************************/
int Telnet_RxDont(uint8_t data)
{
   Logger2_Msg(Logger.Ser2Net,LOG_SUPPORT,LOG_TIME,"Ser2NetRxTask: Rx DONT(%d)\r\n",data) ;
   return(CMD_DATA) ;
}

/*******************************************************************************
* Routine  : Telnet_RxSub
* Gazintas : data - Subnegotiation data
* IOs      : None
* Returns  : next state
* Globals  : TBD
*
* This routine handles SubNegotiation blocks.  Subnegotiation data gets
* accumulated with sequential SB calls, then acted on with the SE call.
* Obviously, this routine is stateful for the accumulation part.
*******************************************************************************/
int Telnet_RxSub  (uint8_t data)
{
   static uint8_t SubNegMsg[S2N_SBSIZE] = {0} ; /* Message accumulator */
   static int     MsgPtr                =  0  ; /* Message pointer     */

   int retval = CMD_SB ; /* Default */

   //Logger2_Msg(Logger.Ser2Net,LOG_REGIO,LOG_TIME,"Ser2NetRxTask: RxSub(%d)\r\n",data) ;

   /* Store the incoming byte no matter what (well except for overflow) */
   SubNegMsg[MsgPtr] = data ;
   MsgPtr=(MsgPtr+1)%S2N_SBSIZE ;

   /* Since I'm looking back for sequences, Make sure we have at least two    */
   /* bytes accumulated before doing anything fancy.                          */
   if (MsgPtr>1)
   {
      /* If we got two IACs in a row, it was just an 0xff data byte, go back one. */
      if ((CMD_IAC==data) && (CMD_IAC==SubNegMsg[MsgPtr-2])) MsgPtr-- ;

      /* If we got an (IAC SE) sequence, then we have the complete message! */
      else if ((CMD_SE==data) && (CMD_IAC==SubNegMsg[MsgPtr-2]))
      {
         /* I'm only expecting Subnegotiations for COMPORT protocol (at least */
         /*  so far). If this expands, go to a switch statement               */
         if (TELNET_COMPORT==SubNegMsg[0])
         {
            /* For the message length, subtract 2 for the (IACSB) flag */
   	        Logger2_Msg(Logger.Ser2Net,LOG_SUPPORT,LOG_TIME,"Ser2NetRxTask: SB(%d,%d,%d)\r\n",SubNegMsg[0],SubNegMsg[1],MsgPtr-2) ;
            ComPort_SN(SubNegMsg,MsgPtr-2) ;
         }
         else
         {
   	        Logger2_Msg(Logger.Ser2Net,LOG_SUPPORT,LOG_TIME,"Ser2NetRxTask: SB Option (%d) Not handled.\r\n",SubNegMsg[0]) ;
         }
         MsgPtr = 0 ; /* Reset the pointer for the next message */
         retval = CMD_DATA ; /* and go back to the data state */
      }
      /* If not (IAC,IAC) or (IAC,SE), just keep accumulating bytes */
   }
   return(retval) ;
}

/*******************************************************************************
* Routine  : ComPort_SN
* Gazintas : msg - the Subnegotiation message
*          : len - message length
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine handles a COMPORT Subnegotiation message.  I currently handle
* only message IDs 1-4, ignoring 0 and 5-12.  Basically just serial comms, no
* HW or SW flow control or error conditions.
*
* NOTE: Can I ignore unsupported IDs or should I respond negatively?
*******************************************************************************/
void ComPort_SN (uint8_t* msg,int len)
{
   /* We only get here if msg[0] is 44 (COMPORT option), so start looking at  */
   /* what COMPORT option is being sent.                                      */
   switch(msg[1])
   {
      case CPCMD_BAUD    : CpCmd_Baud   (msg+2) ; break ;
      case CPCMD_DBITS   : CpCmd_DBits  (msg+2) ; break ;
      case CPCMD_PARITY  : CpCmd_Parity (msg+2) ; break ;
      case CPCMD_STOP    : CpCmd_Stop   (msg+2) ; break ;
      case CPCMD_CONTROL : CpCmd_Control(msg+2) ; break ;
      default            : /* Ignore others */    break ;
   }
}

/*******************************************************************************
* Routine  : CpCmd_Baud, CpCmd_DBits, CpCmd_Parity, CpCmd_Stop, CpCmd_Control
* Gazintas : data - Command data
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* These are the routines handling the supported COMPORT Subnegotiation
* commands.
*******************************************************************************/
void CpCmd_Baud (uint8_t* data)
{
   uint32_t NewBaud = 0 ; /* New Baud rate */

   /* Get the baud into a word-aligned, host format */
   memcpy(&NewBaud,data,4)  ;
   NewBaud = ntohl(NewBaud) ;

   /* A value of 0 means just query the baud rate */
   if (0==NewBaud)
   {
      NewBaud = huart7.Init.BaudRate ;
   }
   else
   {
      /* We have a new baud rate.  Go set it and note it if logging enabled   */
      Change_UART(CPCMD_BAUD,NewBaud) ;
      Logger2_Msg(Logger.Ser2Net,LOG_SUPPORT,LOG_TIME,"Ser2NetRxTask: New Baudrate: %d\r\n",NewBaud) ;
   }

   /* Whether query or set, return the baud rate */
   NewBaud = htonl(NewBaud) ; /* Convert back to network format */
   CpCmdAck(CPCMD_BAUD,(uint8_t*)&NewBaud,4) ;
}

void CpCmd_DBits (uint8_t* data)
{
   uint8_t bits = *data ;

   /* Telnet supports data bit sizes of 5-8 bits.         */
   /* The STM32 supports data bit sizes of 7-9 bits.      */
   /* So, LCS is 7 or 8 bits, but only 8-bit makes sense. */

   /* A value of 0 means just query the data bits */
   if (0==bits)
   {
      bits = (UART_WORDLENGTH_8B==huart7.Init.WordLength)?8:7 ;
   }
   else
   {
      /* We have a data size, limit it to 7 or 8 bits only */
      if (8!=bits) bits = 7 ;
      Change_UART(CPCMD_DBITS,(8==bits)?UART_WORDLENGTH_8B:UART_WORDLENGTH_7B) ;
      Logger2_Msg(Logger.Ser2Net,LOG_SUPPORT,LOG_TIME,"Ser2NetRxTask: New data bits: %d\r\n",bits) ;
   }

   /* Whether query or set, return the baud rate */
   CpCmdAck(CPCMD_DBITS,&bits,1) ;
}

void CpCmd_Parity (uint8_t* data)
{
   uint8_t  parity = *data ; /* Easier          */
   uint32_t StmVal =     0 ; /* STM32 HAL value */

   /* Telnet supports None, Even, Odd, Mark, Space parities. */
   /* The STM32 supports None, Even, Odd only.               */
   /* Map unused Telnet parties to none.                     */

   /* A value of 0 means just query the data bits */
   if (0==parity)
   {
      switch(huart7.Init.Parity)
      {
          case UART_PARITY_NONE : parity = 1 ; break ;
          case UART_PARITY_EVEN : parity = 3 ; break ;
          case UART_PARITY_ODD  : parity = 2 ; break ;
          default               : parity = 1 ; break ;
      }
   }
   else
   {
      switch(parity)
      {
          case 1 : StmVal = UART_PARITY_NONE ;              break ;
          case 2 : StmVal = UART_PARITY_ODD  ;              break ;
          case 3 : StmVal = UART_PARITY_EVEN ;              break ;
          default: StmVal = UART_PARITY_NONE ; parity = 1 ; break ; /* override value */
      }

      Change_UART(CPCMD_PARITY,StmVal) ;
      Logger2_Msg(Logger.Ser2Net,LOG_SUPPORT,LOG_TIME,"Ser2NetRxTask: New Parity: %s\r\n",Parities[parity]) ;
   }

   /* Whether query or set, return the baud rate */
   CpCmdAck(CPCMD_PARITY,&parity,1) ;
}

void CpCmd_Stop (uint8_t* data)
{
   uint8_t  stop   = *data ; /* Easier          */
   uint32_t StmVal =     0 ; /* STM32 HAL value */

   /* Telnet supports 1, 1.5, and 2 stop bits.         */
   /* The STM32 supports 0.5, 1, 1.5, and 2 stop bits. */
   /* Map STs 0.5 to 1 stop bit for Telnet.            */

   /* A value of 0 means just query the data bits */
   if (0==stop)
   {
      switch(huart7.Init.StopBits)
      {
          case UART_STOPBITS_0_5 : stop = 1 ; break ;
          case UART_STOPBITS_1   : stop = 1 ; break ;
          case UART_STOPBITS_1_5 : stop = 3 ; break ;
          case UART_STOPBITS_2   : stop = 2 ; break ;
          default                : stop = 1 ; break ;
      }
   }
   else
   {
      switch(stop)
      {
          case 1 : StmVal = UART_STOPBITS_1   ; break ;
          case 2 : StmVal = UART_STOPBITS_2   ; break ;
          case 3 : StmVal = UART_STOPBITS_1_5 ; break ;
          default: StmVal = UART_STOPBITS_1   ; break ;
      }

      Change_UART(CPCMD_STOP,StmVal) ;
      Logger2_Msg(Logger.Ser2Net,LOG_SUPPORT,LOG_TIME,"Ser2NetRxTask: New Stop Bits: %s\r\n",StopBits[stop]) ;
   }

   /* Whether query or set, return the baud rate */
   CpCmdAck(CPCMD_STOP,&stop,1) ;
}

void CpCmd_Control (uint8_t* data)
{
   /* For now, just see what the control command is. */
   Logger2_Msg(Logger.Ser2Net,LOG_SUPPORT,LOG_TIME,"Ser2NetRxTask: Control %d\r\n",*data) ;
}

/*******************************************************************************
* Routine  : Change_UART
* Gazintas : param - parameter to change
*          : newval - New value for that parameter
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine takes care of stopping the UART, changing the requested
* parameter, and then re-starting the UART.
* NOTE: More example of why abandoning the HAL makes sense for the UART, this
* is a LOT of overhead!
*******************************************************************************/
void Change_UART(int param,uint32_t newval)
{
   /* Stop the UART */
   HAL_UART_DMAStop(&huart7);
   HAL_UART_DeInit(&huart7);

   switch (param)
   {
      case CPCMD_BAUD  : huart7.Init.BaudRate   = newval ; break ;
      case CPCMD_DBITS : huart7.Init.WordLength = newval ; break ;
      case CPCMD_PARITY: huart7.Init.Parity     = newval ; break ;
      case CPCMD_STOP  : huart7.Init.StopBits   = newval ; break ;
      default          :                                   break ;
   }

   /* Re-start the UART */
   HAL_UART_Init(&huart7) ;
   HAL_UART_Receive_DMA (&huart7,S2NRx_buf,S2N_RX_BUFSIZE) ;
}

/*******************************************************************************
* Routine  : CpCmdAck
* Gazintas : cmd - the Subnegotiotion command we're acknowledging
*          : data - the parameter being acknowledged
*          : len - parameter length (in bytes)
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This send out a subnegotiation command acknowledgment.  It is just byte
* stuffing the info and then sending it to netconn.
*******************************************************************************/
void CpCmdAck (int cmd,uint8_t* data,int len)
{
   uint8_t cmdbuf[S2N_SBSIZE] = {0} ; /* Telnet reply buffer (max size) */
   int     i                  =  0  ; /* Counter                        */

   if (len<S2N_SBSIZE-6)
   {
      cmdbuf[0] = CMD_IAC ;
      cmdbuf[1] = CMD_SB  ;
      cmdbuf[2] = TELNET_COMPORT ;
      cmdbuf[3] = cmd ;
      for(i=0;i<len;i++) cmdbuf[4+i]=data[i] ;
      cmdbuf[len+4] = CMD_IAC ;
      cmdbuf[len+5] = CMD_SE  ;
      netconn_write(S2Nnewconn,cmdbuf,len+6,NETCONN_COPY) ;
   }
}

/*******************************************************************************
* Routine  : Telnet_TxDo, TxDont
* Gazintas : data - Option byte to "do" or "don't"
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* These routines return the Telnet DO and DONT commands.
*******************************************************************************/
void Telnet_TxDo (uint8_t data)
{
   uint8_t cmdbuf[3] = {0} ;

   Logger2_Msg(Logger.Ser2Net,LOG_SUPPORT,LOG_TIME,"Ser2NetRxTask: Tx DO(%d)\r\n",data) ;
   cmdbuf[0] = CMD_IAC ;
   cmdbuf[1] = CMD_DO ;
   cmdbuf[2] = data ;
   netconn_write(S2Nnewconn,cmdbuf,3,NETCONN_COPY) ;
}

void Telnet_TxDont (uint8_t data)
{
   uint8_t cmdbuf[3] = {0} ;

   Logger2_Msg(Logger.Ser2Net,LOG_SUPPORT,LOG_TIME,"Ser2NetRxTask: Tx DONT(%d)\r\n",data) ;
   cmdbuf[0] = CMD_IAC ;
   cmdbuf[1] = CMD_DONT ;
   cmdbuf[2] = data ;
   netconn_write(S2Nnewconn,cmdbuf,3,NETCONN_COPY) ;
}

/*******************************************************************************
* Routine  : S2N_ToUART
* Gazintas : data - data byte
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This is the routine to queue up data to be sent out via the UART.  All that
* is done here is to put it in the outgoing queue.  The ISR for the UART Tx
* picks it up.
*
* NOTE: I stall Ethernet on Queue full, I think that is OK.
*******************************************************************************/
void S2N_ToUART(uint8_t data)
{
   int JustWrote = 0 ; /* Just written byte (before increment) */

   /* If the buffer is full, stall. Fancy overflow math follows */
   while (S2NTxWrPtr==(S2NTxRdPtr+S2N_IOBUFSIZE-1)%S2N_IOBUFSIZE) osDelay(10) ;

   TxDataBytes++ ; /* Acknowledge this is a byte of actual data */

   /* When there is space, save the byte */
   S2NTxQueue[S2NTxWrPtr] = data ;
   JustWrote  =  S2NTxWrPtr ;
   S2NTxWrPtr = (S2NTxWrPtr+1)%S2N_IOBUFSIZE ;

   /* If the UART is idle, fire up the UART to transmit just this first byte.*/
   /* Note that if the UART is busy, just keep queueing up data.  When the   */
   /* UART end-of-DMA IRQ happens, it will send whatever has been queued up. */
   if (!UART_TXBusy)
   {
      UART_TXBusy = true ;
      HAL_UART_Transmit_DMA(&huart7,&S2NTxQueue[JustWrote],1) ;
      S2NTxRdPtr = S2NTxWrPtr ;
      /* After this first character gets sent, the TX_Complete ISR will look  */
      /* at the ring buffer and queue up as many bytes as there are.  Given   */
      /* data over Ethernet can come in a lot faster, subsequent DMAs can be  */
      /* more than a single byte.                                             */
   }
}

/*******************************************************************************
* Routine  : S2NUARTTxComplete
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : UART_Complete
*
* This routine gets called when the Tx DMA for the Repeater UART is complete.
* Look at the TX queue.  If something is still pending, DMA it out to the
* UART, otherwise set the Busy flag to false to tell the enqeuer to re-start
* the DMA on receipt of the next new data.
*******************************************************************************/
void S2NUARTTxComplete(void)
{
   int TempWrPtr = 0 ; /* Temporary write pointer in case of wraps */

   /* If the read and write pointers are the same, no data is pending, let    */
   /* enquerer know we are done, so that it knows to fire up the DMA the next */
   /* time data comes in to get sent.                                         */
   if (S2NTxWrPtr==S2NTxRdPtr)
   {
      UART_TXBusy = false ;
   }
   else
   {
      /* Otherwise, there is pending data!  It is a circular buffer, if the   */
      /* queued data wraps in the buffer, just DMA to the end of the buffer.  */
      /* At the end of that DMA, this code will then start another DMA        */
      /* starting at buffer start for any remaining data.                     */
      TempWrPtr = (S2NTxWrPtr>S2NTxRdPtr)?S2NTxWrPtr:S2N_IOBUFSIZE ;

      HAL_UART_Transmit_DMA(&huart7,&S2NTxQueue[S2NTxRdPtr],TempWrPtr-S2NTxRdPtr) ;
      S2NTxRdPtr = TempWrPtr%S2N_IOBUFSIZE ;
   }
}
