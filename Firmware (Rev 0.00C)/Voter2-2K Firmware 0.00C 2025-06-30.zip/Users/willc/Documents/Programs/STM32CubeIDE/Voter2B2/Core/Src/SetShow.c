/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Set/Show file.  It is in charge changing and showing various   */
/* system settings for the Voter2.  This is all via the set and show CLI      */
/* commands.                                                                  */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Cmd_set - Change settings CLI command                                   */
/*  - Cmd_show - Show settings CLI command                                    */
/*                                                                            */
/******************************************************************************/
// TO DO:
// More error checking on SetNum?

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>

#include "lwip.h"

#include "Options.h"
#include "main.h"
#include "ConsoleTask.h"
#include "Settings.h"
#include "Utils.h"
#include "DialTask.h"
#include "EthernetTask.h"
#include "Logger2rt.h"
#include "LocalMode.h"
#include "AnalogIO.h"
#include "Rx_DSP.h"
#include "Setshow.h"
#include "SPINOR.h"

#ifdef LOCALVOTER
#include "LocalVoter/LocalSettings.h"
#endif
#ifndef NODIALTASK
#include "DIALSettings.h"
#endif

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/
extern RNG_HandleTypeDef hrng ;

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
/* Right now no on/off commands to show, but rather than deleting the code,   */
/* just #ifdefing it out to avoid compiler complaints as I'll likely need it  */
/* later.                                                                     */
//#define SHOWONOF

enum
{
   CMD_OOPS = 0,
   CMD_MYSTATICIP,
   CMD_MYSTATICSUBNET,
   CMD_MYSTATICGATEWAY,
   CMD_MYSTATICDNS,
   CMD_MYACTUALIP,
   CMD_MYMACADDR,
   CMD_MYSERIALNUM,
   CMD_MYHWREV,
   CMD_MYIPMODE,
   CMD_GUESTPASSWORD,
   CMD_ROOTPASSWORD,
   CMD_LOGGING,
   CMD_CREDITS,
   CMD_GPSDEV,
   CMD_GPSBAUD,
   CMD_GPSEDGE,
   CMD_PROBE,
   CMD_S2NPORT,
   CMD_S2NPTIME,
   CMD_RXMODE,
   CMD_RSSIMODE,
   CMD_MYNAME,
   CMD_FLAGS,
   CMD_TFTPADDR,
#ifndef NODIALTASK
   CMD_DIAL,
#endif
#ifdef LOCALVOTER
   CMD_LOCAL,
#endif
   CMD_ALL, /* Should be the last one */
} SETSHOW_ENUMS ;

enum
{
   LOG_BOOT = 1,
   LOG_MAINAPP,
   LOG_ETHAPP,
   LOG_ETHLL_IO,
   LOG_KSZ8081,
   LOG_CONSOLE,
   LOG_I2C,
   LOG_DIALTASK,
   LOG_GPSCODE,
   LOG_LOGTELNET,
   LOG_LOCAL,
   LOG_SER2NET,
   LOG_SPINOR,
   LOG_SPIMTR,
   LOG_TFTP,
} LOGGERBLOCK_ENUMS ;

enum
{
   GPS_LIV4F = 0,
   GPS_M8N
} GPSDEV_ENUMS ;

#define LINE_SIZE 6 /* Console input line length */

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
uint8_t Probe = PROBE_NONE ;

char* cmd_set_cmd  = "set" ;
char* cmd_show_cmd = "show" ;
char* cmd_ss_help = "set/show - setting [value] Change/show Voter2 setting\n"
                    " ============= - NETWORK SETTINGS ======================\n"
                    "    mystaticip - Voter2 IP address (if static)\n"
                    "    mystaticsn - Voter2 Subnet (if static)\n"
                    "    mystaticgw - Voter2 Gateway IP (if static)\n"
                    "   mystaticdns - Voter2 DNS Address (if static)\n"
                    "    myactualip - Voter2 actual IP address (show only)\n"
                    "      tftpaddr - TFTP server address\n"
                    "         mymac - mac address (show only)\n"
                    "   myserialnum - Voter2 serial number (show only)\n"
                    "       myhwrev - Voter2 Hardware Revision (show only)\n"
                    "      myipmode - Voter IP acquisition mode\n"
                    "       s2nport - Ser2Net IP Port\n"
                    "      s2nptime - Ser2Net Rx Poll time (ms)\n"
                    "      guestpwd - Guest login password\n"
                    "       rootpwd - Root login password\n"
                    " ============= - DIAL, LOCAL, GPS AND MISC SETTINGS ====\n"
#ifndef NODIALTASK
                    "          dial - [param value] DIAL server settings\n"
#endif
#ifdef LOCALVOTER
                    "         local - [param value] local mode settings\n"
#endif
                    "        gpsdev - GPS params by device\n"
                    "       gpsbaud - GPS interface baud rate\n"
                    "       gpsedge - GPS interface 1PPS edge (rising/falling)\n"
                    "        rxmode - Receive active mode\n"
                    "      rssimode - RSSI detect mode\n"
                    "       logging - [block value] Debugging logger level\n"
                    "         probe - Analog probe source\n"
                    "         flags - Debug flags\n"
                    "        myname - Voters command prompt name\n"
                    "       credits - Project credits\n"
                    "           all - All params (show only)\n" ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TOKENLIST SSCmds[] =
{
   {"mystaticip"   ,CMD_MYSTATICIP     },
   {"mystaticsn"   ,CMD_MYSTATICSUBNET },
   {"mystaticgw"   ,CMD_MYSTATICGATEWAY},
   {"mystaticdns"  ,CMD_MYSTATICDNS    },
   {"myactualip"   ,CMD_MYACTUALIP     },
#ifdef LOCALVOTER
   {"local"        ,CMD_LOCAL          },
#endif
#ifndef NODIALTASK
   {"dial"         ,CMD_DIAL           },
#endif
   {"mymac"        ,CMD_MYMACADDR      },
   {"tftpaddr"     ,CMD_TFTPADDR       },
   {"gpsdev"       ,CMD_GPSDEV         },
   {"gpsbaud"      ,CMD_GPSBAUD        },
   {"gpsedge"      ,CMD_GPSEDGE        },
   {"myipmode"     ,CMD_MYIPMODE       },
   {"myserialnum"  ,CMD_MYSERIALNUM    },
   {"myhwrev"      ,CMD_MYHWREV        },
   {"guestpwd"     ,CMD_GUESTPASSWORD  },
   {"rootpwd"      ,CMD_ROOTPASSWORD   },
   {"logging"      ,CMD_LOGGING        },
   {"probe"        ,CMD_PROBE          },
   {"s2nport"      ,CMD_S2NPORT        },
   {"s2nptime"     ,CMD_S2NPTIME       },
   {"credits"      ,CMD_CREDITS        },
   {"rxmode"       ,CMD_RXMODE         },
   {"rssimode"     ,CMD_RSSIMODE       },
   {"myname"       ,CMD_MYNAME         },
   {"flags"        ,CMD_FLAGS          },
   {"all"          ,CMD_ALL            }, /* Keep this one last */
   {NULL           ,0                  }
} ;

static TOKENLIST MyIPModes[] =
{
   {"static",MYIPMODE_STATIC},
   {"dhcp"  ,MYIPMODE_DHCP  },
   {NULL    ,0           }
} ;

TOKENLIST Booleans[] =
{
   {"off"  ,false},
   {"on"   ,true },
   {"false",false},
   {"true" ,true },
   {"0"    ,false},
   {"1"    ,true },
   {NULL   ,0    }
} ;

static TOKENLIST LoggerBlocks[] =
{
   {"boot",   LOG_BOOT     },
   {"mainapp",LOG_MAINAPP  },
   {"ethapp", LOG_ETHAPP   },
   {"ethlwip",LOG_ETHLL_IO },
   {"ksz8081",LOG_KSZ8081  },
   {"console",LOG_CONSOLE  },
   {"i2c",    LOG_I2C      },
   {"dial",   LOG_DIALTASK },
   {"gps",    LOG_GPSCODE  },
   {"logtel", LOG_LOGTELNET},
   {"local",  LOG_LOCAL    },
   {"ser2net",LOG_SER2NET  },
   {"spinor" ,LOG_SPINOR   },
   {"spimtr" ,LOG_SPIMTR   },
   {"tftp"   ,LOG_TFTP     },
   {NULL   ,0    }
} ;

static TOKENLIST LoggerLevels[] =
{
   {"none"   ,LOG_NONE   },
   {"major"  ,LOG_MAJOR  },
   {"support",LOG_SUPPORT},
   {"io"     ,LOG_REGIO  },
   {NULL     ,0          }
};

static TOKENLIST GPS_Edges[] =
{
   {"falling",GPS_1PPS_FALLING},
   {"rising" ,GPS_1PPS_RISING },
   {NULL     ,0               }
} ;

static TOKENLIST Probes[] =
{
   {"none"    ,PROBE_NONE   },
   {"rxin"    ,PROBE_RXIN   },
   {"rxdem"   ,PROBE_RXDEM  },
   {"rxvoice" ,PROBE_RXVOICE},
   {"txsrc"   ,PROBE_TXSRC  },
   {"txpl"    ,PROBE_TXPL   },
   {"txout"   ,PROBE_TXOUT  },
   {"rsssig"  ,PROBE_RSSSIG },
   {"rsslvl"  ,PROBE_RSSLVL },
   {NULL      ,0            }
} ;

static TOKENLIST GPS_Devices[] =
{
   {"liv4f" ,GPS_LIV4F},
   {"m8n"   ,GPS_M8N  },
   {NULL    ,0        }
} ;

static TOKENLIST RxModes[] =
{
   {"off"     ,RXMODE_OFF  },
   {"cor"     ,RXMODE_COR  },
   {"ctcss"   ,RXMODE_CTCSS},
   {"corctcss",RXMODE_BOTH },
   {"on"      ,RXMODE_ON   },
   {NULL      ,0        }
} ;

static TOKENLIST RssiModes[] =
{
   {"analog" ,RSSI_ANALOG},
   {"hpf"    ,RSSI_HPF   },
   {NULL     ,0          }
} ;

static uint8_t OTPdata[16] IN_DMADD2 = {0} ;  /* The data to program in OTP */

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/
static void ShowNum  (char*,uint32_t) ;
static void ShowList (char*,uint8_t,TOKENLIST*) ;
#ifdef SHOWONOF
static void ShowOnOff(char*,uint8_t ) ;
#endif
static void ShowMAC  (char*,uint8_t*) ;
static void ShowHwRev(void          ) ;
static void ShowStr  (char*,char*   ) ;
static void ShowCreds(void          ) ;
static void ShowActIP(void          ) ;
static void ShowLogs (void          ) ;
static void ShowFlags(void          ) ;

static void SetLog    (int,char**   ) ;
static void SetGpsDev (int,char**   ) ;
static void SetFlags  (int,char**   ) ;
static void SetOTP    (int,char**   ) ;
static void ProgramOTP(uint32_t,uint8_t,uint8_t) ;

/*******************************************************************************
* Routine  : Cmd_set
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command sets a parameter.
*******************************************************************************/
int Cmd_set(int argc, char* argv[])
{
   int     error = false ; /* Parsing error flag */
   int     Token = 0     ; /* Command token      */
   int32_t tmp   = 0     ; /* Temporary value    */

   /* See which settings command */
   Token = parse_token(SSCmds,argv[1],&error) ;

   if (error)
   {
      Console_printf("Not a recognized parameter, try help set.\n") ;
   }
   else
   {
      /* If a not a list command, then it needs a parameter. (List commands   */
      /* will list the parameters if no parameter is given)                   */
      if ((argc<3) && ((Token!=CMD_MYIPMODE)&&(Token!=CMD_GPSEDGE)&&(Token!=CMD_PROBE)))
      {
         Console_printf("Missing setting for the parameter\n") ;
      }
      else
      {
          /* Take care of a few special cases first... */
         if (!RootMode && ((CMD_GUESTPASSWORD==Token)||(CMD_ROOTPASSWORD==Token)))
         {
            Console_printf("Sorry, not accessible with guest login.\n") ;
            Token = 0 ; /* so it won't get processed */
         }

         switch(Token)
         {
            case CMD_MYSTATICIP     : SetIP    ("Voter2 IP Address:"               ,argv[2],                   &Settings.My_StaticIP                  ) ; break ;
            case CMD_MYSTATICSUBNET : SetIP    ("Voter2 Subnet:"                   ,argv[2],                   &Settings.My_StaticSubnet              ) ; break ;
            case CMD_MYSTATICGATEWAY: SetIP    ("Voter2 Gateway IP:"               ,argv[2],                   &Settings.My_StaticGateway             ) ; break ;
            case CMD_MYSTATICDNS    : SetIP    ("Voter2 DNS:"                      ,argv[2],                   &Settings.My_StaticDNS                 ) ; break ;
            case CMD_MYACTUALIP     : SetNot   ()                                                                                                       ; break ;
            case CMD_TFTPADDR       : SetIP    ("TFTP Server Address:"             ,argv[2],                   &Settings.TFTP_Addr                    ) ; break ;
            case CMD_GPSBAUD        : SetNum   ("GPS Baud rate:"                   ,argv[2],2400,115200,&tmp) ; Settings.GPS_Baud    = tmp              ; break ;
#ifdef LOCALVOTER
            case CMD_LOCAL          : SetLocal (argc,argv)                                                                                              ; break ;
#endif
#ifndef NODIALTASK
            case CMD_DIAL           : SetDIAL  (argc,argv)                                                                                              ; break ;
#endif
            case CMD_MYMACADDR      : SetNot   ()                                                                                                       ; break ;
            case CMD_MYSERIALNUM    : SetOTP   (argc,argv)                                                                                              ; break ;
            case CMD_MYHWREV        : SetNot   ()                                                                                                       ; break ;
            case CMD_MYIPMODE       : SetList  ("Voter2 IP Acquisition mode:"      ,argv[2],                   &Settings.My_IPMode,MyIPModes,true     ) ; break ;
            case CMD_GUESTPASSWORD  : SetStr   ("Guest Login Password:"            ,argv[2],                    Settings.Guest_Password ,SETTINGS_PASSWORD_LEN ) ; break ;
            case CMD_ROOTPASSWORD   : SetStr   ("Root Login Password:"             ,argv[2],                    Settings.Root_Password  ,SETTINGS_PASSWORD_LEN ) ; break ;
            case CMD_MYNAME         : SetStr   ("Voters name (for CLI):"           ,argv[2],                    Settings.Voter_Name     ,SETTINGS_NAME_LEN     ) ; break ;
            case CMD_LOGGING        : SetLog   (argc,argv)                                                                                              ; break ;
            case CMD_CREDITS        : SetNot   ()                                                                                                       ; break ;
            case CMD_GPSEDGE        : SetList  ("GPS 1PPS active edge:"            ,argv[2],                   &Settings.GPS_PPSEdge,GPS_Edges,true   ) ; break ;
            case CMD_GPSDEV         : SetGpsDev(argc,argv)                                                                                              ; break ;
            case CMD_PROBE          : SetList  ("Analog Probe Source:"             ,argv[2],                   &Probe,Probes,false                    ) ; break ;
            case CMD_S2NPORT        : SetNum   ("Ser2Net IP Port:"                 ,argv[2],1,65535,&tmp)     ; Settings.S2N_Port = tmp                 ; break ;
            case CMD_S2NPTIME       : SetNum   ("Ser2Net Rx Poll time (ms):"       ,argv[2],1,1000,&tmp)      ; Settings.S2N_PollTime = tmp             ; break ;
            case CMD_RXMODE         : SetList  ("Rx Detect:"                       ,argv[2],                   &Settings.RxMode,RxModes,true          ) ; break ;
            case CMD_RSSIMODE       : SetList  ("RSSI Method:"                     ,argv[2],                   &Settings.RssiMode,RssiModes,true      ) ; break ;
            case CMD_FLAGS          : SetFlags (argc,argv)                                                                                              ; break ;
            case CMD_ALL            : SetNot   ()                                                                                                       ; break ;
            default                 : /* Unsupported tokens */                                                                                            break ;
         }

         /* Take care of a few post-setting notices too... */
         if ((CMD_MYSTATICIP   ==Token) || (CMD_MYSTATICSUBNET==Token) || (CMD_MYSTATICGATEWAY==Token) ||
             (CMD_MYIPMODE     ==Token) ||
             (CMD_GPSBAUD      ==Token) || (CMD_GPSEDGE       ==Token) || (CMD_S2NPORT        ==Token) ||
             (CMD_GPSDEV       ==Token) || (CMD_S2NPORT       ==Token)
            )
         {
            Console_printf("The parameter you just changed requires a reboot to take effect.\n") ;
            Console_printf("Saving settings first would be a good idea too.") ;
            Console_printf("Unsaved changes are lost on reboot! :)\n") ;
         }
      }
   }
   return (0) ;
}

/*******************************************************************************
* Routine  : Cmd_show
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command shows a parameter
*******************************************************************************/
int Cmd_show(int argc, char* argv[])
{
   int error = false ; /* Parsing error flag    */
   int Token  = 0    ; /* Command token (users) */
   int Token2 = 0    ; /* Command token (shown) */

   /* See which settings command */
   Token = parse_token(SSCmds,argv[1],&error) ;

   if (error)
   {
      Console_printf("Not a recognized parameter, try help show.\n") ;
   }
   else
   {
      /* Fancy conditionals to show just one parameter unless the token is    */
      /* "all".  If "all", show all parameters.                               */
      for (Token2=(CMD_ALL==Token)?CMD_MYSTATICIP:Token ; Token2<((CMD_ALL==Token)?CMD_ALL:Token+1) ; Token2++)
	  {
         /* Take care of a few special cases first... */
         if (!RootMode && ((CMD_GUESTPASSWORD==Token2)||(CMD_ROOTPASSWORD==Token2)))
         {
            Console_printf("Sorry, not accessible with guest login.\n") ;
            Token2 = 0 ; /* so it won't get processed */
         }

         switch(Token2)
         {
            case CMD_MYSTATICIP     : ShowIP    ("Voter2 IP Address:"               ,Settings.My_StaticIP     ) ; break ;
            case CMD_MYSTATICSUBNET : ShowIP    ("Voter2 Subnet:"                   ,Settings.My_StaticSubnet ) ; break ;
            case CMD_MYSTATICGATEWAY: ShowIP    ("Voter2 Gateway IP:"               ,Settings.My_StaticGateway) ; break ;
            case CMD_MYSTATICDNS    : ShowIP    ("Voter2 DNS:"                      ,Settings.My_StaticDNS    ) ; break ;
            case CMD_MYACTUALIP     : ShowActIP ()                                                              ; break ;
            case CMD_TFTPADDR       : ShowIP    ("TFTP Server Adddress:"            ,Settings.TFTP_Addr       ) ; break ;
            case CMD_GPSBAUD        : ShowNum   ("GPS Receiver baud rate:"          ,Settings.GPS_Baud        ) ; break ;
#ifdef LOCALVOTER
            case CMD_LOCAL          : ShowLocal (                                                             ) ; break ;
#endif
#ifndef NODIALTASK
            case CMD_DIAL           : ShowDIAL  (                                                             ) ; break ;
#endif
            case CMD_MYMACADDR      : ShowMAC   ("Voter2 MAC Address:"              ,Settings.MyMACAddr       ) ; break ;
            case CMD_MYSERIALNUM    : ShowNum   ("Voter2 serial number:"            ,Settings.MySerialNum     ) ; break ;
            case CMD_MYHWREV        : ShowHwRev (                                                             ) ; break ;
            case CMD_MYIPMODE       : ShowList  ("Voter2 IP acquisition mode:"      ,Settings.My_IPMode,MyIPModes) ; break ;
            case CMD_GUESTPASSWORD  : ShowStr   ("Guest Login Password:"            ,Settings.Guest_Password  ) ; break ;
            case CMD_ROOTPASSWORD   : ShowStr   ("Root Login Password:"             ,Settings.Root_Password   ) ; break ;
            case CMD_MYNAME         : ShowStr   ("Voters name (for CLI):"           ,Settings.Voter_Name      ) ; break ;
            case CMD_LOGGING        : ShowLogs  (                                                             ) ; break ;
            case CMD_CREDITS        : ShowCreds (                                                             ) ; break ;
            case CMD_GPSEDGE        : ShowList  ("GPS 1PPS active edge:"            ,Settings.GPS_PPSEdge,GPS_Edges) ; break ;
            case CMD_PROBE          : ShowList  ("Analog Probe Source:"             ,Probe,Probes             ) ; break ;
            case CMD_S2NPORT        : ShowNum   ("Ser2Net IP Port:"                 ,Settings.S2N_Port        ) ; break ;
            case CMD_S2NPTIME       : ShowNum   ("Ser2Net Rx Poll Time (ms):"       ,Settings.S2N_PollTime    ) ; break ;
            case CMD_GPSDEV         : Console_printf("See gpsbaud and gpsedge\n"                              ) ; break ;
            case CMD_RXMODE         : ShowList  ("Rx Detect Mode:"                  ,Settings.RxMode,RxModes  ) ; break ;
            case CMD_RSSIMODE       : ShowList  ("RSSI Method:"                     ,Settings.RssiMode,RssiModes) ; break ;
            case CMD_FLAGS          : ShowFlags (                                                             ) ; break ;
            default                 : /* Shouldn't happen */                                                      break ;
         }
      }
   }
   return (0) ;
}

/*******************************************************************************
* Routine  : Show(...)
*   Inputs : id - parameter identifier
*          : (varies) - The variable to show
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* These are the commands to show the various parameter types
*******************************************************************************/
void ShowIP(char*id,uint32_t IPAddr)
{
   Console_printf("%s %d.%d.%d.%d\n",id,IPAddr>>24,(IPAddr>>16)&0xff,(IPAddr>>8)&0xff,(IPAddr)&0xff) ;
}

static void ShowNum(char*id,uint32_t Num)
{
   Console_printf("%s %u\n",id,Num) ;
}

static void ShowList(char*id,uint8_t entry,TOKENLIST* Tokens)
{
   Console_printf("%s %s\n",id,Tokens[entry].token) ;
}

#ifdef SHOWONOF
static void ShowOnOff(char*id,uint8_t token)
{
   Console_printf("%s %s\n",id,token?"On":"Off") ;
}
#endif

static void ShowMAC(char*id,uint8_t* Addr)
{
   int i = 0 ;
   Console_printf("%s ",id) ;
   for (i=0;i<5;i++) Console_printf("%2.2x:",Addr[i]) ;
   Console_printf("%2.2x:",Addr[5]) ;
   Console_printf("\n") ;
}

static void ShowHwRev(void)
{
   Console_printf("Voter2 Hardware Revision: %d.%2.2d\n",Settings.MyHwRev>>8,Settings.MyHwRev&0xff) ;
}

static void ShowStr(char*id,char* str)
{
   /* THIS ASSUMES A NULL TERMINATED STRING! */
   Console_printf("%s %s\n",id,str) ;
}

static void ShowCreds(void)
{
   /* THIS ASSUMES A NULL TERMINATED STRING! */
   Console_printf("Voter2-2K Rev 1.10\n") ;
   Console_printf("====================\n") ;
   Console_printf("Sponsored by:\n") ;
   Console_printf("Wayne (W0ARP)\n") ;
   Console_printf("Colorado Connection (colcon.org)\n") ;
   Console_printf("Rocky Mountain Ham (rmham.org)\n") ;
   Console_printf("====================\n") ;
   Console_printf("Design team:\n") ;
   Console_printf("  Ben (KC2VJW)\n") ;
   Console_printf(" Dave (WA1JHK)\n") ;
   Console_printf(" Doug (K2AD)\n") ;
   Console_printf("James (KI0KN)\n") ;
   Console_printf(" Jeff (K0JSC)\n") ;
   Console_printf(" Mark (N7CTM)\n") ;
   Console_printf(" Will (N0XGA)\n") ;
   Console_printf("====================\n") ;
   Console_printf("Open Source Hardware\n") ;
   Console_printf("Open Source Software\n") ;
   Console_printf("====================\n") ;
}

static void ShowActIP(void)
{
   Console_printf("Voter2's currently active IP address: %s\n",ActualIPstr()) ;
}

static void ShowLogs (void)
{
   /* For showing logging levels, just show them all */
   Console_printf("%7s: %s\n",LoggerBlocks[ 0].token,LoggerLevels[Logger.Boot   ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 1].token,LoggerLevels[Logger.MainApp].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 2].token,LoggerLevels[Logger.EthApp ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 3].token,LoggerLevels[Logger.EthLWIP].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 4].token,LoggerLevels[Logger.KSZ8081].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 5].token,LoggerLevels[Logger.Console].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 6].token,LoggerLevels[Logger.i2c    ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 7].token,LoggerLevels[Logger.Dial   ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 8].token,LoggerLevels[Logger.GPS    ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 9].token,LoggerLevels[Logger.LogTel ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[10].token,LoggerLevels[Logger.Local  ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[11].token,LoggerLevels[Logger.Ser2Net].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[12].token,LoggerLevels[Logger.SpiNor ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[13].token,LoggerLevels[Logger.SpiMtr ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[14].token,LoggerLevels[Logger.Tftp   ].token) ;
   Console_printf("Logging levels are none, major, support, and io.\n") ;
   Console_printf("Note that logging levels are not saved across reboots.\n") ;
}

static void ShowFlags (void)
{
   int i = 0 ;
   for (i=0;i<NFLAGS;i++)
   {
      Console_printf("Debug Flag %d = %d\n",i,Flags[i]) ;
   }
}

/*******************************************************************************
* Routine  : Set(...)
*   Inputs : id - parameter identifier
*      IOs : (varies) - The variable to set
*  Returns : Nothing
*  Globals : None
*
* These are the commands to set the various parameter types
* Routines start off as static, then become extern as needed.
*******************************************************************************/
void SetIP(char*id, char* newval, uint32_t* IPAddr)
{
   ip_addr_t NewAddr = {0} ; /* IP address in LWIP format */
   uint32_t  Addr32  =  0  ; /* IP address in my format   */
   int       err     =  0  ; /* Error accumulator         */

   /* LWIP has a nice function to parse a text IP address */
   err = ipaddr_aton(newval,&NewAddr) ;

   if (!err)
   {
	   Console_printf("Invalid IP address\n") ;
   }
   else
   {
      /* Get the address from the LWIP struct and convert to host format */
      Addr32 = ntohl(NewAddr.addr) ;
      *IPAddr = Addr32 ;
      Console_printf("%s now %d.%d.%d.%d\n",id,Addr32>>24,(Addr32>>16)&0xff,(Addr32>>8)&0xff,(Addr32)&0xff) ;
      Settings.Dirty = true ;
   }
}

void SetNum(char*id, char* newval,int32_t min, int32_t max, int32_t* value)
{
   int32_t Val32 = 0     ; /* New value         */
   int     err   = false ; /* Error accumulator */

   /* Go get the number */
   Val32=parse_num(newval,min,max,&err) ;

   if (err)
   {
	   Console_printf("Invalid or out of range number, range is %d to %d.\n",min,max) ;
   }
   else
   {
      *value = Val32 ;
      Console_printf("%s now %u\n",id,Val32) ;
      Settings.Dirty = true ;
   }
}

void SetList(char*id, char* newval, uint8_t* value,TOKENLIST* Tokens,int SetDirty)
{
   int8_t Token = 0     ; /* New value         */
   int    err   = false ; /* Error accumulator */
   int    i     = 0     ; /* index             */

   /* See which settings command */
   Token = parse_token(Tokens,newval,&err) ;

   if (err)
   {
	   /* If error, show list of possible parameters */
	   Console_printf("Invalid parameter.\nParameters can be: ") ;
	   while (Tokens[i].token) Console_printf("%s ",Tokens[i++].token) ;
	   Console_printf("\n") ;
   }
   else
   {
      *value = Token ;
      Console_printf("%s now %s\n",id,Tokens[Token].token) ;
      if (SetDirty) Settings.Dirty = true ;
   }
}

void SetOnOff(char*id, char* newval, uint8_t* value)
{
   int8_t Token = 0     ; /* New value         */
   int    err   = false ; /* Error accumulator */

   /* See which settings command */
   Token = parse_token(Booleans,newval,&err) ;

   if (err)
   {
	   /* If error, show list of possible parameters */
	   Console_printf("Invalid parameter.\nParameters can be: on/off, true/false, or 1/0\n") ;
   }
   else
   {
      *value = Token ;
      Console_printf("%s now %s\n",id,newval) ;
      Settings.Dirty = true ;
   }
}

void SetNot(void)
{
   Console_printf("Sorry, this parameter isn't changeable.\n") ;
}

void SetStr(char*id, char* newval, char* target, int targlen)
{
   int len = 0 ; /* incoming string length */

   /* Get the length, if null, the default of 0 is fine */
   if (NULL!=newval) len = strlen(newval) ;

   if (0==len)
   {
      Console_printf("Missing parameter\n") ;
   }
   else if (len>targlen-1)
   {
      /* -1 on length for EOS */
      Console_printf("String too long\n") ;
   }
   else /* Good! */
   {
      /* Clear out the old value completely, then put in new */
      memset(target,0,targlen) ;
      strcpy(target,newval) ;
      Console_printf("%s now %s\n",id,newval) ;
      Settings.Dirty = true ;
   }
}

static void SetLog (int argc,char** argv)
{
   int err = false ;
   int module = 0 ;
   int level = 0 ;

   /* Parameters for logging settings are the functional block and the        */
   /* logging level.                                                          */

   if (4!=argc)
   {
      Console_printf("Parameters are Module and debug level (type show logging to see settings).\n") ;
   }
   else
   {
      module = parse_token(LoggerBlocks,argv[2],&err) ;
      level  = parse_token(LoggerLevels,argv[3],&err) ;

      if (err)
      {
         Console_printf("Parameter error (type show logging to see parameters).\n") ;
      }
      else
      {
         switch(module)
         {
            case LOG_BOOT      : Logger.Boot    = level ; break ;
            case LOG_MAINAPP   : Logger.MainApp = level ; break ;
            case LOG_ETHAPP    : Logger.EthApp  = level ; break ;
            case LOG_ETHLL_IO  : Logger.EthLWIP = level ; break ;
            case LOG_KSZ8081   : Logger.KSZ8081 = level ; break ;
            case LOG_CONSOLE   : Logger.Console = level ; break ;
            case LOG_I2C       : Logger.i2c     = level ; break ;
            case LOG_DIALTASK  : Logger.Dial    = level ; break ;
            case LOG_GPSCODE   : Logger.GPS     = level ; break ;
            case LOG_LOGTELNET : Logger.LogTel  = level ; break ;
            case LOG_LOCAL     : Logger.Local   = level ; break ;
            case LOG_SER2NET   : Logger.Ser2Net = level ; break ;
            case LOG_SPINOR    : Logger.SpiNor  = level ; break ;
            case LOG_SPIMTR    : Logger.SpiMtr  = level ; break ;
            case LOG_TFTP      : Logger.Tftp    = level ; break ;
            default            :                          break ;
         }
      }
   }
}

static void SetGpsDev (int argc,char** argv)
{
   int     error = false ; /* Parsing error flag */
   int     Token = 0     ; /* Command token      */

   if (3!=argc)
   {
      Console_printf("GPS Devices supported are liv4f and m8n.\n") ;
   }
   else
   {
      /* See which settings command */
      Token = parse_token(GPS_Devices,argv[2],&error) ;
      if (error)
      {
         Console_printf("GPS Devices supported are liv4f and m8n.\n") ;
      }
      else
      {
         switch (Token)
         {
            case GPS_LIV4F: Settings.GPS_Baud = 115200 ;
                            Settings.GPS_PPSEdge = GPS_1PPS_RISING ;
                            break ;
            case GPS_M8N  : Settings.GPS_Baud = 9600 ;
                            Settings.GPS_PPSEdge = GPS_1PPS_RISING ;
                            break ;
            default       : break ; /* Shouldn't happen */
         }
         Console_printf("For %s, Baud set to %d, edge set to %s.\n",GPS_Devices[Token].token,Settings.GPS_Baud,GPS_Edges[Settings.GPS_PPSEdge].token) ;
         Settings.Dirty = true ;
      }
   }
}

static void SetFlags (int argc,char** argv)
{
   int err = false ;
   int Flagnum = 0 ;
   int Flagval = 0 ;

   /* Exactly two parameters, the flag number (0-NFLAGS) and value (0-255)    */

   if (4!=argc)
   {
      Console_printf("Flag parameters are flag number (0-%d) and value (0-255)\n",NFLAGS) ;
   }
   else
   {
      Flagnum = parse_num(argv[2],0,NFLAGS-1,&err) ;
      Flagval = parse_num(argv[3],0,255,&err) ;

      if (err)
      {
         Console_printf("Parameter error (type set flags to see parameters).\n") ;
      }
      else
      {
         Flags[Flagnum] = Flagval ;
      }
   }
}

/*******************************************************************************
* Routine  : SetOTP
*   Inputs : argv, argc - standard params
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This is the routine to program the serial number, hardware revision, and MAC
* address of the Voter2 into the OTP area of the SPINOR flash.  As this is
* programming OTP this command can only be executed once and is assumed to be
* executed as part of "factory bring-up" of the Voter2.  It will only run if
* the OTP area is confirmed as being blank.
* The user supplies the serial number and major and minor HW revision numbers,
* the MAC address is generated automatically (see ProgramOTP).
*******************************************************************************/
static void SetOTP (int argc,char** argv)
{
   int err    = false ; /* Error accumulator      */
   int SNum   = 0     ; /* Serial Number          */
   int HwMaj  = 0     ; /* HW Major revision      */
   int HwMin  = 0     ; /* HW Minor revision      */
   int result = 0     ; /* Result code            */
   char response[LINE_SIZE] = {0} ; /* User input */

   /* If OTP is already programmed, then it's too late */
   if (Settings.MySerialNum!=0xffffffff)
   {
      Console_printf("Sorry, this parameter isn't changeable.\n") ;
   }
   else
   {
      /* Exactly three parameters, serial number, major HW Rev and minor HW Rev */
      if (5!=argc)
      {
         Console_printf("Parameters are serial number (32-bit), major HW Rev (0-255), and minor HW Rev (0-99)\n") ;
      }
      else
      {
         SNum  = parse_num(argv[2],0,0  ,&err) ;
         HwMaj = parse_num(argv[3],0,255,&err) ;
         HwMin = parse_num(argv[4],0,99 ,&err) ;

         if (err)
         {
            Console_printf("Parameter errors.\n") ;
         }
         else
         {
            /* Echo back exactly what will be programmed and make sure!       */
            Console_printf("I have Serial number %d and Hardware Rev %d.%02d\n",SNum,HwMaj,HwMin) ;
            Console_printf("Is this what you want to program into OTP?\n") ;
            Console_printf("THIS IS IRREVERSIBLE!!\n======================\n") ;
            Console_printf("A randomized MAC Address will also be generated and saved in OTP.\n") ;
            Console_printf("Enter \"yes\" to confirm.\n") ;
            result = Consoleio_gets(response,LINE_SIZE) ;

            if (!strncmp(response,"yes",4))
            {
               Console_printf("Programming OTP...\n") ;
               ProgramOTP(SNum,HwMaj,HwMin) ;
               Console_printf("Please reboot for settings to take effect.\n") ;
            }
            else
            {
               Console_printf("OK, never mind...\n") ;
            }
         }
      }
   }
}

/*******************************************************************************
* Routine  : ProgramOTP
*   Inputs : SNum - Voter2 product serial number
*          : HwMaj - Hardware revision (Major number)
*          : HwMin - hardware revision (Minor number)
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This is the routine to program the OTP area of the SPINOR flash.  It is 4Kbits
* (512 bytes), but I'm using only 12 bytes!  Assignments are as follows:
*  - Addr 0x00-0x03 : 32-bit Serial Number, MSByte first
*  - Addr 0x04-0x09 : 6-byte MAC address MSByte first
*  - Addr 0x0a-0x0b : 2-byte HW Rev (Major, Minor)
*
* The rest of the OTP is unused.
*
* Note that the MAC address is not provided as parameter, it is a randomly
* generated, locally administered Unicast address.
* Practically, all random bits except for the first byte having bit 0 (the
* unicast/multicast bit) set to 0 and bit 1 (globally vs locally administered)
* bit set to 1.
*******************************************************************************/
static void ProgramOTP(uint32_t SNum,uint8_t HwMaj,uint8_t HwMin)
{
   uint32_t rand1 = 0 ; /* Random number #1  */
   uint32_t rand2 = 0 ; /* Random number #2  */
   int errors = false ; /* Error accumulator */

   /* Take care of the easy stuff first */
   OTPdata[ 0] = (SNum>>24) & 0xff ;
   OTPdata[ 1] = (SNum>>16) & 0xff ;
   OTPdata[ 2] = (SNum>> 8) & 0xff ;
   OTPdata[ 3] = (SNum    ) & 0xff ;
   OTPdata[10] = HwMaj             ;
   OTPdata[11] = HwMin             ;

   /* For the random MAC address fire up the random number generator! */
   if (HAL_RNG_GenerateRandomNumber(&hrng, &rand1) != HAL_OK) errors = true ;
   if (HAL_RNG_GenerateRandomNumber(&hrng, &rand2) != HAL_OK) errors = true ;

   if (errors)
   {
      Console_printf("Problems creating the MAC Address, aborting...\n") ;
   }
   else
   {
      /* For the MSByte, set bits for unicast and locally administered */
      OTPdata[ 4] = ((rand1>>24) & 0xfc) | 0x02  ;
      OTPdata[ 5] =  (rand1>>16) & 0xff  ;
      OTPdata[ 6] =  (rand1>> 8) & 0xff  ;
      OTPdata[ 7] =  (rand1    ) & 0xff  ;
      OTPdata[ 8] =  (rand2>>24) & 0xff  ;
      OTPdata[ 9] =  (rand2>>16) & 0xff  ;

      /* All set, write the OTP and lock it. (Note locking not implemented yet) */
      SpiNor_writeOTP(OTPdata,0,12) ;
      SpiNor_lockOTP() ;
   }
}
