/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Utils file.  This is a hodge podge set of generic helper       */
/* routines that are needed in multiple places.  They are mostly helper       */
/* routines for command line parsing, but will probably expand.               */
/******************************************************************************/
/*                                                                            */
/* Public Mainline routines are:                                              */
/*  - parse_token - Parse text tokens to an index.                            */
/*  - parse_num - Parse a string that should be a number                      */
/*  - ReadHex - read a 2-digit ASCII Hex string                               */
/*  - strntcpy - strcpy, but forces an EOS at the end                         */
/*                                                                            */
/******************************************************************************/

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "Options.h"
#include "Utils.h"

/******************************************************************************/
/* STs way of doing handles                                                   */
/******************************************************************************/

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : parse_token
*   Inputs : tokenlist - list of valid tokens (last is NULL,0)
*          : param - parameter to look up
*      IOs : error - error flag
*  Returns : 0 for no match, or tag number for a match
*  Globals : None
*
* This is a quick token parser looking for matching text and returning that
* texts associated token.  If no match, 0 is returned and *error is set to true.
*******************************************************************************/
int parse_token (TOKENLIST* tokenlist,char* param,int* error)
{
   int index = 0     ; /* command list index */
   int match = 0     ; /* matching tag       */
   int found = false ; /* Found flag         */

   /* Loop until a match or end of the list */
   while ((tokenlist[index].token != NULL) && !found)
   {
      /* Safe to use strcmp since both params are vetted strings */
      if (!strcmp(param,tokenlist[index].token))
      {
    	  match = tokenlist[index].tag ;
    	  found = true ;
      }
      index++ ;
   }

   /* return the matching tag and update error flag if problems */
   if (!found) *error = true ;
   return(match) ;
}

/*******************************************************************************
* Routine  : parse_num
*   Inputs : param - paramter to parse
*          : min - parameter minimum value (see note below)
*          : max - parameter maximum value (see note below)
*      IOs : errors - error accumulator
*  Returns : parameter value (if OK)
*  Globals : None
*
* My flavor or atoi, adding an error for non-numberic characters and an
* optional range check.  This assumes the string is nothing but an optional
* negative sign and digits, so no spaces, etc.
*
* NOTE: If both min and max are 0, then range checking is not performed.
*******************************************************************************/
int parse_num (char *param,int min,int max,int* errors)
{
   int rval = 0     ; /* value being accumulated */
   int neg  = false ; /* Negative flag           */

   /* This first part is reformatted standard atoi source */
   if (param[0] == '-')
   {
      neg = true ;
      param++ ;
   }

   while (*param && isdigit((unsigned char)(*param)))
   {
      rval = rval * 10 + *param++  - '0' ;
   }

   if (neg) rval = -rval ;

   /* Now for my features.  First, if we ended with anything but an EOS, then */
   /* there was something non-numeric in the parameter.                       */
   if (*param) *errors = true ;

   /* Now for the range checking.  Only if at least min or max is non-zero.   */
   /* Also, if errors before, go ahead and zero result too.                   */
   /* Yea, that level of conditional construction took a bit! :)              */
   if ((*errors) || (((min!=0)||(max!=0)) && ((rval<min) || (rval>max))))
   {
      rval = 0 ;
      *errors = true ;
   }
   return(rval) ;
}

/*******************************************************************************
* Routines : ReadHex
* Gazintas : str - string to parse
*          : nchrs - number of characters to parse
*          : argtype - if argument must be whitespace after, otherwise just
*          :           digits
* IOs      : success - error flag, any error sets this to false
* Returns  : value parsed (assuming no failure)
* Globals  : None
*
* A quick and dirty routine to parse a fixed length hex string including error
* handling. Probably a cleaner way of doing this, but it works.
*******************************************************************************/
uint32_t ReadHex (char* str,int nchrs,int argtype,int* success)
{
   int      i     = 0 ;
   uint32_t accum = 0 ;
   uint32_t dig   = 0 ;

   if (nchrs>8)
   {
      *success = false ;
   }
   else
   {
       for (i=0;i<nchrs;i++)
       {
          if (isxdigit((unsigned int)str[i]))
          {
             /* if legit, convert each ASCII hex digit to binary */
             dig = (str[i]-'0') ;
             if (dig > 10) dig = 10+tolower(str[i])-'a' ;
             accum = accum*16+dig ;
          }
          else
          {
             *success = false ;
          }
       }

       /* Done with expected data.  If the hex string is supposed to be a     */
       /* command line argument, then the character after it had better be    */
       /* whitespace, or at least not a hex digit.                            */
       if ((SOLOPARAM==argtype) && (isxdigit((unsigned int)str[i]))) *success = false ;
    }

   return(accum) ;
}

/*******************************************************************************
* Routines : ReadHexVar
* Gazintas : str - string to parse
* IOs      : success - error flag, any error sets this to false
* Returns  : value parsed (assuming no failure)
* Globals  : None
*
* A quick and dirty routine to parse a variable length hex string including
* error handling.  Up to 8 characters ending with whitespace or EOS.
* Probably a cleaner way of doing this, but it works.
*******************************************************************************/
uint32_t ReadHexVar (char* str,int* success)
{
   int      i     = 0 ;
   uint32_t accum = 0 ;
   uint32_t dig   = 0 ;

    while ((isxdigit((unsigned int)str[i])) && (i<9))
    {
       /* while legit, convert each ASCII hex digit to binary */
       dig = (str[i]-'0') ;
       if (dig > 10) dig = 10+tolower(str[i])-'a' ;
       accum = accum*16+dig ;
       i++ ;
    }

   /* Better be 1-8 characters and ending with EOS or whitespace */
   if ((0==i) || (9==i)) *success = false ;
   if ((0!=str[i]) && !(isspace((unsigned int)str[i]))) *success = false ;

   return(accum) ;
}

/*******************************************************************************
* Routines : strntcpy
* Gazintas : src - source string (null termianted)
*            dest_size - Destination string size (inluding EOS)
* IOs      : dest - destination string
* Returns  : Nothing
* Globals  : None
*
* A variation on strncpy that forces an EOS at the end so the destination
* string will be null (EOS) terminated always.
*******************************************************************************/
void strntcpy(char* dest,char* src,int dest_size)
{
   strncpy(dest,src,dest_size) ; /* Copy up to dest size                      */
   dest[dest_size-1] = 0       ; /* force null at the end if strncpy didn't   */
}
