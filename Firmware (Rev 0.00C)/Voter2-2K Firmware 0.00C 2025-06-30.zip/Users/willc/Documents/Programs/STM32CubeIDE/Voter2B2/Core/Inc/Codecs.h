#ifndef INC_CODECS_H_
#define INC_CODECS_H_

void CompressuLaw(int16_t*,uint8_t*) ;
void DecompressuLaw (uint8_t*, int16_t*) ;

int  CompressADPCM(int16_t*,uint8_t*) ;
void DecompressADPCM(uint8_t*,int16_t*) ;

#endif /* INC_CODECS_H_ */
