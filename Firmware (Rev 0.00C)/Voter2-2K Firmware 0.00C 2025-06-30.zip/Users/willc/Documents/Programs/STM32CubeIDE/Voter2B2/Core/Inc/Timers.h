#ifndef INC_TIMERS_H_
#define INC_TIMERS_H_

#define GPS_1PPS_FALLING 0
#define GPS_1PPS_RISING 1

#define TIM2_FREQ 40000000 /* TIM2 count frequency (40MHz) */
#define TIM2_ERRB 1000     /* TIM2 frequency error band    */

extern void MY_TIM2_FinishInit(void) ;
#ifndef DUMBTIMERMODE
extern void MY_TIM2_Svc(void) ;
#endif
extern void MY_TIM7_Svc(void);
extern void MY_TIM15_FinishInit(void) ;
extern void WWDG_HariKiri(void);
extern void MainTaskWatchdogPet(void) ;
extern void RebootNow(void) ;

/* For FreeRTOS Runtime monitoring */
extern uint32_t RunTime   ; /* For RTOS profiling  */
extern int      GPSLocked ; /* GPS Locked flag     */
extern int      GPSUsed   ; /* GPS being used flag */

#endif /* INC_TIMERS_H_ */
