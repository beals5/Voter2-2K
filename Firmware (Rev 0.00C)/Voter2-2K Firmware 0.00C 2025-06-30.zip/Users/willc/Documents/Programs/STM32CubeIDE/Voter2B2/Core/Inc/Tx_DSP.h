#ifndef INC_TX_DSP_H_
#define INC_TX_DSP_H_

#define MAINBUF  0 /* Tx buffer main  channel */
#define DEBUGBUF 1 /* Tx buffer debug channel */

#define PROBE_AUDIO 0 /* Probe data is signed audio */
#define PROBE_RAW   1 /* Probe data is raw data     */

typedef enum
{
   CTCSS_670 = 0,
   CTCSS_719,
   CTCSS_744,
   CTCSS_770,
   CTCSS_797,
   CTCSS_825,
   CTCSS_854,
   CTCSS_885,
   CTCSS_915,
   CTCSS_948,
   CTCSS_974,
   CTCSS_1000,
   CTCSS_1035,
   CTCSS_1072,
   CTCSS_1109,
   CTCSS_1148,
   CTCSS_1188,
   CTCSS_1230,
   CTCSS_1273,
   CTCSS_1318,
   CTCSS_1365,
   CTCSS_1413,
   CTCSS_1462,
   CTCSS_1514,
   CTCSS_1567,
   CTCSS_1622,
   CTCSS_1679,
   CTCSS_1738,
   CTCSS_1799,
   CTCSS_1862,
   CTCSS_1928,
   CTCSS_2035,
   CTCSS_2107,
   CTCSS_2181,
   CTCSS_2257,
   CTCSS_2336,
   CTCSS_2418,
   CTCSS_2503
} CTCSS_ENUMS ;

typedef enum
{
   GENERAL_TIMED,
   GPS_TIMED,
   LOCAL_TIMED
} TIMING_TYPES ;

extern uint16_t GlobTxBufDly ;
extern uint8_t  Local_PLL_Lvl  ;
extern uint8_t  Local_PLL_Freq ;
extern uint16_t ProbeBuf[APKT_SAMPLES] ; /* Probe data buffer */

void Tx_ClearPacket(uint16_t*,int) ;
void Tx_DeqPacket(uint16_t*) ;
void Tx_EnqPacket(int16_t*,int,uint32_t,uint32_t) ;
void ProbeCheck(void*,int8_t,int) ;

#endif /* INC_TX_DSP_H_ */
