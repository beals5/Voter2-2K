#ifndef VOICEFILTER_H_
#define VOICEFILTER_H_

/******************************************************************************/
/* There are actually two filters here, the first is voice only, omitting     */
/* CTCSS tones and above 2400Hz.  The second passes CTCSS tones but still     */
/* omits frequencies above 2400Hz.                                            */
/* The VoiceFilter_init() and VoiceFilter_put() calls are identical for either*/
/* filter, they just have different VoiceFilter_get() calls.                  */
/******************************************************************************/

/******************************************************************************/
/* First one                                                                  */
/******************************************************************************/
/*

FIR filter designed with
http://t-filter.engineerjs.com/

sampling frequency: 8000 Hz

fixed point precision: 16 bits

* 0 Hz - 250 Hz
  gain = 0
  desired attenuation = -40 dB
  actual attenuation = n/a

* 400 Hz - 2400 Hz
  gain = 1
  desired ripple = 5 dB
  actual ripple = n/a

* 2600 Hz - 4000 Hz
  gain = 0
  desired attenuation = -25 dB
  actual attenuation = n/a

*/

/******************************************************************************/
/* Second one                                                                 */
/******************************************************************************/
/*

FIR filter designed with
http://t-filter.engineerjs.com/

sampling frequency: 8000 Hz

fixed point precision: 16 bits

* 0 Hz - 2400 Hz
  gain = 1
  desired ripple = 5 dB
  actual ripple = n/a

* 2600 Hz - 4000 Hz
  gain = 0
  desired attenuation = -25 dB
  actual attenuation = n/a

*/
#define VOICEFILTER_TAP_NUM 64

/******************************************************************************/
/* If using the CMSIS DSP library, we don't need any of the structures and    */
/* routines below, just the coefficient table.                                */
/******************************************************************************/

extern int16_t voice_filter_taps1[] ;
extern int16_t voice_filter_taps2[] ;

#ifndef USE_CMSIS_DSP

typedef struct {
  int16_t history[VOICEFILTER_TAP_NUM];
  unsigned int last_index;
} VoiceFilter;

void    VoiceFilter_init(VoiceFilter* f);
void    VoiceFilter_put (VoiceFilter* f, int16_t input);
int16_t VoiceFilter_get1(VoiceFilter* f);
int16_t VoiceFilter_get2(VoiceFilter* f);

#endif
#endif
