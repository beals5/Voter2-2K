#ifndef INC_RX_DSP_H_
#define INC_RX_DSP_H_

typedef enum
{
   RXMODE_OFF,
   RXMODE_COR,
   RXMODE_CTCSS,
   RXMODE_BOTH,
   RXMODE_ON
} RXMODES ;

typedef enum
{
   RSSI_ANALOG = 0,
   RSSI_HPF
} RSSI_ENUMS ;


extern int LocalDeemph ;
extern int16_t  Rx_ppbuf1[APKT_SAMPLES] ;
extern int16_t  Rx_ppbuf2[APKT_SAMPLES] ;
extern uint16_t VinPP ;
extern uint8_t  Hpf_RSSI ;
extern uint32_t Gui_hpf_RSSI ;

void Rx_FilterInit(void) ;
void Rx_EnqPacket(uint16_t*) ;

#endif /* INC_RX_DSP_H_ */
