/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the RTC file.  It allows setting (manually or using GPS time) the  */
/* RTC and showing its state.  Right now it isn't used for anything, so the   */
/* only access is the CLI.                                                    */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Cmd_rtc - RTC CLI command                                               */
/*                                                                            */
/******************************************************************************/
// TO DO:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "Options.h"
#include "main.h"
#include "RTC.h"
#include "ConsoleTask.h"
#include "GPS.h"
#include "Timers.h"
#include "Utils.h"
#include "Bootloader.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/
extern RTC_HandleTypeDef hrtc ;

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
enum
{
   CMD_OOPS = 0,
   CMD_SET,
   CMD_SYNC,
   CMD_SHOW,
} RTC_ENUMS ;

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
char* cmd_rtc_cmd  = "rtc" ;
char* cmd_rtc_help = "rtc - [set|sync|show]\n"
                     "       sync - sets RTC from GPS time\n"
                     "       set yy mm dd hh mm ss - set RTC manually\n"
                     "            Use 24 hour time, preferably UTC\n"
                     "       show - shows RTC time\n" ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TOKENLIST RtcCmds[] =
{
   {"set" ,CMD_SET },
   {"sync",CMD_SYNC},
   {"show",CMD_SHOW},
   {NULL  ,0       }
} ;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void RTC_Set(int,char**) ;
static void RTC_Sync(void) ;
static void RTC_Show(void) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : MY_RTC_FinishInit
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This routine finishes up the initialization of the RTC on boot. For normal
* boots we just need to ensure that the bootloader magic number isn't in
* backup register 0--although if it was, then this code won't execute!
* As part of the MX init routines, the backup registers are already modifiable.
*******************************************************************************/
void MY_RTC_FinishInit(void)
{
   RTC_Bootloader_Enable(false) ;
}
/*******************************************************************************
* Routine  : RTC_Bootloader_Enable
*   Inputs : ena - true to enable bootloader on next boot.
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This routine puts the magic value in backup register 0 so that on the next
* boot the bootloader will see that number and do a software update.  As part
* of the MX init routines, the backup registers are already modifiable.
*******************************************************************************/
void RTC_Bootloader_Enable(int ena)
{
   hrtc.Instance->BKP0R = ena?BOOTLOADER_MAGICNUM:0 ;
}

/*******************************************************************************
* Routine  : Cmd_rtc
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command sets or shows the time from the RTC.
*******************************************************************************/
int Cmd_rtc(int argc, char* argv[])
{
   int error = false ; /* Parsing error flag */
   int Token = 0     ; /* Command token      */

   /* See which settings command */
   Token = parse_token(RtcCmds,argv[1],&error) ;

   if (error)
   {
      Console_printf("Parameter must be set, sync or show.\n") ;
   }
   else
   {
      switch(Token)
      {
         case CMD_SET : RTC_Set (argc,argv) ;  break ;
         case CMD_SYNC: RTC_Sync(         ) ;  break ;
         case CMD_SHOW: RTC_Show(         ) ;  break ;
         default : /* Shouldn't happen */      break ;
      }
   }

   return (0) ;
}

/*******************************************************************************
* Routine  : RTC_Set
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This command allows you to set the RTC time manually if no GPS is being used.
*******************************************************************************/
static void RTC_Set(int argc, char* argv[])
{
   RTC_DateTypeDef sdatestructure = {0} ;
   RTC_TimeTypeDef stimestructure = {0} ;
   int errs = 0 ;

   /* 8 total arguments! 2 for commands, 6 for parameters */
   if (8!=argc)
   {
      Console_printf("Need six arguments, see help\n") ;
   }
   else
   {
      /* If locked, just copy data from GPS time to RTC structure and set! */
      sdatestructure.Year           = parse_num(argv[2],0,99,&errs) ;
      sdatestructure.Month          = parse_num(argv[3],1,12,&errs) ;
      sdatestructure.Date           = parse_num(argv[4],1,31,&errs) ;
      sdatestructure.WeekDay        = RTC_WEEKDAY_SUNDAY ; /* Not used */

      stimestructure.Hours          = parse_num(argv[5],0,23,&errs) ;
      stimestructure.Minutes        = parse_num(argv[6],0,59,&errs) ;
      stimestructure.Seconds        = parse_num(argv[7],0,59,&errs) ;
      stimestructure.SubSeconds     = 0x00;
      stimestructure.TimeFormat     = RTC_HOURFORMAT12_AM;
      stimestructure.DayLightSaving = RTC_DAYLIGHTSAVING_NONE ;
      stimestructure.StoreOperation = RTC_STOREOPERATION_RESET;

      if (!errs)
      {
         if(HAL_RTC_SetDate(&hrtc,&sdatestructure,RTC_FORMAT_BIN) != HAL_OK) errs++ ;
         if(HAL_RTC_SetTime(&hrtc,&stimestructure,RTC_FORMAT_BIN) != HAL_OK) errs++ ;
      }

      if (errs)
      {
         Console_printf("Errors setting the RTC time, check parameters\n");
      }
      else
      {
         Console_printf("RTC Time set!\n");
      }
   }
}

/*******************************************************************************
* Routine  : RTC_Sync
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This command synchronizes the RTC time to GPS time--within about a second or
* so, not trying to be more accurate than that.
*******************************************************************************/
static void RTC_Sync(void)
{
   RTC_DateTypeDef sdatestructure = {0} ;
   RTC_TimeTypeDef stimestructure = {0} ;
   int errs = 0 ;

   /* GPS had better be locked! */
   if (!GPSLocked)
   {
      Console_printf("GPS not locked! (not setting RTC)\n");
   }
   else
   {
      /* If locked, just copy data from GPS time to RTC structure and set! */
      sdatestructure.Year           = GPSData.UTC_Year ;
      sdatestructure.Month          = GPSData.UTC_Month ;
      sdatestructure.Date           = GPSData.UTC_Day ;
      sdatestructure.WeekDay        = RTC_WEEKDAY_SUNDAY ; /* Not used */

      stimestructure.Hours          = GPSData.UTC_Hour ;
      stimestructure.Minutes        = GPSData.UTC_Min ;
      stimestructure.Seconds        = GPSData.UTC_Sec ;
      stimestructure.SubSeconds     = 0x00;
      stimestructure.TimeFormat     = RTC_HOURFORMAT12_AM;
      stimestructure.DayLightSaving = RTC_DAYLIGHTSAVING_NONE ;
      stimestructure.StoreOperation = RTC_STOREOPERATION_RESET;

      if(HAL_RTC_SetDate(&hrtc,&sdatestructure,RTC_FORMAT_BIN) != HAL_OK) errs++ ;
      if(HAL_RTC_SetTime(&hrtc,&stimestructure,RTC_FORMAT_BIN) != HAL_OK) errs++ ;

      if (errs)
      {
         Console_printf("Errors setting the RTC time!\n");
      }
      else
      {
         Console_printf("RTC Time sync'd with GPS!\n");
      }
   }
}

/*******************************************************************************
* Routine  : RTC_Show
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This command reads the RTC and shows the date and time.  Assuming it was set
* by GPS, it will be UTC.
*******************************************************************************/
static void RTC_Show(void)
{
   RTC_DateTypeDef sdatestructureget = {0};
   RTC_TimeTypeDef stimestructureget = {0};

   /* Get the time */
   HAL_RTC_GetTime(&hrtc,&stimestructureget,RTC_FORMAT_BIN);
   HAL_RTC_GetDate(&hrtc,&sdatestructureget,RTC_FORMAT_BIN);

   /* Show it! */
   Console_printf("%.2d/%.2d/%.2d "     ,sdatestructureget.Month,sdatestructureget.Date   ,sdatestructureget.Year+2000);
   Console_printf("%.2d:%.2d:%.2d UTC\n",stimestructureget.Hours,stimestructureget.Minutes,stimestructureget.Seconds  );
}
