#ifndef INC_RTC_H_
#define INC_RTC_H_

extern char* cmd_rtc_cmd ;
extern char* cmd_rtc_help ;

extern void MY_RTC_FinishInit(void) ;
extern void RTC_Bootloader_Enable(int) ;
extern int  Cmd_rtc(int, char**) ;

#endif /* INC_RTC_H_ */
