/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/* ************************************************************************** */
/* This is the DialSettings file, in charge of the settings for DIAL or       */
/* Asterisk mode. The settings for DIAL mode are separated from the main      */
/* set/show/settings code as DIAL mode can be optionally disabled and if so,  */
/* all the settings UI and NVM IO should be removed as well.                  */
/* This contains the segregated code that would be the equivalent of what is  */
/* in the set/show commands and settings commands.                            */
/******************************************************************************/
/* Public routines are:                                                       */
/*  - DIALSettingsInit - Set factory defaults.                                */
/*  - DIALSettingsRead - process and NVM TLV read                             */
/*  - DIALSettingsWrite - Write settings to NVM                               */
/*  - SetDIAL - CLI Change local mode settings                                */
/*  - ShowDIAL - CLI Display local mode settings                              */
/*                                                                            */
/******************************************************************************/
// To Do:
//  -

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>
#include "lwip.h"

#include "Options.h"
#ifndef NODIALTASK

#include "Utils.h"
#include "ConsoleTask.h"
#include "Settings.h"
#include "Setshow.h"
#include "AnalogIO.h"
#include "Tx_DSP.h"
#include "DialTask.h"
#include "DialSettings.h"
/******************************************************************************/
/* Local defines (including enums)                                            */
/******************************************************************************/
enum
{
   CMD_STATIC_IP,
   CMD_ACTUALIP,
   CMD_PORT,
   CMD_UNAUTHRATE,
   CMD_TXBUFDELAY,
   CMD_COMPRESSION,
   CMD_PACKETTIMING,
   CMD_IPMODE,
   CMD_HOSTPASSWORD,
   CMD_VOTERCHALLENGE,
   CMD_VOTERPASSWORD,
   CMD_FQDN,
   CMD_RESTART,
} DIALCMD_ENUMS ;

enum
{
   TLVT_STATICIP = 1,
   TLVT_IPMODE = 2,
   TLVT_UNAUTHRATE = 3,
   TLVT_COMPRESSION = 4,
   TLVT_PACKETTIMING = 5,
   TLVT_TXBUFDELAY = 6,
   TLVT_VOTERCHALLENGE = 7,
   TLVT_VOTERPASSWORD = 8,
   TLVT_HOSTPASSWORD = 9,
   TLVT_FQDN = 10,
   TLVT_PORT = 11,
} DIAL_TLVTS ;

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
DIALSETTINGS DIALSettings = {0} ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TOKENLIST DIALCliCmds[] =
{
   {"staticip"     ,CMD_STATIC_IP      },
   {"actualip"     ,CMD_ACTUALIP       },
   {"unauthrate"   ,CMD_UNAUTHRATE     },
   {"txbuf"        ,CMD_TXBUFDELAY     },
   {"compression"  ,CMD_COMPRESSION    },
   {"packettiming" ,CMD_PACKETTIMING   },
   {"ipmode"       ,CMD_IPMODE         },
   {"voterchal"    ,CMD_VOTERCHALLENGE },
   {"voterpwd"     ,CMD_VOTERPASSWORD  },
   {"hostpwd"      ,CMD_HOSTPASSWORD   },
   {"fqdn"         ,CMD_FQDN           },
   {"port"         ,CMD_PORT           },
   {"restart"      ,CMD_RESTART        },
} ;

static TOKENLIST Compressions[] =
{
   {"mulaw" ,COMPRESSION_MULAW},
   {"adpcm" ,COMPRESSION_ADPCM},
   {NULL    ,0                }
} ;

static TOKENLIST Timings[] =
{
   {"general",PKTTIM_GP   },
   {"gps"    ,PKTTIM_GPS  },
   {"fakegps",PKTTIM_FKGPS},
   {NULL     ,0           }
} ;

static TOKENLIST DIALIPModes[] =
{
   {"static",DIALIPMODE_STATIC},
   {"dns"   ,DIALIPMODE_DNS   },
   {NULL    ,0                }
} ;

/******************************************************************************/
/* External globals. CubeMX has you define them as externs in each file       */
/* instead of an include file, weird.                                         */
/******************************************************************************/

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/
static void SyncSettings(void) ;
static void Restart(void) ;

/*******************************************************************************
* Routine  : DIALSettingsInit
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : LocalSettings
*
* This routine fills in the DIALSettings structure with the factory default
* settings.  If NODIALTASK is't defined (yes, that's a double negative), then
* SettingsInit calls this routine on power-up if NVM is corrupted.
*******************************************************************************/
void DIALSettingsInit(void)
{
 //DIALSettings.Static_IP    = (192<<24) + (168<<16) + (  2<<8) + 194 ; /* My Computer */
   DIALSettings.Static_IP    = (192<<24) + (168<<16) + (  2<<8) + 208 ; /* RPi DIAL server */
   DIALSettings.Unauth_Rate  = 1000 ;
   DIALSettings.VoterPort    = 1667 ; /* For ASL3 */
   DIALSettings.TxBufDly     = 100 ;
   DIALSettings.Compression  = COMPRESSION_MULAW ;
   DIALSettings.PacketTiming = PKTTIM_GP ;
   DIALSettings.IPMode       = DIALIPMODE_STATIC ;

   strcpy(DIALSettings.Voter_Challenge,"CCRIVoter") ;
   strcpy(DIALSettings.Voter_Password, "Thorodin") ;
   strcpy(DIALSettings.Host_Password,  "Master_Control") ;
   strcpy(DIALSettings.fqdn,           "n0call.dyndns.net") ;

   /* Sync up with the global settings */
   SyncSettings() ;

} ;

/*******************************************************************************
* Routine  : DIALSettingsRead
* Gazintas : tag - The TLV T (tag) value
*          : buf - the TLV V data  (note L is implied by this point)
* IOs      : None
* Returns  : Nothing
* Globals  : LocalSettings
*
* This routine processes DIAL interface settings being read from NVM.  As
* entries are read, the main code looks at the group setting and if for a DIAL
* setting, calls this routine to process it.
*******************************************************************************/
void DIALSettingsRead(uint8_t tag,uint8_t* buf)
{
   switch (tag)
   {
      case TLVT_STATICIP       : memcpy(&DIALSettings.Static_IP       ,buf,4) ; break ;
      case TLVT_IPMODE         : memcpy(&DIALSettings.IPMode          ,buf,1) ; break ;
      case TLVT_PORT           : memcpy(&DIALSettings.VoterPort       ,buf,2) ; break ;
      case TLVT_UNAUTHRATE     : memcpy(&DIALSettings.Unauth_Rate     ,buf,2) ; break ;
      case TLVT_TXBUFDELAY     : memcpy(&DIALSettings.TxBufDly        ,buf,2) ; break ;
      case TLVT_COMPRESSION    : memcpy(&DIALSettings.Compression     ,buf,1) ; break ;
      case TLVT_PACKETTIMING   : memcpy(&DIALSettings.PacketTiming    ,buf,1) ; break ;
      case TLVT_VOTERCHALLENGE : memcpy(&DIALSettings.Voter_Challenge ,buf,SETTINGS_CHALLENGE_LEN) ; break ;
      case TLVT_VOTERPASSWORD  : memcpy(&DIALSettings.Voter_Password  ,buf,SETTINGS_PASSWORD_LEN)  ; break ;
      case TLVT_HOSTPASSWORD   : memcpy(&DIALSettings.Host_Password   ,buf,SETTINGS_PASSWORD_LEN)  ; break ;
      case TLVT_FQDN           : memcpy(&DIALSettings.fqdn            ,buf,SETTINGS_FQDN_LEN    )  ; break ;
      default                  :                                                break ;
   }

   /* Sync up with the global settings */
   SyncSettings() ;
}

/*******************************************************************************
* Routine  : DIALSettingsWrite
* Gazintas : None
* IOs      : memaddr
* Returns  : Nothing
* Globals  : LocalSettings
*
* This routine gets called by the 'settings save' command to save all the DIAL
* settings if DIAL mode is enabled.  memaddr is the I2C write address that
* gets incremented after each write based on the bytes in the TLV entry.
*******************************************************************************/
void DIALSettingsWrite(uint32_t* memaddr)
{
   write_tlv_i1 (memaddr,TGRP_ASTERISK,TLVT_IPMODE         ,&DIALSettings.IPMode          ) ;
   write_tlv_i1 (memaddr,TGRP_ASTERISK,TLVT_COMPRESSION    ,&DIALSettings.Compression     ) ;
   write_tlv_i1 (memaddr,TGRP_ASTERISK,TLVT_PACKETTIMING   ,&DIALSettings.PacketTiming    ) ;
   write_tlv_i2 (memaddr,TGRP_ASTERISK,TLVT_UNAUTHRATE     ,&DIALSettings.Unauth_Rate     ) ;
   write_tlv_i2 (memaddr,TGRP_ASTERISK,TLVT_PORT           ,&DIALSettings.VoterPort       ) ;
   write_tlv_i2 (memaddr,TGRP_ASTERISK,TLVT_TXBUFDELAY     ,&DIALSettings.TxBufDly        ) ;
   write_tlv_i4 (memaddr,TGRP_ASTERISK,TLVT_STATICIP       ,&DIALSettings.Static_IP       ) ;
   write_tlv_str(memaddr,TGRP_ASTERISK,TLVT_VOTERCHALLENGE ,&DIALSettings.Voter_Challenge ,SETTINGS_CHALLENGE_LEN) ;
   write_tlv_str(memaddr,TGRP_ASTERISK,TLVT_VOTERPASSWORD  ,&DIALSettings.Voter_Password  ,SETTINGS_PASSWORD_LEN ) ;
   write_tlv_str(memaddr,TGRP_ASTERISK,TLVT_HOSTPASSWORD   ,&DIALSettings.Host_Password   ,SETTINGS_PASSWORD_LEN ) ;
   write_tlv_str(memaddr,TGRP_ASTERISK,TLVT_FQDN           ,&DIALSettings.fqdn            ,SETTINGS_FQDN_LEN     ) ;
}

/*******************************************************************************
* Routine  : SetDIAL
* Gazintas : argc - argument count for the whole line including "set dial"
*          : argv - arguments (argv[0]="set", argv[1] = "dial")
* IOs      : None
* Returns  : Nothing
* Globals  : DIALSettings
*
* This is the CLI support routine for DIAL mode settings.  If the CLI code
* gets 'set dial' it just defers to this routine for any subsequent parsing.
* It only does that is NODIALTASK isn't defined just as any of this code only
* gets compiled if NODIALTASK isn't defined.
*******************************************************************************/
void SetDIAL (int argc,char** argv)
{
   int     error = false ; /* Parsing error flag */
   int     Token = 0     ; /* Command token      */
   int32_t tmp   = 0     ; /* Temporary value    */

   /* Have at least a setting before trying to parse the parameter */
   if (argc<2) error = true ;

   /* See which setting command */
   if (!error) Token = parse_token(DIALCliCmds,argv[2],&error) ;

   /* actualip and restart have no parameters, the rest have 1 */
   if ((((CMD_ACTUALIP==Token) || (CMD_RESTART==Token)) && argc!=3) ||
       (((CMD_ACTUALIP!=Token) && (CMD_RESTART!=Token)) && argc!=4)    )
   {
      error = true ;
   }

   if (error)
   {
      Console_printf("Not a recognized DIAL setting or missing/extra argument, enter 'show dial' for list.\n") ;
   }
   else if (!RootMode && ((CMD_HOSTPASSWORD==Token)||(CMD_VOTERCHALLENGE==Token)||(CMD_VOTERPASSWORD==Token)))
   {
      Console_printf("Sorry, not accessible with guest login.\n") ;
   }
   else
   {
      switch(Token)
      {
         case CMD_STATIC_IP      : SetIP    ("DIAL Server IP (if static):"      ,argv[3],                   &DIALSettings.Static_IP                    ) ; break ;
         case CMD_ACTUALIP       : SetNot   ()                                                                                                           ; break ;
         case CMD_UNAUTHRATE     : SetNum   ("Unauthorized challenge rate (ms):",argv[3], 100, 10000,&tmp) ; DIALSettings.Unauth_Rate = tmp              ; break ;
         case CMD_PORT           : SetNum   ("DIAL Server UDP Port:            ",argv[3],   1, 65535,&tmp) ; DIALSettings.VoterPort   = tmp              ; break ;
         case CMD_TXBUFDELAY     : SetNum   ("Transmit buffer delay (ms):"      ,argv[3],  60,   800,&tmp) ; DIALSettings.TxBufDly    = tmp              ; break ;
         case CMD_COMPRESSION    : SetList  ("Compression:"                     ,argv[3],                   &DIALSettings.Compression,Compressions,true) ; break ;
         case CMD_PACKETTIMING   : SetList  ("Packet Timing Mode:"              ,argv[3],                   &DIALSettings.PacketTiming,Timings,true    ) ; break ;
         case CMD_IPMODE         : SetList  ("DIAL Server IP Acquisition mode:" ,argv[3],                   &DIALSettings.IPMode,DIALIPModes,true      ) ; break ;
         case CMD_HOSTPASSWORD   : SetStr   ("Host Password:"                   ,argv[3],                    DIALSettings.Host_Password  ,SETTINGS_PASSWORD_LEN ) ; break ;
         case CMD_VOTERCHALLENGE : SetStr   ("Voter Challenge string:"          ,argv[3],                    DIALSettings.Voter_Challenge,SETTINGS_CHALLENGE_LEN) ; break ;
         case CMD_VOTERPASSWORD  : SetStr   ("Voter Password:"                  ,argv[3],                    DIALSettings.Voter_Password ,SETTINGS_PASSWORD_LEN ) ; break ;
         case CMD_FQDN           : SetStr   ("DIAL Server FQDN:"                ,argv[3],                    DIALSettings.fqdn           ,SETTINGS_FQDN_LEN     ) ; break ;
         case CMD_RESTART        : Restart  ()                                                                                                           ; break ;
         default                 : /* Unsupported tokens */                                                                                                break ;
      }
   }

   /* If we messed with packet timing mode, re-sync the GPS settings */
   if (CMD_PACKETTIMING==Token)
   {
      GPSLocked = false ;
      GPSUsed   = false ;
      Console_printf("Resetting GPS Sync...\n") ;
   }

   /* Sync up with the gobal settings */
   SyncSettings() ;
}

/*******************************************************************************
* Routine  : ShowDIAL
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : DIALSettings
*
* This is the CLI support routine for displaying DIAL settings.  If the CLI code
* gets 'show dial' it just defers to this routine for any subsequent parsing.
* Since there are relatively few DIAL settings, there are no parameters,
* I just display them all.
* The main CLI code only does this if NODIALTASK isn't defined just as any of
* this code only gets compiled if NODIALTASK isn't defined.

*******************************************************************************/
void ShowDIAL (void)
{
   /* For showing DIAL settings, just show them all */
   Console_printf("      DIAL Server IP (if static) (%12s):"     ,DIALCliCmds[ 0].token) ; ShowIP("",DIALSettings.Static_IP   ) ;
   Console_printf(" DIAL server IP acquisition mode (%12s): %s\n",DIALCliCmds[ 6].token,DIALIPModes[DIALSettings.IPMode]      ) ;
   Console_printf("         DIAL Server resolved IP (%12s):"     ,DIALCliCmds[ 1].token) ; ShowIP("",ntohl(DIAL_ip)           ) ;
   Console_printf("            DIAL Server UDP Port (%12s): %d\n",DIALCliCmds[11].token,DIALSettings.VoterPort                ) ;
   Console_printf("Unauthorized challenge rate (ms) (%12s): %d\n",DIALCliCmds[ 2].token,DIALSettings.Unauth_Rate              ) ;
   Console_printf("             Tx Bufer Delay (ms) (%12s): %d\n",DIALCliCmds[ 3].token,DIALSettings.TxBufDly                 ) ;
   Console_printf("                     Compression (%12s): %s\n",DIALCliCmds[ 4].token,Compressions[DIALSettings.Compression]) ;
   Console_printf("              Packet Timing Mode (%12s): %s\n",DIALCliCmds[ 5].token,Timings[DIALSettings.PacketTiming]    ) ;
   if (RootMode) /* Only  show if in root mode */
   {
      Console_printf("                   Host Password (%12s): %s\n",DIALCliCmds[ 9].token,DIALSettings.Host_Password         ) ;
      Console_printf("                  Voter Password (%12s): %s\n",DIALCliCmds[ 8].token,DIALSettings.Voter_Password        ) ;
      Console_printf("          Voter Challenge string (%12s): %s\n",DIALCliCmds[ 7].token,DIALSettings.Voter_Challenge       ) ;
   }
   Console_printf("                DIAL Server FQDN (%12s): %s\n",DIALCliCmds[10].token,DIALSettings.fqdn                     ) ;
}


/*******************************************************************************
* Routine  : SyncSettings
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : Settings
*
* This syncs up the necessary global settings after any update to the local
* settings.  Because there can be different local mode implementations, each
* with their own settings structures, the common code needs some shared global
* settings to react to no matter which local implementation is being used.
* These are those common settings.
*******************************************************************************/
static void SyncSettings(void)
{
   GlobTxBufDly = DIALSettings.TxBufDly ;
}

/*******************************************************************************
* Routine  : Restart
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This restarts the DIAL comms by just setting DIAL_Restart to true.
* The DIAL state machine will reset the connection status and pause all comms
* for 5 seconds (though #define prorammable, see DialTask.c).
*******************************************************************************/
static void Restart(void)
{
   Console_printf("Restarting DIAL comms...\n") ;
   DIAL_Restart = true ;
}

#endif /* NODIALTASK */
