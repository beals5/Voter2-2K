/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Tx_DSP file.  It is in charge of all the Transmit DSP          */
/* functions.  These routines get passed a packets worth of decompressed      */
/* samples from the Ethernet interface and prepares that data for DMAing to   */
/* the audio DACS.  This includes buffering, any filtering and CTCSS stuff    */
/* and (eventually) time stamp syncing.                                       */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Tx_ClearPacket - Clear a packet to "0V"                                 */
/*  - Tx_EnqPacket - Process an incoming packet, put it in the FIFO.          */
/*  - Tx_DeqPacket - Get a packet (if available) and put into DAC DMA buffer  */
/*  - ProbeCheck - Copies debug data to DAC2 buffer if it's the probe         */
/*                                                                            */
/******************************************************************************/
/* For the transmit data here is where we do our buffering to handle any      */
/* Network jitter.  When the first packets of a transmission start coming in, */
/* we buffer for roughly Settings.TxBufDly ms.  Since packets come in in      */
/* chunks of 20ms that is how accurate the buffering can be.  This gives some */
/* wiggle room for late packets after transmitting starts.                    */
/******************************************************************************/
// TO DO:
//
/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h> /* for memcpy */

#include "Options.h"
#include "main.h"
#include "Settings.h"
#include "AnalogIO.h"
#include "Tx_DSP.h"
#include "Gpio.h"
#include "DialTask.h"
#include "Settings.h"
#include "Codecs.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
/* The Tx Jitter buffer is a user-settable parameter.  For voting, the max    */
/* delay is 800ms which comes out to 40 160-sample buffers.  Adding a couple  */
/* more as we need a bit of margin if the user selects the full 800ms.        */
/* This is a pretty decent-sized buffer, almost 14KBytes!                     */
/* If not voting (local mode only), this can be a MUCH smaller buffer!!       */
#ifndef NODIALTASK
#define TXFIFO_NBUFS 42  /* Number of packets in Tx FIFO with voting support  */
#else
#define TXFIFO_NBUFS 5  /* Number of packets in Tx FIFO in local-only mode    */
#endif

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/
typedef struct
{
   uint32_t secs ;
   uint32_t ns   ;
   int      type ;
} PACKET_INFO ;

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
/* For offline PL Tones.  The default is off unless a local mode overrides */
/* it.  Note that each local mode has its own settings structure, so for code */
/* independence, this is the common setting each local mode must set.         */
uint8_t  Local_PLL_Lvl = 0 ;
uint8_t  Local_PLL_Freq = 0 ;

uint16_t ProbeBuf[APKT_SAMPLES] = {0} ; /* Probe data buffer */
uint16_t GlobTxBufDly = 60 ;  /* Global Tx Buffer delay (updated by settings  */

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
/* The Transmit FIFO */
static int         DAC_Busy     = false ;
static int         TxFIFO_WrPtr = 0     ;
static int         TxFIFO_RdPtr = 0     ;
static int16_t     TxFIFO[TXFIFO_NBUFS][APKT_SAMPLES] = {0} ;
static PACKET_INFO TxFIFO_info[TXFIFO_NBUFS] = {0} ;

/* Below is the increment (in 100ths of a degree) per sample off a sinewave   */
/* at the specified frequency.  A sample of course being at 8KHz.             */
/* This is a SW implementation of what I see in hardware Digital Phase Locked */
/* loops and seems to fit quite nicely here.  Yea, using degrees instead of   */
/* radians or something is probably non-standard, but it is just an index, so */
/* doesn't really matter and makes more sense to me.                          */
/* The idea is we increment the phase counter by the value below every sample */
/* then do a lookup of the sine value based on that phase.                    */
/* See Voter2-2K Support.xlsx for how I computed this.                        */
static int16_t CTCSS_Deltas[] = {
   302, // CTCSS_670
   324, // CTCSS_719
   335, // CTCSS_744
   347, // CTCSS_770
   359, // CTCSS_797
   371, // CTCSS_825
   384, // CTCSS_854
   398, // CTCSS_885
   412, // CTCSS_915
   427, // CTCSS_948
   438, // CTCSS_974
   450, // CTCSS_1000
   466, // CTCSS_1035
   482, // CTCSS_1072
   499, // CTCSS_1109
   517, // CTCSS_1148
   535, // CTCSS_1188
   554, // CTCSS_1230
   573, // CTCSS_1273
   593, // CTCSS_1318
   614, // CTCSS_1365
   636, // CTCSS_1413
   658, // CTCSS_1462
   681, // CTCSS_1514
   705, // CTCSS_1567
   730, // CTCSS_1622
   756, // CTCSS_1679
   782, // CTCSS_1738
   810, // CTCSS_1799
   838, // CTCSS_1862
   868, // CTCSS_1928
   916, // CTCSS_2035
   948, // CTCSS_2107
   981, // CTCSS_2181
   1016,// CTCSS_2257
   1051,// CTCSS_2336
   1088,// CTCSS_2418
   1126,// CTCSS_2503
} ;

/* There may be fancier ways of doing this, but this is simple.  It is the    */
/* first quarter of a full scale (16-bit) sine wave in increments of one      */
/* degree.  When creating a CTCSS tone the degree count gets incremented in   */
/* hundredths of a degree using the index above, then the whole degree amount */
/* is used to look up the sine value.  The overall accuracy is still 1/100th  */
/* of a degree and rounding to a degree is just a bit of amplitude noise.     */
/* Digital PLLs are cool, hence liking this SW implementation.                */
/* It is only the first quarter of the sine wave as the other three quarters  */
/* are just mirror and/or negative versions of the first quarter.  Yea flash  */
/* space isn't a huge concern, but still want to be efficient.                */
/* NOTE: An optimization to this would be for the table's length to be a      */
/* power of 2 instead of 91.                                                  */
static int16_t sinetable[91] = {
       0,  572, 1144, 1715, 2286, 2856, 3425, 3993,
    4560, 5126, 5690, 6252, 6813, 7371, 7927, 8481,
    9032, 9580,10126,10668,11207,11743,12275,12803,
   13328,13848,14365,14876,15384,15886,16384,16877,
   17364,17847,18324,18795,19261,19720,20174,20622,
   21063,21498,21926,22348,22763,23170,23571,23965,
   24351,24730,25102,25466,25822,26170,26510,26842,
   27166,27482,27789,28088,28378,28660,28932,29197,
   29452,29698,29935,30163,30382,30592,30792,30983,
   31164,31336,31499,31651,31795,31928,32052,32166,
   32270,32365,32449,32524,32588,32643,32688,32723,
   32748,32763,32767
} ;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void Tx_AddTones (int16_t*,int16_t*) ;
static void MakeDAClike(int16_t*,uint16_t*,int) ;
static void HandleDebugData(uint16_t*) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : Tx_ClearPacket
* Gazintas : buf - Buffer to clear (sample buffer, so 1/2 of DMA buffer)
*          : channel - which channel to clear
* IOs      : None.
* Returns  : Nothing
* Globals  : None
*
* This routine clears out a channel in the ping or pong buffer to 0V (midway
* point for DAC).
*******************************************************************************/
void Tx_ClearPacket(uint16_t* buf,int channel)
{
   int i = 0 ;
   for (i=0;i<APKT_SAMPLES;buf[(i++)*2+channel]=0x0800) ;
}

/*******************************************************************************
* Routine  : `
* Gazintas : SrcBuffer - pointer to 16-bit uncompressed audio samples
*          :  - Normally 160 samples if voting supported, variable if local-only
*          : Pkt_Type - Packet timing type
*          : TS_secs - Packet timestamp - seconds
*          : TS_ns - Packet timestamp - ns
* IOs      : None.
* Returns  : Nothing
* Globals  : TxFIFO - Tramsmiter FIFO
*          : DAC_Busy - DAC Busy state (to stall initial transmission)
*          : TxFIFO_WrPtr - Transmit FIFO Write Pointer
*          : TxFIFO_RdPtr - Transmit FIFO Read Pointer
*
* This routine is the handler for a packets worth of audio samples from the
* server (if connected) or incoming audio (if in local mode).  See top header
* for how buffering works.
*******************************************************************************/
void Tx_EnqPacket(int16_t* SrcBuffer,int Pkt_Type,uint32_t TS_secs,uint32_t TS_ns)
{

   if (((TxFIFO_WrPtr+1)%TXFIFO_NBUFS)==TxFIFO_RdPtr) /* If FIFO is full */
   {
      /* If FIFO is full, don't do nuthin! (Packet gets dropped) */
      /* Shouldn't happen, may do some error logging here later */
   }
   else
   {
      /* Otherwise copy the audio samples into the transmit FIFO and save the */
      /* timestamp for that buffer.                                           */
      TxFIFO_WrPtr = (TxFIFO_WrPtr+1)%TXFIFO_NBUFS ;
      memcpy(TxFIFO[TxFIFO_WrPtr],SrcBuffer,APKT_SAMPLES*2) ;
      TxFIFO_info[TxFIFO_WrPtr].type = Pkt_Type ;
      TxFIFO_info[TxFIFO_WrPtr].secs = TS_secs  ;
      TxFIFO_info[TxFIFO_WrPtr].ns   = TS_ns    ;

      /* If the DAC is already running, great.  If it isn't, see if we have   */
      /* Enough packets queued up to start the DAC.                           */
      /* Settings.TxBufDly is in ms, and a packets of data is 20ms long, so   */
      /* need to convert ms to packet count below by dividing by 20.          */
      if (!DAC_Busy)
      {
         if (((TxFIFO_WrPtr+TXFIFO_NBUFS-TxFIFO_RdPtr)%TXFIFO_NBUFS)>= GlobTxBufDly/20)
         {
            /* We've delayed enough, start transmitting! */
            DAC_Busy = true ;
         }
      }
   }
}

/*******************************************************************************
* Routine  : Tx_DeqPacket
* Gazintas : TargetBuf - Next buffer (ping or pong) to fill.
* IOs      : None.
* Returns  : Nothing
* Globals  : TxFIFO - Tramsmiter FIFO
*          : DAC_Busy - DAC Busy state (to stall initial transmission)
*          : TxFIFO_WrPtr - Transmit FIFO Write Pointer
*          : TxFIFO_RdPtr - Transmit FIFO Read Pointer
*
* This routine gets the next available packet of data from the Tx FIFO, does
* any DSPing (CTCSS and pre-emphasis), and puts it into either the Ping or Pong
* buffer depending on which ISR called it.
* See top header for how buffering works.
*
* OPEN ISSUE: Data going to the A2D is 12-bit unsigned DAC samples.  The
* incoming data and decompression algos assume 16-bit signed samples.  Should
* I decimate to 12-bit first then do all the DSP on 12-bit data then convert to
* the A2D or stick with 16-bit data and do the DSP on 16-bit data? I like less
* chance of overflows but might have better DSPing with more bits.  Going
* to go 16-bit DSPing for now.
*
* Execution time of this ISR depends on if we are transmitting or not, or adding
* tones or not.  Without any big filters, no CMSIS DSP routines here.
* Execution time with C code: 3.68us min, 16.2us max. (0.081% of the CPU)
* Execution time with CMSIS: N/A
*
*******************************************************************************/
void Tx_DeqPacket(uint16_t* TargetBuf)
{
   static int16_t Tx_ppbuf1[APKT_SAMPLES] ; /* Pipeline buffer for uncompressed audio */

   /* If read and write pointers are the same (buffer is empty) or DAC is     */
   /* stalled to pre-fill the buffer, just fill the DAC buffer with a packet  */
   /* of "0V"                                                                 */
   if ((TxFIFO_RdPtr==TxFIFO_WrPtr) || (!DAC_Busy))
   {
      Tx_ClearPacket(TargetBuf,MAINBUF) ;
      /* Whether full or not busy make sure we exit not busy.                 */
      DAC_Busy = false ;
      Show_State(TX_STATE,false) ;
      PTT_State(false) ;

      /* If any of the Tx probes are active but we are not actually           */
      /* transmitting, just clear the debug buffer.                           */
      if ((PROBE_TXSRC==Probe)||(PROBE_TXPL==Probe)||(PROBE_TXOUT==Probe))
      {
         Tx_ClearPacket(TargetBuf,DEBUGBUF) ;
      }
   }

   /* IF DAC is running or in test tone mode, transmit! */
   if ((DAC_Busy) || (Settings.TTone_lvl!=TTONE_NONE))
   {
      Show_State(TX_STATE,true) ;
      PTT_State(true) ;

      /* ******************************************************************** */
      /* THIS IS THE MAIN TRANSMITTER COMPUTATIONAL SEQUENCE!!  Here is where */
      /* we convert IP-received data to DAC samples!!!                        */
      /* ******************************************************************** */
      /* After each step I have ProbeCheck().  This allows the user to "probe"*/
      /* the audio signal after each step in the chain and see the results on */
      /* DAC2.  What to probe is a CLI command.                               */
      /* ******************************************************************** */

      ProbeCheck(TxFIFO[TxFIFO_RdPtr],PROBE_TXSRC ,PROBE_AUDIO) ;
      /* Coming Soon: Pre-emphasis                 ; */
      Tx_AddTones (TxFIFO[TxFIFO_RdPtr],Tx_ppbuf1) ;
      MakeDAClike(Tx_ppbuf1,TargetBuf,MAINBUF)     ;

      /* All done processing the packet, increment the read pointer */
      TxFIFO_RdPtr = (TxFIFO_RdPtr+1)%TXFIFO_NBUFS ;

      /* If we are in test tone mode, keep the FIFO pointers reset */
      if (Settings.TTone_lvl!=TTONE_NONE)
      {
    	  TxFIFO_RdPtr = 0 ;
    	  TxFIFO_WrPtr = 0 ;
      }
   }
   /* If there is data but we're note busy yet, the only reason is we haven't */
   /* buffered up enough data.  If so, do nuthin and wait for enough data to  */
   /* buffer up.                                                              */

   /* Now for the debug channel handling. */
   HandleDebugData(TargetBuf) ;
}

/*******************************************************************************
* Routine  : MakeDAClike
* Gazintas : SignedData Audio samples in 16-bit signed format
*          : Buffer - which buffer (main vs debug)
* IOs      : DACData - Audio samples in unsigned 12-bit offset format
* Returns  : Nothing
* Globals  : None
*
* This routine converts the 16-bit signed data with 0V at 0 used by the DSP
* routines into DAC format which is 12-bit unsigned, with 0V at the mid way
* point.
* This routine also takes care of the interleaving between the main and debug
* channels.
*
* Execution time with C code: 1.77us max.
* Execution time with CMSIS: N/A
*******************************************************************************/
static void MakeDAClike(int16_t* SignedData,uint16_t* DACData,int buffer)
{
   int i = 0 ;

   //DISR_SHOWSTART ;

   for (i=0;i<APKT_SAMPLES;i++)
   {
      DACData[(i*2)+buffer] = (uint16_t)((SignedData[i]>>4)+2048) ;
   }

   //DISR_SHOWEND ;
}

/*******************************************************************************
* Routine  : Tx_AddTones
* Gazintas : in - audio samples before adding CTCSS
* IOs      : out - audio samples with CTCSS added
* Returns  : Nothing
* Globals  : Settings, DIAL_State
*
* This routine adds test and/or CTCSS tones to the packet of audio if requested.
* Test tones replace any incoming audio completely with the frequency and
* amplitude called out in Settings.  CTCSS tones are only applicable in local
* mode.  The frequency and volume are called out in local Settings.  If the
* CTCSS volume is 0, that means CTCSS is disabled.
*
* Execution time with C code: 0us min, 14.2us max.
* Execution time with CMSIS: N/A
*******************************************************************************/
static void Tx_AddTones (int16_t* in,int16_t* out)
{
   static uint32_t ttphase = 0 ; /* Phase accumulator of the test tone */
   static uint32_t phase   = 0 ; /* Phase accumulator of the PL tone   */
   int             degonly = 0 ; /* Phase in unit degrees only         */
   int16_t         tone    = 0 ; /* Tone voltage level                 */
   int             i       = 0 ; /* General counter                    */
   int32_t         tmp     = 0 ; /* 32-bit temp value (no overflows!)  */

   //DISR_SHOWSTART ;

   /* If test tones are enabled, replace the incoming audio with the test tone*/
   if (TTONE_NONE!=Settings.TTone_lvl)
   {
      for (i=0;i<APKT_SAMPLES;i++)
      {
         /* Increment the test tone phase based on the selected frequency and */
         /* handle wrap-around (360 degrees in 1000ths of a degree)           */
         /* NOTE: freq*45 is simplified freq/8000*360000 to avoid overflows   */
         ttphase = (ttphase + Settings.TTone_freq*45)%360000 ;

         /* Get just integer degrees and then do the four quadrants of the    */
         /* sine wave table.                                                  */
         degonly = ttphase/1000 ;
              if (degonly< 90) tone =  sinetable[degonly    ] ;
         else if (degonly<180) tone =  sinetable[180-degonly] ;
         else if (degonly<270) tone = -sinetable[degonly-180] ;
         else                  tone = -sinetable[360-degonly] ;

         /* Figger it out in 32-bit space where it may overflow intermediately*/
         /* before putting it back in 16-bit space.                           */
         tmp = tone*Settings.TTone_lvl ;
         in[i] = tmp>>12 ;
      }
   }

   /* If authorized (not local mode), or if local and the CTCSS volume level  */
   /* is 0, then just copy samples.                                           */
   if ((DIAL_AUTHORIZED) || (0==Local_PLL_Lvl))
   {
      memcpy(out,in,APKT_SAMPLES*2) ;
   }
   else
   {
      for (i=0;i<APKT_SAMPLES;i++)
      {
         /* Increment the PL tone phase based on the selected frequency and   */
         /* handle wrap-around (360 degrees in 100ths of a degree)            */
         phase = (phase + CTCSS_Deltas[Local_PLL_Freq])%36000 ;

         /* Get just integer degrees and then do the four quadrants of the    */
         /* sine wave table.                                                  */
         degonly = phase/100 ;
              if (degonly< 90) tone =  sinetable[degonly    ] ;
         else if (degonly<180) tone =  sinetable[180-degonly] ;
         else if (degonly<270) tone = -sinetable[degonly-180] ;
         else                  tone = -sinetable[360-degonly] ;

         /* I was getting set up to do some fancy logarithmic volume mixing,  */
         /* but that looked really messy and so just going to try linear      */
         /* volume mixing first.                                              */
         /* Volumes 0-10 will be 0%-100% tone respectively with the incoming  */
         /* audio decreased by the inverse (100-x) amount to ensure no        */
         /* overflow.                                                         */

         /* Figger it out in 32-bit space where it may overflow intermediately*/
         /* before putting it back in 16-bit space.                           */
         tmp = (tone*Local_PLL_Lvl + in[i]*(10-Local_PLL_Lvl)) ;
         out[i] = tmp/10 ;
      }
   }

   //DISR_SHOWEND ;

   /* Check for probing */
   ProbeCheck(out,PROBE_TXPL,PROBE_AUDIO) ;
}

/*******************************************************************************
* Routine  : ProbeCheck
* Gazintas : src - Packet source (16-bit samples)
*          : channel - the Probe channel being offered
*          : format - the data format, either signed audio or raw DAC samples
* IOs      : None
* Returns  : Nothing
* Globals  : Probe, ProbeBuf
*
* This routine gets called after each stage of the Rx and Tx DSP routines to
* see if the data should be sent to the debug DAC.  If the current Probe
* setting matches the source data, then the data is copied to the ProbeBuf
* buffer to be sent to the DAC.  There are two data types, signed audio or
* unsigned Raw DAC data.
*******************************************************************************/
void ProbeCheck(void* src,int8_t channel,int format)
{
   int      i    = 0   ; /* loop counter   */
   int16_t* isrc = src ; /* Correctly cast */

   if (Probe==channel)
   {
      if (PROBE_RAW==format)
      {
         memcpy(ProbeBuf,src,APKT_SAMPLES*2) ;
      }
      else /* it is signed audio data */
      {
         for (i=0;i<APKT_SAMPLES;i++)
         {
            ProbeBuf[i] = (uint16_t)((isrc[i]>>4)+2048) ;
         }
      }
   }
}

/*******************************************************************************
* Routine  : HandleDebugData
* Gazintas : Target - The target output buffer (ping or pong)
* IOs      : None
* Returns  : Nothing
* Globals  : Probe, ProbeBuf
*
* This routine copies the debug data (if any) to the right area of the ping or
* pong buffer to be sent out the debug DAC.  If nothing is being probed, it
* makes sure the debug data is cleared.  There is a boundary case where if I
* change from another probe to a Tx.. probe and we are not transmitting that
* stale data is left in ProbeBuf.  I handle that below by simply clearing
* ProbeBuf on any change in the Probe value.
*******************************************************************************/
static void HandleDebugData(uint16_t* Target)
{
   static uint8_t LastProbe = PROBE_NONE ; /* Last probe value */
   int            i         = 0          ; /* loop counter     */

   if (Probe != LastProbe)
   {
      for (i=0;i<APKT_SAMPLES;i++)
      {
         ProbeBuf[i] = 0x0800 ;
      }
   }

   if (PROBE_NONE==Probe)
   {
      Tx_ClearPacket(Target,DEBUGBUF) ;
   }
   else
   {
      for (i=0;i<APKT_SAMPLES;i++)
      {
         Target[(i*2)+1] = ProbeBuf[i] ;
      }
   }
   LastProbe = Probe ;
}
