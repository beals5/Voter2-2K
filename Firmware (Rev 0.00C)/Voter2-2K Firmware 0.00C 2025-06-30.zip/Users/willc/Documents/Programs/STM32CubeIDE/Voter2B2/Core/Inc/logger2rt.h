#ifndef LOGGER2_H_
#define LOGGER2_H_

/******************************************************************************/
/* Logger level: This is the verboseness of logging information.  Each call   */
/* to log a message has a level.  Only messages with a level equal to or      */
/* lower than this level will be sent.  Four levels are supported with these  */
/* suggested meanings (admittedly arbitrary):                                 */
/*  - Level 0: No logging and logging routines are not compiled into code.    */
/*             Logging routines exist, but are empty, hopefully optimized out */
/*             of existence.                                                  */
/*  - Level 1: High level Status messaging with critical data such as errors, */
/*             unexpected conditions or important decisions.                  */
/*  - Level 2: Processed data used for decision making and intermediate (raw) */
/*             data.                                                          */
/*  - Level 3: Low level raw register data.                                   */
/* Note that this sets the initial level.  If any level other than 0, the     */
/* level can be dynamically updated by calling Logger2_NewLevel().            */
/* If set to 0 here, logging is compiled out, so not dynamically alterable.   */
/******************************************************************************/

#define LOGGER2_LEVEL 2

#define LOG_NONE 0
#define LOG_MAJOR 1
#define LOG_SUPPORT 2
#define LOG_REGIO 3

#define LOG_ERR_OK 0
#define LOG_ERR_NOLOGGING 1
#define LOG_ERR_NOUART 2
#define LOG_ERR_FULL 3

/* Just to put words behind the long time or not parameter */
#define LOG_TIME true
#define LOG_NOTIME false

/* This routine tells Logger2 which UART handle to use for messages.  Note    */
/* Logger2 does not initialize the UART.  It assumes it is set up by CubeMX   */
/* to whatever the user wants (pins, baud rate, etc.).                        */
void Logger2_SetUart(UART_HandleTypeDef *husart) ;

/* Sends a message.  param1: Logging threshold to meet/exceed (group setting) */
/*                   param2: level for this message                           */
/*                   param3: Timestamp - LOG_TIMESTAMP or LOG_NOTIMESTAMP     */
/*                           Includes timestamp at start of msg (SysTicks)    */
/*                   param4: format - regular printf formatting string        */
/*                   param5: ... Data to print.                               */
int Logger2_Msg(int,int, int, const char* format, ...) ;

/* For LWIP support you need to modify the following file too:                */
/* Middlewares/Third_Party/LwIP/src/include/lwip/arch.h and change the        */
/* definition of LWIP_PLATFORM_DIAG to include this header and call the       */
/* routine below.  It should look like:                                       */
/*    #ifndef LWIP_PLATFORM_DIAG                                              */
/*    #include "main.h"                                                       */
/*    #include "Logger2r.h"                                                   */
/*    #define LWIP_PLATFORM_DIAG(x) do {Logger2_LWIP x;} while(0)             */
/*    #include <stdio.h>                                                      */
/*    #include <stdlib.h>                                                     */
/*    #endif                                                                  */
/* Or, for easier cut and paste, just the three #ifdef'd out lines below:     */
#if 0
#include "main.h"
#include "Logger2r.h"
#define LWIP_PLATFORM_DIAG(x) do {Logger2_LWIP x;} while(0)
#endif

/* Logger2_LWIP is just a flavor of Logger2_Msg specifically for LWIP logging.*/
/* It only takes a string, so I need a flavor only accepting the string so    */
/* just hard code the levels and time stamp.                                  */
/* This is a separate routine since I can't pass vargs, but suspect some      */
/* fancy routine #defining could solve this better.                           */
int Logger2_LWIP(const char* format, ...) ;

/* For IRQ routines, I need to handle if the IRQ happens to fall exactly when */
/* some internal mutexed variables are being fiddled with.  In this case,     */
/* instead of the string being pritned, just the ShortForm value is printed   */
/* as four separate bytes.  The idea is the first byte is the IRQ ID and the  */
/* subsequent 3 bytes are data associated with that source.                   */
/* WARNING!!!  A source of 0 is reserved for "regular" RTOS messages, so      */
/* cannot be used here.  If you do by accident, the message will be converted */
/* to 0xbaadbeef.  Letting a value of 0 through would be bad.                 */
/*  - param1: Logging threshold to meet/exceed (group setting) */
/*  - param2: level for this message                           */
/*  - param3: Timestamp - LOG_TIMESTAMP or LOG_NOTIMESTAMP     */
/*  - param4: ShortForm - Backup 32-bit value if IRQ conflict  */
/*  - param4: format - regular printf formatting string        */
/*  - param5: ... Data to print.                               */
int Logger2_IRQMsg(int,int,int,uint32_t, const char* format, ...) ;

/* This is a helper routine to print out a byte array in ASCII.  It just      */
/* writes to a string that then gets sent by Logger2_Msg().  It first writes  */
/* out the string length, then up to the max number of bytes, stopping if the */
/* actual array is bigger.  The destination string should be at least 6+3n    */
/* bytes long where n is the number of bytes to display.  Add one byte for    */
/* going above 100, 1 more for > 1000, etc.                                   */
/* Byte array string param1: str - destination string                         */
/*                   param2: data - data to display                           */
/*                   param3: arraylen - actual length of array                */
/*                   param4: max - max # of bytes to display                  */
void Logger2_DispBytes(char*,void*,int,int) ;

/* This is the task in charge of getting messages to the UART.  Logger2_Msg   */
/* sends messages to it to fire it off.                                       */
void Logger2Task(void const *);

/* Transmit complete ISR handler */
void Logger2TxComplete(void) ;

#endif /* LOGGER2_H_ */
