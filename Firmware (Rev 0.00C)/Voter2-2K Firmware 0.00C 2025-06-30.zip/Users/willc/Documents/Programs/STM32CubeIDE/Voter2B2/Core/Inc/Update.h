#ifndef INC_UPDATE_H_
#define INC_UPDATE_H_

extern char* cmd_update_cmd ;
extern char* cmd_update_help ;

extern int  Cmd_update(int, char**) ;

#endif /* INC_UPDATE_H_ */
