/* ************************************************************************** */
/* This is the Ethernet Task file.  By going to netconn, the EthernetTask     */
/* task itself got trivial!  It is in charge if initial setup of the Ethernet */
/* port and thats it!  With netconn, all the other connections are in         */
/* separate threads.                                                          */
/*                                                                            */
/* NOTE!! Be sure to wait 50ms or more before invoking another task that may  */
/* rely on LWIP.  I need to do a HW Reset to the PHY first before firing up   */
/* LWIP, and calling LWIP routines before MX_LWIP_Init() finishes is bad.     */
/*                                                                            */
/* It isn't practical to modify MX_LWIP_Init() in lwip.c to handle both a     */
/* static IP and DHCP based on user preference and have it survive a CubeMX   */
/* regen.  So, I've #ifdef'd all of lwip.c away (and it wont come back with a */
/* regen) and copied the pertinent code below into MY_LWIP_Init() where       */
/* changes will survive.                                                      */
/*                                                                            */
/* IMPORTANT: Be sure to increase MEMP_NUM_NETBUF to 4 and MEMP_NUM_NETCONN   */
/* to 8 if making more than one simultaneous connection!!                     */
/******************************************************************************/
/* Public routines are:                                                       */
/*  - EthernetTask - The Ethernet task.                                       */
/******************************************************************************/
// To Do:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "cmsis_os.h"
#include "lwip.h"
#include "dns.h"

#include "Options.h"
#include "main.h"
#include "Settings.h"
#include "logger2rt.h"
#include "EthernetTask.h"
#include "KSz8081.h"

/******************************************************************************/
/* Local defines (including enums)                                            */
/******************************************************************************/

/******************************************************************************/
/* Local structures                                                           */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
int EthernetUp = false ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
/* Well, sorta local, they get passed around a lot by reference !! */
struct netif gnetif  = {0} ; /* Overall network handle */
ip4_addr_t   ipaddr  = {0} ; /* Voter2 IP address      */
ip4_addr_t   netmask = {0} ; /* Voter2 Net Mask        */
ip4_addr_t   gw      = {0} ; /* Voter2 Gateway IP      */
ip4_addr_t   dnsaddr = {0} ; /* Voter2 DNS Address     */

/******************************************************************************/
/* External globals. CubeMX has you define them as externs in each file       */
/* instead of an include file, weird.                                         */
/******************************************************************************/

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/
static void MY_LWIP_Init(void) ;
static void ethernet_link_status_updated(struct netif *netif) ;

/*******************************************************************************
* Routine  : EthernetTask
* Gazintas : None
* IOs      : None
* Returns  : Never
* Globals  : TBD
*
* This is the top level Ethernet task.  It fires up the Ethernet hardware,
* does the LWIP initialization, and that's it!  With netconn, this task has
* become trivial.  Leaving it for now in case something comes up.
*******************************************************************************/
void EthernetTask(void const * argument)
{
   /* Startup sequencing enforcement. See Options.h */
   osDelay(StartDelay_EthernetTask) ;
   Logger2_Msg(Logger.EthApp,LOG_MAJOR,LOG_TIME,"EthernetTask: Start\r\n") ;

   /* Reset the PHY */
   KSZ8081_Toggle_HWReset() ;

   /* Do the MX initialization of the LWIP library.  Sets the local IP        */
   /* addresses and fires up the LWIP tasks and such.                         */
   Logger2_Msg(Logger.EthApp,LOG_REGIO,LOG_TIME,"EthTopTask: Pre MY_LWIP_Init\r\n") ;
   MY_LWIP_Init(); /* note: MY... (below), not MX... (ST code) */
   Logger2_Msg(Logger.EthApp,LOG_REGIO,LOG_TIME,"EthTopTask: Post MY_LWIP_Init\r\n") ;

   /* Let other tasks know Ethernet has been initialized */
   EthernetUp = true ;

   /* EthTopTask Infinite loop.  A do-nothing loop for now. */
   for (;;)
   {
      osDelay(5000) ;
   }
} ;


/*******************************************************************************
* Routine  : MY_LWIP_Init (vs MX_LWIP_Init)
* Gazintas : None
* IOs      : None
* Returns  : Never
* Globals  : Many!!!
*
* This is a copy of the ST MX_LWIP_Init() code generated to support DHCP, but
* modified to be able to select Static IP as well based on user preference.
*******************************************************************************/
static void MY_LWIP_Init(void)
{
   /* Initialize the LwIP stack with RTOS */
   tcpip_init( NULL, NULL );

   /* If a static IP, set it up, otherwise 0's for DHCP later */
   if (MYIPMODE_STATIC==Settings.My_IPMode)
   {
      ipaddr.addr = ntohl(Settings.My_StaticIP     ) ;
      netmask.addr= ntohl(Settings.My_StaticSubnet ) ;
      gw.addr     = ntohl(Settings.My_StaticGateway) ;
   }
   else
   {
      /* Probably not needed given I initialize the structure to 0's */
      ipaddr.addr  = 0 ;
      netmask.addr = 0 ;
      gw.addr      = 0 ;
   }

   /* add the network interface (IPv4/IPv6) with RTOS */
   netif_add(&gnetif, &ipaddr, &netmask, &gw, NULL, &ethernetif_init, &tcpip_input);

   /* Registers the default network interface */
   netif_set_default(&gnetif);

   if (MYIPMODE_STATIC==Settings.My_IPMode)
   {
      if (netif_is_link_up(&gnetif))
      {
        /* When the netif is fully configured this function must be called */
        netif_set_up(&gnetif);
      }
      else
      {
        /* When the netif link is down this function must be called */
        netif_set_down(&gnetif);
      }
   }
   else
   {
      /* We must always bring the network interface up connection or not... */
      netif_set_up(&gnetif);
   }

   /* If Static IP, wait until the end to set the DNS server IP.  I probably  */
   /* Could do this when I set up all the other static IPs, but seems safer   */
   /* to do it after all the networking is running.                           */
   if (MYIPMODE_STATIC==Settings.My_IPMode)
   {
      dnsaddr.addr = ntohl(Settings.My_StaticDNS) ;
      dns_setserver(0, &dnsaddr);
   }

   /* Start DHCP negotiation if using DHCP) */
   if (MYIPMODE_DHCP==Settings.My_IPMode)
   {
      /* else if DHCP, start the service */
      dhcp_start(&gnetif);
   }

   /* Finally set up the status callback routine */
   netif_set_status_callback(&gnetif, ethernet_link_status_updated);
}

/*******************************************************************************
* Routine  : ethernet_link_status_updated
* Gazintas : None
* IOs      : None
* Returns  : Never
* Globals  : TBD
*
* This routine gets called by LWIP whenever the link status changes.  All I do
* is report the change for now.
*******************************************************************************/
static void ethernet_link_status_updated(struct netif *netif)
{
  if (netif_is_up(netif))
  {
   Logger2_Msg(Logger.EthLWIP,LOG_MAJOR,LOG_TIME,"LWIP: Link is up %s\r\n",ip4addr_ntoa(netif_ip4_addr(netif))) ;
  }
  else /* netif is down */
  {
   Logger2_Msg(Logger.EthLWIP,LOG_MAJOR,LOG_TIME,"LWIP: Link is down\r\n") ;
  }
}

/*******************************************************************************
* Routine  : ActualIP
* Gazintas : None
* IOs      : None
* Returns  : string with IP address
* Globals  : gnetif
*
* This is just a wrapper to return a string of the current IP address.
* There are lots of warnings that ip4addr_ntoa() isn't reentrant, but for
* what I need, that isn't really an issue, so OK using it over the reentrant
* one.
*******************************************************************************/
char* ActualIPstr(void)
{
   return(ip4addr_ntoa(netif_ip4_addr(&gnetif))) ;
}
