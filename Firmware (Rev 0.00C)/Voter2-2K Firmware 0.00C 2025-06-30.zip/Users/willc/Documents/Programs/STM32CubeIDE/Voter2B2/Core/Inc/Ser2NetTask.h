#ifndef INC_SER2NETTASK_H_
#define INC_SER2NETTASK_H_

/* S2N_RX_BUFSIZE below  is the max characters that can arrive in a single    */
/* polling period.  The MTR2000s RSS port runs at 9600 baud and the polling   */
/* period is 100ms, so that comes out to 96 bytes so 128 with margin.         */
/* The DMA out buffer can be bigger as we have to convert 0xff's to double-   */
/* IAFs.  For now since 128 has margin on incoming, 128 for DMA seems OK.     */
#define S2N_RX_BUFSIZE    128 /* Circular DMA Rx buffer size                  */
#define S2N_RXDMA_BUFSIZE 128 /* Circular DMA Rx DMAbuffer size               */

extern uint8_t S2N_RxChar ;
extern uint8_t S2NRx_buf[S2N_RX_BUFSIZE]  ;

extern void Ser2NetRxTask(void const*) ;
extern void Ser2NetTask(void const*) ;
extern void S2NUARTTxComplete(void) ;

#endif /* INC_SER2NETTASK_H_ */
