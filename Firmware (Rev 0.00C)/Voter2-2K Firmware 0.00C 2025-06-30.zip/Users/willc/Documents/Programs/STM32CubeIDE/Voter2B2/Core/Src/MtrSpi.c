/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the MtrSpi file.  It is in charge of the MTR2000 internal SPI      */
/* interface.  The MTR2K can send a 16-bit chunk of data at any time and if   */
/* this board wiggles OPT_IRQ*, then it will read the Voter2's 16-bits of     */
/* data.  Well, that's the theory.  This just a basic CLI test interface to   */
/* try out that theory and check out the hardware.                            */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Cmd_mtrspi - CLI to test MTR SPI interface                              */
/*  - My_MtrSpi_FinisInit - Finish intialization of SPI interface             */
/*  - HAL_SPI_TxRxCpltCallback - (weak override) SPI Tx/Rx ISR                */
/*                                                                            */
/******************************************************************************/
// TO DO:
//  - Use a dedicated timer interrupt over HAL sequencer for OPT_IRQ.

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "cmsis_os.h"

#include "Options.h"
#include "main.h"
#include "ConsoleTask.h"
#include "Settings.h"
#include "logger2rt.h"
#include "Gpio.h"
#include "Utils.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/
extern SPI_HandleTypeDef hspi2;

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
enum
{
   CMD_OOPS = 0,
   CMD_TXDATA,
   CMD_RXDATA,
   CMD_REQTX,
} MTRSPI_ENUMS ;

enum
{
   WIGGLE_IDLE = 0,
   WIGGLE_QUEUED,
   WIGGLE_ACTIVE
} WIGGLE_STATES ;

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
char* cmd_mtrspi_cmd  = "mtrspi" ;
char* cmd_mtrspi_help = "mtrspi - [txd ####|rxd|rtx]\n"
                        "         txd - Data to send when requested, then 4 hex digits\n"
                        "         rxd - Report last received data\n"
                        "         rtx - Ask MTR to request txd data\n";

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TOKENLIST MtrSpiCmds[] =
{
   {"txd",CMD_TXDATA},
   {"rxd",CMD_RXDATA},
   {"rtx",CMD_REQTX },
   {NULL   ,0       }
} ;

static uint16_t mtrspi_txbuf    = 0 ; /* Data to send to MTR2000 on request   */
static uint16_t mtrspi_rxbuf    = 0 ; /* Last received data from MTR2000      */
static uint32_t mtrspi_lastTxIo = 0 ; /* Timestamp of last MTR2000 Tx         */
static uint32_t mtrspi_lastRxIo = 0 ; /* Timestamp of last MTR2000 Rx         */

/* Our wiggler state machine */
static int OPTIRQ_WiggleState = WIGGLE_IDLE ;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void MtrSpiTxd(int,char*) ;
static void MtrSpiRxd(void) ;
static void MtrSpiRtx(void) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : Cmd_mtrspi
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command tests the MTR2000 "option" SPI interface.
*******************************************************************************/
int Cmd_mtrspi(int argc, char* argv[])
{
   int error = false ; /* Parsing error flag */
   int Token = 0     ; /* Command token      */

   /* If no arguments, say oops */
   if (1==argc)
   {
         Console_printf("No arguments, try help mtrspi.\n") ;
   }
   else /* at least one argument! */
   {
      /* See which settings command */
      Token = parse_token(MtrSpiCmds,argv[1],&error) ;

      if (error)
      {
         Console_printf("Bad parameter, try help mtrspi.\n") ;
      }
      else
      {
         switch(Token)
         {
            case CMD_TXDATA: MtrSpiTxd(argc,argv[2]) ;  break ;
            case CMD_RXDATA: MtrSpiRxd()             ;  break ;
            case CMD_REQTX : MtrSpiRtx()             ;  break ;
            default : /* Shouldn't happen */            break ;
         }
      }
   }

   return (0) ;
}

/*******************************************************************************
* Routine  : MtrSpiTxd
*   Inputs : argc - number of CLI arguments (for checking)
*          : arg2 - CLI argument #2
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This routine implements the txd option which allows the user to say what data
* goes back to the MTR when the MTR requests it.  No data is sent, it is just
* queued up so it will be ready when requested.  The rtx command tells the MTR
* to request the data
*******************************************************************************/
static void MtrSpiTxd(int argc,char* arg2)
{
   uint32_t NewVal = 0 ;
   int success = true ;

   /* Should be 3 arguments, the command, txd, and the data */
   if (3!=argc)
   {
      Console_printf("For txd the parameter is a 16-bit hex (no 0x) value.\n") ;
   }
   else
   {
      NewVal = ReadHex(arg2,4,SOLOPARAM,&success) ;
      if (!success)
      {
         Console_printf("For txd the parameter is a 16-bit hex (no 0x) value.\n") ;
      }
      else
      {
         mtrspi_txbuf = NewVal ;
         Console_printf("Value will be sent on next MTR request.\n") ;
      }
   }
}

/*******************************************************************************
* Routine  : MtrSpiRxd
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This routine displays the last received SPI data along with how long ago it
* was received.
*******************************************************************************/
static void MtrSpiRxd(void)
{
   Console_printf("Last received SPI value from the MTR: 0x%4.4x.\n",mtrspi_txbuf) ;
   Console_printf("Timestamp %d, %dms ago,\n",mtrspi_lastRxIo,HAL_GetTick()-mtrspi_lastRxIo) ;
}

/*******************************************************************************
* Routine  : MtrSpiRtx
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This routine wiggles the MTR2000's OPT-IRQ signal which should make it read
* the Voter2 Option bits (defined my the mtrspi txd command). After wiggling it
* waits up to 1 second to see if the read happens and reports the response
* time or failure if no read happens.
*******************************************************************************/
static void MtrSpiRtx(void)
{
   uint32_t Wiggle_time = 0 ;
   int i = 0 ;

   /* Wiggle the bit and note the time */
   Console_printf("Wiggling OPT_IRQ...\n") ;
   /* Generating a clean wiggling of OPT_IRQ using RTOS timers isn't working, */
   /* so instead set a semaphore whereby it will be handled by the HAL 1ms    */
   /* timer tick instead.                                                     */
   OPTIRQ_WiggleState = WIGGLE_QUEUED ;
   Wiggle_time = HAL_GetTick() ;

   /* Hang around for up to 1 second (in 10ms chunks) for the MTR2000 to read */
   mtrspi_lastTxIo = 0 ;
   while ((i++<100) && (0==mtrspi_lastTxIo)) osDelay(10) ;

   if (0==mtrspi_lastTxIo)
   {
      Console_printf("No response after 1 second, giving up.\n") ;
   }
   else
   {
      Console_printf("MTR2000 responded within %dms\n",mtrspi_lastTxIo-Wiggle_time) ;
   }
}

/*******************************************************************************
* Routine  : My_MtrSpi_FinisInit
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* CubeMX has already configued the SPI's parameters, this just sets it up for
* interrupt driven IO.  Note that after an interrupt, it needs to be re-enabled
* each time.  Ick for efficiency.
*******************************************************************************/
void My_MtrSpi_FinisInit(void)
{

   HAL_SPI_TransmitReceive_IT(&hspi2, (uint8_t*)&mtrspi_txbuf, (uint8_t *)&mtrspi_rxbuf, 1) ;

}

/*******************************************************************************
* Routine  : HAL_SPI_TxRxCpltCallback
*   Inputs : hspi - handle for the SPI interface (always hspi2)
*      IOs : None
*  Returns : Nothing
*  Globals : mtrspi_lastRxIo,mtrspi_lastTxIo - time stamps for last Rx and Tx
*          : mtrspi_rxbuf, mtrspi_txbuf - Values transmitted and received
*
* This overrides a dummy _weak version of this routine.
* The MTR2000 generates two different chip selects for a SPI read vs a SPI
* write.  OPx_CS1 is for inputs to the MTR, OPx_CS2 is for when it is writing.
* Since reads and writes share the same SPI signals, the Voter2 just ORs the
* two chip selects into the single chip select to the MCU and has an RS flip-
* flop to remember which CS was last.  That signal comes in via MTRSPI_CSID and
* is 0 for writes and 1 for reads.
*******************************************************************************/
void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
{


   /* Look at MTRSPI_CSID to know if it was a Tx or Rx transaction. */
   if (0==SPI_CSID_State())
   {
      /* A write by the MTR2000*/
      mtrspi_lastRxIo = HAL_GetTick() ;
      Logger2_IRQMsg(Logger.SpiMtr,LOG_REGIO,LOG_TIME,0x02000001,"MTR SPI Write, val received was 0x%4.4x\r\n",mtrspi_rxbuf) ;
   }
   else
   {
      /* A read by the MTR2000*/
      mtrspi_lastTxIo = HAL_GetTick() ;
      Logger2_IRQMsg(Logger.SpiMtr,LOG_REGIO,LOG_TIME,0x02000001,"MTR SPI Read, val sent was 0x%4.4x\r\n",mtrspi_txbuf) ;
   }

   /* Whatever the transaction, set up the SPI so there will be an interrupt  */
   /* for the next transaction.                                               */
   HAL_SPI_TransmitReceive_IT(hspi, (uint8_t*)&mtrspi_txbuf, (uint8_t *)&mtrspi_rxbuf, 1) ;
}

/*******************************************************************************
* Routine  : OPTIRQ_Wiggler
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : OPTIRQ_WiggleState
*
* The RTOS delay calls have a lot of variability in them--especially for a delay
* on the order of just one timer tick, so not useful.  To address this, this
* routine gets called by the HAL timer tick (accurately 1ms) where I simply
* sequence though the states every 1ms to generate a clean wiggle of the
* OPT_IRQ line.
*
* While better, I grimmace at this being called every 1ms all the time for a
* routine being used rarely if at all.  Hence making it as efficient as possible
* using fast GPIO below.  I could put a conditional in the ISR before even
* calling this routine, but not sure if that saves time.
*
* I'm only using 6 of the 24 timers in the STM32H7, so a better long term
* solution will be to use one of those for a single on-request interrupt that
* can give a pulse shorter than 1ms and not have the continuous overhead.
* Alas the GPIO pin isn't under control of a timer directly.
*******************************************************************************/
void OPTIRQ_Wiggler(void)
{
   switch (OPTIRQ_WiggleState)
   {
      case WIGGLE_IDLE  :                                                        break ;
      case WIGGLE_QUEUED: OPTIRQ_ASSERT   ; OPTIRQ_WiggleState = WIGGLE_ACTIVE ; break ;
      case WIGGLE_ACTIVE: OPTIRQ_DEASSERT ; OPTIRQ_WiggleState = WIGGLE_IDLE   ; break ;
      default           :                   OPTIRQ_WiggleState = WIGGLE_IDLE   ; break ;
   }
}
