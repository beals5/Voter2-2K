/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2025                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Codecs file.  It is in charge of uLaw and ADPCM codecs.        */
/* While the codecs are only for voting and voting is fixed at 160 sample     */
/* packet sizes, this is hopefully coded to support a variable packet size.   */
/* There isn't any way to verify this though, so user beware! :)              */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - CompressuLaw - uLaw compress a packet                                   */
/*  - DecompressuLaw - uLaw decompress a packet                               */
/*  - CompressADPCM - ADPCM compress a packet                                 */
/*  - DecompressADPCM - ADPCM decompress a packet                             */
/*                                                                            */
/******************************************************************************/
// TO DO:

/******************************************************************************/
/* Jim's notes about the ADPCM codec used:                                    */
/* Note: It would have been nicer to (1) use G.726 rather than this ancient   */
/* version of ADPCM, but G.726 was a bit too computationally complex for this */
/* hardware platform, and (2) *not* to have to transcode the tx audio into    */
/* mulaw before outputting it, but there is no room in RAM for signed linear  */
/* audio of the necessary buffer size; sigh!                                  */
/*                                                                            */
/* See my note in the comment block above ADPCM_Encode() about the quality of */
/* the ADPCM codec, I wasted most of week thinking I had a codec              */
/* implementation issue and it is just the nature of the codec.  The quality  */
/* is pretty bad, but hey, it is trying to compress 16-bit audio into 4-bit   */
/* samples and Shannon has a theory about that!  For the amount of            */
/* compressing it is doing, I guess it ain't that bad.                        */
/******************************************************************************/

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "Options.h"
#include "main.h"
#include "Settings.h"
#include "AnalogIO.h"
#include "Codecs.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/

/******************************************************************************/
/* Structures                                                                 */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static int8_t MuLawCompressTable[256] =
{
     0,0,1,1,2,2,2,2,3,3,3,3,3,3,3,3,
     4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,
     5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,
     5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,
     6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
     6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
     6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
     6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
     7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
     7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
     7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
     7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
     7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
     7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
     7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
     7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7
};

/* For Mu-Law decompression, just a simple (fast) lookup table */
static int16_t MuLawDecompressTable[256] =
{
     -32124,-31100,-30076,-29052,-28028,-27004,-25980,-24956,
     -23932,-22908,-21884,-20860,-19836,-18812,-17788,-16764,
     -15996,-15484,-14972,-14460,-13948,-13436,-12924,-12412,
     -11900,-11388,-10876,-10364, -9852, -9340, -8828, -8316,
      -7932, -7676, -7420, -7164, -6908, -6652, -6396, -6140,
      -5884, -5628, -5372, -5116, -4860, -4604, -4348, -4092,
      -3900, -3772, -3644, -3516, -3388, -3260, -3132, -3004,
      -2876, -2748, -2620, -2492, -2364, -2236, -2108, -1980,
      -1884, -1820, -1756, -1692, -1628, -1564, -1500, -1436,
      -1372, -1308, -1244, -1180, -1116, -1052,  -988,  -924,
       -876,  -844,  -812,  -780,  -748,  -716,  -684,  -652,
       -620,  -588,  -556,  -524,  -492,  -460,  -428,  -396,
       -372,  -356,  -340,  -324,  -308,  -292,  -276,  -260,
       -244,  -228,  -212,  -196,  -180,  -164,  -148,  -132,
       -120,  -112,  -104,   -96,   -88,   -80,   -72,   -64,
        -56,   -48,   -40,   -32,   -24,   -16,    -8,    -1,
      32124, 31100, 30076, 29052, 28028, 27004, 25980, 24956,
      23932, 22908, 21884, 20860, 19836, 18812, 17788, 16764,
      15996, 15484, 14972, 14460, 13948, 13436, 12924, 12412,
      11900, 11388, 10876, 10364,  9852,  9340,  8828,  8316,
       7932,  7676,  7420,  7164,  6908,  6652,  6396,  6140,
       5884,  5628,  5372,  5116,  4860,  4604,  4348,  4092,
       3900,  3772,  3644,  3516,  3388,  3260,  3132,  3004,
       2876,  2748,  2620,  2492,  2364,  2236,  2108,  1980,
       1884,  1820,  1756,  1692,  1628,  1564,  1500,  1436,
       1372,  1308,  1244,  1180,  1116,  1052,   988,   924,
        876,   844,   812,   780,   748,   716,   684,   652,
        620,   588,   556,   524,   492,   460,   428,   396,
        372,   356,   340,   324,   308,   292,   276,   260,
        244,   228,   212,   196,   180,   164,   148,   132,
        120,   112,   104,    96,    88,    80,    72,    64,
         56,    48,    40,    32,    24,    16,     8,     0
};

/* Quantizer step size lookup table for ADPCM */
static const uint16_t StepSizeTable[89]=
   {
      7,8,9,10,11,12,13,14,16,17,
      19,21,23,25,28,31,34,37,41,45,
      50,55,60,66,73,80,88,97,107,118,
      130,143,157,173,190,209,230,253,279,307,
      337,371,408,449,494,544,598,658,724,796,
      876,963,1060,1166,1282,1411,1552,1707,1878,2066,
      2272,2499,2749,3024,3327,3660,4026,4428,4871,5358,
      5894,6484,7132,7845,8630,9493,10442,11487,12635,13899,
      15289,16818,18500,20350,22385,24623,27086,29794,32767
   } ;

/* Table of index changes for ADPCM*/
const int8_t IndexTable[16]={-1,-1,-1,-1,2,4,6,8,-1,-1,-1,-1,2,4,6,8};

static int16_t enc_index      = 0 ; /* ADPCM Encoder persistent state (index) */
static int32_t enc_predsample = 0 ; /* ADPCM Encoder persistent state (sample)*/

static int16_t dec_index      = 0 ; /* ADPCM Decoder persistent state (index) */
static int32_t dec_predsample = 0 ; /* ADPCM Decoder persistent state (sample)*/

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static uint8_t LinearToMuLawSample(int16_t) ;
static uint8_t ADPCM_Encode(int32_t) ;
static int16_t ADPCM_Decode(uint8_t) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : CompressuLaw
* Gazintas : uncompressed - 160 Audio samples in 16-bit signed format
* IOs      : compressed - 160 Audio samples in 8-bit compressed format
* Returns  : Nothing
* Globals  : None
*
* This routine converts a 160-sample packet of data from 16-bit signed raw
* audio samples to 8-bit Mu-Law compressed samples.
*******************************************************************************/
void CompressuLaw(int16_t* uncompressed, uint8_t* compressed)
{
   int i = 0 ;

   for (i=0;i<APKT_SAMPLES;i++)
   {
      compressed[i] = LinearToMuLawSample(uncompressed[i]) ;
   }
}

/*******************************************************************************
* Routine  : LinearToMuLawSample
* Gazintas : sample - uncompressed 16-bit audio sample
* IOs      : None.
* Returns  : 8-bit Mu-Law compressed version of the sample
* Globals  : None
*
* This routine converts a single 16-bit raw audio sample to an 8-bit Mu-Law
* compressed sample.  Code for this came from:
* https://web.archive.org/web/20110719132013/http://hazelware.luggle.com/tutorials/mulawcompression.html
* The only changes were to stdint types and a bit of formatting.
* Still want to tweak the code to match my programming style guidelines, but
* will do it later.
*******************************************************************************/
static const int cBias = 0x84;
static const int cClip = 32635;

static uint8_t LinearToMuLawSample(int16_t sample)
{
   int32_t sign = (sample >> 8) & 0x80;
   if (sign)
          sample = (int16_t)-sample;
   if (sample > cClip)
          sample = cClip;
   sample = (int16_t)(sample + cBias);

   int32_t exponent = (int32_t)MuLawCompressTable[(sample>>7) & 0xFF];
   int32_t mantissa = (sample >> (exponent+3)) & 0x0F;
   int32_t compressedByte = ~ (sign | (exponent << 4) | mantissa);

   return (uint8_t)compressedByte;
}

/*******************************************************************************
* Routine  : DecompressuLaw
* Gazintas : compressed - Compressed buffer pointer (source)
*          : decompressed - Decomperssed buffer (destination)
* IOs      : None.
* Returns  : Nothing
* Globals  : None
*
* This routine decompresses the 160 samples from 8-bit Mu-Law to 16-bit signed
* audio samples.  Just a simple lookup table for speed.
*******************************************************************************/
void DecompressuLaw (uint8_t* compressed, int16_t* decompressed)
{
   int i = 0 ;

   for (i=0;i<APKT_SAMPLES;i++)
   {
      decompressed[i]=MuLawDecompressTable[compressed[i]] ;
   }
}

/*******************************************************************************
* Routine  : CompressADPCM
* Gazintas : indata - Uncompressed buffer pointer (source)
* IOs      : outdata - Compressed buffer (destination)
* Returns  : true if compressed data ready to send
* Globals  : None
*
* This routine compresses 160 samples of audio data using ADPCM.  It takes two
* 160 sample batches to create one 163-byte output packet.  It returns true if
* an output packet is ready for sending, false if it is still accumulating.
*
* This routine is the supervisor that handles the packet structure, the code
* doing the sample-bysample compressing below comes from ST's AN4453,
*******************************************************************************/
int CompressADPCM(int16_t* indata, uint8_t* outdata)
{
   static int     First = true ; /* Flag for first (of two) incoming packets  */
   static uint8_t *outp = NULL ; /* output buffer pointer (keep across calls) */

   int     i     = 0 ; /* Loop counter                  */
   uint8_t accum = 0 ; /* Compressed sample accumulator */

   /* If our first of a pair of incoming packets, reset the output pointer    */
   /* and put in the header (AT THE END!!!!  Very weird since it is           */
   /* initialization data), otherwise if the second incoming packet, just     */
   /* keep on adding data.                                                    */
   if (First)
   {
      outp = outdata ;
      outp[APKT_SAMPLES  ] = (enc_predsample>>8) & 0x00ff ;
      outp[APKT_SAMPLES+1] = (enc_predsample   ) & 0x00ff ;
      outp[APKT_SAMPLES+2] = enc_index                    ;
   }

   /* Now run through the 160 incoming audio samples.  Each compressed sample */
   /* is 4 bits, so shift up in the accumulator and write the byte every      */
   /* other iteration of the loop.                                            */
   for (i=0;i<APKT_SAMPLES;i++)
   {
      accum  = accum<<4 ;
      accum |= ADPCM_Encode((int32_t)(*indata++)) ;
      if(i&1) *outp++ = accum ;
   }

   /* Toggle the First flag to put two uncompressed packets into one         */
   /* compressed packet.  Since the return is *after* inverting First, the   */
   /* meaning is reversed!  Main point is return true on "second".           */
   First = !First ;
   return (First) ;
}

/*******************************************************************************
* Routine  : DecompressADPCM
* Gazintas : indata - Compressed buffer pointer (source)
* IOs      : outdata - Decomperssed buffer (destination)
* Returns  : Nothing
* Globals  : None
*
* This routine decompresses 320 samples of audio data using ADPCM.  It takes a
* 163 byte compressed packet and generates 320 16-bit audio samples from it.
*
* This routine is the supervisor that handles the packet structure, the code
* doing the sample-bysample compressing below comes from ST's AN4453,
*******************************************************************************/
void DecompressADPCM(uint8_t* indata, int16_t* outdata)
{
   int16_t tmp = 0 ; /* For some explicit casting */
   int     i   = 0 ; /* Loop counter              */

   /* Looking at the Voter1 code, the prediction value and index are at the   */
   /* *end* of the packet, not the beginning--weird given that they are       */
   /* initialization vectors!!!!                                              */
   tmp = (indata[APKT_SAMPLES] << 8) + indata[APKT_SAMPLES+1]; /* two steps for careful casting   */
   dec_predsample = tmp ;
   dec_index = indata[APKT_SAMPLES+2];

   /* After setting up the initialization vectors, there are two              */
   /* decompressed samples per compressed byte.  Go through all 160 incoming  */
   /* bytes to get 320 outgoing 16-bit audio samples.                         */
   for (i=0;i<APKT_SAMPLES;i++)
   {
      *outdata++ = ADPCM_Decode(((*indata)>>4)&0x0f) ;
      *outdata++ = ADPCM_Decode(((*indata++) )&0x0f) ;
   }
}


/*******************************************************************************
* Routines : ADPCM_Encode and ADPCM_Decode
* Gazintas : sample (encode) - the 16-bit sample in a 32-bit variable
           : code (decode) - compressed sample (4 bits) in a 16-bit variable
* IOs      : None
* Returns  : 4-bit ADPCM value (encode), 16-bit audio sample (decode)
* Globals  : enc_predsample/enc_index (encode) Compression state
*          : dec_predsample/dec_index (decode) Decompression state
*
* These are the actual ST Reference routines from AN4453 for encoding and
* decoding.  They do it one sample at a time.  The only change I've made
* (besides a little formatting and a few extra comments) is is to take the
* internal static prediction vectors and indexes out and made them local
* globals so they can be accessed or modified by their calling routines.
*
* I started off with the code from Stichting Mathematisch Centrum that Jim used,
* but it wasn't using precisely defined variable types. I was seeing weird
* issues I suspected might be related to that, so switched to this ST code.
* Alas, that wasn't the issue, but I like well defined variable types anyway,
* so sticking with the ST code.  The weirdness I was seeing was basically
* distortion I thought was due to a programming bug, but now am pretty sure it
* is just the nature of this codec.  It isn't great!  My "proof" was taking my
* test signal (a 1KHz sine wave) and running it through an ACPCM encoder on my
* computer using the same setup (8KHz sample rate and 4-bit IMA ADPCM) and I
* hear similar artifacts on the PC!  They are a bit less pronounced on the PC,
* but figure that is due to the code below admitting it is an approximation of
* the "real" ADPCM codec that needs floating point.
*******************************************************************************/
static uint8_t ADPCM_Encode(int32_t sample)
{
  uint8_t  code    = 0 ;
  uint16_t tmpstep = 0 ;
  int32_t  diff    = 0 ;
  int32_t  diffq   = 0 ;
  uint16_t step    = 0 ;

  step = StepSizeTable[enc_index];

  /* 2. compute diff and record sign and absolute value */
  diff = sample-enc_predsample;
  if (diff < 0)
  {
    code=8;
    diff = -diff;
  }

  /* 3. quantize the diff into ADPCM code */
  /* 4. inverse quantize the code into a predicted diff */
  tmpstep = step;
  diffq = (step >> 3);

  if (diff >= tmpstep)
  {
    code |= 0x04;
    diff -= tmpstep;
    diffq += step;
  }

  tmpstep = tmpstep >> 1;

  if (diff >= tmpstep)
  {
    code |= 0x02;
    diff -= tmpstep;
    diffq+=(step >> 1);
  }

  tmpstep = tmpstep >> 1;

  if (diff >= tmpstep)
  {
    code |=0x01;
    diffq+=(step >> 2);
  }

  /* 5. fixed predictor to get new predicted sample*/
  if (code & 8)
  {
    enc_predsample -= diffq;
  }
  else
  {
    enc_predsample += diffq;
  }

  /* check for overflow*/
  if (enc_predsample > 32767)
  {
    enc_predsample = 32767;
  }
  else if (enc_predsample < -32768)
  {
    enc_predsample = -32768;
  }

  /* 6. find new stepsize index */
  enc_index += IndexTable[code];
  /* check for overflow*/
  if (enc_index <0)
  {
    enc_index = 0;
  }
  else if (enc_index > 88)
  {
    enc_index = 88;
  }

  /* 8. return new ADPCM code*/
  return (code & 0x0f);
}

static int16_t ADPCM_Decode(uint8_t code)
{
  uint16_t step  = 0 ;
  int32_t  diffq = 0 ;

  step = StepSizeTable[dec_index];

  /* 2. inverse code into diff */
  diffq = step>> 3;
  if (code&4)
  {
    diffq += step;
  }

  if (code&2)
  {
    diffq += step>>1;
  }

  if (code&1)
  {
    diffq += step>>2;
  }

  /* 3. add diff to predicted sample*/
  if (code&8)
  {
    dec_predsample -= diffq;
  }
  else
  {
    dec_predsample += diffq;
  }

  /* check for overflow*/
  if (dec_predsample > 32767)
  {
    dec_predsample = 32767;
  }
  else if (dec_predsample < -32768)
  {
    dec_predsample = -32768;
  }

  /* 4. find new quantizer step size */
  dec_index += IndexTable [code];
  /* check for overflow*/
  if (dec_index < 0)
  {
    dec_index = 0;
  }
  if (dec_index > 88)
  {
    dec_index = 88;
  }

  /* 5. save predict sample and index for next iteration */
  /* done! static variables */

  /* 6. return new speech sample*/
  return ((int16_t)dec_predsample);
}

#if 0
   /* I needed compressed values for a 1KHz sinewave at Volume levels 10-0 in */
   /* the compressed domain.  Plunking them here then creating tables was the */
   /* easiest way.  Now I'm doing all the audio in the uncompressed domain    */
   /* since there are two codecs.  I'm keeping this because it was a pain to  */
   /* create and I'm using a LOT of memory for audio buffers.  I may need to  */
   /* buffer in the compressed domain later to save space. This may mean      */
   /* transcoding ADPCM to uLaw.  Voter1 does this.                           */
   /* If needed again, plunk this into Rx_EnqPacket() right before the call   */
   /* to CompressuLaw()                                                       */
   ppbuf1[ 0] =      0 ;
   ppbuf1[ 1] =  23170 ; /* Vol = 10 */
   ppbuf1[ 2] =  32767 ;
   ppbuf1[ 3] = -23170 ;
   ppbuf1[ 4] = -32768 ;
   ppbuf1[ 5] =  11585 ; /* Vol = 9 */
   ppbuf1[ 6] =  16384 ;
   ppbuf1[ 7] = -11585 ;
   ppbuf1[ 8] = -16384 ;
   ppbuf1[ 9] =   5793 ; /* Vol = 8 */
   ppbuf1[10] =   8192 ;
   ppbuf1[11] =  -5793 ;
   ppbuf1[12] =  -8192 ;
   ppbuf1[13] =   2897 ; /* Vol = 7 */
   ppbuf1[14] =   4096 ;
   ppbuf1[15] =  -2897 ;
   ppbuf1[16] =  -4096 ;
   ppbuf1[17] =   1449 ; /* Vol = 6 */
   ppbuf1[18] =   2048 ;
   ppbuf1[19] =  -1449 ;
   ppbuf1[20] =  -2048 ;
   ppbuf1[21] =    725 ; /* Vol = 5 */
   ppbuf1[22] =   1024 ;
   ppbuf1[23] =   -725 ;
   ppbuf1[24] =  -1024 ;
   ppbuf1[25] =    363 ; /* Vol = 4 */
   ppbuf1[26] =    512 ;
   ppbuf1[27] =   -363 ;
   ppbuf1[28] =   -512 ;
   ppbuf1[29] =    182 ; /* Vol = 3 */
   ppbuf1[30] =    256 ;
   ppbuf1[31] =   -182 ;
   ppbuf1[32] =   -256 ;
   ppbuf1[33] =     91 ; /* Vol = 2 */
   ppbuf1[34] =    128 ;
   ppbuf1[35] =    -91 ;
   ppbuf1[36] =   -128 ;
   ppbuf1[37] =     46 ; /* Vol = 1 */
   ppbuf1[38] =     64 ;
   ppbuf1[39] =    -46 ;
   ppbuf1[40] =    -64 ; /* Vol is just all 8 being ppbuf1[0] */
#endif
