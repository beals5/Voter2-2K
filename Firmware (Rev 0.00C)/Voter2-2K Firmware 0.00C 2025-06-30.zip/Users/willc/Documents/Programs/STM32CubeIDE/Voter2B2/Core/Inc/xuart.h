#ifndef INC_XUART_H_
#define INC_XUART_H_

extern char* cmd_xuart_cmd ;
extern char* cmd_xuart_help ;

extern int  Cmd_xuart(int, char**) ;

/* ISR callbacks */
extern void XUARTTxComplete(void) ;
extern void XUARTRxComplete(void) ;

#endif /* INC_XUART_H_ */
