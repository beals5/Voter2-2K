################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

ELF_SRCS := 
OBJ_SRCS := 
S_SRCS := 
C_SRCS := 
S_UPPER_SRCS := 
O_SRCS := 
CYCLO_FILES := 
SIZE_OUTPUT := 
OBJDUMP_LIST := 
SU_FILES := 
EXECUTABLES := 
OBJS := 
MAP_FILES := 
S_DEPS := 
OBJCOPY_SREC := 
S_UPPER_DEPS := 
C_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
Core/Src \
Core/Src/LocalDummy \
Core/Src/LocalVoter \
Core/Startup \
Drivers/STM32H7xx_HAL_Driver/Src \
LWIP/App \
LWIP/Target \
Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS \
Middlewares/Third_Party/FreeRTOS/Source \
Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F \
Middlewares/Third_Party/FreeRTOS/Source/portable/MemMang \
Middlewares/Third_Party/LwIP/src/api \
Middlewares/Third_Party/LwIP/src/apps/mqtt \
Middlewares/Third_Party/LwIP/src/core \
Middlewares/Third_Party/LwIP/src/core/ipv4 \
Middlewares/Third_Party/LwIP/src/core/ipv6 \
Middlewares/Third_Party/LwIP/src/netif \
Middlewares/Third_Party/LwIP/src/netif/ppp \
Middlewares/Third_Party/LwIP/system/OS \

