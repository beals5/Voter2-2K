/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Update file.  It is the UI and functional part of the firmware */
/* updater--or at least it will be.  For now it is just a series of erase/    */
/* write/read tests for the update flash.                                     */
/******************************************************************************/
/* Here is how memory is mapped from build address space to SPI (download     */
/* flash) address pace to QSPI (execuable flash) address space back to build  */
/* address space.  Note that for downloads using the debugger, the SPI step   */
/* is bypassed.                                                               */
/*                                                                            */
/* Executable   QSPI        SPI                                               */
/* Image        Image       Image                                             */
/* ==========   =========== =============                                     */
/* 0x00000000   0x00000000  0x00000000                                        */
/* ITCM (64K)   ITCM (64K)  ITCM (64K)                                        */
/* 0x0000ffff   0x0000ffff  0x0000ffff                                        */
/*                                                                            */
/* 0x08000000   N/A, ST     0x001e0000                                        */
/* Int Flash    Internal    ST internal                                       */
/* (128K)       Flash       flash image                                       */
/* 0x0801ffff               0x001fffff                                        */
/*                                                                            */
/* 0x09010000   0x00010000  0x00010000                                        */
/* QSPI Flash   QSPI Flash  QSPI Flash                                        */
/* (4M-64K)     (4M-192K)   (4M-192K)                                         */
/* 0x091dffff   0x091dffff  0x091dffff                                        */
/*                                                                            */
/* Put into text, the first 64K of both the SPI and QSPI flash is where the   */
/* ITCM image goes.  The last 128K of the SPI flash is where the STM32's      */
/* internal flash image goes.  The last 128K of the QSPI flash is effectively */
/* unusable as it can't get loaded by the SPI flash.                          */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Cmd_update - Update CLI command (just starts a test for now)            */
/*                                                                            */
/******************************************************************************/
// TO DO:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "lwip.h"
#include "lwip/api.h"

#include "string.h"
#include "Options.h"
#include "main.h"
#include "ConsoleTask.h"
#include "Settings.h"
#include "SPINOR.h"
#include "Utils.h"
#include "Setshow.h"
#include "Tftp.h"
#include "logger2rt.h"
#include "Utils.h"
#include "SPINOR.h"
#include "RTC.h"
#include "Timers.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
#define VERSTRLEN     80 /* Server Firmware data string length     */
#define FNAMERLEN     40 /* Server Firmware filename string length */
#define NTOKENS        5 /* max argv tokens                        */
#define MAXSRECLINE   80 /* Max S-Record line length (by spec!)    */
#define SPIBUFLEN    256 /* SPI DMA Buffer length                  */
#define REPORT_DELTA 250 /* TFT Report time delta (1000 normally)  */

enum
{
   CMD_CHECK = 1,
   CMD_DOWNLOAD,
   CMD_VERIFY,
   CMD_DUMP,
   CMD_ERASE,
   CMD_PROGRAM,
   CMD_XMODEM
} UPDCOMMANDS ;

typedef enum
{
   PSP_RESET = 0,
   PSP_PROGRAM,
   PSP_VERIFY
} PSP_STATES ;

#define XMRBUFLEN 133 /* Rx buffer for a 128-byte record */
#define XMTBUFLEN   3 /* Tx buffer for an ACK */
#define XMSTART_TRIES 10
#define XMSTART_TIMEOUT 10000
#define XMXFER_TIMEOUT 1000

#define ANSI_SOH 0x01
#define ANSI_EOT 0x04
#define ANSI_ACK 0x06
#define ANSI_NAK 0x15
#define ANSI_CAN 0x18
#define ANSI_EOF 0x1A
#define XMDM_CRC 0x43

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/
typedef struct
{
   int srec_dstidx ;
   int LineCount ;
   int BytesProcessed ;
   int errors ;
} SREC_STATS ;


/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
char* cmd_update_cmd   = "update" ;
char* cmd_update_cmdsc = "upd"    ;
char* cmd_update_help  = "update - [check|download|verify|program|xmodem|erase|dump] Software update\n"
                         "         check (chk) - check for newer version\n"
                         "         download (dld) - download latest version\n"
                         "         xmodem (xmd) - Download using XMODEM/CRC\n"
                         "         verify (ver) - Verify download\n"
                         "         program (prg) -  Program download to executable flash\n"
                         "         erase (era) - Erase download flash\n"
                         "         dump (dmp)[addr] [len] - Dump download flash contents (hex params)\n"
                         "      NOTE: for download and verify you can specify an optional filename.\n"
                         "      This will override any filename from the check command.\n" ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TOKENLIST UpdCmds[] =
{
   {"check"    ,"chk",CMD_CHECK    },
   {"download" ,"dld",CMD_DOWNLOAD },
   {"verify"   ,"ver",CMD_VERIFY   },
   {"dump"     ,"dmp",CMD_DUMP     },
   {"erase"    ,"era",CMD_ERASE    },
   {"program"  ,"prg",CMD_PROGRAM  },
   {"xmodem"   ,"xmd",CMD_XMODEM   },
   {NULL       ,NULL ,0            }
} ;

static char DownloadFname[FNAMERLEN] = {0} ;
static uint8_t SpiBuf[SPIBUFLEN] IN_DMADD2 = {0} ;
static int good_download = false ;

const uint16_t xmodem_crc16_table[256] = {
   0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50A5, 0x60C6, 0x70E7,
   0x8108, 0x9129, 0xA14A, 0xB16B, 0xC18C, 0xD1AD, 0xE1CE, 0xF1EF,
   0x1231, 0x0210, 0x3273, 0x2252, 0x52B5, 0x4294, 0x72F7, 0x62D6,
   0x9339, 0x8318, 0xB37B, 0xA35A, 0xD3BD, 0xC39C, 0xF3FF, 0xE3DE,
   0x2462, 0x3443, 0x0420, 0x1401, 0x64E6, 0x74C7, 0x44A4, 0x5485,
   0xA56A, 0xB54B, 0x8528, 0x9509, 0xE5EE, 0xF5CF, 0xC5AC, 0xD58D,
   0x3653, 0x2672, 0x1611, 0x0630, 0x76D7, 0x66F6, 0x5695, 0x46B4,
   0xB75B, 0xA77A, 0x9719, 0x8738, 0xF7DF, 0xE7FE, 0xD79D, 0xC7BC,
   0x48C4, 0x58E5, 0x6886, 0x78A7, 0x0840, 0x1861, 0x2802, 0x3823,
   0xC9CC, 0xD9ED, 0xE98E, 0xF9AF, 0x8948, 0x9969, 0xA90A, 0xB92B,
   0x5AF5, 0x4AD4, 0x7AB7, 0x6A96, 0x1A71, 0x0A50, 0x3A33, 0x2A12,
   0xDBFD, 0xCBDC, 0xFBBF, 0xEB9E, 0x9B79, 0x8B58, 0xBB3B, 0xAB1A,
   0x6CA6, 0x7C87, 0x4CE4, 0x5CC5, 0x2C22, 0x3C03, 0x0C60, 0x1C41,
   0xEDAE, 0xFD8F, 0xCDEC, 0xDDCD, 0xAD2A, 0xBD0B, 0x8D68, 0x9D49,
   0x7E97, 0x6EB6, 0x5ED5, 0x4EF4, 0x3E13, 0x2E32, 0x1E51, 0x0E70,
   0xFF9F, 0xEFBE, 0xDFDD, 0xCFFC, 0xBF1B, 0xAF3A, 0x9F59, 0x8F78,
   0x9188, 0x81A9, 0xB1CA, 0xA1EB, 0xD10C, 0xC12D, 0xF14E, 0xE16F,
   0x1080, 0x00A1, 0x30C2, 0x20E3, 0x5004, 0x4025, 0x7046, 0x6067,
   0x83B9, 0x9398, 0xA3FB, 0xB3DA, 0xC33D, 0xD31C, 0xE37F, 0xF35E,
   0x02B1, 0x1290, 0x22F3, 0x32D2, 0x4235, 0x5214, 0x6277, 0x7256,
   0xB5EA, 0xA5CB, 0x95A8, 0x8589, 0xF56E, 0xE54F, 0xD52C, 0xC50D,
   0x34E2, 0x24C3, 0x14A0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
   0xA7DB, 0xB7FA, 0x8799, 0x97B8, 0xE75F, 0xF77E, 0xC71D, 0xD73C,
   0x26D3, 0x36F2, 0x0691, 0x16B0, 0x6657, 0x7676, 0x4615, 0x5634,
   0xD94C, 0xC96D, 0xF90E, 0xE92F, 0x99C8, 0x89E9, 0xB98A, 0xA9AB,
   0x5844, 0x4865, 0x7806, 0x6827, 0x18C0, 0x08E1, 0x3882, 0x28A3,
   0xCB7D, 0xDB5C, 0xEB3F, 0xFB1E, 0x8BF9, 0x9BD8, 0xABBB, 0xBB9A,
   0x4A75, 0x5A54, 0x6A37, 0x7A16, 0x0AF1, 0x1AD0, 0x2AB3, 0x3A92,
   0xFD2E, 0xED0F, 0xDD6C, 0xCD4D, 0xBDAA, 0xAD8B, 0x9DE8, 0x8DC9,
   0x7C26, 0x6C07, 0x5C64, 0x4C45, 0x3CA2, 0x2C83, 0x1CE0, 0x0CC1,
   0xEF1F, 0xFF3E, 0xCF5D, 0xDF7C, 0xAF9B, 0xBFBA, 0x8FD9, 0x9FF8,
   0x6E17, 0x7E36, 0x4E55, 0x5E74, 0x2E93, 0x3EB2, 0x0ED1, 0x1EF0
};
/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void Update_Check(void) ;
static void Update_DownVer(int,char*) ;
static void Update_Dump(char*,char*) ;
static void Update_Erase(void) ;
static void Update_Program(void) ;
static void Update_Xmodem(void) ;
static uint16_t xmodem_crc(const uint8_t*,int) ;

static int  GetTextLine(char*,int*,int,int,char*,int*) ;
static int  ParseSrecLine(char*,int*,uint32_t*,int*,uint8_t*) ;
static void ProcessSrecPackets(uint8_t*,int,int,int,SREC_STATS*) ;

/* Static here, but gets passed as a parameter */
static void SpinnyThing(void) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : Cmd_update
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command manages the software update process.  It is TFTP-based, the IP
* address of the TFTP server is a set command.
*
* With an argument of 'check', we download the file "PROJECTNAME.txt" (where
* PROJECTNAME is the #define in Options.h) from the TFTP server and that will
* have the version and filename of the latest software version.  That will be
* reported.
*
* With an argument of download, we download the filename noted in the check
* command into the download flash and verify its integrity.
*
* With an argument of program we program the XIP flash and STM32 internal flash
* with the verified image in the download flash.  We have to reboot into a
* download mode to do this, then boot again into the new code.
*******************************************************************************/
int Cmd_update (int argc, char* argv[])
{
   int error   = false ; /* Parsing error flag   */
   int command = 0     ; /* Command token        */
   char* fname = NULL  ; /* Default filename ptr */

   /* Need at least one argument, the update type! */
   error = (argc<2) ;
   stolower(argv[1]) ; /* To lower case first (NULL checked) */
   if (!error) command = parse_token(UpdCmds,argv[1],&error) ;

   /* Make sure we have the right numbers of parameters */
   error |= ((CMD_CHECK   ==command) && (argc!=2)) ;
   error |= ((CMD_DOWNLOAD==command) && (argc> 3)) ; /* can be 2 or 3 */
   error |= ((CMD_VERIFY  ==command) && (argc> 3)) ; /* can be 2 or 3 */
   error |= ((CMD_DUMP    ==command) && (argc!=4)) ;
   error |= ((CMD_ERASE   ==command) && (argc!=2)) ;
   error |= ((CMD_PROGRAM ==command) && (argc!=2)) ;

   /* For update download/verify, a filename is optional, handle that.  Most  */
   /* importantly, fname needs to be NULL if no optional filename.            */
   if (argc==3) fname = argv[2] ;

   if (error)
   {
      Console_printf("First parameter must be check, download, xmodem, verify, dump, or program.\n") ;
      Console_printf("For download/verify, you can provide an optional override filename.\n") ;
      Console_printf("For dump, provide a hex starting address and length.\n") ;
   }
   else
   {
      /* Go run the appropriate command! */
      switch (command)
      {
         case CMD_CHECK   : Update_Check()                    ; break ;
         case CMD_DOWNLOAD: Update_DownVer(PSP_PROGRAM,fname) ; break ;
         case CMD_VERIFY  : Update_DownVer(PSP_VERIFY,fname)  ; break ;
         case CMD_DUMP    : Update_Dump(argv[2],argv[3])      ; break ;
         case CMD_ERASE   : Update_Erase()                    ; break ;
         case CMD_PROGRAM : Update_Program()                  ; break ;
         case CMD_XMODEM  : Update_Xmodem()                   ; break ;
         default          :                                     break ;
      }
   }
   return (0) ;
}

/*******************************************************************************
* Routine  : Update_Check
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : DownloadFname
*
* This routine executes the check command, downloading the PROJECTNAME.txt file
* from the TFTP server and reporting the latest version available for download.
*******************************************************************************/
static void Update_Check(void)
{
   TFTP_CONTEXT Context       = {0} ; /* TFTP Session context    */
   char  fname[FNAMELEN]      = {0} ; /* Project filename        */
   int   bytes                =  0  ; /* Byte counter            */
   int   My_argc              =  0  ; /* My locally parsed argc  */
   char* My_argv[NTOKENS]     = {0} ; /* My locally parsed argvs */

   /* "Delete" any previously stored filename in case this read fails.        */
   memset(DownloadFname,0,FNAMERLEN) ;

   /* The file we want is the project name (PROJECTNAME #define).txt */
   strcpy(fname,PROJECTNAME) ;
   strcat(fname,".txt") ;

   /* Contact the TFTP Server... */
   ShowIP("Contacting TFTP server at",Settings.TFTP_Addr) ;

   TFTP_Init(Settings.TFTP_Addr,&Context) ;
   TFTP_SendRWRQ(fname,TFTP_RRQ,TFTP_MODE_ASCII,&Context) ;
   /* No errors even possible yet! Keep plunking along */
   bytes = TFTP_GetData(&Context) ; /* Get the version string */
   Show_TFTP_Err(&Context) ; /* Prints error if one happened */

   /* If no error and <512 byte response, all good, send Ack. */
   if ((!Context.Error) && (512!=bytes)) TFTP_SendAck(&Context) ;

   /* If 512 bytes (or more), not expected, send back an error to the server  */
   if (512==bytes)
   {
      Context.Error = TFTPERR_BADLEN ;
      TFTP_SendErr(&Context) ;
   }

   /* If we got through all that without any errors, print out the version    */
   /* string we got.                                                          */
   if (!Context.Error)
   {
      //strncpy(VerString,(char*)TFTP_Buf+4,VERSTRLEN) ;
      //Console_printf("Version on server: %s\n",VerString) ;

      /* The filename is the 3rd parameter in the line, so use my CLI line    */
      /* parser to pick it out and save it in case the user wants to download */
      /* it.                                                                  */
      ParseLine((char*)TFTP_Buf+4,&My_argc,My_argv) ;
      strncpy(DownloadFname,My_argv[2],FNAMERLEN) ;
      Console_printf("Running version: %s %s\n",PROJECTREV,PROJECTDATE) ;
      Console_printf(" Server version: %s %s\n",My_argv[0],My_argv[1]) ;
      Console_printf(" Server    File: %s\n",DownloadFname) ;
   }
   else
   {
      Console_printf("Unable to obtain version from server.\n") ;
      memset(DownloadFname,0,FNAMERLEN) ;
   }

   /* All done, shut down the port. */
   TFTP_Terminate(&Context) ;
}

/*******************************************************************************
* Routine  : Update_DownVer
*   Inputs : mode - DLD_DOWNLOAD or DLD_VERIFY
*          : fname - Optional override filename.  NULL to use default
*      IOs : None
*  Returns : Nothing
*  Globals : DownloadFname
*
* This routine downloads the Motorola S-Record file identified by the update
* check command and either programs it into the download flash or verifies that
* the image in flash matches the downloaded S-Record data.
* See address mapping in the file header.
*******************************************************************************/
static void Update_DownVer(int mode,char* ufname)
{
   TFTP_CONTEXT Context            = {0}   ; /* TFTP Session context          */
   SREC_STATS   Stats              = {0}   ; /* S-Recrod parsing stats        */
   int      bytes                  =  0    ; /* Download byte counter         */
   int      SectorCount            =  0    ; /* TFTP Sector counter           */
   uint32_t errors                 =  0    ; /* Verify errors accumulator     */
   uint32_t StartTime              =  0    ; /* Programming start time        */
   uint32_t ReportTime             =  0    ; /* Programming Report time       */

   /* if the user provided an override filename, copy it */
   if (NULL != ufname) strntcpy(DownloadFname,ufname,FNAMERLEN) ;

   /* Make sure we have a filename first */
   if (0==DownloadFname[0])
   {
      Console_printf("Please enter 'update check' first to check the version on server.\n") ;
   }
   else
   {
      /* If download mode, first erase the download flash */
      if (PSP_PROGRAM==mode)
      {
         Console_printf("Erasing download flash, this can take up to %d seconds...\n",(SPINOR_MX25L3233==SPINOR_Type)?30:210) ;
         //Console_printf("JKLOL, debugging, so not doing it\n") ;
         SpiNor_erase(ERASE_ALL,0,SpinnyThing) ;
      }

      /* Contact the TFTP Server... */
      ShowIP("\rContacting TFTP server at",Settings.TFTP_Addr) ;

      TFTP_Init(Settings.TFTP_Addr,&Context) ;
      TFTP_SendRWRQ(DownloadFname,TFTP_RRQ,TFTP_MODE_ASCII,&Context) ;
      /* No errors even possible yet! Keep plunking along */
      StartTime = HAL_GetTick() ;
      ReportTime = StartTime+REPORT_DELTA ;

      /* Reset our Packet processor state */
      ProcessSrecPackets(NULL,512,PSP_RESET,false,&Stats) ;

      /* OK, start reading data via TFTP parsing S-Records! */
      do
      {
         bytes = TFTP_GetData(&Context) ; /* Get a packet of data */
         SectorCount++ ;
         if (!Context.Error) TFTP_SendAck(&Context) ;

         if ((!Context.Error) && (TFTP_DUP!=bytes))
         {
            ProcessSrecPackets(TFTP_Buf+4,bytes,PSP_PROGRAM,(bytes!=512),&Stats) ;

            /* Report progress every quarter second or so */
            if (HAL_GetTick()>ReportTime)
            {
               Console_printf("%d bytes processed\r",Stats.BytesProcessed) ;
               ReportTime += REPORT_DELTA ;
            }
        }
      } while (((512==bytes) || (TFTP_DUP==bytes)) && (!Context.Error)) ; /* until error or EOF */
   }

   if (!Context.Error)
   {
      Console_printf("\nDownload complete, %d bytes processed (%d%% of flash) in %d seconds\n",
         Stats.BytesProcessed,Stats.BytesProcessed*100/((SPINOR_MX25L3233==SPINOR_Type)?4194304:33554432),
         (HAL_GetTick()-StartTime)/1000) ;
      good_download = true ;

      /* Even if no TFTP errors, still report any verify errors if there were any */
      if (PSP_VERIFY==mode)
      {
         /* But do highlight if errors! */
         if (0!=errors) Console_printf("\n **** ") ;
         Console_printf("%d flash programming errors\n",errors) ;
         if (errors>0) good_download = false ;
      }

      /* If download mode, remind them to program! */
      if (PSP_PROGRAM==mode)
      {
         Console_printf("\nTo program the image you just downloaded into executable flash,\n"
                        "enter 'update program' next.\n") ;
      }
   }
   else
   {
      Console_printf("\n") ;
      Show_TFTP_Err(&Context) ;
      Console_printf("Errors downloading the new image.\n") ;
      Console_printf("Failed at line %d in sector %d.\n",Stats.LineCount,SectorCount) ;
      good_download = false ;
   }

   /* All done, shut down the port. */
   TFTP_Terminate(&Context) ;
}

/*******************************************************************************
* Routine  : Update_Dump
*   Inputs : taddr - starting address (ASCII hex)
*          : tlen - Number of bytes to dump  (ASCII hex)
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This routine dumps a range of memory from the SPI download flash.
*******************************************************************************/
static void Update_Dump(char* taddr, char* tlen)
{
   uint32_t saddr   = 0    ; /* Dump starting address */
   uint32_t len     = 0    ; /* Dump length           */
   uint32_t i       = 0    ; /* General counter       */
   uint32_t j       = 0    ; /* General counter       */
   int      success = true ; /* error counter         */

   /* parse the starting address and length */
   saddr = ReadHexVar(taddr,&success) ;
   len   = ReadHexVar(tlen ,&success) ;

   /* Print 16 bytes at a time in ASCII hex and ASCII (if printable) */
   if (success)
   {
      for (i=0;i<len;i+=16)
      {
         Console_printf("%8.8x: ",saddr+i) ;
         SpiNor_read(SpiBuf,saddr+i,16) ;
         for (j=0;j<16;j++)
         {
            Console_printf("%2.2x ",SpiBuf[j]) ;
         }
         Console_printf("| ") ;

         for (j=0;j<16;j++)
         {
            Console_printf("%c",isgraph(SpiBuf[j])?SpiBuf[j]:'.') ;
         }
         Console_printf("\n") ;
      }
   }
   else
   {
      Console_printf("Address/length parameter error") ;
   }
}

/*******************************************************************************
* Routine  : Update_Erase
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This routine erases the download flash.  It gets erased anyways as part of
* the download command too, so this is mainly for debugging.
*******************************************************************************/
static void Update_Erase(void)
{
   uint32_t MaxAddr = 0 ; /* Flash ending address         */
   uint32_t idx     = 0 ; /* Block check starting address */
   uint32_t percent = 0 ; /* Percent done                 */
   uint32_t i       = 0 ; /* General counter              */
   uint32_t errors  = 0 ; /* Error counter                */

   Console_printf("Erasing download flash, this can take up to %d seconds...\n",(SPINOR_MX25L3233==SPINOR_Type)?30:210) ;
   SpiNor_erase(ERASE_ALL,0,SpinnyThing) ;

   /* Max address depends on SPINOR attached */
   MaxAddr = (SPINOR_MX25L3233==SPINOR_Type)?4194304:33554432 ;

   Console_printf("Verifying erase...\n") ;
   /* Read in chunks of data and verify all 0sff's */
   for (idx=0;idx<MaxAddr;idx+=SPIBUFLEN)
   {
      SpiNor_read(SpiBuf,idx,SPIBUFLEN) ;
      for (i=0;i<SPIBUFLEN;i++) if (SpiBuf[i]!=0xff) errors++ ;
      if (idx>=percent*MaxAddr/100)
      {
         Console_printf("%2d%%...\r",percent) ;
         percent += 10 ;
      }
   }

   Console_printf("100%%..\n") ;
   Console_printf("Verification complete, %d errors.\n",errors) ;
   good_download = false ;

}

/*******************************************************************************
* Routine  : Update_Program
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This routine fires of the programming sequence to program the STM32 internal
* flash and QSPI flash with the image in the SPI download flash.  No real work
* here, I just program the magic number into the RTCMs non-volatile memory and
* initiate a reboot.  The downloader will recognize the magic number on reboot
* and do the update.  Or at least it will when I get it working! :)
*******************************************************************************/
static void Update_Program(void)
{
   if (!good_download)
   {
      Console_printf("No good image in download flash.\n") ;
   }
   else
   {
      Console_printf("\n\nProgramming executable flash.  This involves two reboots.\n") ;
      Console_printf("The process can take up to 90 seconds.\n") ;
      Console_printf("The heartbeat LED reverse-blinks (mostly on) during this process.\n") ;
      Console_printf("Logging info is available on the debug ports UART pins.\n") ;
      HAL_Delay(200) ; /* Time for the above text to go out... */
      RTC_Bootloader_Enable(true) ;
      RebootNow() ;
   }
}

/*******************************************************************************
* Routine  : GetTextLine
*   Inputs : source - source data (512-byte chunks)
*          : srclen - Bytes in source data
*          : LastPacket - Last Packet flag
*      IOs : srcidx - Index into source data for copying (gets updated)
*          : dest - The parsed out line
*          : dstidx - index into the destination (gets updated)
*  Returns : True if a line is ready, false if not yet.
*  Globals : None
*
* This routine copies a full line of text at a time from the source buffer that
* is fixed size and could contain multiple (or even fractional) lines in it.
* If the copying gets to the end of the source buffer without reaching the end
* of the line it returns a false expecting to be called back again with a new
* buffers worth of data.
* The end of the line can be any combination of CRs and LFs.
* The line is terminated by an EOS, the CRs and LFs are not copied.
*******************************************************************************/
static int GetTextLine(char* source, int* srcidx, int srclen, int LastPacket,char* dest, int* dstidx)
{
   static int LastWasCrLf   = false ; /* For noting paired CR/LFs  */
   int        LineReady     = false ; /* Flag to say line is ready */
   int        HaveSomething = false ; /* Have parsed some data     */

   /* Copying stops if we get to the end of either buffer or a line of text   */
   while ((*srcidx<srclen) && (*dstidx<MAXSRECLINE) && !LineReady)
   {
      /* If printable ASCII copy it over */
      if ((source[*srcidx]>=' ') && (source[*srcidx]<='`'))
      {
         dest[*dstidx] = source[*srcidx] ;
         (*srcidx)++ ;
         (*dstidx)++ ;
         LastWasCrLf = false ;
         HaveSomething = true ;
      }
      /* If a CR/LF, terminate the destination string and if it was the first */
      /* CR/LF note that the destination line is ready to be parsed.          */
      else if (('\r'==source[*srcidx]) || ('\n'==source[*srcidx]))
      {
         (*srcidx)++ ;
         if (!LastWasCrLf) LineReady = true ;
         LastWasCrLf = true ;
      }
      else /* anything else, ignore it */
      {
         (*srcidx)++ ;
      }
   }

   /* If we got to the end of the file and we have some source line material  */
   /* without a CR/LF at the end, make it legit.                              */
   if ((*srcidx==srclen) && LastPacket && HaveSomething) LineReady = true ;

   return (LineReady) ;
}

/*******************************************************************************
* Routine  : ParseSrecLine
*   Inputs : SrecLine - Line of text that should be an S-Record
*      IOs : SrecType - S-Record type (0,3,7 allowed)
*          : SrecAddr - Address of parsed S-Record data
*          : NumBytes  - Number of data bytes in S-Record data
*          : SrecBin - Data of parsed S-Record data
*          :
*  Returns : error state
*  Globals : None (yet)
*
* This routine parses out an S-Record line of text.  Supported S-Record types
* are 0 (header), 3 (32-bit addressed data) and 7 (32-bit terminator). I don't
* think I need to support type 5 (counter).
* Of note, I just have one error code, BADSREC.  Knowing the exact "badness" is
* only handy for initial debugging.  For actual use, just care if its good or
* bad only.  Details don't matter.
*******************************************************************************/
static int ParseSrecLine(char* SrecLine, int* SrecType, uint32_t* SrecAddr,int* NumBytes,uint8_t* SrecBin)
{
   int      SrecLen                =  0   ; /* S-Record length       */
   uint8_t  SrecCheck              =  0   ; /* S-Record Checksum     */
   int      err                    =  0   ; /* Overall error flag    */
   int      success                = true ; /* Hex parser result     */
   int      AddrLen                =  0   ; /* Address field length  */
   int      i                      =  0   ; /* General counter       */

   /* Basic checks first, minimum line length and begins with an S */
   if ((strlen(SrecLine)<14) || (SrecLine[0]!='S')) err = TFTPERR_BADSREC ;

   /* Get the S-Record type, only legit types are 0, 3, and 7.  From that,    */
   /* remember the address length.                                            */
   if (!err)
   {
      *SrecType = SrecLine[1] ;
      switch (*SrecType)
      {
         case '0': AddrLen = 4           ; break ;
         case '3': AddrLen = 8           ; break ;
         case '7': AddrLen = 8           ; break ;
         default : err = TFTPERR_BADSREC ; break ;
      }
   }

   /* Get the bytes in the S-Record and make sure the line length matches.    */
   /* Also now I know the number of data bytes to expect.                     */
   if (!err)
   {
      SrecLen = ReadHex(SrecLine+2,2,JUSTDIGITS,&success) ;
      if (!success) err = TFTPERR_BADSREC ;
      if (strlen(SrecLine)!=SrecLen*2+4) err = TFTPERR_BADSREC ;
      *NumBytes = SrecLen-AddrLen/2-1 ;
      SrecCheck = SrecLen ;
   }

   /* Get the Address */
   if (!err)
   {
      *SrecAddr = ReadHex(SrecLine+4,AddrLen,JUSTDIGITS,&success) ;
      for (i=0;i<AddrLen/2;i++) SrecCheck += (*SrecAddr>>(i*8))&0xff ;
      if (!success) err = TFTPERR_BADSREC ;
   }

   /* If we got this far without errors, we know the line is already the      */
   /* right length, so go read in the data!                                   */
   if (!err)
   {
      for (i=0;i<*NumBytes+1;i++) /* include the checksum */
      {
         SrecBin[i] = ReadHex(SrecLine+4+AddrLen+i*2,2,JUSTDIGITS,&success) ;
         SrecCheck += SrecBin[i] ;
      }

      /* Since I included the checksum in the running checksum, the answer    */
      /* with it should be 0xff.                                              */
      if ((!success) || (0xff != SrecCheck)) err = TFTPERR_BADSREC ;
   }

   /* For Debugging, show results */
#if 0
   if (err)
   {
      Console_printf("TFTP: S-Record formatting error.\n") ;
   }
   else
   {
      Console_printf("S%c Len %d Addr %8.8x Data: ",*SrecType,SrecLen,*SrecAddr) ;
      if ('0'==*SrecType)
      {
         SrecBin[*NumBytes] = 0 ;
         Console_printf("%s\n",SrecBin) ;
      }
      else
      {
         for (i=0;i<*NumBytes;i++)
         {
            Console_printf("%2.2x",SrecBin[i]) ;
         }
         Console_printf(" Check %2.2x\n",SrecBin[*NumBytes]) ;
      }
   }
#endif

   return(err) ;
}

/*******************************************************************************
* Routine  : SpinnyThing
* Gazintas : None
* IOs      : None
* Returns  : Nothing, can't fail!
* Globals  : None
*
* This is a callback routine that prints out a spinny thing to the console
* while flash is getting erased.  It gets called by the "wait" routine waiting
* for the flash to be erased.  This can take upwards of a minute for bigger
* flash that is fully programmed, so I need some kind of "I'm still alive"
* feedback.
*******************************************************************************/
static void SpinnyThing(void)
{
   static int  state      = 0       ; /* Spinny state */
   static char spinner[4] = "-\\|/" ; /* Spinny chars */

   Console_printf("\r%c",spinner[state]) ;
   state = (state+1)%4 ;
}

/*******************************************************************************
* Routine  : Update_Xmodem
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This routine downloads an S-Record file using the XMODEM/CRC protocol via the
* console interface instead of via TFTP.  The sequencing is as follows:
*  - Enter update xmodem on Voter2
*  - Erase the download flash
*  - After flash erased, tell user to start XMODEM transfer
*  - Voter2 starts sending 'C's (NAK is for checksum)
*  - Start file transfer on Host PC - it starts looking for NACK/'C's
*  - Host starts sending packets starting with Block #1 using CRC16.
*  - Voter2 responds with ACK (assuming good)
*  - Repeat two steps above with incrementing packet numbers (mod 256) until EOF
*  - Host sends EOT
* Transmission is complete.  Above is the happy path, there are lots of timeout
* and error conditions as well.
*
* NOTE: Unlike *all other code* in the Voter2, this routine uses the
* Consoleio_read() and Consoleio_write() functions instead of the regular
* string based Consoleio functions. While the file won't have anything binary in
* it, the protocol does *and* I need to bypass all the CR/LF fiddling the
* regular string functions have.
*
* NOTE2: Additionally, Telnet in ASCII mode (which I'm in) does some fiddling
* with control characters too, so no XMODEM over Telnet yet.  I suspect I can
* change Telnet to binary mode for the transfer then back to ASCII mode once
* done.  This is future work.
*
* NOTE3: Since this is using the console for a file transfer, I can't send any
* status/error messages to the console!  Hence lots of debug statements instead.
*******************************************************************************/
static void Update_Xmodem(void)
{
   /* These are in DMAable space as if using the UART, that is by DMA   */
   static IN_DMADD2 uint8_t rbuf[XMRBUFLEN] = {0} ; /* XMODEM Rx buffer */
   static IN_DMADD2 uint8_t tbuf[XMTBUFLEN] = {0} ; /* XMODEM Tx buffer */

   uint32_t StartTime = 0     ; /* Download time         */
   int      result    = 0     ; /* ConsoleIO call result */
   int      tries     = 0     ; /* Timeout tries counter */
   int      PktNum    = 1     ; /* Packet counter        */
   int      PktDelta  = 0     ; /* Packet delta          */
   int      Success   = true  ; /* Success accumulator   */
   int      Done      = false ; /* Done flag             */
   uint16_t crc       = 0     ; /* Packet CRC (local)    */
   int      i         = 0     ; /* General Counter       */
   int      BufLen    = 0     ; /* Buffer length         */

   SREC_STATS Stats = {0} ; /* S-Recrod parsing stats    */

   /* For now, abort if the user is using Telnet */
   if (CONSOLE_TELNET==ActiveConsole)
   {
      Console_puts("SORRY! XMODEM over Telnet isn't working yet, Telnet in ASCII mode\n"
                   "modifies data messing up Xmodem.  Working on it!\n") ;
      Success = false ;
      Done = true ;
   }

   if (Success)
   {
      /* If download mode, first erase the download flash */
      if (1) /* Save this in case I do verifies over XMODEM */
      {
         Console_printf("Erasing download flash, this can take up to %d seconds...\n",(SPINOR_MX25L3233==SPINOR_Type)?30:210) ;
       //Console_printf("JKLOL, debugging, so not doing it\n") ;
         SpiNor_erase(ERASE_ALL,0,SpinnyThing) ;
      }

      /* Erase complete, tell 'em next steps. */
      Console_puts("Voter2 ready! Please start the file transfer!\nYou may see Cs on the screen, that is OK.\nPress Control-D to abort.\n") ;

      /* Purge anything in the console input queue to start off clean.        */
      Consoleio_purge() ;

      StartTime = HAL_GetTick() ; /* Record the starting timestamp */

      /* Start Sending 'C's until we get an SOH, EOT or 10 10-second timeouts.*/
      /* C's is telling the host we want XMODEM CRC vs checksum packets.      */
      do
      {
         tbuf[0] = XMDM_CRC ;
         Consoleio_write(tbuf,1) ;
         Logger2_Msg(Logger.Xmodem,LOG_REGIO,LOG_TIME,"Xmodem: Ping...\r\n") ;
         result = Consoleio_read(rbuf,1,XMSTART_TIMEOUT) ;
         tries++ ;
      } while ((tries<XMSTART_TRIES)&&(result!=CONSOLEIO_FLAGS_DATA)) ;

      /* What's next depends on how we exited */
      if (result!=CONSOLEIO_FLAGS_DATA) /* If no data after 10 tries */
      {
         Logger2_Msg(Logger.Xmodem,LOG_MAJOR,LOG_TIME,"Xmodem: Host never responded, aborting.\r\n") ;
         Success = false ;
         Done = true ;
      }
      else if (ANSI_EOT==rbuf[0]) /* Got an abort */
      {
         Logger2_Msg(Logger.Xmodem,LOG_MAJOR,LOG_TIME,"Xmodem: Host or client sent an abort.\r\n") ;
         Success = false ;
         Done = true ;
      }
      else if (ANSI_SOH!=rbuf[0])
      {
         /* Only other legit reply is an SOH, so if not that, abort */
         Logger2_Msg(Logger.Xmodem,LOG_MAJOR,LOG_TIME,"Xmodem: Unexpected host data, aborting.\r\n") ;
         Success = false ;
         Done = true ;
      }
   }

   /* If none of the above errors happened, we failed to fail! Go! */
   if (Success)
   {
      /* Reset our Packet processor state */
      ProcessSrecPackets(NULL,128,PSP_RESET,false,&Stats) ;

      do /* per XMODEM packet */
      {
         /* We have the SOH of the packet already, go get the rest of the     */
         /* packet.                                                           */
         result = Consoleio_read(rbuf+1,XMRBUFLEN-1,XMXFER_TIMEOUT) ;

         /* If something other than requested data. Most likely a timeout */
         if (result!=CONSOLEIO_FLAGS_DATA)
         {
            Logger2_Msg(Logger.Xmodem,LOG_MAJOR,LOG_TIME,"Xmodem: Timeout getting host data. (%d), aborting.\r\n",result) ;
            Success = false ;
            Done = true ;
         }
         else /* We have data! */
         {
            /* Got a packet, start checking it. First check is CRC.           */
            /* The spec is vague on what bytes the CRC covers.  It is ONLY    */
            /* the data bytes, not SOH or packet numbers.                     */
            crc = xmodem_crc(rbuf+3,128) ;
            /* Some fancy bit fiddling to just look at the lower 8 bits.      */
            if ((rbuf[131]!=(0xff&(crc>>8))) || (rbuf[132]!=(0xff&(crc))))
            {
               Logger2_Msg(Logger.Xmodem,LOG_MAJOR,LOG_TIME,"Xmodem: CRC error (Pkt %d calc %4.4x host %2.2x%2.2x)\r\n",PktNum,crc,rbuf[131],rbuf[132]) ;
               Success = false ;
               Done = true ;
               /* Will send NACKs at the end */
            }
            /* See if its a new or duplicate packet with a good packet number.*/
            /* More fancy bit twiddling to only look at lower 8 bits of the   */
            /* packet number.                                                 */
            else if (((rbuf[1]==((PktNum-1)&0xff))||(rbuf[1]==((PktNum)&0xff)))&&((rbuf[2]&0xff)==((~rbuf[1])&0xff)))
            {
               if (rbuf[1]==((PktNum-1)&0xff))
               {
                  /* If a duplicate, just ignore the data and go on to the    */
                  /* ACK code common with good data.                          */
                  Logger2_Msg(Logger.Xmodem,LOG_REGIO,LOG_TIME,"Xmodem: Dup Pkt (%d)\r\n",PktNum) ;
               }
               else
               {
                  /* OK, we have a legit new data packet! Process it.          */
                  Logger2_Msg(Logger.Xmodem,LOG_REGIO,LOG_TIME,"Xmodem: Good Pkt (%d)\r\n",PktNum) ;
                  /* Since we're processing a text packet, search for EOFs to */
                  /* see if we are at the end of the file.                    */
                  /* This wouldn't work with a binary file, but this isn't a  */
                  /* binary file, so OK.                                      */
                  BufLen = 128 ;
                  for (i=127;i>=0;i--) if (ANSI_EOF==rbuf[i+3]) BufLen=i ;

                  /* Go parse for S-Record lines */
                  ProcessSrecPackets(rbuf+3,BufLen,PSP_PROGRAM,(BufLen!=128),&Stats) ;
                  Logger2_Msg(Logger.Xmodem,LOG_REGIO,LOG_TIME,"Xmodem: Intra Pkt (%d %d)\r\n",Stats.BytesProcessed,Stats.srec_dstidx,Stats) ;
                  PktDelta = 1 ;
               }

               /* This is the common ACK process whether it was a duplicate   */
               /* packet or a new data packet.  Send the ACK                  */
               tbuf[0] = ANSI_ACK ;
               Consoleio_write(tbuf,1) ;
               Logger2_Msg(Logger.Xmodem,LOG_REGIO,LOG_TIME,"Xmodem: Sent ACK (%d)\r\n",PktNum) ;

               /* ACK sent, now wait for the next byte from the host.  If an  */
               /* SOH, that is the first byte of the next packet, so loop on  */
               /* back.  If an EOT, then we are done.                         */
               result = Consoleio_read(rbuf,1,XMXFER_TIMEOUT) ;
               if (CONSOLEIO_FLAGS_DATA==result)
               {
                  if (ANSI_SOH==rbuf[0])
                     {
                        /* Nothing here other than a debug statement, loop    */
                        /* back to get the rest of the packet.                */
                        Logger2_Msg(Logger.Xmodem,LOG_REGIO,LOG_TIME,"Xmodem: SOH, another packet\r\n") ;
                     }
                  else if (ANSI_EOT==rbuf[0])
                     {
                        /* All done! Set flag to exit. */
                        Done = true ;
                        Logger2_Msg(Logger.Xmodem,LOG_REGIO,LOG_TIME,"Xmodem: EOT\r\n") ;
                     }
                  else
                  {
                     /* Anything other than SOH or EOT is an error */
                     Logger2_Msg(Logger.Xmodem,LOG_MAJOR,LOG_TIME,"Xmodem: Not SOH/EOT (%d)\r\n",PktNum) ;
                     Success = false ;
                     Done = true ;
                  }
               }
               else /* a timeout or something else bad.  Exit */
               {
                  Logger2_Msg(Logger.Xmodem,LOG_MAJOR,LOG_TIME,"Xmodem: Bad/No Pkt (%d %d)\r\n",PktNum,result) ;
                  Success = false ;
                  Done = true ;
               }
            }
            /* Else of header checking. If none of the above, probably a      */
            /* sequence error                                                 */
            else
            {
               Logger2_Msg(Logger.Xmodem,LOG_MAJOR,LOG_TIME,"Xmodem: Sequence error Pkt (%d 0x%2.2x 0x%2.2x)\r\n",PktNum,rbuf[1],rbuf[2]) ;
               Success = false ;
               Done = true ;
            }
         }

         /* All done reporting, increment packet count if it was a new packet */
         /* only.                                                             */
         PktNum += PktDelta ;
         PktDelta = 0 ;
      } while (!Done) ;
   }

   /* We end up here good or bad.  If bad, send some NAKs to make sure we     */
   /* abort any XMODEM transfers the host may be sending, then report the     */
   /* failure.                                                                */
   if (!Success)
   {
      tbuf[0] = ANSI_NAK ;
      tbuf[1] = ANSI_NAK ;
      Consoleio_write(tbuf,2) ;
      osDelay(200) ; /* Time for host to abort xfer */
      Console_puts("\nErrors downloading, aborting.\n") ;
      Logger2_Msg(Logger.Xmodem,LOG_REGIO,LOG_TIME,"Xmodem: Exit with errors\r\nREMINDER: IO logging breaks XMODEM timing!\r\n") ;
   }
   else
   {
      /* If success, send the  final ACK to the hosts EOT, wait a bit for it  */
      /* to get there and then report results.                                */
      tbuf[1] = ANSI_ACK;
      Consoleio_write(tbuf,1) ;
      osDelay(200) ; /* Time for host to abort xfer */
      Console_printf("\nDownload complete! %d XMODEM packets (%d bytes) received.\n",PktNum-1,(PktNum-1)*128) ;
      Logger2_Msg(Logger.Xmodem,LOG_REGIO,LOG_TIME,"Xmodem: Exit OK\r\n") ;
      Console_printf("%d bytes of flash processed (%d%% of flash) in %d seconds\n",
         Stats.BytesProcessed,Stats.BytesProcessed*100/((SPINOR_MX25L3233==SPINOR_Type)?4194304:33554432),
         (HAL_GetTick()-StartTime)/1000) ;
      Console_printf("\nTo program the image you just downloaded into executable flash,\n"
                     "enter 'download program' next.\n") ;
   }
}

/*******************************************************************************
* Routine  : xmodem_crc
*   Inputs : data - Data to compute the CRC of
*          : length - number of bytes to compute
*      IOs : None
*  Returns : 16-bit CRC
*  Globals : None
*
* This computes the CRC of the packet of data per the XMODEM spec.  It is a
* cut and paste from the spec, then just reformatted to my coding style.
* Not obvious from the spec is the CRC is over just the data bytes, not any of
* the header, so the length is always 128.
*******************************************************************************/
uint16_t xmodem_crc(const uint8_t *data, int length)
{
   int      i           = 0 ; /* Counter         */
   uint16_t crc         = 0 ; /* CRC accumulator */
   uint8_t  table_index = 0 ; /* CRC table index */

   for (i = 0; i < length; i++)
   {
      /* Index table using the top 8 bits of the CRC XORed with the input byte*/
      table_index = ((crc >> 8) ^ data[i]) & 0xFF;
      crc = (crc << 8) ^ xmodem_crc16_table[table_index];
   }
   return (crc) ;
}

/*******************************************************************************
* Routine  : ProcessSrecPackets
*   Inputs : packet - packet of S-Record data
*          : len - number of bytes in the packet
*          : mode - Download or verify mode (or reset)
*          : LastPacket - flag for last packet
*      IOs : Stats - S-Record parsing state
*  Returns : error flags
*  Globals : TBD
*
* This routine accepts fixed length packets of data containing S-Records and
* processes them to either program the download flash or verify the download
* flash matches. As S-Records are variable length and incoming packets are fixed
* length, this is very stateful!
*******************************************************************************/
static void ProcessSrecPackets(uint8_t* packet,int len,int mode,int LastPacket,SREC_STATS* Stats)
{
   static char SrecLine[MAXSRECLINE  ] = {0} ; /* S-record line */
   uint8_t     SrecBin [MAXSRECLINE/2] = {0} ; /* S-Record data */

   int      GotALine    = false ; /* Full, Valid line flag   */
   int      ParseError  = false ; /* Parsing error flag      */
   int      i           = 0     ; /* General counter         */
   int      srec_srcidx = 0     ; /* S-Record Src Copy index */
   int      SrecType    = 0     ; /* S-Record ID             */
   uint32_t SrecAddr    = 0     ; /* S-Record Address        */
   int      NumBytes    = 0     ; /* S-Record byte count     */


   /* If doing a reset, clear out all our state variables and exit */
   if (PSP_RESET==mode)
   {
      Stats->srec_dstidx    = 0 ;
      Stats->LineCount      = 0 ;
      Stats->BytesProcessed = 0 ;
      Stats->errors         = 0 ;
      return ;
   }

   do /* while not end of the packet */
   {
      /* Go see if we can pull a full line of text from the packet of data.   */
      /* If not, copy what there is and go get the next packet to continue.   */
      GotALine = GetTextLine((char*)packet,&srec_srcidx,len,LastPacket,SrecLine,&(Stats->srec_dstidx)) ;

      /* If we got a full line, process it */
      if (GotALine)
      {
         Logger2_Msg(Logger.Xmodem,LOG_REGIO,LOG_TIME,"Xmodem: SREC >%s<\r\n",SrecLine) ;
         Stats->LineCount++ ;

         /* Go parse the S-Record line */
         ParseError = ParseSrecLine(SrecLine,&SrecType,&SrecAddr,&NumBytes,SrecBin) ;

         /* Only care if no errors and S3 S-Record type.  Ignore   */
         /* S0 and S7 record types, no data in them.               */
         if ((!ParseError) && ('3'==SrecType))
         {
            /* Translate Target XIP flash memory address space to  */
            /* Download flash memory address space (and check for  */
            /* valid addressing too).                              */
            if ((SrecAddr>=0x08000000) && (SrecAddr+NumBytes<=0x0801ffff))
            {
               /* Map STM32 internal flash to end of SPI NOR */
               SrecAddr += 0x001e0000 ;
            }
            else if ((SrecAddr>=0x90000000) && (SrecAddr+NumBytes<=((SPINOR_MX25L3233==SPINOR_Type)?0x903fffff:0x91ffffff)))
            {
               /* Map QSPI NOR to start of SPI NOR */
               SrecAddr -= 0x90000000 ;
            }
            else
            {
               ParseError = TFTPERR_BADADDR ;
            }
         }

         /* If no errors, ready to program/verify SPI Flash!!! */
         if ((!ParseError) && ('3'==SrecType))
         {
            if (PSP_PROGRAM==mode)
            {
               /* Copy to DMA-able space, then program */
               memcpy(SpiBuf,SrecBin,NumBytes) ;
               SpiNor_write(SpiBuf,SrecAddr,NumBytes) ;
               Stats->BytesProcessed += NumBytes ;
            }
            else
            {
               SpiNor_read(SpiBuf,SrecAddr,NumBytes) ;
               for (i=0;i<NumBytes;i++) if (SpiBuf[i]!=SrecBin[i]) Stats->errors++ ;
               Stats->BytesProcessed += NumBytes ;
            }

#if 0 /* Needs to go, but put code in TFTP area before deleting */
            /* Report progress every second (usually)*/
            if (HAL_GetTick()>ReportTime)
            {
               Console_printf("%d bytes processed\r",BytesProcessed) ;
               ReportTime += REPORT_DELTA ;
            }
#endif
         }

         /* Finished handling that S-Record line, clean it up and go get the  */
         /* next S-Record line.                                               */
         Stats->srec_dstidx = 0 ;
         memset(SrecLine,0,MAXSRECLINE) ;

      }
   } while (GotALine && (!ParseError)) ; /* Keep getting lines until the buffer runs out */
}
