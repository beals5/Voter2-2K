#ifndef INC_TX_DSP_H_
#define INC_TX_DSP_H_

#define MAINBUF  0 /* Tx buffer main  channel */
#define DEBUGBUF 1 /* Tx buffer debug channel */

#define PROBE_AUDIO 0 /* Probe data is signed audio */
#define PROBE_RAW   1 /* Probe data is raw data     */

/* AddATONE mixer modes and formats */
#define TONE_BYPASS     0
#define TONE_REPLACE    1
#define TONE_ADD        2
#define TONE_MIX        3


typedef enum
{
   GENERAL_TIMED,
   GPS_TIMED,
   LOCAL_TIMED
} TIMING_TYPES ;

typedef struct
{
   uint32_t phase ;
   uint32_t freq ;
   uint8_t  level ;
   uint8_t  mix ;
} TONE_CONTEXT ;

extern uint32_t GlobDialTxBufDly ;
extern uint32_t GlobLocTxBufDly ;
extern uint8_t  Local_CTCSS_Enable ;
extern uint8_t  DIAL_GP_CTCSS_Enable ;
extern uint8_t  DIAL_GPS_CTCSS_Enable ;
extern uint16_t ProbeBuf[APKT_SAMPLES] ; /* Probe data buffer */
extern int      LocalOverride ;
extern TONE_CONTEXT TTone_Context ;

extern void Tx_ClearPacket(uint16_t*,int) ;
extern void Tx_DeqPacket(uint16_t*,uint32_t) ;
extern void Tx_EnqPacket(int16_t*,int,uint32_t,uint32_t) ;
extern void AddATone16s(int16_t*,int16_t*,TONE_CONTEXT*) ;
extern void AddATone12u(uint16_t*,uint16_t*,TONE_CONTEXT*) ;
extern void ProbeCheck(void*,int8_t,int) ;

#endif /* INC_TX_DSP_H_ */
