#ifndef INC_LOCALVOTER_LOCALSETTINGS_H_
#define INC_LOCALVOTER_LOCALSETTINGS_H_

#ifdef LOCALVOTER

typedef enum
{
   OFF_NONE = 0,
   OFF_SIM,
   OFF_TRIGGER,
   OFF_REPEATER
} OFFLINEMODE_ENUMS ;

typedef struct
{
   /* Offline settings                                         */
   uint16_t OffinePreCw      ; /* Offline Pre CW delay (ms)    */
   uint16_t OffinePostCw     ; /* Offline Post CW delay (ms)   */
   uint16_t OffineIdTime     ; /* Offline ID period (secs)     */
   uint16_t OffineHangTime   ; /* Offline Rx Hang time (ms)    */
   uint16_t OffineTxDly      ; /* Offline Tx buffer delay (ms) */
   uint8_t  OfflineMode      ; /* Offline mode                 */
   uint8_t  OffineCwSpd      ; /* Offline CW speed (WPM)       */
   uint8_t  OffineDeemph     ; /* Offline Rx De-emphasis (TF)  */
   uint8_t  OfflineCTCSS     ; /* Offline CTCSS enable         */

   char     OfflineID[SETTINGS_CWID_LEN]   ; /* Offline station ID */
   char     OfflineProc[SETTINGS_CWID_LEN] ; /* Offline Proceed ID */
} LOCALSETTINGS;

extern LOCALSETTINGS LocalSettings ;

void LocalSettingsInit (void) ;
void LocalSettingsRead (uint8_t,uint8_t*) ;
void LocalSettingsWrite(uint32_t*) ;
void LocalSettingsHelp(char*) ;

void SetLocal (int,char**) ;
void ShowLocal(void      ) ;

int Backup_Local(char*,int) ;

#endif /* LOCALVOTER */

#endif /* INC_LOCALVOTER_LOCALSETTINGS_H_ */
