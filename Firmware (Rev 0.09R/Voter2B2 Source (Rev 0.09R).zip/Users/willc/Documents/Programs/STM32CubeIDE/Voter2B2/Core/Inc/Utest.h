#ifndef INC_XUART_H_
#define INC_XUART_H_

extern char* cmd_utest_cmd   ;
extern char* cmd_utest_cmdsc ;
extern char* cmd_utest_help  ;

extern int  Cmd_utest(int, char**) ;

/* ISR callbacks */
extern void XUARTTxComplete(void) ;
extern void XUARTRxComplete(void) ;

#endif /* INC_XUART_H_ */
