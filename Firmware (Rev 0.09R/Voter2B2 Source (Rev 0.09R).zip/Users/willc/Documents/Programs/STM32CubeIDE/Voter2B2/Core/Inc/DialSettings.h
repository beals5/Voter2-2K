#ifndef INC_DIALSETTINGS_H_
#define INC_DIALSETTINGS_H_

#ifndef NODIALTASK

#define DIAL_INIT_FACTORY 0
#define DIAL_INIT_ATBOOT  1

typedef struct
{
   uint32_t Static_IP    ; /* DIAL Server IP (static)       */
   uint32_t TxBufDly     ; /* Transmit buffer delay (in ns) */
   uint16_t Unauth_Rate  ; /* Unauth mode xmit rate         */
   uint16_t VoterPort    ; /* Voter UDP Port number         */
   uint8_t  IPMode       ; /* DIAL server acquisition mode  */
   uint8_t  PacketTiming ; /* Packet timing mode            */
   uint8_t  Compression  ; /* Compression (MuLaw or ADPCM)  */
   uint8_t  CTCSSes      ; /* CTCSS modes                   */
   char     Voter_Challenge[SETTINGS_CHALLENGE_LEN] ; /* Voter challenge string */
   char     Voter_Password [SETTINGS_PASSWORD_LEN]  ; /* Voter Password         */
   char     Host_Password  [SETTINGS_PASSWORD_LEN]  ; /* Host Password          */
   char     fqdn           [SETTINGS_FQDN_LEN]      ; /* DIAL server FQDN       */
} DIALSETTINGS;

extern DIALSETTINGS DIALSettings ;

void DIALSettingsInit (int) ;
void DIALSettingsRead (uint8_t,uint8_t*) ;
void DIALSettingsWrite(uint32_t*) ;
void DialSettingsHelp(char*) ;

void SetDIAL (int,char**) ;
void ShowDIAL(void      ) ;

int Backup_DIAL(char*,int) ;

#endif /* NODIALTASK */

#endif /* INC_DIALSETTINGS_H_ */
