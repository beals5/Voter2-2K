ren Voter2B2.srec Voter2B2-0.09R.srec
del C:\OpenTFTPServer\Voter2B2-0.09R.srec
move Voter2B2-0.09R.srec C:\OpenTFTPServer