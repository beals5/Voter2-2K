#ifndef INC_SETSHOW_H_
#define INC_SETSHOW_H_

typedef enum
{
   PROBE_NONE = 0,
   PROBE_RXIN,
   PROBE_RXDEM,
   PROBE_RXVOICE,
   PROBE_TXSRC,
   PROBE_TXPL,
   PROBE_TXTONE,
   PROBE_TXOUT,
   PROBE_RSSSIG,
   PROBE_RSSLVL,
} PROBE_ENUMS ;

typedef enum
{
   CTCSS_670 = 0,
   CTCSS_719,
   CTCSS_744,
   CTCSS_770,
   CTCSS_797,
   CTCSS_825,
   CTCSS_854,
   CTCSS_885,
   CTCSS_915,
   CTCSS_948,
   CTCSS_974,
   CTCSS_1000,
   CTCSS_1035,
   CTCSS_1072,
   CTCSS_1109,
   CTCSS_1148,
   CTCSS_1188,
   CTCSS_1230,
   CTCSS_1273,
   CTCSS_1318,
   CTCSS_1365,
   CTCSS_1413,
   CTCSS_1462,
   CTCSS_1514,
   CTCSS_1567,
   CTCSS_1622,
   CTCSS_1679,
   CTCSS_1738,
   CTCSS_1799,
   CTCSS_1862,
   CTCSS_1928,
   CTCSS_2035,
   CTCSS_2107,
   CTCSS_2181,
   CTCSS_2257,
   CTCSS_2336,
   CTCSS_2418,
   CTCSS_2503
} CTCSS_ENUMS ;

extern char* cmd_set_cmd    ;
extern char* cmd_set_cmdsc  ;
extern char* cmd_show_cmd   ;
extern char* cmd_show_cmdsc ;
extern char* cmd_ss_help    ;

/* Parameter lists needed in other places */
extern TOKENLIST Booleans[]  ;
extern TOKENLIST GPS_Edges[] ;
extern TOKENLIST MyIPModes[] ;
extern TOKENLIST RxModes[]   ;
extern TOKENLIST RssiModes[] ;
extern TOKENLIST PLTones[]   ;
extern TOKENLIST RxLEDModes[] ;
extern uint8_t AnalogProbe ;

extern int  Cmd_set(int, char**) ;
extern int  Cmd_show(int, char**) ;
extern void SetShowHelp(char*,char*) ;

extern void SetNum   (char*,char*,int32_t,int32_t,int32_t* ) ;
extern void SetD6Num (char*,char*,int32_t,int32_t,int32_t* ) ;
extern void SetList  (char*,char*,uint8_t*,TOKENLIST*,int) ;
extern void SetOnOff (char*,char*,uint8_t* ) ;
extern void SetStr   (char*,char*,char*,int) ;
extern void SetIP    (char*,char*,uint32_t*) ;
extern void SetNot   (void                 ) ;
extern void ShowIP   (char*,uint32_t) ;

#endif /* INC_SETSHOW_H_ */
